using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Globalization;
using APPDEVDLL;
using System.Xml;
using System.Xml.XPath;
using System.IO;
using System.Collections.Specialized;
using System.Xml.Serialization;
using System.Collections;
using System.Collections.Generic;
using System.Data.OracleClient;

[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class AppDevService : System.Web.Services.WebService
{
    public AppDevService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }



    [WebMethod]
    public DataTable NewTransTagService(int bra_code, int cus_num, DateTime start_Date, DateTime end_Date)
    {
        DataTable ret_val = new DataTable("TransTagService");
        BASIS basis = new BASIS();
        ret_val = basis.NewGetTaggedTranx(bra_code, cus_num, start_Date, end_Date);
        return ret_val;
    }

    [WebMethod]
    public DataSet RetrieveOrangLocBranches(string status)
    {
        IRequest ireq = new IRequest();
        DataSet response = new DataSet();
        response = ireq.RetrieveOrangLocBranches(status);
        return response;
    }

    [WebMethod]
    public String OrangeLocBranchProfile(int branch, string userid, string status)
    {
        IRequest ireq = new IRequest();

        string response = ireq.OrangeLocBranchProfile(branch, userid, status);
        return response;
    }

    [WebMethod(Description = "Validates User Token. The response is an XML containing status code and description. Status 1000 is success")]
    public String ValidateUserToken(String userid, String tokenvalue, String purp, String chann) 
    {
        String ret_val = null;
        Token tk = new Token();
        ret_val = tk.ValidateToken(userid, tokenvalue, "USER", purp, chann);
       
        return ret_val;
    }

    [WebMethod(Description = "Validates staff Token. The response is an XML containing status code and description. Status 1000 is success")]
    public String ValidateAdminUserToken(String userid, String tokenvalue, String purp, String chann)
    {
        String ret_val = null;
        Token tk = new Token();
        ret_val = tk.ValidateToken(userid, tokenvalue, "ADMIN", purp, chann);

        return ret_val;
    }

    [WebMethod(Description = "Resets locked customers token. The response is an XML containing status code and description. Status 1000 is success")]
    public String ResetUserToken(String userid, String tokenvalue, String tokenID, String purp, String chann)
    {
        String ret_val = null;
        Token tk = new Token();
        ret_val = tk.ResetUserToken(userid, tokenvalue, tokenID, "USER", purp, chann);

        return ret_val;
    }

    [WebMethod(Description = "Resets locked staff token. The response is an XML containing status code and description. Status 1000 is success")]
    public String ResetAdminUserToken(String userid, String tokenvalue, String tokenID, String purp, String chann)
    {
        String ret_val = null;
        Token tk = new Token();
        ret_val = tk.ResetUserToken(userid, tokenvalue, tokenID, "ADMIN", purp, chann);

        return ret_val;
    }

    [WebMethod(Description = "Resets locked customer token one-off. The response is an XML containing status code and description. Status 1000 is success")]
    public String ResetUserToken_OneOff(String userid, String tokenID, String purp, String chann)
    {
        String ret_val = null;
        Token tk = new Token();
        ret_val = tk.ResetToken(userid, tokenID, "USER", purp, chann);

        return ret_val;
    }

    [WebMethod(Description = "Resets locked staff token one-off. The response is an XML containing status code and description. Status 1000 is success")]
    public String ResetAdminUserToken_OneOff(String userid, String tokenID, String purp, String chann)
    {
        String ret_val = null;
        Token tk = new Token();
        ret_val = tk.ResetToken(userid, tokenID, "ADMIN", purp, chann);

        return ret_val;
    }

    [WebMethod(Description = "Kill staff teller-id. The response is an XML containing status code and description. Status 1000 is success")]
    public String KillMyID(int bracode, int tellerid)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.KillMyID(bracode, tellerid);

        return ret_val;
    }

    [WebMethod(Description = "Kill staff teller-id. The response is an XML containing status code and description. Status 1000 is success")]
    public String KillMyID2(String userid)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.KillMyID2(userid);

        return ret_val;
    }

    [WebMethod(Description = "Kill staff teller-id. The response is an XML containing status code and description. Status 1000 is success")]
    public String KillMyID3(String userid, String branchcode)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.KillMyID3(userid, branchcode);

        return ret_val;
    }

    [WebMethod(Description = "Get account balance transaction date. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetAccountBalanceTrandate(String bracode, String cusnum)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetAccountBalanceTrandate(Convert.ToInt32(bracode), Convert.ToInt32(cusnum));

        return ret_val;
    }

    [WebMethod(Description = "Validate beneficiary account number. The response is an XML containing status code and description. Status 1000 is success")]
    public String ValidateBeneficiaryAccount(String userid, String benacctno, String type)
    {
        String ret_val = null;
        Eone eone = new Eone();
        if (type == "PRE")
            ret_val = eone.ValidateBeneficiaryAcct(userid, benacctno);
        else if(type =="ANY")
            ret_val = eone.ValidateAccountNuber(userid, benacctno);
        else
            ret_val = eone.ValidateAccountNuber(userid, benacctno);

        return ret_val;
    }

    [WebMethod(Description = "Validate staff user-id. The response is an XML containing status code and description. Status 1000 is success")]
    public String ValidateAdminUser(String userid, String password, int appid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.ValidateAdminUsr(userid, password, appid, "");

        return ret_val;
    }

    [WebMethod(Description = "Validate encrypted staff user-id. The response is an XML containing status code and description. Status 1000 is success")]
    public String ValidateEncryptedAdminUser(String userid, String password, String code, int appid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.ValidateAdminUsr(this.DecryptData(userid,code), this.DecryptData(password,code), appid, "");

        return ret_val;
    }

    [WebMethod(Description = "Off-site validation of staff user-id . The response is an XML containing status code and description. Status 1000 is success")]
    public String ValidateAdminUserOffSite(String userid, String password, int appid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.ValidateAdminUsrOffSite(userid, password, appid);

        return ret_val;
    }

    [WebMethod(Description = "Off-site validation of encrypted staff user-id . The response is an XML containing status code and description. Status 1000 is success")]
    public String ValidateEncryptedAdminUserOffSite(String userid, String password, string code, int appid)
    {
        EncryptLib2003.Encrypt enc2003 = new EncryptLib2003.Encrypt();
        Encryption encrypt = new Encryption();
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.ValidateAdminUsrOffSite(enc2003.Decrypt_TrpDes(userid), enc2003.Decrypt_TrpDes(password), appid);

        return ret_val;
    }

    [WebMethod(Description = "Validate staff user. The response is an XML containing status code and description. Status 1000 is success")]
    public String ValidateUser(String userid, String password)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.ValidateUser(userid, password);

        return ret_val;
    }

    [WebMethod(Description = "Get IVR turnover . The response is an XML containing status code and description. Status 1000 is success")]
    public String GetTurnover(String userid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetTurnover(userid);

        return ret_val;
    }

    [WebMethod(Description = "Get customer account balance . The response is an XML containing status code and description. Status 1000 is success")]
    public String GetAccountBalance(String bracode, String cusnum, String curcode, String ledcode, String subacctcode)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetAccountBalance(Convert.ToInt32(bracode), Convert.ToInt32(cusnum), Convert.ToInt32(curcode), Convert.ToInt32(ledcode), Convert.ToInt32(subacctcode));

        return ret_val;
    }

    [WebMethod(Description = "Get customer account name . The response is an XML containing status code and description. Status 1000 is success")]
    public String GetCustomerName(String bracode, String cusnum)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetCustomerName(Convert.ToInt32(bracode), Convert.ToInt32(cusnum));

        return ret_val;
    }

    [WebMethod(Description = "Get customer transaction details . The response is an XML containing status code and description. Status 1000 is success")]
    public String GetLastTransactionDetails(int bracode, int cusnum, int curcode, int ledcode, int subacctcode)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetLastTransactionDetails(bracode, cusnum, curcode, ledcode, subacctcode);

        return ret_val;
    }

    [WebMethod(Description = "Get customer last account statement. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetLastAccountStatement(int bracode, int cusnum, int curcode, int ledcode, int subacctcode, String custemail)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetLastAccountStatement(bracode, cusnum, curcode, ledcode, subacctcode, custemail);

        return ret_val;
    }

    [WebMethod(Description = "Request for customer cheque book. The response is an XML containing status code and description. Status 1000 is success")]
    public String RequestChequeBook(int bracode, int cusnum, int curcode, int ledcode, int subacctcode)
    {
        String ret_val = null;
        //Eone eone = new Eone();
        //ret_val = eone.ValidateUser(userid, password);

        return ret_val;
    }

    [WebMethod(Description = "Stop customer cheque. The response is an XML containing status code and description. Status 1000 is success")]
    public String StopCheque(int bracode, int cusnum, int curcode, int ledcode, int subacctcode, int start, int stop, String amount)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.StopCheque(bracode, cusnum, curcode, ledcode, subacctcode, start, stop, amount);
        return ret_val;
    }

    [WebMethod(Description = "Confirm cheque. The response is an XML containing status code and description. Status 1000 is success")]
    public String ConfirmCheque(String cust_acct_no, int docnum, Decimal amount)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.ConfirmCheque(cust_acct_no, docnum, amount);

        return ret_val;
    }

    [WebMethod(Description = "Confirm cheque. The response is an XML containing status code and description. Status 1000 is success")]
    public String ConfirmCheque2(String cust_acct_no, int docnum, Decimal amount, String ChequeDate, String BeneficiaryName, String Remarks)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.ConfirmCheque2(cust_acct_no, docnum, amount, ChequeDate, BeneficiaryName, Remarks);

        return ret_val;
    }

    //[WebMethod]
    //public String TransferFund(String Acct_fro, String Acct_to, Double Amount, String type, String channel, String Remarks)
    //{
    //    int transfercount = -1, blk_res = -1;
    //    String rescode;
    //    String ret_val = null;
    //    Eone eone = new Eone();
    //    Double str_amount = Convert.ToDouble(ConfigurationManager.AppSettings["FirstTimeLimit"].ToString());
    //    String blk_fund = ConfigurationManager.AppSettings["BlockFund"].ToString();

    //    try
    //    {
    //        if (channel == "IVR" && type == "ANY" && Amount > str_amount)
    //        {
    //            transfercount = eone.CheckBeneficiaryTransferLimit(Remarks, Acct_to);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        transfercount = -1;
    //    }

    //    ret_val = eone.TransferFunds(Acct_fro, Acct_to, Amount, type, channel, Remarks);
    //    rescode = GetResponseMsg(ret_val);
    //    //--------------------------Block First timer---------------------------------------------------------------------------

    //    String[] tempstr;
    //    if (rescode == "1000")
    //    {
    //        if (channel == "IVR" && type == "ANY" && Amount > str_amount && blk_fund == "YES")
    //        {
    //            if (transfercount == 0)
    //            {
    //                tempstr = Acct_to.Split('/');
    //                blk_res = eone.PostToBASIS_Block(Convert.ToInt32(tempstr[0]), Convert.ToInt32(tempstr[1]), Convert.ToInt32(tempstr[2]), Convert.ToInt32(tempstr[3]), Convert.ToInt32(tempstr[4]), Amount);
    //            }
    //        }
    //    }
    //    //----------------------------------------------------------------------------------------------------

    //    return ret_val;
    //}

    [WebMethod(Description = "Transfer fund. The response is an XML containing status code and description. Status 1000 is success")]
    public String TransferFund(String Acct_fro, String Acct_to, Double Amount, String type, String channel, String Remarks)
    {
        int transfercount = -1, blk_res = -1;
        int dailylimit = 1;
        String rescode;
        String ret_val = null;
        Eone eone = new Eone();
        Double str_amount = Convert.ToDouble(ConfigurationManager.AppSettings["FirstTimeLimit"].ToString());
        String blk_fund = ConfigurationManager.AppSettings["BlockFund"].ToString();


        if (channel == "IVR" && type == "ANY" && Amount > str_amount)
        {
            try
            {
                transfercount = eone.CheckBeneficiaryTransferLimit(Remarks, Acct_to);
            }
            catch (Exception ex)
            {
                transfercount = -1;
            }

            //Check daily limit
            try
            {
                String[] acct_array = Acct_to.Split('/');
                dailylimit = eone.CheckDailyLimit(Convert.ToInt64(Remarks), Amount, Convert.ToInt32(acct_array[3]));
            }
            catch (Exception ex)
            {
                dailylimit = 1;
            }

            if (dailylimit == 0)
            {
                ret_val = eone.TransferFunds(Acct_fro, Acct_to, Amount, type, channel, Remarks);
                rescode = GetResponseMsg(ret_val);

                //--------------------------Block First timer---------------------------------------------------------------------------

                String[] tempstr;
                if (rescode == "1000")
                {
                    if (blk_fund == "YES")
                    {
                        if (transfercount == 0)
                        {
                            tempstr = Acct_to.Split('/');
                            blk_res = eone.PostToBASIS_Block(Convert.ToInt32(tempstr[0]), Convert.ToInt32(tempstr[1]), Convert.ToInt32(tempstr[2]), Convert.ToInt32(tempstr[3]), Convert.ToInt32(tempstr[4]), Amount);
                        }
                    }
                }
                //----------------------------------------------------------------------------------------------------
            }
            else
            {
                String xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1004</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: daily balance limit exceeded.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                ret_val = xmlstring;
            }
        }
        else
        {
            ret_val = eone.TransferFunds(Acct_fro, Acct_to, Amount, type, channel, Remarks);
            rescode = GetResponseMsg(ret_val);
        }


        return ret_val;
    }

    [WebMethod(Description = "Transfer fund. The response is an XML containing status code and description. Status 1000 is success")]
    public String TransferFund2(String Acct_fro, String Acct_to, Double Amount, String type, int EXPL_CODE, String channel, String Remarks, int org_branch)
    {
        Eone eone = new Eone();
        String ret_val = null;

        ret_val = eone.TransferFunds2(Acct_fro, Acct_to, Amount, type, channel, EXPL_CODE, Remarks, org_branch);
        return ret_val;
    }

    //[WebMethod]
    //public String TransferFund2_NEFT(string Acct_from, string Acct_to, double Tra_amt, int Expl_code, string Remark, string docnum, int identifier, string VATAccount, string commacct, String channel)
    //{
    //    Eone eone = new Eone();
    //    String ret_val = null;

    //    ret_val = eone.TransferFunds2_OBT(Acct_from, Acct_to, Tra_amt, commacct, VATAccount, Expl_code, docnum, identifier, channel, Remark);
    //    return ret_val;
    //}

    [WebMethod(Description = "Transfer fund. The response is an XML containing status code and description. Status 1000 is success")]
    public String TransferFund_Prin_Comm_VAT(string Acct_from, string Acct_to, double Tra_amt, int Expl_code, string Remark, string Req_code, string docnum, int identifier, string VATAccount, string commacct, decimal comm, decimal vat, int commexpl, int vatexpl)
    {
        Eone eone = new Eone();
        String ret_val = null;

        ret_val = eone.PostToBasis_Prin_Comm_VAT(Acct_from, Acct_to, Tra_amt, Expl_code, Remark, Req_code, docnum, identifier, VATAccount, commacct, comm, vat, commexpl, vatexpl);
        return ret_val;
    }

    [WebMethod(Description = "Validation first time transfer limit. The response is an XML containing status code and description. Status 1000 is success")]
    public String CheckFirstTime(String userid, String Acct_to, Decimal Amount)
    {
        BASIS basis = new BASIS();
        int transfercount = 0;
        String ret_val = null;
        Eone eone = new Eone();
        Decimal str_amount = Convert.ToDecimal(ConfigurationManager.AppSettings["FirstTimeLimit"].ToString());
        String str_smsmess = "";
        String ben_acctno = "";
        String ben_acctname;
        String oldacctno = "";
        String customer_phone;
        String sms_response = "";

        try
        {
            if (Amount > str_amount)
            {
                //Parse Account, check for NUBAN
                Acct_to = Acct_to.Replace("/", "");
                if (Acct_to.Length == 10) //Validate NUBAN
                {
                    Converter cnv = new Converter(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
                    if (cnv.verifyNubanCheckDigit("058", Acct_to) == true)
                    {
                        oldacctno = cnv.ConvertToOldAccountNumber(Acct_to);
                        ben_acctno = oldacctno.Replace("/", "").Substring(0, 9);
                    }
                    else
                    {
                        ret_val = "<Response>";
                        ret_val = ret_val + "<CODE>1003</CODE>";
                        ret_val = ret_val + "<ERROR>FAILED</ERROR>";
                        ret_val = ret_val + "</Response>";
                        return ret_val;
                    }
                }
                else
                    ben_acctno = Acct_to;

                String retval = null;
                DataSet ds;
                DataTable dt_customer;
                DataTable dt_account;

                //Get beneficiary account details
                retval = basis.GetBasisCustomerDetails_NoSig(Convert.ToInt32(ben_acctno.Substring(0, 3)), Convert.ToInt32(ben_acctno.Substring(3, 6)));
                ds = ConvertXMLToDataSet(retval);
                dt_customer = ds.Tables["CUSTOMER"];
                dt_account = ds.Tables["ACCOUNT"];
                ben_acctname = dt_customer.Rows[0]["NAME"].ToString();

                transfercount = eone.CheckBeneficiaryTransferLimit(userid, Acct_to);
                if (transfercount == 0)
                {
                    //Get Customer's Phone number
                    retval = basis.GetBasisCustomerDetails_NoSig(Convert.ToInt32(userid.Substring(0, 3)), Convert.ToInt32(userid.Substring(3, 6)));
                    ds = ConvertXMLToDataSet(retval);
                    dt_customer = ds.Tables["CUSTOMER"];
                    dt_account = ds.Tables["ACCOUNT"];
                    customer_phone = dt_customer.Rows[0]["mobile_num"].ToString();

                    //Send alert
                    str_smsmess = "You have initiated a GTBank transfer of N" + Amount.ToString("N") + " To " + ben_acctname + ". Pls call GTConnect on 4480000 to stop unauthorize transfers. Always protect your token details";
                    sms_response = SendSMS(str_smsmess, customer_phone);

                    ret_val = "<Response>";
                    ret_val = ret_val + "<CODE>1000</CODE>";
                    ret_val = ret_val + "<MESSAGE>SUCCESS</MESSAGE>";
                    ret_val = ret_val + "</Response>";
                }
                else
                {
                    ret_val = "<Response>";
                    ret_val = ret_val + "<CODE>1000</CODE>";
                    ret_val = ret_val + "<MESSAGE>SUCCESS</MESSAGE>";
                    ret_val = ret_val + "</Response>";
                }
            }
            else
            {
                ret_val = "<Response>";
                ret_val = ret_val + "<CODE>1000</CODE>";
                ret_val = ret_val + "<MESSAGE>SUCCESS</MESSAGE>";
                ret_val = ret_val + "</Response>";
            }
        }
        catch (Exception ex)
        {
            ret_val = "<Response>";
            ret_val = ret_val + "<CODE>1003</CODE>";
            ret_val = ret_val + "<ERROR>FAILED: " + ex.Message.Replace("'", "") + "</ERROR>";
            ret_val = ret_val + "</Response>";
        }

        return ret_val;
    }

    [WebMethod(Description = "Transfer fund from one account to another(same currency). The response is an XML containing status code and description. Status 1000 is success")]
    public String Transfer(String Acct_fro, String Acct_to, Double Amount, int expl_code, String Remarks)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.Transfer(Acct_fro, Acct_to, Amount, expl_code, Remarks);

        return ret_val;
    }

    [WebMethod(Description = "Transfer fund from one account to another(different currency). The response is an XML containing status code and description. Status 1000 is success")]
    public String TransferFund_Cross(String Acct_fro, String Acct_to, Double Amount, Double rate, Double crossrate, String type, String channel, String Remarks)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.TransferFunds_Cross(Acct_fro, Acct_to, Amount, rate, crossrate, type, channel, Remarks);

        return ret_val;
    }

    [WebMethod(Description = "Transfer cheque from one account to another. The response is an XML containing status code and description. Status 1000 is success")]
    public String TransferCheques(String Acct_fro, String Acct_to, Double Amount, String type, String channel, String Remarks, String docnum, Int16 identifier, Int16 bankcode, Int16 days)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.TransferCheques(Acct_fro, Acct_to, Amount, type, channel, Remarks, docnum, identifier, bankcode, days);

        return ret_val;
    }

    [WebMethod(Description = "Transfer GTBank cheque from one account to another. The response is an XML containing status code and description. Status 1000 is success")]
    public String TransferGTBCheques(String Acct_fro, String Acct_to, Double Amount, String type, String channel, String Remarks, String docnum, Int16 identifier, Int16 bankcode, Int16 days)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.TransferGTBCheques(Acct_fro, Acct_to, Amount, type, channel, Remarks, docnum, identifier, bankcode, days);

        return ret_val;
    }

    [WebMethod(Description = "Send SMS. The response is a string containing SMSTicketID and MobileNO.")]
    public String SendSMS(String strmessage, String strMobNum)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.SendSMS(strmessage, strMobNum);
        return ret_val;
    }

    [WebMethod(Description = "Send Email. The response is an XML containing status code and description. Status Succeed is success")]
    public String SendEmail1(string sender, string recipient, string EmSuj, string EmMsg)
    {
        String ret_val = null;
        Email em = new Email();
        ret_val = em.SendEmail(sender, recipient, EmSuj, EmMsg);
        return ret_val;
    }

    [WebMethod(Description = "Send Email. The response is an XML containing status code and description. Status Succeed is success")]
    public String SendEmail2(string sender, string recipient, string EmSuj, string EmMsg, string copy)
    {
        String ret_val = null;
        Email em = new Email();
        ret_val = em.SendEmail(sender, recipient, EmSuj, EmMsg, copy);
        return ret_val;
    }

    [WebMethod(Description = "Send SMS. The response is a string containing SMSTicketID and MobileNO.")]
    public String SendSMS2(String strmessage, String strMobNum, String Application, String SenderName)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.SendSMS2(strmessage, strMobNum, Application, SenderName);
        return ret_val;
    }

    [WebMethod(Description = "Send Email. The response is an XML containing status code and description. Status Succeed is success")]
    public String SendEmail(String subject, String mailmessage, String emailfrom, String emailto, String CCopy, String attachment)
    {
        String ret_val = null;
        Email email = new Email();
        ret_val = email.SendEmail(emailfrom, emailto, subject, mailmessage, CCopy);

        return ret_val;
    }

    [WebMethod(Description = "Send HTML mail. The response is an XML containing status code and description. Status Succeed is success")]
    public String SendEmail_HTML(String subject, String mailmessage, String emailfrom, String emailto, String CCopy, String attachment)
    {
        String ret_val = null;
        Email email = new Email();
        ret_val = email.SendEmail_HTML(emailfrom, emailto, subject, mailmessage, CCopy);

        return ret_val;
    }

    [WebMethod(Description = "Reset user password. The response is an XML containing status code and description. Status 1000 is success")]
    public String ResetUserPasscode(String userid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.ResetUserPassword(userid);

        return ret_val;
    }

    [WebMethod]
    public String ResetUserPasscodeOther(String userid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.ResetUserPasswordOther(userid);

        return ret_val;
    }

    [WebMethod(Description = "Change user password. The response is an XML containing status code and description. Status 1000 is success")]
    public String ChangeUserPasscode(String userid, String pass)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.ChangeUserPassword(userid, pass);

        return ret_val;
    }

    [WebMethod(Description = "Change staff password. The response is an XML containing status code and description. Status 1000 is success")]
    public String ChangeAdminUserPasscode(String userid, String pswd)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.ChangeAdminUserPasscode(userid, pswd);

        return ret_val;
    }

    [WebMethod(Description = "Get role user for an application. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetApplicationRoleUsers(int roleid, int appid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetRoleUsers(roleid, appid);

        return ret_val;
    }

    [WebMethod(Description = "Get staff user name. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetAdminUserName(String uid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetAdminUserName(uid);

        return ret_val;
    }
    
    [WebMethod(Description = "Get customer detail. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetCustomerDetails(String userid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetCustomerDetails(userid);

        return ret_val;
    }

    [WebMethod(Description = "Validate account number. The response is an XML containing status code and description. Status 1000 is success")]
    public String ValidateAccount(String userid, String acctno)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.ValidateAccountNuber(userid, acctno);

        return ret_val;
    }

    [WebMethod(Description = "Validate basis account number. The response is an XML containing status code and description. Status 1000 is success")]
    public String ValidateBASISAccount(String acctno)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.ValidateBASISAccountNuber(acctno);

        return ret_val;
    }

    [WebMethod(Description = "Check if user id was flagged. The response is an XML containing status code and description. Status 1000 is success")]
    public String CheckUserFlag(String uid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.CheckUserFlag(uid);

        return ret_val;
    }

    [WebMethod(Description = "Check if batch run is on-going. The response is an XML containing status code and description. Status 1000 is success")]
    public String CheckBatchRun()
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.CheckBatchRun();

        return ret_val;
    }

    [WebMethod]
    public String ResetUserFlag(String uid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.ResetUserFlag(uid);

        return ret_val;
    }

    [WebMethod(Description = "Encryption of data with key. The response is a string containing the encrypted value")]
    public String EncryptData(String datavalue, String key)
    {
        String ret_val = null;
        Encryption enc = new Encryption();
        ret_val = enc.EncryptPIN(datavalue, key);

        return ret_val;
    }

    [WebMethod(Description = "Decryption of encrypted data with key. The response is a string containing the plain value")]
    public String DecryptData(String datavalue, String key)
    {
        String ret_val = null;
        Encryption enc = new Encryption();
        ret_val = enc.DecryptPIN(datavalue, key);

        return ret_val;
    }

    [WebMethod(Description = "Send CTI Message on IVR. The response is an XML containing status code and description. Status 1000 is success")]
    public String TransferCTI(String IVRINFO, String CHANID)
    {
        String ret_val = null;
        IVR ivr = new IVR();
        ret_val = ivr.SendCTIMessage(IVRINFO, CHANID);

        return ret_val;
    }

    [WebMethod]
    public String InitiatePopup(String customerno, String IVRINFO)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.InitiatePopup(customerno, IVRINFO);

        return ret_val;
    }

    [WebMethod(Description = "Get information on IVR. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetIVRINFO(String customerno)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetPopupInfo(customerno);

        return ret_val;
    }

    [WebMethod(Description = "Get information on IVR. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetIVRINFO2(String customerno)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetPopupInfo2(customerno);

        return ret_val;
    }

    [WebMethod(Description = "Delete IVR pop-up info. The response is an XML containing status code and description. Status 1000 is success")]
    public String DeleteIVRINFO(String customerno)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.DeletePopupInfo(customerno);

        return ret_val;
    }

    [WebMethod(Description = "Send CTI start message. The response is an XML containing status code and description. Status 1000 is success")]
    public String StartCTI(String CHANID)
    {
        String ret_val = null;
        IVR ivr = new IVR();
        ret_val = ivr.SendCTIStartMessage(CHANID);

        return ret_val;
    }

    [WebMethod(Description = "Log action performed by a user. The response is an XML containing status code and description. Status 1000 is success")]
    public String LogAdminUserAction(int AppID, String userid, long staffid, String Action)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.LogUserAction(AppID, userid, staffid, Action);

        return ret_val;
    }

    [WebMethod(Description = "Add a new staff user. The response is an XML containing status code and description. Status 1000 is success")]
    public String AddNewAdminUser(String UserID, int BASISID, String Username, String staffid, String password, int branch_code, String emailaddress, String roleid, String status)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.AddNewAdminUser(UserID, BASISID, Username, staffid, password, branch_code, emailaddress, roleid, status);

        return ret_val;
    }

    [WebMethod(Description = "Update staff user info. The response is an XML containing status code and description. Status 1000 is success")]
    public String UpdateAdminUser(String UserID, int BASISID, String Username, String staffid, int branch_code, String emailaddress, String roleid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.UpdateAdminUser(UserID, BASISID, Username, staffid, branch_code, emailaddress, roleid);

        return ret_val;
    }

    [WebMethod(Description = "Get staff user details. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetAdminUserDetails(String UserID)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetAdminUserDetails(UserID);

        return ret_val;
    }

    [WebMethod(Description = "Search for staff user on e-one. The response is an XML containing status code and description. Status 1000 is success")]
    public String SearchAdminUser(String str)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.SearchAdminUser(str);

        return ret_val;
    }

    [WebMethod(Description = "Get all menu roles. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetAllRoles()
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetAllRoles();

        return ret_val;
    }

    [WebMethod(Description = "Get all staff users. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetAllAdminUsers()
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetAllAdminUsers();

        return ret_val;
    }

    [WebMethod(Description = "Get all GtBank branches. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetAllBranches()
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetAllBranches();

        return ret_val;
    }

    [WebMethod(Description = "Activate staff user. The response is an XML containing status code and description. Status 1000 is success")]
    public String ActivateAdminUser(String userid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.ActivateAdminUser(userid);

        return ret_val;
    }

    [WebMethod(Description = "Deactivate staff user. The response is an XML containing status code and description. Status 1000 is success")]
    public String DeactivateAdminUser(String userid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.DeactivateAdminUser(userid);

        return ret_val;
    }

    [WebMethod(Description = "Get teller till account number. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetTellerTillAcct(String userid, int appid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetTellerTillAcct(userid, appid);

        return ret_val;
    }

    [WebMethod(Description = "Get branch info. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetBranchInfo(String bcode)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetBranchInfo(bcode);

        return ret_val;
    }

    [WebMethod(Description = "Get basis teller till account. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetBasisTellerTillAcct(String bracode, String tellerid, String currency)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetBasisTellerTillAcct(bracode, tellerid, currency);

        return ret_val;
    }

    [WebMethod(Description = "Get basis teller till account. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetBasisTellerTillAcct2(String username, String bracode, String currency)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetBasisTellerTillAcct2(username, bracode, currency);

        return ret_val;
    }

    [WebMethod(Description = "Get zone account number. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetZoneAcct(int branch_code, int appid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetZoneAcct(branch_code, appid);

        return ret_val;
    }

    [WebMethod(Description = "Get branch account. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetBranchAcct(String userid, int appid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetBranchAcct(userid, appid);

        return ret_val;
    }

    [WebMethod(Description = "Get branch IP address. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetBranchIPAddress(String bracode)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetBranchIPAddress(bracode);

        return ret_val;
    }

    [WebMethod(Description = "Get branch IP address. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetBranchIPAddress2(String userid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetBranchIPAddress2(userid);

        return ret_val;
    }

    [WebMethod(Description = "Get staff user branch IP address and location. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetAdminUserBranchIPAndLocation(String userid, String locationIP)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetUserBranchIPAndLocation(userid, locationIP);

        return ret_val;
    }

    [WebMethod(Description = "Get all basis roles. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetAllBasisRoles()
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.GetAllBasisRoles();

        return ret_val;
    }

    [WebMethod(Description = "Get basis customer details. The response is an XML containing status code and description. Status 1000 is success")]
    public CustDetRetVal GetBasisCustomerDetails(int branch_code, int Customer_no)
    {
        //String ret_val = null;
        CustDetRetVal ret_val;
        BASIS basis = new BASIS();
        ret_val = basis.GetBasisCustomerDetails(branch_code, Customer_no);

        return ret_val;
    }

    [WebMethod(Description = "Get all basis customer details. The response is an XML containing status code and description. Status 1000 is success")]
    public String GetAllBasisUsers()
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.GetAllBasisUsers();

        return ret_val;
    }

    [WebMethod(Description = "Get basis customer details. The response is an XML containing status code and description. Status 1000 is success")]
    public String AddEoneRole(String role_desc)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.AddAdminRole(role_desc);

        return ret_val;
    }

    [WebMethod(Description = "Get basis customer details. The response is an XML containing status code and description. Status 1000 is success")]
    public String AddBasisRole(String role_desc)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.AddBasisRole(role_desc);

        return ret_val;
    }

    [WebMethod(Description = "Add new teller. The response is an XML containing status code and description. Status 1000 is success")]
    public String AddNewTeller(int BASISID, String Username, String password, int branch_code, String roleid, String UpdateFlag)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.AddTeller(BASISID, Username, password, branch_code, roleid, UpdateFlag);

        return ret_val;
    }

    [WebMethod(Description = "Search basis user. The response is an XML containing status code and description. Status 1000 is success")]
    public String SearchBASISUser(String str, String branch_code)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.SearchBASISUser(str, branch_code);

        return ret_val;
    }

    [WebMethod(Description = "Check external transaction flag. The response is an XML containing status code and description. Status 1000 is success")]
    public String CheckExternalTransactionFlag(String ledgercode)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.GetExtTransFlagFromBASIS(ledgercode);

        return ret_val;
    }

    [WebMethod(Description = "Analyze fx and get fx details. The response is an XML containing status code and description. Status 1000 is success")]
    public String AnalyzeFx(String acctno, Decimal transfer_amt, DateTime anal_date)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.AnalyzeFx(acctno, transfer_amt, anal_date);

        return ret_val;
    }

    [WebMethod(Description = "Analyze fx and get fx details. The response is an XML containing status code and description. Status 1000 is success")]
    public String CheckDailyLimit_FUELCARD(String acctno)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.ChkLimitFuelCard(acctno);

        return ret_val;
    }

    //[WebMethod(Description = "Post collection data. The response is an XML containing status code and description. Status 1000 is success")]
    //public String PostCollectionData(int customer_id, int CollFormID, String userid, String postingbranchcode, Decimal tra_amt, String narration, String customer_acct, String pptno, String fname, String lname, String dob, String phoneno, String visa_cat, String cat_name, String emb_code, String emb_name)
    //{
    //    String ret_val = null;
    //    GTCollect collect = new GTCollect();
    //    ret_val = collect.PostCollectionData(customer_id, CollFormID, userid, postingbranchcode, tra_amt, narration, customer_acct, pptno, fname, lname, dob, phoneno, visa_cat, cat_name, emb_code, emb_name);
        
    //    return ret_val;
    //}

    //[WebMethod(Description = "Post collection data. The response is an XML containing status code and description. Status 1000 is success")]
    //public String PostCollectionData_new(int customer_id, int CollFormID, String coll_acct, String userid, String postingbranchcode, Decimal tra_amt, String paymentmode, String tellersuspacct, String customer_acct, String trans_type, int doc_num, String posref, String custom_receipt, String startdate_str, String enddate_str, int frequency, String postflag, DataSet dt_dset)
    //{
    //    String ret_val = null;
    //    GTCollect collect = new GTCollect();
    //    ret_val = collect.PostCollectionData2(customer_id, CollFormID, coll_acct, userid, postingbranchcode, tra_amt, customer_acct, tellersuspacct, paymentmode, trans_type, doc_num, posref, custom_receipt, postflag, startdate_str, enddate_str, frequency, dt_dset);

    //    return ret_val;
    //}

    //[WebMethod(Description = "Update collection data. The response is an XML containing status code and description. Status 1000 is success")]
    //public String UpdateCollectionData(decimal transactionid, String transreference)
    //{
    //    String ret_val = null;
    //    GTCollect collect = new GTCollect();
    //    ret_val = collect.UpdateCollectionData(transactionid, transreference);

    //    return ret_val;
    //}

    [WebMethod(Description = "Hot-list card. The response is an XML containing status code and description. Status 1000 is success")]
    public int HotlistCard(string pPAN, long pCustomerID, string pExpiry, string pSeqNo, int pResponseCode)
    {
        string pan = GTBSecure.Secure.DecryptString(pPAN);
        int ret_val = 0;
        Eone eone = new Eone();
        ret_val = eone.HotlistCard(pan, pCustomerID, pExpiry, pSeqNo, pResponseCode);

        return ret_val;
    }

    [WebMethod]
    public String HotlistCard_ivr(String pPAN, String pCustomerID, String pExpiry, int hotlistReason)
    {
        //string pan = GTBSecure.Secure.DecryptString(pPAN);
        string ret_val = string.Empty;
        Eone eone = new Eone();
        ret_val = eone.HotlistCard_ivr(pPAN, pCustomerID, pExpiry, hotlistReason);

        return ret_val;
    }

    [WebMethod(Description = "Get card status. The response is an XML containing status code and description. Status 1000 is success")]
    public string GetCardStatus(string pPAN, string pCustomerID, string pExpiry, string pSeqNo)
    {
     //   string pan = GTBSecure.Secure.DecryptString(pPAN);
        string  ret_val = string.Empty;
        Eone eone = new Eone();
        ret_val = eone.GetCardStatus(pExpiry, pPAN, pSeqNo, pCustomerID);//.HotlistCard(pan, pCustomerID, pExpiry, pSeqNo, pResponseCode);

        return ret_val;
    }

    //[WebMethod(Description = "Get GTcollection list of values. The response is an XML containing status code and description. Status 1000 is success")]
    //public String GetCollectionListOfValues(int lov_ID)
    //{
    //    String ret_val = null;
    //    GTCollect collect = new GTCollect();
    //    ret_val = collect.GetCollectionListOfValues(lov_ID);

    //    return ret_val;
    //}

    //[WebMethod(Description = "Get GTcollection list of values. The response is an XML containing status code and description. Status 1000 is success")]
    //public DataTable GetCollectionListOfValues2(int lov_ID)
    //{
    //    DataTable ret_val = new DataTable();
    //    GTCollect collect = new GTCollect();
    //    ret_val = collect.GetCollectionListOfValues2(lov_ID);
    //    ret_val.TableName = "LOVDETAILS";
    //    return ret_val;
    //}

    //[WebMethod(Description = "Get GTcollection list of values. The response is an XML containing status code and description. Status 1000 is success")]
    //public String GetCollectionListOfValueData(int lov_ID, String value)
    //{
    //    String ret_val = null;
    //    GTCollect collect = new GTCollect();
    //    ret_val = collect.GetCollectionListOfValuesData(lov_ID, value);

    //    return ret_val;
    //}

    //[WebMethod(Description = "Get GTcollection details. The response is an XML containing status code and description. Status 1000 is success")]
    //public DataSet GetCollectionDetails()
    //{
    //    GTCollect collect = new GTCollect();
    //    DataSet ds = collect.GetCollectionDetails_US();

    //    return ds;
    //}

    [WebMethod(Description = "Initial standing instruction. The response is an XML containing status code and description. Status 1000 is success")]
    public String InitiateStandingInstruction(String acctno, int pFreq, DateTime p1stPayDate, Decimal Amount, DateTime pLastPayDate, String pAcctToCredit, String pRemarks)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.InitiateStandingInstruction(acctno, pFreq, p1stPayDate, Amount, pLastPayDate, pAcctToCredit, pRemarks);

        return ret_val;
    }

    [WebMethod(Description = "Initiate standing instruction. The response is an XML containing status code and description. Status 1000 is success")]
    public String InitiateStandingInstruction2(String acctno, int pFreq, String p1stPayDate, Decimal Amount, String pLastPayDate, String pAcctToCredit, String pRemarks)
    {
        String ret_val = null;
        Eone eone = new Eone();
        DateTime dt_st = new DateTime(Convert.ToInt32(p1stPayDate.Substring(4, 4)), Convert.ToInt32(p1stPayDate.Substring(2, 2)), Convert.ToInt32(p1stPayDate.Substring(0, 2)));
        DateTime dt_t = new DateTime(Convert.ToInt32(pLastPayDate.Substring(4, 4)), Convert.ToInt32(pLastPayDate.Substring(2, 2)), Convert.ToInt32(pLastPayDate.Substring(0, 2)));

        ret_val = eone.InitiateStandingInstruction(acctno, pFreq, dt_st, Amount, dt_t, pAcctToCredit, pRemarks);

        return ret_val;
    }

    [WebMethod(Description = "Initiate standing instruction charge. The response is an XML containing status code and description. Status 1000 is success")]
    public String InitiateStandingInstruction_Charge(String acctno, int pFreq, String p1stPayDate, Decimal Amount, String pLastPayDate, String pAcctToCredit, String pRemarks)
    {
        String ret_val = null;
        Eone eone = new Eone();
        DateTime dt_st = new DateTime(Convert.ToInt32(p1stPayDate.Substring(4, 4)), Convert.ToInt32(p1stPayDate.Substring(2, 2)), Convert.ToInt32(p1stPayDate.Substring(0, 2)));
        DateTime dt_t = new DateTime(Convert.ToInt32(pLastPayDate.Substring(4, 4)), Convert.ToInt32(pLastPayDate.Substring(2, 2)), Convert.ToInt32(pLastPayDate.Substring(0, 2)));

        ret_val = eone.InitiateStandingInstruction_Charge(acctno, pFreq, dt_st, Amount, dt_t, pAcctToCredit, pRemarks);

        return ret_val;
    }

    [WebMethod(Description = "Cancel standing instruction. The response is an XML containing status code and description. Status 1000 is success")]
    public String CancelStandingInstruction(String acctno, int pSeq)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.CancelStandingInstruction(acctno, pSeq);

        return ret_val;
    }

    [WebMethod(Description = "Get standing instruction from basis. The response is an XML containing status code and description. Status 1000 is success")]
    public DataSet GetStandingInstructionFromBASIS(String debit_acctno, String doc_num, String cred_acct, Decimal amt)
    {
        DataSet ret_val;
        BASIS basis = new BASIS();
        ret_val = basis.GetStandInsFromBASIS(debit_acctno, doc_num, cred_acct, amt);

        return ret_val;
    }

    [WebMethod(Description = "Get standing instruction from basis. The response is an XML containing status code and description. Status 1000 is success")]
    public DataSet GetStandingInstructionFromBASIS2(String debit_acctno, String doc_num, String cred_acct, Decimal amt, int basisseq)
    {
        DataSet ret_val;
        BASIS basis = new BASIS();
        ret_val = basis.GetStandInsFromBASIS2(debit_acctno, doc_num, cred_acct, amt, basisseq);

        return ret_val;
    }

    //[WebMethod(Description = "Get GTcollection categories. The response is an XML containing status code and description. Status 1000 is success")]
    //public DataSet GetCollectionCategtories()
    //{
    //    GTCollect collect = new GTCollect();
    //    DataSet ds = collect.GetCollectionCategtories();

    //    return ds;
    //}

    //[WebMethod(Description = "Get GTcollection forms by category. The response is an XML containing status code and description. Status 1000 is success")]
    //public DataSet GetCollectionFormsByCategory(int catid)
    //{
    //    GTCollect collect = new GTCollect();
    //    DataSet ds = collect.GetCollectionFormsByCategory(catid);
    //    //ds.TableName = "COLLFORM";

    //    return ds;
    //}

    //[WebMethod(Description = "Get GTcollection customer. The response is an XML containing status code and description. Status 1000 is success")]
    //public DataSet GetCollectionCustomers()
    //{
    //    GTCollect collect = new GTCollect();
    //    DataSet ds = collect.GetCollectionCustomers();

    //    return ds;
    //}

    //[WebMethod(Description = "Get GTcollection forms by customerID. The response is an XML containing status code and description. Status 1000 is success")]
    //public DataSet GetCollectionForms(int custid)
    //{
    //    GTCollect collect = new GTCollect();
    //    DataSet ds = new DataSet();
    //    ds.Tables.Add(collect.GetCollectionForms(custid));

    //    return ds;
    //}

    //[WebMethod(Description = "Get GTcollection form by formID. The response is an XML containing status code and description. Status 1000 is success")]
    //public DataSet GetCollectionFormByID(int formid)
    //{
    //    GTCollect collect = new GTCollect();
    //    DataSet ds = new DataSet();
    //    ds.Tables.Add(collect.GetCollectionFormByID(formid));

    //    return ds;
    //}

    //[WebMethod(Description = "Get cGTollection charges. The response is an XML containing status code and description. Status 1000 is success")]
    //public DataSet GetCollectionCharges(int form_ID)
    //{
    //    DataSet dt;
    //    GTCollect collect = new GTCollect();
    //    dt = collect.GetCollectionCharges(form_ID);

    //    return dt;
    //}

    //[WebMethod(Description = "Get GTcollection form fields. The response is an XML containing status code and description. Status 1000 is success")]
    //public DataSet GetCollectionFormFields(int formid)
    //{
    //    GTCollect collect = new GTCollect();
    //    DataSet ds = collect.GetCollectionFormFields(formid);

    //    return ds;
    //}

    
    //public DataSet GetCollectionFormFieldDetails(int customerid, int formid, DataSet dt_fieldset)
    //{
    //    GTCollect collect = new GTCollect();
    //    DataSet ds = collect.GetCollectionFormFieldDetails(customerid, formid, dt_fieldset);

    //    return ds;
    //}

    
    //public DataSet GetCollectionTransactionsByUser(int formid, String userID)
    //{
    //    GTCollect collect = new GTCollect();
    //    //DataSet ds = collect.GetCollectionFormFieldDetails(customerid, formid, dt_fieldset);
    //    DataSet ds = collect.GetTransactionHistoryByUser(formid, userID);

    //    return ds;
    //}

    //[WebMethod(Description = "Update GTcollection GTPay Transaction. The response is an XML containing status code and description. Status 1000 is success")]
    //public int UpdateGTCollectionGTPayTransaction(int transid, String transstatus, String message)
    //{
    //    GTCollect collect = new GTCollect();

    //    int ds = collect.UpdateTransaction(Convert.ToDecimal(transid), transstatus, message);

    //    return ds;
    //}

    [WebMethod(Description = "Get authorization limit. The response is an XML containing status code and description. Status 1000 is success")]
    public Decimal GetAuthorizationLimit(String adminuserid)
    {
        BASIS basis = new BASIS();
        Decimal ds = basis.GetAuthorizationLimit(adminuserid);

        return ds;
    }

    [WebMethod(Description = "Retrieve card pin. The response is an XML containing status code and description. Status 1000 is success")]
    public String RetrieveCardPIN(String userid, String PANDigits, String CardExpiry)
    {
        String ret_val; // = "<Response><CODE>1000</CODE><PIN>1234</PIN><MESSAGE>SUCCESS</MESSAGE></Response>";

        Eone eone = new Eone();
        ret_val = eone.RetrieveCustomerCardPIN(userid, PANDigits, CardExpiry);

        return ret_val;
    }

    [WebMethod(Description = "Send email to new IBank user. The response is an XML containing status code and description. Status 1000 is success")]
    public String SendEmailToNewIbankUser(long userid)
    {
        Eone eone = new Eone();
        String sendmail = eone.SendHtmlMessageToUser(userid);

        return sendmail;
    }

    [WebMethod(Description = "Generate MT940 statement. The response is an XML containing status code and description. Status 1000 is success")]
    public byte[] GenerateMT940Statement(int custid, String accountNumber, String startdate, String enddate)
    {
        String Day = DateTime.Now.ToString("dd-MM-yy", CultureInfo.CreateSpecificCulture("en-GB"));
        String Today = DateTime.Now.ToString("yyyy-MM-dd", CultureInfo.CreateSpecificCulture("en-GB"));

        string filePath = ConfigurationManager.AppSettings["workarea"].ToString() + "\\ftpfiles\\" + Day;
        SqlConnection conn;
        SqlCommand comm;
        DataTable ds_cust, ds;
        SqlDataAdapter adpt;
        String sqlstr_cust = null, sqlstr = null;
        int StmtNo = 0;
        string output = "";
        String freqdesc = String.Empty;

        DateTime dt_start, dt_end;

        //get customers info
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MT940_Conn"].ToString());

        //open connetion
        if (conn.State != ConnectionState.Open)
        {
            conn.Open();
        }

        dt_start = DateTime.ParseExact(startdate, "ddMMyyyy", CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces);
        dt_end = DateTime.ParseExact(enddate, "ddMMyyyy", CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces);

        sqlstr_cust = "select * from customers where id = " + custid.ToString();

        comm = new SqlCommand(sqlstr_cust, conn);
        comm.CommandType = CommandType.Text;
        adpt = new SqlDataAdapter(comm);
        ds_cust = new DataTable();
        adpt.Fill(ds_cust);

        if (ds_cust.Rows.Count > 0)
        {
            foreach (DataRow dr_cust in ds_cust.Rows)
            {
                //if (dr_cust["active"].ToString() == "1")
                //{
                    sqlstr = "select * from account where customerid = " + dr_cust["id"].ToString() + " and AccountNumber = '" + accountNumber + "'";
                    comm = new SqlCommand(sqlstr, conn);
                    comm.CommandType = CommandType.Text;
                    adpt = new SqlDataAdapter(comm);
                    ds = new DataTable();
                    adpt.Fill(ds);

                    MT940 gn = null;
                    //foreach (DataRow dr in ds.Rows)
                    if(ds.Rows.Count > 0)
                    {
                        DataRow dr = ds.Rows[0];
                        StmtNo = Convert.ToInt32(dr["StmtNo"]);
                        StmtNo = StmtNo + 1;
                        gn = new MT940(dr_cust, dr, dt_start, dt_end);
                        gn.GetBasisTransactions(dr_cust, dr);
                        output = gn.Generate940_Full(dr_cust, dr, StmtNo);

                        //Update statement number
                        if (gn != null)
                            gn.UpdateStatementNo(Convert.ToInt32(dr["AccountID"]), StmtNo, Convert.ToDecimal(dr["last_balance"]));
                   }
            }
        }

        conn.Close();
        conn = null;

        byte[] image = null;
        if (output != "")
        {
            try
            {
                FileInfo file = new FileInfo(output);

                FileStream fs = new FileStream(output, FileMode.Open, FileAccess.Read);

                BinaryReader br = new BinaryReader(fs);

                image = br.ReadBytes((int)fs.Length);

                br.Close();

                fs.Close();
            }
            catch (Exception ex)
            {
                //ErrHandler.LogError("An error " + ex.Message + " has occured");
                //return null;
            }

        }

        return image;
    }

    [WebMethod(Description = "Convert XML to dataset. The response is an XML containing status code and description. Status 1000 is success")]
    private DataSet ConvertXMLToDataSet(string xmlData)
    {
        StringReader stream = null;
        XmlTextReader reader = null;
        try
        {
            DataSet xmlDS = new DataSet();
            stream = new StringReader(xmlData);
            // Load the XmlTextReader from the stream
            reader = new XmlTextReader(stream);
            xmlDS.ReadXml(reader);
            return xmlDS;
        }
        catch
        {
            return null;
        }
        finally
        {
            if (reader != null) reader.Close();
        }
    }

    [WebMethod(Description = "Get response message. The response is an XML containing status code and description. Status 1000 is success")]
    private String GetResponseMsg(String resp)
    {
        XmlDocument document = null;
        XPathNavigator navigator = null;
        XPathNodeIterator snodes = null;
        XPathNavigator node1 = null;
        String retcode = null;

        document = new XmlDocument();
        document.LoadXml(resp);
        navigator = document.CreateNavigator();

        snodes = navigator.Select("/Response/CODE");
        snodes.MoveNext();
        return snodes.Current.Value;
    }

    //Added by Mayowa Ogundele on  21/02/2014
    //This webmethod enables the placing of Standing Instruction From E-Tracker
    [WebMethod(Description = "Initiate Standing Instruction For SMS Charge. The response is an XML containing status code and description. Status 1000 is success")]
    public String InitateStandingInstructionForSMSCharge(string xmlRequest)
    {
        BASIS basis = new BASIS();
       string response =  basis.InitaiteStandingInstructionForSMSCharge(xmlRequest);
     return response;
      
    }

    [WebMethod(Description = "Cancel BASIS Posting Request. The response is an XML containing status code and description. Status 1000 is success")]
    public string CancellationRequest(string OrigbraCode, string tellerId, string origttraseq1, string applicationid, string tellerbracode, string cancelreason)
    {
        string ret_val = "";
        BASIS tranx = new BASIS();
        ret_val = tranx.CancellationRequest(OrigbraCode, tellerId, origttraseq1, applicationid, tellerbracode, cancelreason);
        return ret_val;
    }

    [WebMethod(Description = "Get Customer Opportunity Advert Text. The response is an XML containing status code and description. Status 1000 is success")]
    public string GetCustomerOpportunity(int braCode, int cusnum)
    {
        string ret_val = "";
        Eone tranx = new Eone();
        ret_val = tranx.GetCustomerOpportunity(braCode, cusnum);
        return ret_val;
    }

    [WebMethod(Description = "Initiate IRefer. The response is an XML containing status code and description. Status 1000 is success")]
    public string InitiateIRefer(int braCode, int cusnum, String Referred_name, String Referred_mobileno, String Referred_email, String Channel, String initiator, String nubannumber)
    {
        string ret_val = "";
        Eone tranx = new Eone();
        ret_val = tranx.InitiateIRefer(braCode, cusnum, Referred_name, Referred_mobileno, Referred_email, Channel, initiator, nubannumber);
        return ret_val;
    }

    [WebMethod(Description = "Update IRefer. The response is an XML containing status code and description. Status 1000 is success")]
    public string UpdateIRefer2(long refcode, String updatedby)
    {
        string ret_val = "";
        Eone tranx = new Eone();
        ret_val = tranx.UpdateIRefer(refcode, updatedby);
        return ret_val;
    }

    [WebMethod(Description = "Update IRefer. The response is an XML containing status code and description. Status 1000 is success")]
    public string UpdateIRefer(long refcode, String updatedby)
    {
        string ret_val = "";
        Eone tranx = new Eone();
        ret_val = tranx.UpdateIRefer2(refcode, updatedby);
        return ret_val;
    }

    [WebMethod(Description = "Get Blocked Funds. The response is an XML containing status code and description. Status 1000 is success")]
    public DataTable GetBlockedFunds(string bra_code, string cus_num)
    {
        DataTable returnDataTable = new DataTable();
        Eone tranx = new Eone();
        returnDataTable = tranx.BlockedFunds(bra_code, cus_num);
        return returnDataTable;
    }

    [WebMethod]
    public DataTable GetBasisBlockedFunds(string bra_code, string cus_num)
    {
        DataTable returnDataTable = new DataTable();
        Eone tranx = new Eone();
        returnDataTable = tranx.BasisBlockFund(bra_code, cus_num);
        return returnDataTable;
    }

    [WebMethod]
    public DataTable GetBlockedFundsSTAN(string bra_code, string cus_num)
    {
        DataTable returnDataTable = new DataTable();
        Eone tranx = new Eone();
        returnDataTable = tranx.BlockedFundsSTAN(bra_code, cus_num);
        return returnDataTable;
    }

    [WebMethod(Description = "Dispense Error Main. The response is an XML containing status code and description. Status 1000 is success")]
    public string DispenseErrorMain(int branchCode, int origbraCode, int cusNum, int curCode, int ledCode, int subacctCode, decimal tranAmount, decimal amtDispensed, string PAN, string STAN, string bankNam, string transacDate, string merchant, string userID, string smartCardNo, string phoneNo, string network, string declineReason, string errorType, string GTBATMLocation, string ATMBranchCode, string benePhoneNo, string beneAcctNo, string refID, string ticks)
    {
        string result = null;
        DispenseError disErr = new DispenseError();
        result = disErr.SubmitSingle(branchCode, origbraCode, cusNum, curCode, ledCode, subacctCode, tranAmount, amtDispensed, PAN, STAN, bankNam, transacDate, merchant, userID, smartCardNo, phoneNo, network, declineReason, errorType, GTBATMLocation, ATMBranchCode, benePhoneNo, beneAcctNo, refID, ticks);
        return result;
    }

    [WebMethod(Description = "Book GTAppointment. The response is an XML containing status code and description. Status 1000 is success")]
    public string GTCheckIn_Book(string userID, string cusName, string acctNum, string transType, int branchCode, string appointmentDate, string phoneNo, string eMail, string timeSlot, string Medium, string Additional_Request)
    {
        string result = null;
        GTCheckIn gtcheck = new GTCheckIn();
        result = gtcheck.BookAppointment(userID, cusName, acctNum, transType, branchCode, Convert.ToDateTime(appointmentDate), phoneNo, eMail, timeSlot, Medium, Additional_Request );
        return result;
    }

    [WebMethod(Description = "Cancel GTAppointment. The response is an XML containing status code and description. Status 1000 is success")]
    public string GTCheckIn_Cancel(string userID,  string refNO)
    {
        string result = null;
        GTCheckIn gtcheck = new GTCheckIn();
        result = gtcheck.CancelAppointment(userID, refNO);
        return result;
    }

    [WebMethod(Description = "Reject GTAppointment. The response is an XML containing status code and description. Status 1000 is success")]
    public string GTCheckIn_Reject(string userID, string refNo, string rejectedBy, string rejectedReason)
    {
        string result = null;
        GTCheckIn gtcheck = new GTCheckIn();
        result = gtcheck.RejectAppointment(userID, refNo, rejectedBy, rejectedReason);
        return result;
    }

    [WebMethod(Description = "For tracking the request of customers . The response is an XML containing status code and description. Status 1000 is success")]
    public DataTable GTTrackIt(string trackID, string requestType, string dateFrom, string dateTo)
    {
        DataTable result = new DataTable();
        GTTrack_IT trac = new GTTrack_IT();
        result = trac.TrackIt(trackID, requestType, dateFrom, dateTo);
        return result;
    }

    [WebMethod(Description = "NUBAN To Old Account Number. The response is an XML containing status code and description. Status 1000 is success")]
    public string NubanToOldAccountNumber(string NubanAccountNumber)
    {
        string result = null;
        BASIS callBasis = new BASIS();
        result = callBasis.NubanToOldAcct(NubanAccountNumber);
        return result;
    }

    [WebMethod(Description = "List of holidays on basis. The response is an XML containing status code and description. Status 1000 is success")]
    public DataTable Holidays()
    {
        DataTable result = null;
        GTCheckIn gtcheck = new GTCheckIn();
        result = gtcheck.Holidays();
        return result;
    }

    [WebMethod(Description = "Send SMS via Lubred. The response is an XML containing status code and description. Status 1000 is success")]
    public string SendSMSLubred(string mobileNum, string message, string ApplicationName)
    {
        string ret_val = "";
        Eone tranx = new Eone();
        ret_val = tranx.SendSMSLubred(mobileNum, message, ApplicationName);
        return ret_val;
    }

    [WebMethod(Description = "Initiate Account Update Request. The response is an XML containing status code and description. Status 1000 is success")]
    public String InitiateAccountUpdateRequest(string RequestType, string FirstName, string LastName, string IDCard, string AddressLine1, string AddressLine2, string EmailAddress, string MobileNumber, string AccountNumber, string UserID)
    {

        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.InitiateAccountUpdateRequest(RequestType, FirstName, LastName, IDCard, AddressLine1, AddressLine2, EmailAddress, MobileNumber, AccountNumber, UserID);

        return ret_val;
    }

    [WebMethod(Description = "Get Account Managers. The response is an XML containing status code and description. Status 1000 is success")]
    public DataTable GetAccountManagers(string bra_code, string cus_num, string curcode, string ledcode, string subacctcode)
    {
        DataTable returnDataTable = new DataTable();
        Eone tranx = new Eone();
        returnDataTable = tranx.AccountManagers(bra_code, cus_num, curcode, ledcode, subacctcode);
        return returnDataTable;
    }

    [WebMethod(Description = "Populate details. The response is an XML containing status code and description. Status 1000 is success")]
    public String PopulateDetails(string NubanNo)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.PopulateDetails(NubanNo);

        return ret_val;
    }

    [WebMethod(Description = "Convert regular account to Nuban. The response is an XML containing status code and description. Status 1000 is success")]
    public string ConvertToNuban(string OldAccountNumber)
    {
        //String ret_val = null;
        string ret_val;
        BASIS basis = new BASIS();
        ret_val = basis.ConvertToNuban(OldAccountNumber);

        return ret_val;
    }

    [WebMethod(Description = "Update Salary Advance Status. The response is an XML containing status code and description. Status 1000 is success")]
    public String UpdateSalaryAdvanceStatus(string uuid, string caseid, string status, int delindex)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.UpdateSalaryAdvanceStatus(uuid, caseid, status, delindex);

        return ret_val;

    }

    [WebMethod(Description = "Get Referal Code. The response is an XML containing status code and description. Status 1000 is success")]
    public string GetReferalCode(string mobnum)
    {
        string ret_val = "";
        Eone tranx = new Eone();
        ret_val = tranx.GetRefferedAccount(mobnum);
        return ret_val;
    }

    [WebMethod(Description = "Update IRefer. The response is an XML containing status code and description. Status 1000 is success")]
    public string UpdateIRefer3(long refcode, String updatedby, string nuban)
    {
        string ret_val = "";
        Eone tranx = new Eone();
        ret_val = tranx.UpdateIRefer(refcode, updatedby, nuban);
        return ret_val;
    }

    [WebMethod(Description = "Get Number of Active FEP Cards. The response is an XML containing status code and description. Status 1000 is success")]
    public int GetNumberOfActiveFEPCards(string bracode, string cusnum)
    {
        int ret_val = 0;
        Eone tranx = new Eone();
        ret_val = tranx.GetActiveFEPCards(bracode, cusnum);
        return ret_val;
    }

    [WebMethod]
    public String RetrieveAccountUpdateDetails(string RequestReference)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.RetrieveAccountUpdateDetails(RequestReference);

        return ret_val;
    }

    private ParameterValue[] ConvertNameValueCollectionIntoParams(ArrayList nvp)
    {
        ParameterValue[] parameters = new ParameterValue[nvp.Count];
        for (int i = 0; i < nvp.Count; i++)
        {
            ParameterValue parameter = new ParameterValue();
            string[] strNameValuePair = (string[])nvp[i];
            parameter.Name = strNameValuePair[0];
            parameter.Value = strNameValuePair[1];
            parameters[i] = parameter;
        }
        return parameters;
    }

    [WebMethod]
    [XmlInclude(typeof(string[]))]
    public string ProcessmakernewCase(string sessionid, object[] newcaseParameters)
    {
        string result = string.Empty;
        ProcessMaker PM = new ProcessMaker();
        ArrayList al = new ArrayList(newcaseParameters);
        ParameterValue[] Params = ConvertNameValueCollectionIntoParams(al);
        result = PM.newCase(sessionid, Params);
        return result;
    }

    [WebMethod]
    public string ProcessmakerLogin()
    {
        string result = string.Empty;
        ProcessMaker PM = new ProcessMaker();
        result = PM.login();
        return result;
    }

    [WebMethod]
    public string ProcessmakerRouteCase(string sessionid, string caseid, int delindex)
    {
        string result = string.Empty;
        ProcessMaker PM = new ProcessMaker();
        result = PM.routeCase(sessionid, caseid, delindex);
        return result;
    }

    [WebMethod]
    public string BVNLinkerHelper(string userID, string BVN, string FirstName, string bankcode, string LastName, string PhoneNumber, string RegistrationDate, string EnrollmentBank, string channel, string nuban, string MiddleName, string DateOfBirth, string sign, string platformid, string EnrollmentBranch)
    {
        string result = String.Empty;
        Eone PM = new Eone();
        result = PM.BVNLinkerHelper(userID, BVN, FirstName, bankcode, LastName, PhoneNumber, RegistrationDate, EnrollmentBank, channel, nuban, MiddleName, DateOfBirth, sign, platformid, EnrollmentBranch);
        return result;
    }


    [WebMethod]
    public string AddRestrictionWithNuban(int tell_id, string nuban, int restrictcode, string restricttext)
    {
        string ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.AddRestriction(tell_id.ToString(), nuban, restrictcode.ToString(), restricttext);

        return ret_val;

    }
    [WebMethod]
    public string GetActiveFEPCards(string pCustomerID)
    {
        //   string pan = GTBSecure.Secure.DecryptString(pPAN);
        string ret_val = string.Empty;
        Eone eone = new Eone();
        ret_val = eone.GetActiveFEPCards(pCustomerID);

        return GTBSecure.Secure.EncryptString(ret_val);
    }



    [WebMethod(Description = "Get International Transactions. The response is a datatable containing last 7 international transactions")]
    public DataTable GetInternationalTransactions(string bra_code, string cus_num)
    {
        DataTable returnDataTable = new DataTable();
        Eone tranx = new Eone();
        returnDataTable = tranx.InternationalTransactions(bra_code, cus_num);
        return returnDataTable;
    }

    [WebMethod(Description = "Get Total sum for International Transactions. The response is the total sum of international transaction")]
    public string GetTotalInternationalSpending( string bra_code, string cus_num)
    {
        //   string pan = GTBSecure.Secure.DecryptString(pPAN);
        string ret_val = string.Empty;
        Eone eone = new Eone();
        ret_val = eone.GetTotalInternationalSpending(bra_code,cus_num);

        return ret_val;// GTBSecure.Secure.EncryptString(ret_val);
    }


    [WebMethod]
    public String GenerateCVV(String pan, String expiry)
    {
        EncryptionLib.Encrypt enc = new EncryptionLib.Encrypt();
        String ret_val = null;
        string hsmEnv = ConfigurationManager.AppSettings["HSMEnvironment"].ToString();
        string hsmIp = ConfigurationManager.AppSettings["HSMIP"].ToString();
        int hsmport = Convert.ToInt16(ConfigurationManager.AppSettings["HSMPort"].ToString());
        string hsmCVKey = ConfigurationManager.AppSettings["HSMCVKey"].ToString();

        HSMConnect.HSM hsm = new HSMConnect.HSM(hsmEnv, hsmIp, hsmport);
        hsm.CVKey = hsmCVKey;
        hsm.PAN = enc.Decrypt_TrpDes(pan);
        hsm.Expiry = expiry.Substring(2, 2) + expiry.Substring(0, 2);
        string cvv = hsm.GenerateCVV();
        return cvv;
    }

    [WebMethod]
    public string CreateUtility(int branchCode, int cusnum)
    {
        var card = new Cards();
        var result = card.CreateUtility(branchCode, cusnum);
        return result;
    }

    [WebMethod]
    public string LinkUnlinkCard(string pPAN, string pSeqNo, string pExpiry, string pAccountID, string pAccountType, string pCurrencyCode, string RequestBy, string pCardVal2, string pUniqueID, string pLinkType, string pTBPostFix)
    {
        var card = new Cards();
        var result = card.LinkingUnlinkCard(pPAN, pSeqNo, pExpiry, pAccountID, pAccountType, pCurrencyCode, RequestBy, pCardVal2, pUniqueID, pLinkType, pTBPostFix);
        return result.ToString();

    }

    [WebMethod]
    public int HotlistVirtualCard(string pPAN, long pCustomerID, string pExpiry, string pSeqNo, int pResponseCode, string UniqueCode)
    {
        string pan = GTBSecure.Secure.DecryptString(pPAN);
        int ret_val = 0;
        Eone eone = new Eone();
        ret_val = eone.HotlistCard(pan, pCustomerID, pExpiry, pSeqNo, pResponseCode, UniqueCode);

        return ret_val;
    }

    [WebMethod]
    public string Ibank_Onboarding(string Nuban, string lastfourDigit_PAN, string mobileNo, string channel)
    {
        string result = string.Empty;
        AlterChannelIbankReg chann = new AlterChannelIbankReg(Nuban, lastfourDigit_PAN, mobileNo, channel);
        result = chann.Ibank_Regist();
        return result;
    }
    //[WebMethod]
    //public string Ibank_Onboarding(string Nuban, string lastfourDigit_PAN, string mobileNo, string channel)
    //{
    //    string result = string.Empty;
    //    AlterChannelIbankReg chann = new AlterChannelIbankReg(Nuban, lastfourDigit_PAN, mobileNo, channel);
    //    result = chann.Ibank_Regist();
    //    return result;
    //}


    //[WebMethod]
    //public string DispenseErrorMMoney(int branchCode, int origbraCode, int cusNum, int curCode, int ledCode, int subacctCode, int tranAmount, string transacDate, string typeofTrans, string detailsofTransType, string mobileNumber, string userID, string refID)
    //{
    //    string result = null;
    //    DispenseError disErr = new DispenseError();
    //    result = disErr.MobileMoney(branchCode, origbraCode, cusNum, curCode, ledCode, subacctCode, tranAmount, transacDate, typeofTrans, detailsofTransType, mobileNumber, userID, refID);
    //    return result;
    //}


    [WebMethod]
    public String GetCollectionListOfValues(int lov_ID)
    {
        String ret_val = null;
        GTCollect collect = new GTCollect();
        ret_val = collect.GetCollectionListOfValues(lov_ID);

        return ret_val;
    }

    [WebMethod]
    public DataTable GetCollectionListOfValues2(int lov_ID)
    {
        DataTable ret_val = new DataTable();
        GTCollect collect = new GTCollect();
        ret_val = collect.GetCollectionListOfValues2(lov_ID);
        ret_val.TableName = "LOVDETAILS";
        return ret_val;
    }

    [WebMethod]
    public String GetCollectionListOfValueData(int lov_ID, String value)
    {
        String ret_val = null;
        GTCollect collect = new GTCollect();
        ret_val = collect.GetCollectionListOfValuesData(lov_ID, value);

        return ret_val;
    }

    [WebMethod]
    public DataSet GetCollectionDetails()
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetCollectionDetails_US();

        return ds;
    }

    [WebMethod]
    public DataSet GetCollectionCategtories()
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetCollectionCategtories();

        return ds;
    }

    [WebMethod]
    public DataSet GetCollectionFormsByCategory(int catid)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetCollectionFormsByCategory(catid);
        //ds.TableName = "COLLFORM";

        return ds;
    }

    [WebMethod]
    public DataSet GetBranchCollectionFormsByCategory(int catid)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetBranchCollectionFormsByCategory(catid);
        //ds.TableName = "COLLFORM";

        return ds;
    }

    [WebMethod]
    public DataSet GetOnlineCollectionFormsByCategory(int catid)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetOnlineCollectionFormsByCategory(catid);
        //ds.TableName = "COLLFORM";

        return ds;
    }

    [WebMethod]
    public DataSet GetWebCollectionFormsByCategory(int catid)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetWebCollectionFormsByCategory(catid);
        //ds.TableName = "COLLFORM";

        return ds;
    }

    [WebMethod]
    public DataSet GetCollectionFormsByCustomer(int custid)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetFormsByCustomerID(custid);//.GetCollectionFormsByCategory(custid);
        //ds.TableName = "COLLFORM";

        return ds;
    }

    [WebMethod]
    public DataSet GetBranchCollectionFormsByCustomer(int custid)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetBranchCollectionFormsByCustomer(custid);
        //ds.TableName = "COLLFORM";

        return ds;
    }

    [WebMethod]
    public DataSet GetOnlineCollectionFormsByCustomer(int custid)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetOnlineCollectionFormsByCustomer(custid);
        //ds.TableName = "COLLFORM";

        return ds;
    }

    [WebMethod]
    public DataSet GetWebCollectionFormsByCustomer(int custid)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetWebCollectionFormsByCustomer(custid);
        //ds.TableName = "COLLFORM";

        return ds;
    }

    [WebMethod]
    public DataSet GetCollectionCustomers()
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetCollectionCustomers();

        return ds;
    }

    [WebMethod]
    public DataSet GetCollectionCustomersByCategory(int cid)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetCollectionCustomersByCategory(cid);

        return ds;
    }

    [WebMethod]
    public DataSet GetCollectionForms(int custid)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = new DataSet();
        ds.Tables.Add(collect.GetCollectionForms(custid));

        return ds;
    }

    [WebMethod]
    public DataSet GetCollectionFormByID(int formid)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = new DataSet();
        ds.Tables.Add(collect.GetCollectionFormByID(formid));

        return ds;
    }

    [WebMethod]
    public DataSet GetCollectionCharges(int form_ID)
    {
        DataSet dt;
        GTCollect collect = new GTCollect();
        dt = collect.GetCollectionCharges(form_ID);

        return dt;
    }

    [WebMethod]
    public DataSet GetBranchCollectionCharges(int form_ID)
    {
        DataSet dt;
        GTCollect collect = new GTCollect();
        dt = collect.GetBranchCollectionCharges(form_ID);

        return dt;
    }

    [WebMethod]
    public DataSet GetOnlineCollectionCharges(int form_ID)
    {
        DataSet dt;
        GTCollect collect = new GTCollect();
        dt = collect.GetOnlineCollectionCharges(form_ID);

        return dt;
    }

    [WebMethod]
    public DataSet GetWebCollectionCharges(int form_ID)
    {
        DataSet dt;
        GTCollect collect = new GTCollect();
        dt = collect.GetWebCollectionCharges(form_ID);

        return dt;
    }

    [WebMethod]
    public DataSet GetCollectionFormFields(int formid)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetCollectionFormFields(formid);

        return ds;
    }

    [WebMethod]
    public DataSet GetBranchCollectionFormFields(int formid)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetBranchCollectionFormFields(formid);

        return ds;
    }

    [WebMethod]
    public DataSet GetOnlineCollectionFormFields(int formid)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetOnlineCollectionFormFields(formid);

        return ds;
    }

    [WebMethod]
    public DataSet GetWebCollectionFormFields(int formid)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetWebCollectionFormFields(formid);

        return ds;
    }

    [WebMethod(Description = "Get the details of GTcollection form. The response is an XML containing status code and description. Status 1000 is success")]
    public DataSet GetCollectionFormFieldDetails(int customerid, int formid, DataSet dt_fieldset, string channel, string debitAcct)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetCollectionFormFieldDetails(customerid, formid, dt_fieldset, debitAcct,channel );

        return ds;
    }

    [WebMethod(Description = "Get GTcollection transactions by userID. The response is an XML containing status code and description. Status 1000 is success")]
    public DataSet GetCollectionTransactionsByUser(int formid, String userID)
    {
        GTCollect collect = new GTCollect();
        //DataSet ds = collect.GetCollectionFormFieldDetails(customerid, formid, dt_fieldset);
        DataSet ds = collect.GetTransactionHistoryByUser(formid, userID);

        return ds;
    }

    [WebMethod]
    public int UpdateGTCollectionGTPayTransaction(int transid, String transstatus, String message)
    {
        GTCollect collect = new GTCollect();

        int ds = collect.UpdateTransaction(Convert.ToDecimal(transid), transstatus, message);

        return ds;
    }

    [WebMethod]
    public String PostCollectionData(int customer_id, int CollFormID, String userid, String postingbranchcode, Decimal tra_amt, String narration, String customer_acct, String pptno, String fname, String lname, String dob, String phoneno, String visa_cat, String cat_name, String emb_code, String emb_name)
    {
        String ret_val = null;
        GTCollect collect = new GTCollect();
        ret_val = collect.PostCollectionData(customer_id, CollFormID, userid, postingbranchcode, tra_amt, narration, customer_acct, pptno, fname, lname, dob, phoneno, visa_cat, cat_name, emb_code, emb_name);

        return ret_val;
    }

    [WebMethod]
    public String PostCollectionData_new(int customer_id, int CollFormID, String coll_acct, String userid, String postingbranchcode, Decimal tra_amt, String paymentmode, String tellersuspacct, String customer_acct, String trans_type, int doc_num, String posref, String custom_receipt, String startdate_str, String enddate_str, int frequency, String postflag, DataSet dt_dset)
    {
        String ret_val = null;
        GTCollect collect = new GTCollect();
        ret_val = collect.PostCollectionData2(customer_id, CollFormID, coll_acct, userid, postingbranchcode, tra_amt, customer_acct, tellersuspacct, paymentmode, trans_type, doc_num, posref, custom_receipt, postflag, startdate_str, enddate_str, frequency, dt_dset);

        return ret_val;
    }

    [WebMethod]
    public String UpdateCollectionData(decimal transactionid, String transreference)
    {
        String ret_val = null;
        GTCollect collect = new GTCollect();
        ret_val = collect.UpdateCollectionData(transactionid, transreference);

        return ret_val;
    }

    [WebMethod]
    public String PostCollectionData_GTChurch(int customer_id, int CollFormID, String userid, Decimal tra_amt, String narration, String customer_acct, String mem_name)
    {
        String postingbranchcode = "9999";
        String ret_val = null;
        GTCollect collect = new GTCollect();
        ret_val = collect.PostCollectionData_GTChurch(customer_id, CollFormID, userid, postingbranchcode, tra_amt, narration, customer_acct, mem_name);

        return ret_val;
    }

    [WebMethod]
    public String TransferFunds_TranSeqCommit(String Acct_fro, String Acct_to, Double Amount, String type, int EXPL_CODE, String channel, String Remarks, int origtbraCode, string docAlp, int supervisorID, int tellerID, string transUniqIndenf)
    {
        Eone eone = new Eone();
        String ret_val = null;

        ret_val = eone.TransferFunds_TranSeqCommit(Acct_fro, Acct_to, Amount, type, channel, EXPL_CODE, Remarks, origtbraCode, docAlp, supervisorID, tellerID, transUniqIndenf);
        return ret_val;
    }

    [WebMethod]
    public String TransferGTBChequesTransSeqCommit(String Acct_fro, String Acct_to, Double Amount, String type, String channel, String Remarks, int docnum, Int16 identifier, Int16 bankcode, Int16 days, string docAlp, int supervisorID, int tellerID, int origtbraCode, string transUniqIndenf)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.TransferGTBChequesTransSeqCommit(Acct_fro, Acct_to, Amount, type, channel, Remarks, docnum, identifier, bankcode, days, docAlp, supervisorID, tellerID, origtbraCode, transUniqIndenf);

        return ret_val;
    }
        
    [WebMethod]
    public DataSet ExecuteBasisQuery(string quer, int db)
    {
        DataSet result = null;
        BASIS bas = new BASIS();
        return bas.ExecuteBasisQuery(quer, db);
    }

    [WebMethod]
    public string Basis_Transfer_Errors(string errorCode)
    {
        string result = string.Empty;
        BASIS chann = new BASIS();
        result = chann.BasisError(errorCode);
        return result;
    }

    [WebMethod]
    public string AddRestriction(int tell_id, int branchcode, int customernum, int currencycode, int ledgercode, int subacctcode, int restrictcode, string restricttext)
    {
        string ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.AddRestriction(tell_id.ToString(), branchcode.ToString(), customernum.ToString(), currencycode.ToString(), ledgercode.ToString(), subacctcode.ToString(), restrictcode.ToString(), restricttext);

        return ret_val;

    }

    [WebMethod]
    public string RemoveRestriction(int tell_id, int branchcode, int customernum, int currencycode, int ledgercode, int subacctcode, int restrictcode, string restricttext, int restrictionseq, int opetype)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.RemoveRestriction(tell_id, branchcode, customernum, currencycode, ledgercode, subacctcode, restrictcode, restricttext, restrictionseq, opetype);

        return ret_val;
    }

    [WebMethod]
    public string BlockFunds_PM(string bracode, string cusnum, string curcode, string ledcode, string subacctcode, string remarks, string tra_amount, string expdate, string tellerid, string blkType, string blkTypeCode)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.BlockFunds_PM(bracode, cusnum, curcode, ledcode, subacctcode, remarks, tra_amount, expdate, tellerid, blkType, blkTypeCode);

        return ret_val;
    }

    [WebMethod]
    public int UnBlockFundimmediate(int braCode, int cusNum, int curCode, int ledCode, int subAcctCode, int bloSeq, double bloAmt, int tellID)
    {
        BASIS tranx = new BASIS();
        //   int result = tranx.UnBlockFundimmediate(braCode, cusNum, curCode, ledCode, subAcctCode, bloSeq, bloAmt, tellID);
        DateTime eff_Date = DateTime.Now;
        int result = tranx.UnBlockFundbatch(braCode, cusNum, curCode, ledCode, subAcctCode, bloSeq, bloAmt, tellID, eff_Date);

        return result;
    }

    [WebMethod]
    public int UnBlockFundbatch(int braCode, int cusNum, int curCode, int ledCode, int subAcctCode, int bloSeq, double bloAmt, int tellID, DateTime eff_Date)
    {
        BASIS tranx = new BASIS();
        int result = tranx.UnBlockFundbatch(braCode, cusNum, curCode, ledCode, subAcctCode, bloSeq, bloAmt, tellID, eff_Date);
        return result;
    }

    [WebMethod]
    public String PostCollectionData_Others(int ussdcode, int merchantcode, int atmcode, String channel, String userid, Decimal tra_amt, Decimal total_tra_amt, String narration, String customer_acct, String customercode, String customername)
    {
        String postingbranchcode = "999";
        String ret_val = null;
        GTCollect collect = new GTCollect();
        ret_val = collect.PostCollectionData_Others(ussdcode, merchantcode, atmcode, channel, userid, postingbranchcode, tra_amt, total_tra_amt, narration, customer_acct, customercode, customername);

        return ret_val;
    }

    [WebMethod]
    public DataSet GetCollectionFormByUSSDCode(int ussdcode, int merchantcode)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = new DataSet();
        ds.Tables.Add(collect.GetCollectionFormByUSSDCode(ussdcode, merchantcode));

        return ds;
    }

    [WebMethod]
    public DataSet GetCollectionFormByATMCode(int atmcode)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = new DataSet();
        ds.Tables.Add(collect.GetCollectionFormByATMCode(atmcode));

        return ds;
    }


    [WebMethod]
    public DataSet GetUSSDCollectionFormFields(int ussdcode, int merchantcode)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetUSSDCollectionFormFields(ussdcode, merchantcode);

        return ds;
    }

    [WebMethod]
    public DataSet GetATMCollectionFormFields(int atmcode)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetATMCollectionFormFields(atmcode);

        return ds;
    }

    [WebMethod]
    public String TransferFund3(String Acct_fro, String Acct_to, Double Amount, String type, int EXPL_CODE, String channel, String Remarks)
    {
        Eone eone = new Eone();
        String ret_val = null;

        ret_val = eone.TransferFunds3(Acct_fro, Acct_to, Amount, type, channel, EXPL_CODE, Remarks);
        return ret_val;
    }

    [WebMethod]
    public DataSet GetCollectionFormFieldDetails_others(string debAcct, string channel, int merchantcode, int ussdcode, int atmcode, String customercode)
    {
        int customerid = 0;
        int formid = 0;
        DataSet dt_fieldset = null;
        string debitAcc = String.Empty;

        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetCollectionFormFieldDetails_others(debAcct, channel, merchantcode, ussdcode, atmcode, customercode);

        return ds;
    }

    [WebMethod]
    public String SendEmail_Attachment(String subject, String mailmessage, String emailfrom, String emailto, String CCopy, byte[] contentStream, string contentType, string fileName)
    {
        String ret_val = null;
        Email email = new Email();
        ret_val = email.SendEmail_Attachment(emailfrom, emailto, subject, mailmessage, CCopy, contentStream, contentType, fileName);

        return ret_val;
    }

    [WebMethod]
    public string BankPort(string bvn, string mobilenumber)
    {
        string ret_val = string.Empty;
        BASIS bas = new BASIS();
        ret_val = bas.BankPort(bvn, mobilenumber);
        return ret_val;
    }

    [WebMethod]
    public string GenerateOTP(int braCode, int cusNum, string channel, int otpLength, string transID, string terminalID)
    {
        string result = string.Empty;
        OTP otp = new OTP();
        result = otp.GenerateOTP(braCode, cusNum, channel, otpLength, transID, terminalID);
        return result;
    }

    [WebMethod]
    public String ValidateOTP(int braCode, int cusNum, string OTP, string transID, string terminalID)
    {
        string result = string.Empty;
        OTP otp = new OTP();
        result = otp.ValidateOTP(braCode, cusNum, OTP, transID, terminalID);
        return result;
    }

    [WebMethod]
    public String ValidateAdminUserOffSiteWithIP(String userid, String password, int appid, string ipAddress)
    {
        String ret_val = null;
        Eone eone = new Eone();

        ret_val = eone.ValidateAdminUsrOffSite(userid, password, appid, ipAddress);

        return ret_val;
    }

    [WebMethod]
    public String ValidateEncryptedAdminUserOffSiteWithIP(String userid, String password, string code, int appid, string ipAddress)
    {
        EncryptLib2003.Encrypt enc2003 = new EncryptLib2003.Encrypt();
        Encryption encrypt = new Encryption();
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.ValidateAdminUsrOffSite(enc2003.Decrypt_TrpDes(userid), enc2003.Decrypt_TrpDes(password), appid, ipAddress);

        return ret_val;
    }

    [WebMethod]
    public String ValidateAdminUsr(String userid, String password)
    {
        string userid1 = GTBSecure.Secure.GTBDecrypt(userid);
        string password1 = GTBSecure.Secure.GTBDecrypt(password);


        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.ValidateAdminUsr2(userid1, password1);

        return ret_val;
    }

    [WebMethod]
    public String ValidateAdminUserWithIP(String userid, String password, int appid, string ipAddress)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.ValidateAdminUsr(userid, password, appid, ipAddress);

        return ret_val;
    }

    [WebMethod]
    public String ValidateEncryptedAdminUserWithIP(String userid, String password, String code, int appid, string ipAddress)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.ValidateAdminUsr(this.DecryptData(userid, code), this.DecryptData(password, code), appid, ipAddress);

        return ret_val;
    }

    [WebMethod]
    public String GetLastLoginTime(String userid, int appid)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.GetLastLoginTime(userid, appid);

        return ret_val;
    }

    [WebMethod]
    public string BVNLinkerHelperOther(string userID, string BVN, string FirstName, string bankcode, string LastName, string PhoneNumber, string RegistrationDate, string EnrollmentBank, string channel, string nuban, string MiddleName, string DateOfBirth, string sign, string platformid, string EnrollmentBranch, string domainName, string ipAdd)
    {
        string result = String.Empty;
        Eone PM = new Eone();
        result = PM.BVNLinkerHelperOther(userID, BVN, FirstName, bankcode, LastName, PhoneNumber, RegistrationDate, EnrollmentBank, channel, nuban, MiddleName, DateOfBirth, sign, platformid, EnrollmentBranch, domainName, ipAdd);
        return result;
    }

    [WebMethod]
    public int GTGuardEnableIntlTrx(string pPAN, string pExpiry, string pAction, string channel)
    {
        string pan = GTBSecure.Secure.DecryptString(pPAN);
        int ret_val = 0;
        Eone eone = new Eone();
        ErrHandler.WriteError("Parameters for GTGuardEnableIntlTrx : " + pan + "," + pExpiry + "," + pAction + "," + channel);
        ret_val = eone.GTGuardEnableIntlTrx(pan, pExpiry, pAction);

        return ret_val;
    }

    [WebMethod]
    public string GTGuardCardStatus(string pPAN, string Expiry)
    {
        DataTable returnDataTable = new DataTable();
        Eone tranx = new Eone();
        string resp = tranx.GTGuardCardStatus(pPAN, Expiry);
        return resp;
    }

    [WebMethod]
    public string LocalTransfer_ATM(string benNUBAN, double amount, double charge, double vat, string acctToDebitTransfer, int expl_Code, string transRef, string chargeAcc, int expl_Code_charge, int expl_Code_Vat, string vatAcc, double vatAmount, string exemptCharge)
    {
        string result = String.Empty;
        Eone eone = new Eone();
        result = eone.LocalTransfer_ATM(benNUBAN, amount, charge, vat, acctToDebitTransfer, expl_Code, transRef, chargeAcc, expl_Code_charge, expl_Code_Vat, vatAcc, vatAmount, exemptCharge);
        return result;
    }


    [WebMethod]
    public String IRequest(int bracode, int cusnum, string CusName, decimal TransactionAmt, string remarks, string pan, int NoOfLeaves, string ChargeAcct, string StmtAcct, string StartDate, string EndDate, int NoOfCopies, int ReqType, string requestID, int PreferredBranch, string InitiatedBy, string pickUpBy,
        string MeansID, string channel, string docalp, string PickName, List<StatementRequest> lstStatement, string Pickupmethod)
    {
        IRequest ireq = new IRequest();
        string response = ireq.InsertIRequest(bracode, cusnum, CusName, TransactionAmt, remarks, pan, NoOfLeaves, ChargeAcct, StmtAcct, StartDate, EndDate, NoOfCopies, ReqType, requestID, PreferredBranch, InitiatedBy, pickUpBy, MeansID, channel, docalp, PickName, lstStatement, Pickupmethod);
        return response;
    }


    [WebMethod]
    public String CancelIRequest(long RefCode, String update_by, int bracode, int cusnum, string reason, string cancel_channel)
    {
        IRequest ireq = new IRequest();
        string response = ireq.CancelIRequest(RefCode, update_by, bracode, cusnum, reason, cancel_channel);
        return response;
    }

    [WebMethod]
    public String ConfirmIRequest(int requestType, long RefCode, string Updated_By, string tellerTill, int opsHeadBraCode, int tellerBasisID, int supervisorBasisID)
    {
        //, int bracode, int cusnum, int prefbranch
        IRequest ireq = new IRequest();
        string response = ireq.ConfirmsIRequest(requestType, RefCode, Updated_By, tellerTill, opsHeadBraCode, tellerBasisID, supervisorBasisID);
        return response;
    }

    [WebMethod]
    public String AcknowledgeIRequest(Int64 ReqID, string Updated_By, int bracode, int cusnum, int requestType, int sla, int prefbranch, String tokenVal)
    {
        IRequest ireq = new IRequest();
        string response = ireq.AcknowledgeIRequest(ReqID, Updated_By, bracode, cusnum, requestType, sla, prefbranch, tokenVal);
        return response;
    }

    [WebMethod]
    public DataSet ReturnIrequestStatementDetails(long IRequestID)
    {
        DataSet dsResults = new DataSet();
        IRequest ireq = new IRequest();

        dsResults = ireq.ReturnIrequestStatements(IRequestID);
        return dsResults;
    }


    [WebMethod]
    public DataTable RetrieveIRequest(int branch, int reqtype)
    {
        IRequest ireq = new IRequest();
        DataTable response = new DataTable();
        response = ireq.RetriveIRequest_Branch(branch, reqtype);
        return response;
    }

    [WebMethod]
    public DataSet RetrieveIRequest2(long? refCode, int? braCode, string dateFrom, string dateTo, int? ReqType, string status)
    {
        IRequest ireq = new IRequest();
        DataSet response = new DataSet();
        response = ireq.ReturnIRequest(refCode, braCode, dateFrom, dateTo, ReqType, status);
        return response;
    }


    [WebMethod]
    public DataSet RetrieveIRequestByRefCode(long refCode)
    {
        IRequest ireq = new IRequest();
        DataSet response = new DataSet();
        response = ireq.ReturnIRequestByRefCode(refCode);
        return response;
    }

    [WebMethod]
    public DataSet RetrieveIRequest_UserID(int bracode, int cusnum)
    {
        IRequest ireq = new IRequest();
        DataSet response = new DataSet();
        response = ireq.RetreiveIRequest_UserID(bracode, cusnum);
        return response;
    }

    [WebMethod]
    public DataSet RetrieveIRequest_ByDate(int bracode, int cusnum, DateTime fromdate, DateTime endDate)
    {
        IRequest ireq = new IRequest();
        DataSet response = new DataSet();
        response = ireq.RetreiveIRequest_ByDate(bracode, cusnum, fromdate, endDate);
        return response;
    }

    [WebMethod]
    public DataSet RetrieveIRequestBranches(string status, int method)
    {
        IRequest ireq = new IRequest();
        DataSet response = new DataSet();
        response = ireq.IRequestBranchRetrieve(status, method);
        return response;
    }

    [WebMethod]
    public String IRequestBranchProfile(int branch, string userid, string status)
    {
        IRequest ireq = new IRequest();

        string response = ireq.IRequestBranchProfile(branch, userid, status);
        return response;
    }

    [WebMethod]
    public DataSet ReturnIRequestCategories()
    {
        IRequest ireq = new IRequest();

        DataSet response = ireq.ReturnIRequestCategories();
        return response;
    }

    [WebMethod]
    public DataSet ReturnAllActiveTellersPerBranch(int branchCode)
    {
        BASIS basis = new BASIS();

        DataSet response = basis.GetTellersPerBranch(branchCode);
        return response;
    }

    [WebMethod]
    public DataSet SelectSMSBankingMenus()
    {
        Eone eone = new Eone();
        DataSet dsSMSBkMenus = eone.SelectSMSBankingMenus();
        return dsSMSBkMenus;

        //return new DataSet();
    }
    [WebMethod]
    public ServiceResponse ProfileSMSBankingMenu(string syntax, string menuName, string menuDesc, int flag, int action, Int64 sNo)
    {
        ServiceResponse resp = new ServiceResponse();
        Eone eone = new Eone();
        resp = eone.ProfileSMSBankingMenu(syntax, menuName, menuDesc, flag, action, sNo);
        return resp;

        //return new ServiceResponse();
    }

    [WebMethod(Description = "Validates User Token. The response is an XML containing status code and description. Status 1000 is success")]
    public String ValidateUserTokenWithAmount(String userid, String tokenvalue, String purp, String chann, double TransactionAmount)
    {
        String ret_val = null;
        Token tk = new Token();
        ret_val = tk.ValidateTokenWithAmount(userid, tokenvalue, "USER", purp, chann, TransactionAmount);

        return ret_val;
    }

    [WebMethod]
    public string CreateSpend2Save(string requextxml)
    {
        DataTable returnDataTable = new DataTable();
        Eone tranx = new Eone();
        string resp = tranx.CreateSpend2Save(requextxml);

        return resp;
    }

    [WebMethod]
    public string CancelSpend2Save(string requextxml)
    {
        DataTable returnDataTable = new DataTable();
        Eone tranx = new Eone();
        string resp = tranx.CancelSpend2Save(requextxml);

        return resp;
    }

    [WebMethod]
    public string OpenAdditionalAccount(int bracode, int cusnum, int ledcode, int curcode)
    {
        DataTable returnDataTable = new DataTable();
        Eone tranx = new Eone();
        string resp = tranx.OpenAdditionalAccount(bracode, cusnum, ledcode, curcode);

        return resp;
    }

    [WebMethod]
    public string InsertSpendToSaveDEtailsOnBasis(int bracode, int cusnum, int curcode, int ledcode, int subacctcode, decimal savepercent, int opertype)
    {
        Eone tranx = new Eone();
        string resp = tranx.InsertSpendToSaveDEtailsOnBasis(bracode, cusnum, curcode, ledcode, subacctcode, savepercent, opertype);

        return resp;
    }

    [WebMethod]
    public String TransferFund_mob(String Acct_fro, String Acct_to, Double Amount, String type, String channel, String Remarks, String Remarks_2)
    {
        int transfercount = -1, blk_res = -1;
        String rescode;
        String ret_val = null;
        Eone eone = new Eone();
        Double str_amount = Convert.ToDouble(ConfigurationManager.AppSettings["FirstTimeLimit"].ToString());
        String blk_fund = ConfigurationManager.AppSettings["BlockFund"].ToString();

        try
        {
            if (channel == "IVR" && type == "ANY" && Amount > str_amount)
            {
                transfercount = eone.CheckBeneficiaryTransferLimit(Remarks, Acct_to);
            }
        }
        catch (Exception ex)
        {
            transfercount = -1;
        }

        ret_val = eone.TransferFunds_mob(Acct_fro, Acct_to, Amount, type, channel, Remarks, Remarks_2);
        rescode = GetResponseMsg(ret_val);
        //--------------------------Block First timer---------------------------------------------------------------------------

        String[] tempstr;
        if (rescode == "1000")
        {
            if (channel == "IVR" && type == "ANY" && Amount > str_amount && blk_fund == "YES")
            {
                if (transfercount == 0)
                {
                    tempstr = Acct_to.Split('/');
                    blk_res = eone.PostToBASIS_Block(Convert.ToInt32(tempstr[0]), Convert.ToInt32(tempstr[1]), Convert.ToInt32(tempstr[2]), Convert.ToInt32(tempstr[3]), Convert.ToInt32(tempstr[4]), Amount);
                }
            }
        }
        //----------------------------------------------------------------------------------------------------

        return ret_val;
    }

    [WebMethod(Description = "Get the details of GTcollection form. The response is an XML containing status code and description. Status 1000 is success")]
    public DataSet GetCollectionFormFieldDetails2(int customerid, int formid, DataSet dt_fieldset, String acctid, string ch)
    {
        GTCollect collect = new GTCollect();
        DataSet ds = collect.GetCollectionFormFieldDetails(customerid, formid, dt_fieldset, acctid, ch);

        return ds;
    }

    [WebMethod(Description = "Get International spending limit. The response is a datatable")]
    public DataSet GetInternationalSpendingLimit(string bra_code, string cus_num)
    {
        DataSet ds = new DataSet();
        Eone tranx = new Eone();
        ds = tranx.GetInternationalSpendingLimit(bra_code, cus_num);
        return ds;
    }

    [WebMethod(Description = "Generate MT942 statement. The response is an XML containing status code and description. Status 1000 is success")]
    public byte[] GenerateMT942Statement(String accountNumber, string Nuban, String startdate, String enddate) //String des_Code,    String cur_code
    {
        String Day = DateTime.Now.ToString("dd-MM-yy", CultureInfo.CreateSpecificCulture("en-GB"));
        String Today = DateTime.Now.ToString("yyyy-MM-dd", CultureInfo.CreateSpecificCulture("en-GB"));

        string filePath = ConfigurationManager.AppSettings["workarea"].ToString() + "\\MT942\\" + Day;
        SqlConnection conn;
        SqlCommand comm;
        DataTable ds_cust, ds;
        SqlDataAdapter adpt;
        String sqlstr_cust = null, sqlstr = null;
        int StmtNo = 0;
        string output = "";
        String freqdesc = String.Empty;
        DateTime dt_start, dt_end;
        string acctName = string.Empty;
        string[] arrayAcct = null;
        int CreateCustResp = 0;
        //get customers info
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MT940_Conn"].ToString());

        //open connetion
        if (conn.State != ConnectionState.Open)
        {
            conn.Open();
        }

        dt_start = DateTime.ParseExact(startdate, "ddMMyyyy", CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces);
        dt_end = DateTime.ParseExact(enddate, "ddMMyyyy", CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces);



        MT942 gn = null;

        gn = new MT942(accountNumber, dt_start, dt_end);

        gn.GetBasisTransactions2();


        if (!(gn.ExistInMT942Statmt(Nuban)))
        {
            CreateCustResp = gn.CreateCustomerMT942Entry(accountNumber, Nuban);
        }
        else
        {
            CreateCustResp = 1;
        }

        if (CreateCustResp == 0)
        {
            return null;
        }
        //}
        int StmtNumber = gn.GetStatementNo(Nuban);

        if (StmtNumber == 0)
        {
            StmtNumber += 1;
        }

        arrayAcct = accountNumber.Split('/');
        Int16 bra = Convert.ToInt16(arrayAcct[0]);
        Int32 cus = Convert.ToInt32(arrayAcct[1]);
        Int16 cur = Convert.ToInt16(arrayAcct[2]);
        Int16 led = Convert.ToInt16(arrayAcct[3]);
        Int16 sub = Convert.ToInt16(arrayAcct[4]);

        BASIS basis = new BASIS();
        DataTable dtAcctName = basis.GetAccountName(bra, cus, cur, led, sub);
        if (dtAcctName.Rows.Count > 0)
        {
            output = gn.Generate942_Full(StmtNumber, dtAcctName.Rows[0]["cus_sho_name"].ToString().Trim(), arrayAcct[2], Nuban);
        }


        gn.UpdateStatementNo(Nuban, StmtNumber);



        conn.Close();
        conn = null;

        byte[] image = null;
        if (output != "")
        {
            try
            {
                FileInfo file = new FileInfo(output);

                FileStream fs = new FileStream(output, FileMode.Open, FileAccess.Read);

                BinaryReader br = new BinaryReader(fs);

                image = br.ReadBytes((int)fs.Length);

                br.Close();

                fs.Close();
            }
            catch (Exception ex)
            {
                ErrHandler.WriteError("Error converting MT942 file: " + ex.Message);
            }

        }

        return image;
    }

    [WebMethod]
    public string FXBlotterInsert(string trans_deal_slip, string form_no, int sell_buy, string transtype, string currency, string fcy_acct, decimal fcy_amt, string ngn_acct, decimal ngn_equiv, string lc_ba_no, string source_fund, DateTime deal_date, DateTime settlement_date, string prod_type, string gl_id_no, string cus_name, string client_cat, string status, string channel, decimal rate, string currency2, decimal fcy_amt2, string fcy_acct2, decimal crossRate, decimal usd_equ, decimal calypsoRate)
    {
        string result = string.Empty;
        Eone eone = new Eone();
        result = eone.FXBlotterInsert(trans_deal_slip, form_no, sell_buy, transtype, currency, fcy_acct, fcy_amt, ngn_acct, ngn_equiv, lc_ba_no, source_fund, deal_date, settlement_date, prod_type, gl_id_no, cus_name, client_cat, status, channel, rate, currency2, fcy_amt2, fcy_acct2, crossRate, usd_equ, calypsoRate);
        return result;
    }

    [WebMethod]
    public string FXBlotterPosition(string currency, string channel)
    {
        string result = string.Empty;
        Eone eone = new Eone();
        result = eone.FXBlotterPosition(currency, channel);
        return result;
    }

    [WebMethod]
    public Int64 InsertAppLoginDetails(String userid, int appid, string ipAddress)
    {
        Int64 ret_val = -1;
        Eone eone = new Eone();
        ret_val = eone.InsertAppLoginDetails(userid, appid, DateTime.Now, ipAddress);

        return ret_val;
    }

    [WebMethod]
    public string CheckTransactionExist(string bra_code, string cus_num, string cur_code, string led_code, string sub_acct_code, double tra_amt, string remark, string expl_code, int deb_cre_ind)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.CheckTransactionExist(bra_code, cus_num, cur_code, led_code, sub_acct_code, tra_amt, remark, expl_code, deb_cre_ind);

        return ret_val;
    }

    [WebMethod]
     public String ValidateEncryptedAdminUserOffSiteWithIPDesktop(String userid, String password, string code, int appid, string ipAddress)
     {
         EncryptLib2003.Encrypt enc2003 = new EncryptLib2003.Encrypt();
         Encryption encrypt = new Encryption();
         String ret_val = null;
         Eone eone = new Eone();
         ret_val = eone.ValidateAdminUsrOffSiteDesktop(enc2003.Decrypt_TrpDes(userid), enc2003.Decrypt_TrpDes(password), appid, ipAddress);

        return ret_val;
     }

    [WebMethod]
    public DataSet getuserdetails(String username)
    {
        GIRO giro = new GIRO();
        DataSet ret_val = giro.getuserdetails(username);
        return ret_val;
    }

    [WebMethod]
    public void updateGIROLogin(string userName, string firstName, string lastName, string loginStartDate)
    {
        GIRO giro = new GIRO();
        giro.updateGIROLogin(userName, firstName, lastName, loginStartDate);
    }

    [WebMethod]
    public void updateGIROLogout(string userName, string loginstart)
    {
        GIRO giro = new GIRO();
        giro.updateGIROLogout(userName, loginstart);
    }

    [WebMethod]
    public Int64 getLastSequence()
    {
        Int64 result = 0;
        GIRO giro = new GIRO();
        result = giro.getLastSequence();
        return result;
    }

    [WebMethod]
    public string RegisterBeneficiary(string braCode, string cusNum, string email, string mobilenumber, string benename, string beneAccountNumber, string benBank, string transType)
    {
        string ret_val = string.Empty;
        Eone e = new Eone();
        string userId = braCode + "" + cusNum;
        var resp = e.SaveBeneficiary(userId, benename, beneAccountNumber, benBank, transType);
        if (resp == "-100")
        {
            return resp.ToString();
        }
        string emailMessage = "";
        string smsMessage = "You have succesfully registered a NEW Beneficiary (" + benename + ") on your GTBank Internet Banking Profile.";

        string subject = "INTERNET BANKING BENEFICIARY SETUP ALERT";

        emailMessage = "We would like to inform you that You have succesfully registered a NEW Beneficiary (" + benename + ") on your GTBank Internet Banking Profile." + Environment.NewLine + Environment.NewLine;
        emailMessage = emailMessage + "To stop an unauthorized transfer, please call GTConnect on 00700 GTCONNECT (0700 482666328), 01-448 0000, 0803 900 3900 or 0802 900 2900." + Environment.NewLine + Environment.NewLine;
        emailMessage = emailMessage + "Please familiarize yourself with the safety guidelines below to ensure that your account(s) and funds are protected from internet frauds." + Environment.NewLine + Environment.NewLine;
        emailMessage = emailMessage + "1. PLEASE DO NOT DISCLOSE you Internet Banking User Id, Password, Token details or other sensitive information to a third party. " + Environment.NewLine + Environment.NewLine;
        emailMessage = emailMessage + "2. ONLY access our Internet Banking service through the Guaranty Trust Bank website: www.gtbank.com " + Environment.NewLine + Environment.NewLine;
        emailMessage = emailMessage + "3. Always exercise great care when using your ATM card or accessing the GTBank internet banking platform in public places. " + Environment.NewLine + Environment.NewLine;
        emailMessage = emailMessage + "We are committed to providing you with quality and secure service at all times. " + Environment.NewLine + Environment.NewLine;
        emailMessage = emailMessage + "Thank you for choosing Guaranty Trust Bank plc." + Environment.NewLine + Environment.NewLine + Environment.NewLine;
        emailMessage = emailMessage + Environment.NewLine + Environment.NewLine + Environment.NewLine + Environment.NewLine;

        string mailResponse = SendEmail(subject, emailMessage, "intops@gtbank.com", email, null, null);
        string smsResponse = SendSMS(smsMessage, mobilenumber);

        return "OK|" + mailResponse + smsResponse;
    }

    [WebMethod]
    public DataSet ReturnNeftTransactionsForGIRO(String postDate, String FromTraSeq, String ToTraSeq, int subAcctCode)
    {
        GIRO giro = new GIRO();
        DataSet ret_val = giro.ReturnTransactions(postDate, FromTraSeq, ToTraSeq, subAcctCode);
        return ret_val;
    }

    [WebMethod(Description = "Transfer fund from one account to another(same currency). The response is an XML containing status code and description. Status 1000 is success")]
    public String TransferCal(String Acct_fro, String Acct_to, Double Amount, int expl_code, String Remarks)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.TransferCal(Acct_fro, Acct_to, Amount, expl_code, Remarks);

        return ret_val;
    }

    //[WebMethod]
    //public DataTable CardTransactions(string whereClause, SqlWebParameter[] sqlParam)
    //{
    //    DataTable resp = new DataTable();
    //    Cards card = new Cards();
    //    resp = card.CardTransactions(whereClause, sqlParam);
    //    return resp;
    //}

    [WebMethod]
    public string MT940_Range(string cusid, DateTime startDate, DateTime enDate)
    {
        string ret_val = string.Empty;
        Eone eone = new Eone();
        ret_val = eone.SendMT940_Frequency(cusid, startDate, enDate);
        return ret_val;
    }

    [WebMethod(Description = "Initiates salary advance on customers accoount")]
    public string SalaryAdvanceRequest(string accountnumber, double Amount, string medium)
    {
        Eone rev = new Eone();
        string result = string.Empty;
        result = rev.SalaryAdvanceRequest(accountnumber, Amount, medium);
        return result;
    }

    [WebMethod]
    public String SearchOFACList(string cus_sho_name)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.SearchOFACList(cus_sho_name);
        return ret_val;
    }
    [WebMethod]
    public string ValidateSwiftBIC(string SwiftBIC)
    {
        FXSTPProcess fxstp = new FXSTPProcess();
        return fxstp.validateSWIFTBIC(SwiftBIC);
    }

    [WebMethod]
    public string ValidateIBAN(string IBAN)
    {
        FXSTPProcess fxstp = new FXSTPProcess();
        return fxstp.validateIBAN(IBAN);
    }

    [WebMethod]
    public ObjectResponse CreateAdditionalAccount(int bra, int cus, int cur, int led, int tell_id, string acctmgr, string acctnat, string collLedCode, string collSubAcc)
    {
        ObjectResponse objResult = new ObjectResponse();
        string basisResult = string.Empty;
        int subacct;
        string classMeth = "AppDevService|CreateAdditionalAccount";
        string creditAcc = bra.ToString().PadLeft(4, '0') + cus.ToString().PadLeft(7, '0') + cur.ToString().PadLeft(3, '0') + collLedCode.ToString().PadLeft(4, '0') + collSubAcc.ToString().PadLeft(3, '0');

        try
        {
            using (OracleConnection oraconn = new OracleConnection((GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]))))
            {
                using (OracleCommand oracomm = new OracleCommand("EONEPKG.GTBCIR30", oraconn))
                {
                    oracomm.CommandType = CommandType.StoredProcedure;
                    oracomm.CommandTimeout = 30;
                    try
                    {
                        if (oraconn.State == ConnectionState.Closed)
                        {
                            oraconn.Open();
                        }

                        oracomm.Parameters.Add("inp_bra_code", OracleType.Number, 15).Value = bra;
                        oracomm.Parameters.Add("inp_cus_num", OracleType.Number, 15).Value = cus;
                        oracomm.Parameters.Add("inp_cur_code", OracleType.Number, 15).Value = cur;
                        oracomm.Parameters.Add("inp_led_code", OracleType.Number, 15).Value = led;
                        oracomm.Parameters.Add("inp_tell_id", OracleType.Number, 15).Value = tell_id;
                        oracomm.Parameters.Add("out_sub_acct_code", OracleType.Number, 15).Direction = ParameterDirection.Output;
                        oracomm.Parameters.Add("oerr_flag", OracleType.Number, 15).Direction = ParameterDirection.Output;

                        oracomm.ExecuteNonQuery();
                        basisResult = oracomm.Parameters["oerr_flag"].Value.ToString();

                        if (basisResult.CompareTo("0") == 0)
                        {
                            subacct = Convert.ToInt32(oracomm.Parameters["out_sub_acct_code"].Value.ToString());
                            string acct = bra + "/" + cus + "/" + cur + "/" + led + "/" + subacct;
                            string nuban = this.ConvertToNuban(acct);

                            objResult.code = 1000;
                            objResult.message = acct + "|" + nuban;

                            string resultStans = string.Empty;
                            string firstDate = DateTime.Today.Date.ToString("ddMMMyyyy");

                            try
                            {
                                using (OracleCommand oracomm1 = new OracleCommand("eonepkg1.stan_ins_add", oraconn))
                                {
                                    oracomm1.CommandType = CommandType.StoredProcedure;
                                    oracomm1.CommandTimeout = 30;
                                    if (oraconn.State == ConnectionState.Closed)
                                    {
                                        oraconn.Open();
                                    }

                                    oracomm1.Parameters.Add("BRA", OracleType.Number).Value = bra;
                                    oracomm1.Parameters.Add("CUS", OracleType.Number).Value = cus;
                                    oracomm1.Parameters.Add("CUR", OracleType.Number).Value = cur;
                                    oracomm1.Parameters.Add("LED", OracleType.Number).Value = led;
                                    oracomm1.Parameters.Add("SUB", OracleType.Number).Value = subacct;
                                    oracomm1.Parameters.Add("NPAY_FREQ", OracleType.Number).Value = 1;
                                    oracomm1.Parameters.Add("DFST_PAY_DATE", OracleType.DateTime).Value = firstDate;
                                    oracomm1.Parameters.Add("NFST_PAY_AMT", OracleType.Number).Value = 0;
                                    oracomm1.Parameters.Add("DLAS_PAY_DATE", OracleType.DateTime).Value = "01JAN0001";
                                    oracomm1.Parameters.Add("SCRE_ACCT", OracleType.VarChar).Value = creditAcc;
                                    oracomm1.Parameters.Add("SREMARKS", OracleType.VarChar).Value = ConfigurationManager.AppSettings["GTC_BulkSett_StanInsAdd_Remarks"];
                                    oracomm1.Parameters.Add("npaytype", OracleType.Number).Value = 1;
                                    oracomm1.Parameters.Add("ntell_id", OracleType.Number).Value = tell_id;
                                    oracomm1.Parameters.Add("ninstrtype", OracleType.Number).Value = 3;

                                    oracomm1.Parameters.Add("RETURN_STATUS", OracleType.Number).Direction = ParameterDirection.Output;

                                    oracomm1.ExecuteNonQuery();
                                    resultStans = oracomm1.Parameters["RETURN_STATUS"].Value.ToString();

                                    ErrHandler.Log(classMeth, creditAcc, "eonepkg.stan_ins_add Response = " + resultStans);

                                    if (resultStans != "0")
                                    {
                                        objResult.code = 9999;
                                        objResult.message = acct + "|" + nuban;
                                        return objResult;
                                    }

                                    oraconn.Close();
                                }
                            }
                            catch (Exception ex)
                            {
                                ErrHandler.Log(classMeth, creditAcc, "ex ~~ " + ex.Message);
                            }

                            return objResult;
                        }
                        else
                        {
                            objResult.code = 1001;
                            objResult.message = basisResult;

                            return objResult;
                        }
                    }
                    catch (Exception ex1)
                    {
                        ErrHandler.Log(classMeth, creditAcc, "ex1 ~~ " + ex1.Message);
                        objResult.code = 1010;
                        objResult.message = "Failed: ex1 System error = " + ex1.Message.Replace("'", "");
                        return objResult;
                    }
                    finally
                    {
                        oraconn.Close();
                    }
                }
            }
        }
        catch (Exception ex2)
        {
            objResult.code = 1010;
            objResult.message = "Failed: ex2 System error = " + ex2.Message.Replace("'", "");
            return objResult;
        }
    }

    [WebMethod(Description = "Validates User Token. The response is an XML containing status code and description. Status 1000 is success")]
    public String CreateAdditionalSubAccount(int intBraCode, int intCusNum, int intCurCode, int intLedCode, int intTellerID, string strReason, Int64 intUserID, string strChannel, string strCreator, string strDocAlp)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.CreateAdditionalAccount(intBraCode, intCusNum, intCurCode, intLedCode, intTellerID, strReason, intUserID, strChannel, strCreator, strDocAlp);

        return ret_val;
    }

    [WebMethod(Description = "Validates if customer qualifies for loan, returns Status 1000, else 1000 if platinum 1 or 2 customer")]
    public string ValidateLoanMasCustomer(string bra_code, string cus_num, string loan_led)
    {
        String ret_val = null;
        BASIS basis = new BASIS();
        ret_val = basis.ValidateLoanMasCustomer(bra_code, cus_num, loan_led);

        return ret_val;

    }

    [WebMethod(Description = "Avail credit for qualifying customer. Status 1000 is success")]
    public string AvailRevolvingCredit(int bra_code, int cus_num, int cur_code, int led_code, int sub_acct_code, int tell_id, double rate, double bal_lim, string mat_date, string channel, string docAlp, string transUniqIndenf)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.AvailRevolvingCredit(bra_code, cus_num, cur_code, led_code, sub_acct_code, tell_id, rate, bal_lim, mat_date, channel, docAlp, transUniqIndenf);

        return ret_val;
    }


    [WebMethod]
    public String LogDispense(string bra_code, string cusnum, string curcode, string ledcode, string subacctcode, decimal trans_amt, decimal amt_disp, decimal amt_due, string transdate, string stan,
        string userid, int platform, string bank, string status, string errtype, string pan, string mercht, string settled, System.DateTime datelogged, string acctname,
        string smart_card_no, string phoneno, string network, string atmlocate, string atmbranch, string cusname, string benphone, string benacctno, string refid, int orig_bracode,
        string uptick)
    {
        Dispense dispense = new Dispense();
        string response = dispense.InsertDispenseRecord(bra_code, cusnum, curcode, ledcode, subacctcode, trans_amt, amt_disp, amt_due, transdate, stan,
            userid, platform, bank, status, errtype, pan, mercht, settled, datelogged, acctname,
            smart_card_no, phoneno, network, atmlocate, atmbranch, cusname, benphone, benacctno, refid, orig_bracode,
            uptick);
        return response;
    }

    [WebMethod]
    public String LogIntDispute(string bra_code, string cusnum, string cusname, string email, string phoneno, string curcode, string ledcode, string subacctcode, decimal trans_amt, string transdate,
        int channel, int cardtype, string pan, string stan, string mercht, int trans_type, decimal billamt, System.DateTime datelogged, int orig_bracode, int currency,
        int resolution, System.DateTime resolution_date, string tick, string ComplaintType, string GoodsDescription, string MerchantAttempt, string MerchantResolution)
    {
        Dispense dispense = new Dispense();
        string response = dispense.InternationalDispenseError(bra_code, cusnum, cusname, email, phoneno, curcode, ledcode, subacctcode, trans_amt, transdate,
             channel, cardtype, pan, stan, mercht, trans_type, Convert.ToInt32(billamt), datelogged, orig_bracode, currency,
             resolution, resolution_date, tick, ComplaintType, GoodsDescription, MerchantAttempt, MerchantResolution);
        return response;
    }

    [WebMethod]
    public String LogMobileMoney(string bra_code, string cusnum, string curcode, string ledcode, string subacctcode, decimal trans_amt, decimal amt_disp, decimal amt_due, string transdate, string stan,
        string userid, int platform, string bank, string status, string errtype, string pan, string mercht, string settled, System.DateTime datelogged, string acctname,
        string smart_card_no, string phoneno, string network, string atmlocate, string atmbranch, string cusname, string benphone, string benacctno, string refid, int orig_bracode,
        string uptick, string transdetail)
    {
        Dispense dispense = new Dispense();

        string response = dispense.InsertMobileMoney(bra_code, cusnum, curcode, ledcode, subacctcode, trans_amt, amt_disp, amt_due, transdate, stan,
            userid, platform, bank, status, errtype, pan, mercht, settled, datelogged, acctname, smart_card_no, phoneno, network, atmlocate, atmbranch,
            cusname, benphone, benacctno, refid, orig_bracode, uptick, transdetail);
        return response;
    }

    [WebMethod]
    public string NewCase_SMEHUB(string sessionid, string processid, string taskid, ParameterValue[] newcaseParameters)
    {
        try
        {
            string timeofintiation = string.Empty;
            variableListStruct[][] RTGSvariables = new variableListStruct[51][];
            //int noofvariables = 2;
            string message = string.Empty;
            string caseid = string.Empty;
            string caseNumber = string.Empty;
            ProcessMakerServiceSoapClient client = new ProcessMakerServiceSoapClient();
            variableListStruct[] sadvvariables = new variableListStruct[51];

            for (int noofvar = 0; noofvar <= newcaseParameters.Length - 1; noofvar += 1)
            {
                sadvvariables[noofvar] = new variableListStruct();
                sadvvariables[noofvar].name = newcaseParameters[noofvar].Name;
                sadvvariables[noofvar].value = newcaseParameters[noofvar].Value;
            }

            string version = string.Empty;
            string[] strArray = null;

            string sessionvar = client.newCase(sessionid, processid, taskid, sadvvariables, strArray, out message, out caseid, out caseNumber, out timeofintiation);
            client.Close();
            if (string.IsNullOrEmpty(caseNumber))
            {
                ErrHandler.WriteError("Error in creating ProcessMaker case : " + message);
                return string.Empty;
            }
            else
            {
                return caseNumber + "-" + caseid;
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Error occured during new ProcessMaker case creation " + ex.Message);
            return string.Empty;
        }
    }

    [WebMethod]
    public DataSet GetBillPaymentAgregatorByID(int AgreegatorID)
    {
        Eone fxstp = new Eone();

        DataSet ret_val = new DataSet();

        ret_val = fxstp.GetBillPaymentAgregatorByID(AgreegatorID);

        return ret_val;

    }

    [WebMethod]
    public DataSet CardTransactions(string bracode, string cus_num, string cur_code, string led_code, string sub_acct, string pan, DateTime begin, DateTime end, string status)
    {

        //DataSet resp = new DataSet();
        Cards card = new Cards();
        DataSet resp = card.CardTransactions(bracode, cus_num, cur_code, led_code, sub_acct, pan, begin, end, status);
        return resp;
    }


    [WebMethod]
    public ObjectResponse AccountupdateviaPM(string accountNo, string requesttype, string DOB, string Occupation, string marital, string address, string channel, string docIDs, string gender)
    {
        Eone rev = new Eone();
        ObjectResponse result = new ObjectResponse();
        result = rev.AccountupdateviaPM(accountNo, requesttype, DOB, Occupation, marital, address, channel, docIDs, gender);
        return result;
    }

    [WebMethod(Description = "Initiate Account Update Request2. The response is an XML containing status code and description. Status 1000 is success")]
    public String InitiateAccountUpdateRequest2(string RequestType, string FirstName, string LastName, string IDCard, string AddressLine1, string AddressLine2, string EmailAddress, string MobileNumber, string AccountNumber,
                                                  string UserID, string update_status, string MaritalStatus, string Occupation, string Gender, string DOB, string update_by)
    {

        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.InitiateAccountUpdateRequest2(RequestType, FirstName, LastName, IDCard, AddressLine1, AddressLine2, EmailAddress, MobileNumber, AccountNumber, UserID, update_status, MaritalStatus,
                                                              Occupation, Gender, DOB, update_by);
        return ret_val;
    }

    [WebMethod]
    public String TransferFunds_Cal(String Acct_fro, String Acct_to, Double Amount, String type, int EXPL_CODE, String channel, String Remarks, int origtbraCode, string docAlp, int supervisorID, int tellerID, string transUniqIndenf, string bankCode, string docNum, string inp_Period)
    {
        Eone eone = new Eone();
        String ret_val = null;

        ret_val = eone.TransferFunds_Cal(Acct_fro, Acct_to, Amount, type, channel, EXPL_CODE, Remarks, origtbraCode, docAlp, supervisorID, tellerID, transUniqIndenf, bankCode, docNum, inp_Period);

        return ret_val;
    }


    [WebMethod]
    public Int64 UpdateNIPTransactionForReversal(string sessionID, string userID, string batchID, string reversalType, DateTime dtReqDate)
    {
        GIRO giro = new GIRO();
        Int64 ret_val = giro.UpdateNIPTransactionForReversal(sessionID, userID, batchID, reversalType, dtReqDate);
        return ret_val;
    }

    [WebMethod]
    public DataSet GiroOutwardNIPRevReport(string sessionID, string dateFrom, string dateTo)
    {
        GIRO giro = new GIRO();
        DataSet ret_val = giro.GiroOutwardNIPRevReport(sessionID, dateFrom, dateTo);
        return ret_val;
    }

    [WebMethod]
    public DataSet ReturnNIPTransfersForApproval()
    {
        GIRO giro = new GIRO();
        DataSet ret_val = giro.ReturnNIPTransactionForApproval();
        return ret_val;
    }

    [WebMethod]
    public DataSet ReturnNIPTransfersForApprovalByBatchID(string batchID)
    {
        GIRO giro = new GIRO();
        DataSet ret_val = giro.ReturnNIPTransactionForApprovalByBatchID(batchID);
        return ret_val;
    }
    [WebMethod]
    public Int64 UpdateNIPTransactionsForApproval(string sessionID, string userID, int authorizationType)
    {
        GIRO giro = new GIRO();
        Int64 ret_val = giro.UpdateNIPTransactionsForApproval(sessionID, userID, authorizationType);
        return ret_val;
    }
    [WebMethod]
    public DataSet FirstLevelCheckTransactionsForReversals(string sessionID)
    {
        GIRO giro = new GIRO();
        DataSet ret_val = giro.FirstLevelCheckTransactionsForReversals(sessionID);
        return ret_val;
    }

    [WebMethod]
    public DataSet SecondLevelCheckTransactionsForReversals(string sessionID)
    {
        GIRO giro = new GIRO();
        DataSet ret_val = giro.SecondLevelCheckTransactionsForReversals(sessionID);
        return ret_val;
    }

    [WebMethod]
    public DataSet ReturnNIPBasisDebitTransactions(string bracode, string cusnum, string curcode, string ledcode, string subacctcode, string formattedDate, string sessionID)
    {
        GIRO giro = new GIRO();
        DataSet ret_val = new DataSet();
        ret_val.Tables.Add(giro.ReturnNIPBasisDebitTransactions(bracode, cusnum, curcode, ledcode, subacctcode, formattedDate, sessionID));
        return ret_val;
    }

    [WebMethod]
    public ObjectATMHotlist ATM_HotlistCard(string phone, string pin, string terminalId)
    {
        Eone eone = new Eone();
        ObjectATMHotlist obj = new ObjectATMHotlist();
        obj = eone.ATM_HotlistCard(phone, pin, terminalId);
        return obj;
    }

    [WebMethod]
    public DataSet FetchSMEMerchantDetail(string gtpayid)
    {
        DataSet resp = new DataSet();
        GTCollect gtcol = new GTCollect();
        resp = gtcol.GetsmehubMerchantdetails(gtpayid);
        return resp;
    }

    [WebMethod]
    public int creditCardEligibiltyCheck(string bra_code, string cus_num)
    {
        int ret_val = 0;
        BASIS basis = new BASIS();
        ret_val = basis.creditCardEligibiltyCheck(bra_code, cus_num);

        return ret_val;

    }

    [WebMethod]
    public string MaxAdvanceEligibityDetails(double intrate, string tenor, double monthSalAmount, double debitServiceRatio, string channel)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.MaxAdvanceEligibityDetails(intrate, tenor, monthSalAmount, debitServiceRatio, channel);

        return ret_val;
    }

    [WebMethod]
    public string APRandRepaymentAmountForMaxAdvance(double intrate, string tenor, double managementfee, double commitmentfee, double insurancerate, double loanAmt, string channel)
    {
        String ret_val = null;
        Eone eone = new Eone();
        ret_val = eone.APRandRepaymentAmountForMaxAdvance(intrate, tenor, managementfee, commitmentfee, insurancerate, loanAmt, channel);

        return ret_val;
    }

    [WebMethod]
    public string NewCasePM(string sessionid, string processid, string taskid, objectMultiSelect newcaseParameters)
    {
        try
        {
            int arrayLeng = newcaseParameters.sItem.Length;

            string timeofintiation = string.Empty;
            variableListStruct[][] RTGSvariables = new variableListStruct[arrayLeng][];
            //int noofvariables = 2;
            string message = string.Empty;
            string caseid = string.Empty;
            string caseNumber = string.Empty;
            ProcessMakerServiceSoapClient client = new ProcessMakerServiceSoapClient();
            variableListStruct[] sadvvariables = new variableListStruct[arrayLeng];

            for (int i = 0; i < arrayLeng; i++)
            {
                sadvvariables[i] = new variableListStruct();
                sadvvariables[i].name = newcaseParameters.sItem[i];
                sadvvariables[i].value = newcaseParameters.sValue[i];
            }

            string version = string.Empty;
            string[] strArray = null;

            string sessionvar = client.newCase(sessionid, processid, taskid, sadvvariables, strArray, out message, out caseid, out caseNumber, out timeofintiation);
            client.Close();
            if (string.IsNullOrEmpty(caseNumber))
            {
                ErrHandler.WriteError("Error in creating ProcessMaker case : " + message);
                return string.Empty;
            }
            else
            {
                return caseNumber + "-" + caseid;
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Error occured during new ProcessMaker case creation " + ex.Message);
            return string.Empty;
        }
    }

    [WebMethod]
    public DataTable GetExchangeRate()
    {
        DataTable returnDataTable = new DataTable();
        Eone tranx = new Eone();
        returnDataTable = tranx.getexchangerate();
        return returnDataTable;
    }



}



public class objectMultiSelect
{
    public string[] sItem;
    public string[] sValue;
}

public class SqlWebParameter
{
    public SqlWebParameter()
    {

    }

    public string ParameterName { get; set; }
    public string Value { get; set; }
}