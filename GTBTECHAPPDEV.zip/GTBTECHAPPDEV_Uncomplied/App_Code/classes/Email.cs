using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net.Mail;
using System.Net.Mime;
using System.IO;
using System.Net;

/// <summary>
/// Summary description for Email
/// </summary>
public class Email
{
    string emailFrom, emailServer, mPort, userName, password;
    MailMessage email1 = null;

	public Email()
	{
        emailFrom = ConfigurationManager.AppSettings["GTConnectSenderEmail"];
        emailServer = ConfigurationManager.AppSettings["EmailServer"];
        mPort = ConfigurationManager.AppSettings["EmailPort"];
        userName = ConfigurationManager.AppSettings["EmailUserName"];
        password = ConfigurationManager.AppSettings["EmailPassword"];
	}

    public string SendEmailUth(string sender, string recipient, string EmSuj, string EmMsg)
    {
        string sent = "Succeed";

        try
        {
            string emailServerA = ConfigurationManager.AppSettings["EmailServerUth"];
            string mPortA = ConfigurationManager.AppSettings["EmailPortUth"];

            SmtpClient sendmail = new SmtpClient();
            sendmail.UseDefaultCredentials = false;
            System.Net.NetworkCredential credentials = new System.Net.NetworkCredential();
            credentials.UserName = userName;
            credentials.Password = password;
            //sendmail.EnableSsl = true;
            sendmail.Credentials = credentials;
            sendmail.Host = emailServerA;
            sendmail.Port = Convert.ToInt16(mPortA);
            sendmail.Timeout = 500000;
            sendmail.Send(emailFrom, recipient, EmSuj, EmMsg);
            return sent;
        }
        catch (SmtpFailedRecipientException ex)
        {
            ErrHandler.WriteError(ex.Message);
            return ex.Message;
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message);
            return ex.Message;
        }
    }

    public string SendEmail(string sender, string recipient, string EmSuj, string EmMsg)
    {
        string sent = "Succeed";
        SmtpClient sendmail = new SmtpClient();
        try
        {
            sendmail.Host = emailServer;
            sendmail.Send(emailFrom, recipient, EmSuj, EmMsg);
            return sent;
        }
        catch (SmtpFailedRecipientException ex)
        {
            return ex.Message;
        }
        catch (Exception ex)
        {
            return ex.Message; 
        }
    }

    public string SendEmail(string sender, string recipient, string EmSuj, string EmMsg, string copy)
    {
        string sent = "Succeed";
        String[] emailarray;
        Char[] charsep = { ';' };

        SmtpClient sendmail = new SmtpClient();
        try
        {
            MailAddress from = new MailAddress(sender);

            email1 = new MailMessage();
            email1.From = from;

            MailAddress to = null; //= new MailAddress(recipient);
            if (recipient != "" & recipient != null)
            {
                emailarray = recipient.Split(charsep, StringSplitOptions.RemoveEmptyEntries);
                foreach (String entry in emailarray)
                {
                    to = new MailAddress(entry);
                    email1.To.Add(to);
                }
            }

            //email1 = new MailMessage(from, to);

            email1.Subject = EmSuj;
            email1.Body = EmMsg;

            MailAddress ccopy = null;
            if (copy != "")
            {
                emailarray = copy.Split(charsep, StringSplitOptions.RemoveEmptyEntries);
                foreach (String entry in emailarray)
                {
                    ccopy = new MailAddress(entry);
                    email1.CC.Add(ccopy);
                }
            }
            sendmail.Host = emailServer;
            sendmail.Port = Convert.ToInt16(mPort);

            sendmail.Send(email1);
            email1 = null;
            return sent;
        }
        catch (SmtpFailedRecipientException ex)
        {
            return ex.Message;
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
    }

    public string SendEmail_HTML(string sender, string recipient, string EmSuj, string EmMsg, string copy)
    {
        string sent = "Succeed";
        String[] emailarray;
        Char[] charsep = { ',' };
        SmtpClient sendmail = new SmtpClient();
        AlternateView altv;
        try
        {
            //MailAddress from = new MailAddress(emailFrom);
            MailAddress from = new MailAddress(sender);

            email1 = new MailMessage();
            email1.From = from;
            MailAddress to;

            recipient = recipient.Replace(";", ",");
            emailarray = recipient.Split(charsep, StringSplitOptions.RemoveEmptyEntries);
            foreach (String entry in emailarray)
            {
                to = new MailAddress(entry);
                email1.To.Add(to);
            }

            MailAddress ccopy;
            if (copy != "")
            {
                copy = copy.Replace(";", ",");
                emailarray = copy.Split(charsep, StringSplitOptions.RemoveEmptyEntries);
                foreach (String entry in emailarray)
                {
                    ccopy = new MailAddress(entry);
                    email1.CC.Add(ccopy);
                }
            }
            emailarray = null;

            email1.Subject = EmSuj;
            //email1.Body = EmMsg;
            altv = AlternateView.CreateAlternateViewFromString(EmMsg, null, MediaTypeNames.Text.Html);
            email1.AlternateViews.Clear();
            email1.AlternateViews.Add(altv);

            email1.IsBodyHtml = true;

            sendmail.Host = emailServer;
            sendmail.Port = Convert.ToInt16(mPort);

            sendmail.Send(email1);
            email1.Dispose();
            email1 = null;
            return sent;
        }
        catch (SmtpFailedRecipientException ex)
        {
            return ex.Message;
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
    }

    public String SendLoginMail(String cust_name, String cust_email)
    {
        String resp = "";
        String msgString = "Dear " + cust_name + "," + Environment.NewLine + Environment.NewLine;
        msgString = msgString + "GTBANK IVR LOG IN CONFIRMATION" + Environment.NewLine + Environment.NewLine;

        msgString = msgString + "Please be informed that you logged on to the IVR at " + DateTime.Now.ToString("hh:mm:ss tt, {p} MMMM dd, yyyy") + "." + Environment.NewLine + Environment.NewLine;
        msgString = msgString.Replace("{p}", "(GMT+1)");
        msgString = msgString + "If you did not log on to your internet banking profile at the time detailed above, please call " + "GTCONNECT; our 24 hour interactive contact centre on: +234 700 GTCONNECT, +234 700 482666328, +234 1 4602013, +234 80 3900 3900, +234 80 2900 2900 or send an email to e-fraudteam@gtbank.com immediately." + Environment.NewLine + Environment.NewLine + "Thank you for banking with us." + Environment.NewLine + Environment.NewLine + "Guaranty Trust Bank";

        resp = SendEmail("intops@gtbank.com", cust_email, "GTBANK IVR LOG IN CONFIRMATION", msgString, "");

        //resp = Emailer.SendMessage2(, msgString, "intops@gtbank.com", Session("Email").ToString(), "", "")
        //  If resp <> "True" Then
        //    ErrHandler.WriteError(txtUserName.Text & " : " & customerIP & "\n Login notification email was not sent. ")
        //End If

        return resp;
    }

    public string SendEmail_Attachment(string sender, string recipient, string EmSuj, string EmMsg, string copy, byte[] contentStream, string contentType, string fileName)
    {
        string sent = "Succeed";
        String[] emailarray;
        Char[] charsep = { ',' };
        SmtpClient sendmail = new SmtpClient();
        AlternateView altv;
        try
        {
            MailAddress from = new MailAddress(sender);
            Attachment attachment = new Attachment(new MemoryStream(contentStream), new ContentType(contentType));
            attachment.Name = fileName;

            email1 = new MailMessage();
            email1.From = from;
            MailAddress to;

            recipient = recipient.Replace(";", ",");
            emailarray = recipient.Split(charsep, StringSplitOptions.RemoveEmptyEntries);
            foreach (String entry in emailarray)
            {
                to = new MailAddress(entry);
                email1.To.Add(to);
            }

            MailAddress ccopy;
            if (copy != "")
            {
                copy = copy.Replace(";", ",");
                emailarray = copy.Split(charsep, StringSplitOptions.RemoveEmptyEntries);
                foreach (String entry in emailarray)
                {
                    ccopy = new MailAddress(entry);
                    email1.CC.Add(ccopy);
                }
            }
            emailarray = null;

            email1.Subject = EmSuj;
            //email1.Body = EmMsg;
            altv = AlternateView.CreateAlternateViewFromString(EmMsg, null, MediaTypeNames.Text.Html);
            email1.AlternateViews.Clear();
            email1.AlternateViews.Add(altv);
            email1.IsBodyHtml = true;
            email1.Attachments.Add(attachment);

            NetworkCredential credentials = new NetworkCredential(userName, password);
            sendmail.Credentials = credentials;

            string emailServerA = ConfigurationManager.AppSettings["EmailServerUth"];
            string mPortA = ConfigurationManager.AppSettings["EmailPortUth"];          
            sendmail.UseDefaultCredentials = false;
         
            credentials.UserName = userName;
            credentials.Password = password;
            //sendmail.EnableSsl = true;
            sendmail.Credentials = credentials;
            sendmail.Host = emailServerA;
            sendmail.Port = Convert.ToInt16(mPortA);
            sendmail.Timeout = 500000;


      //      sendmail.Host = emailServer;
            //sendmail.Port = Convert.ToInt16(mPort);
            sendmail.Send(email1);
            email1.Dispose();
            email1 = null;
            return sent;
        }
        catch (SmtpFailedRecipientException ex)
        {
            string message = ex.Message;
            if (ex.InnerException != null)
            {
                message = message + ";" + ex.InnerException.Message;
            }
            return message;
        }
        catch (Exception ex)
        {
            string message = ex.Message;
            if (ex.InnerException != null)
            {
                message = message + ";" + ex.InnerException.Message;
            }
            return message;
        }
    }

}