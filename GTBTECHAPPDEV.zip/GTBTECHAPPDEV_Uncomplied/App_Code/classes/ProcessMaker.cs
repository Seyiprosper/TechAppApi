﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Collections.Specialized;
using System.Web;
using System.ServiceModel;


public class ProcessMaker
    {
        //public class ProcessMaker
        //{
        //Transfer Transfer = new Transfer();

        ErrHandler ErrHandler = new ErrHandler();

        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }

        public string login()
        {
            try
            {
                //ServicePointManager.ServerCertificateValidationCallback = ServicePointManager.ServerCertificateValidationCallback + customXertificateValidation
                //ServicePointManager.ServerCertificateValidationCallback = AcceptAllCertifications;

                string sessionid = string.Empty;
                string version = string.Empty;
                string timeStamp = string.Empty;
                ProcessMakerServiceSoapClient client = new ProcessMakerServiceSoapClient();
                string pmusername = ConfigurationManager.AppSettings["PM_UserName"];
                string pmpassword = ConfigurationManager.AppSettings["PM_Password"];
                string sessionvar = client.login(pmusername, pmpassword, out sessionid, out version, out timeStamp);
                client.Close();
                if (sessionvar.Equals("0"))
                {
                    return sessionid;
                }
                else
                {
                    return string.Empty;
                }
                //client.Close();
            }
            catch (Exception ex)
            {
                ErrHandler.WriteError("Error occured during ProcessMaker Login " + ex.Message);
                return string.Empty;
            }            
        }

        public string newCase(string sessionid, ParameterValue[] newcaseParameters)
        {
            try
            {
                //string[] acctofficerdetails = Transfer.getAcctManagerDetails(HttpContext.Current.Session["From_AcctNo"].ToString().Replace("/", ","));
                //string[] acctnumberdetails = HttpContext.Current.Session["From_AcctNo"].ToString().Split("/");
                //SalaryAdvanceCls saldavdetails = default(SalaryAdvanceCls);
                //saldavdetails = (SalaryAdvanceCls)HttpContext.Current.Session["salaryadvval"];
                //string[] customerdetails = Transfer.ValidateAccount(HttpContext.Current.Session["From_AcctNo"].ToString());
                //string[] acctArray = cusAcctNum.Split('/');
                //string issueownerid = ConfigurationManager.AppSettings["PM_UserID"].ToString();
                string processid = ConfigurationManager.AppSettings["PM_ProcessID"].ToString();
                string taskid = ConfigurationManager.AppSettings["PM_TaskID"].ToString();
             //   NameValueCollection RTGSvalues = new NameValueCollection();

                //loanvalues.Add("acct_no", saldavdetails.AcctFrom)

                //RTGSvalues.Add("ttAmt", amount);
                //RTGSvalues.Add("ben_add", benAddress);
                //RTGSvalues.Add("bra_code", acctArray.GetValue(0).ToString());
                //RTGSvalues.Add("cus_num", acctArray.GetValue(1).ToString());
                //RTGSvalues.Add("cur_code", acctArray.GetValue(2).ToString());
                //RTGSvalues.Add("led_code", acctArray.GetValue(3).ToString());
                //RTGSvalues.Add("sub_acct_code", acctArray.GetValue(4).ToString());
                //RTGSvalues.Add("issueownerid", issueOwnerId);
                //RTGSvalues.Add("cus_name", companyName);
                //RTGSvalues.Add("ben_name", benName);
                //RTGSvalues.Add("bankbranch", benBank);
                //RTGSvalues.Add("acct_no", benAcctNo);                
                //RTGSvalues.Add("trans_type", "3");
                //RTGSvalues.Add("ValueDate", payDate);
                //RTGSvalues.Add("trans_mode", "GAPS");

                //RTGSvalues.Add("issueownerid_bk", issueownerid);
                //RTGSvalues.Add("emailAdd", HttpContext.Current.Session["Email"]);
                //RTGSvalues.Add("MobileNo", customerdetails(0));
                //RTGSvalues.Add("TelephoneHome", customerdetails(1));
                //RTGSvalues.Add("PerHomeAdd", customerdetails(2));
                //RTGSvalues.Add("crnt_bal", customerdetails(4));
                //RTGSvalues.Add("cle_bal", customerdetails(4));
                //loanvalues.Add("LMonthSal", saldavdetails.LastMonthSalary)             

                string timeofintiation = string.Empty;
                variableListStruct[][] RTGSvariables = new variableListStruct[51][];
                //int noofvariables = 2;
                string message = string.Empty;
                string caseid = string.Empty;
                string caseNumber = string.Empty;
                ProcessMakerServiceSoapClient client = new ProcessMakerServiceSoapClient();
                variableListStruct[] sadvvariables = new variableListStruct[51];

                for (int noofvar = 0; noofvar <= newcaseParameters.Length - 1; noofvar += 1)
                {
                    sadvvariables[noofvar] = new variableListStruct();
                    sadvvariables[noofvar].name = newcaseParameters[noofvar].Name;
                    sadvvariables[noofvar].value = newcaseParameters[noofvar].Value;
                }
                string version = string.Empty;
                string[] strArray = null;
                // Dim plist() As processListStruct = client.processList(sessionid)
                // Dim tlist() As taskListStruct = client.taskList(sessionid)
                // Dim trigerlist() As triggerListStruct = client.triggerList(sessionid)
                string sessionvar = client.newCase(sessionid, processid, taskid, sadvvariables, strArray, out message, out caseid, out caseNumber, out timeofintiation);
                client.Close();
                if (string.IsNullOrEmpty(caseNumber))
                {
                    ErrHandler.WriteError("Error in creating ProcessMaker case : " + message);
                    return string.Empty;
                }
                else
                {
                    return caseNumber + "-" + caseid;
                }
                //client.Close();
            }
            catch (Exception ex)
            {
                ErrHandler.WriteError("Error occured during new ProcessMaker case creation " + ex.Message);
                return string.Empty;
            }
        }

        public string SendVariables(string sessionid, string approvestate, string caseid)
        {
            try
            {
                NameValueCollection variables = new NameValueCollection();

                string message = string.Empty;
                //loanvalues.Add("acct_no", saldavdetails.AcctFrom)


                variables.Add("accountconfirm", approvestate);
                variables.Add("approveid", approvestate);

                ProcessMakerServiceSoapClient client = new ProcessMakerServiceSoapClient();
                variableListStruct[] updvariables = new variableListStruct[6];

                for (int noofvar = 0; noofvar <= variables.Count - 1; noofvar += 1)
                {
                    updvariables[noofvar] = new variableListStruct();
                    updvariables[noofvar].name = variables.GetKey(noofvar);
                    updvariables[noofvar].value = variables[noofvar].ToString();
                }
                string version = string.Empty;
                string dateString = string.Empty;
                string sessionvar = client.sendVariables(sessionid, caseid, updvariables, out message, out dateString);
                //.newCase(sessionid, "5008894154d8873245f3fd4051333932", "1598304844f83f4113e7b38049798834", sadvvariables, message, caseid, caseNumber, timeofintiation)
                if ((string.IsNullOrEmpty(message)))
                {
                    ErrHandler.WriteError("Error in Salary Advance Module : " + message);
                }
                client.Close();
                return caseid + "-" + message;
                
            }
            catch (Exception ex)
            {
                ErrHandler.WriteError("Error occured during send values to Processmaker " + ex.Message);
                return "";
            }
        }


        public string routeCase(string sessionid, string caseid, int delindex)
		{
			try 
            {
				ProcessMakerServiceSoapClient client = new ProcessMakerServiceSoapClient();
				string message = string.Empty;
				string timeofintiation = string.Empty;
				routeListStruct route = default(routeListStruct);
				routeListStruct[] routevariables = new routeListStruct[50];
				client.routeCase(sessionid, caseid, delindex.ToString(), out message, out timeofintiation, out routevariables);
				return message;

			} 
            catch (Exception ex) 
            {
				ErrHandler.WriteError("Error occured during ProcessMaker route Case " + ex.Message);
                return string.Empty;
			}            
		}

        public string login1()
        {
            try
            {
                //ServicePointManager.ServerCertificateValidationCallback = ServicePointManager.ServerCertificateValidationCallback + customXertificateValidation
                //ServicePointManager.ServerCertificateValidationCallback = AcceptAllCertifications;

                string sessionid = string.Empty;
                string version = string.Empty;
                string timeStamp = string.Empty;

                ProcessMakerServiceSoapClient client = new ProcessMakerServiceSoapClient();
                client.Endpoint.Address = new EndpointAddress(new Uri(ConfigurationManager.AppSettings["PMCIS"]), client.Endpoint.Address.Identity, client.Endpoint.Address.Headers);
                //client.Open();

                string pmusername = ConfigurationManager.AppSettings["PM_UserName"];
                string pmpassword = ConfigurationManager.AppSettings["PM_Password"];
                string sessionvar = client.login(pmusername, pmpassword, out sessionid, out version, out timeStamp);
                client.Close();
                if (sessionvar.Equals("0"))
                {
                    return sessionid;
                }
                else
                {
                    return string.Empty;
                }
                //client.Close();
            }
            catch (Exception ex)
            {
                ErrHandler.WriteError("Error occured during ProcessMaker Login " + ex.Message);
                return string.Empty;
            }
        }

        public string routeCase1(string sessionid, string caseid, int delindex)
        {
            try
            {
                ProcessMakerServiceSoapClient client = new ProcessMakerServiceSoapClient();
                client.Endpoint.Address = new EndpointAddress(new Uri(ConfigurationManager.AppSettings["PMCIS"]), client.Endpoint.Address.Identity, client.Endpoint.Address.Headers);
                client.Open();
                string message = string.Empty;
                string timeofintiation = string.Empty;
                routeListStruct route = default(routeListStruct);
                routeListStruct[] routevariables = new routeListStruct[50];
                client.routeCase(sessionid, caseid, delindex.ToString(), out message, out timeofintiation, out routevariables);
                return message;

            }
            catch (Exception ex)
            {
                ErrHandler.WriteError("Error occured during ProcessMaker route Case " + ex.Message);
                return string.Empty;
            }
        }

        public string newCase1(string sessionid, ParameterValue[] newcaseParameters)
        {
            try
            {
                string processid = ConfigurationManager.AppSettings["AcctUpdatePM_ProcessID"].ToString();
                string taskid = ConfigurationManager.AppSettings["AcctUpdatePM_TaskID"].ToString();

                string timeofintiation = string.Empty;
                variableListStruct[][] RTGSvariables = new variableListStruct[51][];
                //int noofvariables = 2;
                string message = string.Empty;
                string caseid = string.Empty;
                string caseNumber = string.Empty;

                ProcessMakerServiceSoapClient client = new ProcessMakerServiceSoapClient();
                client.Endpoint.Address = new EndpointAddress(new Uri(ConfigurationManager.AppSettings["PMCIS"]), client.Endpoint.Address.Identity, client.Endpoint.Address.Headers);
                //client.Open();
                variableListStruct[] sadvvariables = new variableListStruct[51];

                for (int noofvar = 0; noofvar <= newcaseParameters.Length - 1; noofvar += 1)
                {
                    sadvvariables[noofvar] = new variableListStruct();
                    sadvvariables[noofvar].name = newcaseParameters[noofvar].Name;
                    sadvvariables[noofvar].value = newcaseParameters[noofvar].Value;
                }
                string version = string.Empty;
                string[] strArray = null;

                string sessionvar = client.newCase(sessionid, processid, taskid, sadvvariables, strArray, out message, out caseid, out caseNumber, out timeofintiation);
                client.Close();

                if (string.IsNullOrEmpty(caseNumber))
                {
                    ErrHandler.WriteError("Error in creating ProcessMaker case : " + message);
                    return string.Empty;
                }
                else
                {
                    return caseNumber + "-" + caseid;
                }
            }
            catch (Exception ex)
            {
                ErrHandler.WriteError("Error occured during new ProcessMaker case creation " + ex.Message);
                return string.Empty;
            }
        }


    }
    

