﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Response
/// </summary>
public class ObjectResponse
{
    public Int16 code;
    public string message = string.Empty;
    public string smsStatus = string.Empty;
}

public class Object737GiveCat
{
    public Int16 code = 0;
    public string message = string.Empty;
    public string formtitle = string.Empty;
    public string[] category = null;
}

public class ObjectATMHotlist
{
    public Int16 code = 0;
    public string message = string.Empty;
}