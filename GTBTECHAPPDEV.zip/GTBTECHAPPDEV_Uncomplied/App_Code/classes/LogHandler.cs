﻿using System;
using System.Data;
using System.Configuration;
using System.IO;
using System.Globalization;
using System.Diagnostics;
using System.Web;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
/// <summary>
/// Summary description for ErrHandler
/// Handles error by acception the error message
/// Displays the page on which the error occured
/// </summary>
/// 
//namespace RelationshipLetterMailer
//{
    public class LogHandler
    {
        public LogHandler()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public  void WriteLog(string Message, string emailtype)
        {       
            try
            {
                string errorpath = HttpContext.Current.Server.MapPath("~/Error/" + DateTime.Today.ToString("dd-MM-yy"));

                if (!Directory.Exists(errorpath))
                {
                    Directory.CreateDirectory(errorpath);
                }


                string path = errorpath + "/" + emailtype + ".txt";// StartUpPath + "/Logs/" + DateTime.Today.ToString("dd-MM-yy") + "-" + emailtype + ".txt";
                if (!File.Exists((Path.GetFullPath(path))))
                {
                    File.CreateText(path);
                }
                using (StreamWriter w = File.AppendText(path))
                {
                    w.Write("\r\nLog Entry : :");
                    w.Write("{0}", DateTime.Now.ToString(CultureInfo.InvariantCulture));
                    //w.WriteLine(ui.customername); 
                    //string err = "Error in: " + System.Web.HttpContext.Current.Request.Url.ToString() + ". Error Message:" + errorMessage;
                    w.WriteLine("-:-" + Message);
                    // w.WriteLine("_______________________________________");
                    w.Flush();
                    w.Close();
                }
            }
            catch (Exception ex)
            {
              // WriteLog(ex.Message, emailtype);
            }
        }
    }
//}