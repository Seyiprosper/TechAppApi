using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Security.Cryptography;
using System.IO;
using System.Text;

/// <summary>
/// Summary description for Encryption
/// </summary>
public class Encryption
{
	public Encryption()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public string EncryptPIN(string plainMessage, string key)
    {
        TripleDESCryptoServiceProvider des;
        PasswordDeriveBytes pdb;
        MemoryStream ms;
        CryptoStream encStream;

        try
        {
            des = new TripleDESCryptoServiceProvider();

            des.IV = new byte[8];

            pdb = new PasswordDeriveBytes(key, new byte[0]);

            des.Key = pdb.CryptDeriveKey("RC2", "MD5", 128, new byte[8]);

            ms = new MemoryStream(plainMessage.Length * 2);

            encStream = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write);

            byte[] plainBytes = Encoding.UTF8.GetBytes(plainMessage);

            encStream.Write(plainBytes, 0, plainBytes.Length);

            encStream.FlushFinalBlock();

            byte[] encryptedBytes = new byte[ms.Length];

            ms.Position = 0;

            ms.Read(encryptedBytes, 0, (int)ms.Length);

            encStream.Close();

            return Convert.ToBase64String(encryptedBytes);
        }
        catch (Exception ex)
        {
            return ex.Message;
        }

    }

    public string DecryptPIN(string encryptedBase64, string key)
    {
        TripleDESCryptoServiceProvider des;
        PasswordDeriveBytes pdb;
        MemoryStream ms;
        CryptoStream decStream;

        try
        {
            des = new TripleDESCryptoServiceProvider();

            des.IV = new byte[8];

            pdb = new PasswordDeriveBytes(key, new byte[0]);

            des.Key = pdb.CryptDeriveKey("RC2", "MD5", 128, new byte[8]);

            byte[] encryptedBytes = Convert.FromBase64String(encryptedBase64);

            ms = new MemoryStream(encryptedBase64.Length);

            decStream = new CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Write);

            decStream.Write(encryptedBytes, 0, encryptedBytes.Length);

            decStream.FlushFinalBlock();

            byte[] plainBytes = new byte[ms.Length];

            ms.Position = 0;

            ms.Read(plainBytes, 0, (int)ms.Length);

            decStream.Close();

            return Encoding.UTF8.GetString(plainBytes);
        }
        catch(Exception ex)
        {
            return ex.Message;
        }
    }

    public String DecryptData(String datavalue, String key)
    {
        String ret_val = null;
        Encryption enc = new Encryption();
        ret_val = enc.DecryptPIN(datavalue, key);

        return ret_val;
    }

    public String EncryptData(String datavalue, String key)
    {
        String ret_val = null;
        Encryption enc = new Encryption();
        ret_val = enc.EncryptPIN(datavalue, key);

        return ret_val;
    }

}
