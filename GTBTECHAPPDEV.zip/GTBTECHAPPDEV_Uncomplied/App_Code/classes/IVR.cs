using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net.Sockets;
using System.IO;

/// <summary>
/// Summary description for IVR
/// </summary>
public class IVR
{
    private String xmlstring = null;
    private String serverip, serverport;
	public IVR()
	{
        serverip = "10.2.34.10";
        serverport = "9000";
	}

    public String SendCTIMessage(String ivrinfostr, String chanidstr)
    {
        String message = null;
        long epochtime = (DateTime.Now.ToUniversalTime().Ticks - 621355968000000000) / 10000000;

        try
        {
            // Create a TcpClient.
            // Note, for this client to work you need to have a TcpServer 
            // connected to the same address as specified by the server, port
            // combination.
            //Int32 port = 13000;
            TcpClient client = new TcpClient(serverip, Convert.ToInt32(serverport));

            // Translate the passed message into ASCII and store it as a Byte array.
            message = "CHANID:" + chanidstr + ";";
            message = message + "TYPE:" + "E" + ";";
            message = message + "TIME:" + epochtime.ToString() + ";";
            message = message + ivrinfostr;

            Byte[] data = System.Text.Encoding.ASCII.GetBytes(message);

            // Get a client stream for reading and writing.
            //  Stream stream = client.GetStream();

            NetworkStream stream = client.GetStream();

            // Send the message to the connected TcpServer. 
            stream.Write(data, 0, data.Length);

            xmlstring = xmlstring + "<CODE>1000</CODE>";
            xmlstring = xmlstring + "</MESSAGE>SUCCESS</MESSAGE>";

            // Receive the TcpServer.response.

            //// Buffer to store the response bytes.
            //data = new Byte[256];

            //// String to store the response ASCII representation.
            //String responseData = String.Empty;

            //// Read the first batch of the TcpServer response bytes.
            //Int32 bytes = stream.Read(data, 0, data.Length);
            //responseData = System.Text.Encoding.ASCII.GetString(data, 0, bytes);
            //txt_log.Text = txt_log.Text + "Received: " + responseData + "\n";

            //txt_response.Text = responseData;
            // Close everything.
            stream.Close();
            client.Close();
        }
        catch (ArgumentNullException e)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + e.Message.Replace("'", "") + "</Error>";
        }
        catch (SocketException e)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + e.Message.Replace("'", "") + "</Error>";
        }

        xmlstring = xmlstring + "</Response>";
        return xmlstring;
    }

    public String SendCTIStartMessage(String chanidstr)
    {
        String message = null;
        long epochtime = (DateTime.Now.ToUniversalTime().Ticks - 621355968000000000) / 10000000;
        DateTime dt = DateTime.Now;
        String datestr = dt.Year.ToString().PadLeft(4, '0') + dt.Month.ToString().PadLeft(2, '0') + dt.Day.ToString().PadLeft(2, '0');

        try
        {
            // Create a TcpClient.
            // Note, for this client to work you need to have a TcpServer 
            // connected to the same address as specified by the server, port
            // combination.
            //Int32 port = 13000;
            TcpClient client = new TcpClient(serverip, Convert.ToInt32(serverport));

            // Translate the passed message into ASCII and store it as a Byte array.
            message = "CHANID:" + chanidstr + ";";
            message = message + "TYPE:" + "S" + ";";
            message = message + "TIME:" + epochtime.ToString() + ";";
            message = message + "DATE:" + datestr + ";";

            Byte[] data = System.Text.Encoding.ASCII.GetBytes(message);

            // Get a client stream for reading and writing.
            //  Stream stream = client.GetStream();

            NetworkStream stream = client.GetStream();

            // Send the message to the connected TcpServer. 
            stream.Write(data, 0, data.Length);

            xmlstring = xmlstring + "<CODE>1000</CODE>";
            xmlstring = xmlstring + "</MESSAGE>SUCCESS</MESSAGE>";

            // Receive the TcpServer.response.

            //// Buffer to store the response bytes.
            //data = new Byte[256];

            //// String to store the response ASCII representation.
            //String responseData = String.Empty;

            //// Read the first batch of the TcpServer response bytes.
            //Int32 bytes = stream.Read(data, 0, data.Length);
            //responseData = System.Text.Encoding.ASCII.GetString(data, 0, bytes);
            //txt_log.Text = txt_log.Text + "Received: " + responseData + "\n";

            //txt_response.Text = responseData;
            // Close everything.
            stream.Close();
            client.Close();
        }
        catch (ArgumentNullException e)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + e.Message.Replace("'", "") + "</Error>";
        }
        catch (SocketException e)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + e.Message.Replace("'", "") + "</Error>";
        }

        xmlstring = xmlstring + "</Response>";
        return xmlstring;
    }
}
