﻿using GTBEncryptLibrary;
using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Xml;
using System.Xml.XPath;

/// <summary>
/// Summary description for IRequest
/// </summary>
public class IRequest
{
    Eone eone = new Eone();
    string xmlstring = string.Empty;
    BASIS basis = new BASIS();
    ChequeRequest chqRequest = new ChequeRequest();
	public IRequest()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public DataSet RetrieveOrangLocBranches(string status)
    {

        String user_email = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds = new DataSet();
        SqlDataAdapter adpt;
        String proc = "";

        try
        {

            proc = "usp_OrangLocBranch_Retrieve";

            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }


            comm = new SqlCommand(proc, conn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.AddWithValue("@Status", status);

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);

            adpt.Fill(ds);

        }
        catch (Exception ex)
        {

            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
            ds = null;
        }

        return ds;
    }


    public string CheckOrangeLocBranchProfile(int bracode)
    {

        String profiled = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        // string bracode, cusnum;


        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("Select OrangeLockerEnabled from branches where Branch_Code = @bracode ", conn);
            comm.CommandType = CommandType.Text;
            comm.Parameters.AddWithValue("@bracode", bracode);

            comm.CommandType = CommandType.Text;
            SqlDataReader rdr = comm.ExecuteReader();

            if (rdr.HasRows)
            {
                rdr.Read();
                profiled = rdr["IRequestEnabled"].ToString();
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
        }

        return profiled;
    }



    public String OrangeLocBranchProfile(int bracode, string userid, string status)
    {

        String user_email = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataTable dt = null;
        string ProfiledStatus = "";
        // string bracode, cusnum;


        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            ProfiledStatus = CheckOrangeLocBranchProfile(bracode);
            if (!String.IsNullOrEmpty(ProfiledStatus))
            {
                if (status.Trim().ToUpper().Equals("A"))
                {
                    if (ProfiledStatus.Trim().ToUpper().Equals("A"))
                    {
                        xmlstring = "<Response>";
                        xmlstring = xmlstring + "<CODE>1001</CODE>";
                        xmlstring = xmlstring + "<Error>Branch " + bracode.ToString() + " has been profiled already for I-Require</Error>";
                        xmlstring = xmlstring + "</Response>";
                        return xmlstring;
                    }
                }
                if (status.Trim().ToUpper().Equals("I"))
                {
                    if (ProfiledStatus.Trim().ToUpper().Equals("I"))
                    {
                        xmlstring = "<Response>";
                        xmlstring = xmlstring + "<CODE>1001</CODE>";
                        xmlstring = xmlstring + "<Error>Branch " + bracode.ToString() + " has been disabled already for I-Require</Error>";
                        xmlstring = xmlstring + "</Response>";
                        return xmlstring;
                    }
                }
            }

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("usp_OrangeLocBranch_Profile", conn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.AddWithValue("@branchcode", bracode);
            comm.Parameters.AddWithValue("@Status", status);

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            dt = new DataTable();
            adpt.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "</Response>";

                if (status.Trim().ToUpper().Equals("A"))
                {
                    //Int16 userid2 = Convert.ToInt16(userid);
                    Audit(userid, "Profile", "Profiled Branch " + bracode.ToString() + " as an IRequire Branch");
                }
                if (status.Trim().ToUpper().Equals("I"))
                {
                   // Int16 userid2 = Convert.ToInt16(userid);
                    Audit(userid, "Disable", "Disabled Branch " + bracode.ToString() + " as an IRequire Branch");
                }

            }

        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
        }

        return xmlstring;
    }

    public string InsertIRequest(int bracode, int cusnum, string CusName, decimal TransactionAmt, string remarks, string pan, int NoOfLeaves, string ChargeAcct,
        string StmtAcct, string StDate, string EnDate, int NoOfCopies, int ReqType, string requestID, int PreferredBranch, string InitiatedBy,
        string pickby, string Idmeans, string channel, string docalp, string PickName, List<StatementRequest> lstStatementRequest, string Pickupmethod)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        BASIS basis = new BASIS();

        string iReqAcct = ConfigurationManager.AppSettings["IREQ_ACCT"].ToString();
        double ChrgeAmt = Convert.ToDouble(ConfigurationManager.AppSettings["IREQ_CHARGE"].ToString());
        int maxNoForBranch = Convert.ToInt16(ConfigurationManager.AppSettings["IREQ_BRA_COUNT"]);

        string accountexist = string.Empty;
        string accountreffred = string.Empty;
        string res = string.Empty;
        string xmlstring = string.Empty;
        int pickTime = 0;
        DateTime? StartDate = null;
        DateTime? EndDate = null;
        string role_sla = string.Empty;
        DateTime? ApptTime = null;
        string qury = string.Empty;
        string retcode = string.Empty;
        string blkmess = string.Empty;
        string blkresponse = string.Empty;
        int blqcode = 0;
        string reqTypeName = string.Empty;

        try
        {
            DataTable dtSlaDetails = RetrieveSLADetails(ReqType);
            if (dtSlaDetails != null && dtSlaDetails.Rows.Count > 0)
            {
                pickTime = dtSlaDetails.Rows[0]["SLA"] == DBNull.Value ? 0 : Convert.ToInt16(dtSlaDetails.Rows[0]["SLA"]);
                role_sla = dtSlaDetails.Rows[0]["Role_Enabled"] == DBNull.Value ? "NO" : dtSlaDetails.Rows[0]["Role_Enabled"].ToString();
                reqTypeName = dtSlaDetails.Rows[0]["RequestType"] == DBNull.Value ? "" : dtSlaDetails.Rows[0]["RequestType"].ToString();
            }
            else
            {
                ErrHandler.WriteError("Unable to retrieve SLA Details for Request Type: " + ReqType);
                xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1090</CODE>";
                xmlstring = xmlstring + "<Error>Unable to complete Request. Please try again later!</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }


            if (ReqType.ToString().Trim().Equals("1"))//Cash Withdrawal
            {
                if (string.IsNullOrEmpty(CusName) || string.IsNullOrEmpty(TransactionAmt.ToString()) || string.IsNullOrEmpty(ChargeAcct))
                {
                    xmlstring = "<Response>";
                    xmlstring = xmlstring + "<CODE>1090</CODE>";
                    xmlstring = xmlstring + "<Error>Please check that the Beneficiary Name or Transaction Amount or Account to Debit is not empty</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }
                if (pickby.Trim().ToUpper().Equals("THIRD-PARTY") && (TransactionAmt > 150000))
                {
                    xmlstring = "<Response>";
                    xmlstring = xmlstring + "<CODE>1090</CODE>";
                    xmlstring = xmlstring + "<Error>Transaction Amount for third-party collection cannot be greater than N150,000</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }
                else if (TransactionAmt > 1000000)
                {
                    xmlstring = "<Response>";
                    xmlstring = xmlstring + "<CODE>1090</CODE>";
                    xmlstring = xmlstring + "<Error>Transaction Amount Cannot Be Greater than N1,000,000</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }
            }

            if (ReqType.ToString().Trim().Equals("2")) //Statement Request
            {
                if (lstStatementRequest != null && lstStatementRequest.Count > 0)
                {
                    foreach (StatementRequest stmtRequest in lstStatementRequest)
                    {
                        if (string.IsNullOrEmpty(stmtRequest.AccountNumber) || string.IsNullOrEmpty(stmtRequest.DateFrom) || string.IsNullOrEmpty(stmtRequest.DateTo) || string.IsNullOrEmpty(stmtRequest.NoOfCopies.ToString()))
                        {
                            xmlstring = "<Response>";
                            xmlstring = xmlstring + "<CODE>1090</CODE>";
                            xmlstring = xmlstring + "<Error>Please check all entries.  Charge Account or Statement Account or Start Date or End Date or Number of copies cannot be empty</Error>";
                            xmlstring = xmlstring + "</Response>";
                            return xmlstring;
                        }

                        if (stmtRequest.NoOfCopies < 1)
                        {
                            xmlstring = "<Response>";
                            xmlstring = xmlstring + "<CODE>1090</CODE>";
                            xmlstring = xmlstring + "<Error>Number of Copies cannot be less than one</Error>";
                            xmlstring = xmlstring + "</Response>";
                            return xmlstring;
                        }

                        StartDate = Convert.ToDateTime(stmtRequest.DateFrom);
                        EndDate = Convert.ToDateTime(stmtRequest.DateTo);
                        if (StartDate > DateTime.Today)
                        {
                            xmlstring = "<Response>";
                            xmlstring = xmlstring + "<CODE>1090</CODE>";
                            xmlstring = xmlstring + "<Error>Start Date Cannot be greater than today</Error>";
                            xmlstring = xmlstring + "</Response>";
                            return xmlstring;
                        }

                        if (EndDate > DateTime.Today)
                        {
                            xmlstring = "<Response>";
                            xmlstring = xmlstring + "<CODE>1090</CODE>";
                            xmlstring = xmlstring + "<Error>Please check all entries. End Date Cannot be greater than today</Error>";
                            xmlstring = xmlstring + "</Response>";
                            return xmlstring;
                        }

                        if (StartDate > EndDate)
                        {
                            xmlstring = "<Response>";
                            xmlstring = xmlstring + "<CODE>1090</CODE>";
                            xmlstring = xmlstring + "<Error>Please check all entries. Start Date Cannot be greater than End Date </Error>";
                            xmlstring = xmlstring + "</Response>";
                            return xmlstring;
                        }

                    }
                }
                else
                {
                    xmlstring = "<Response>";
                    xmlstring = xmlstring + "<CODE>1090</CODE>";
                    xmlstring = xmlstring + "<Error>Please check all entries.  Charge Account or Statement Account or Start Date or End Date or Number of copies cannot be empty</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }
            }

            if (ReqType.ToString().Trim().Equals("3")) //Statement Request
            {
                if (string.IsNullOrEmpty(ChargeAcct) || string.IsNullOrEmpty(CusName))
                {
                    xmlstring = "<Response>";
                    xmlstring = xmlstring + "<CODE>1090</CODE>";
                    xmlstring = xmlstring + "<Error>Please check that the Charge Account or Customer Name is not empty</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }
                pickTime = 1;
            }

            if (ReqType.ToString().Trim().Equals("4"))// Card Collection
            {
                if (string.IsNullOrEmpty(CusName))
                {
                    xmlstring = "<Response>";
                    xmlstring = xmlstring + "<CODE>1090</CODE>";
                    xmlstring = xmlstring + "<Error>Please check that the Card Holder Name or Pan is not empty</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }
            }

            if (ReqType.ToString().Trim().Equals("5"))//Cheque book Collection
            {
                if (string.IsNullOrEmpty(CusName))
                {
                    xmlstring = "<Response>";
                    xmlstring = xmlstring + "<CODE>1090</CODE>";
                    xmlstring = xmlstring + "<Error>Please check that the Customer's Name or Number of leaves is not empty</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }
            }


            if (string.IsNullOrEmpty(PreferredBranch.ToString()))
            {
                xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1090</CODE>";
                xmlstring = xmlstring + "<Error>Preferred Branch Cannot be Empty.</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            if (PreferredBranch < 200) //
            {
                xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1090</CODE>";
                xmlstring = xmlstring + "<Error>Invalid Branch Code</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            if (string.IsNullOrEmpty(InitiatedBy))
            {
                xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1090</CODE>";
                xmlstring = xmlstring + "<Error>Initiator cannot be empty</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            if (string.IsNullOrEmpty(pickby))
            {
                xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1090</CODE>";
                xmlstring = xmlstring + "<Error>Pick Up By value cannot be empty</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            if (!pickby.Trim().ToUpper().Equals("SELF"))
            {
                if (string.IsNullOrEmpty(Idmeans))
                {
                    xmlstring = "<Response>";
                    xmlstring = xmlstring + "<CODE>1090</CODE>";
                    xmlstring = xmlstring + "<Error>Means of Identification cannot be empty</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }
            }

            if (role_sla.Trim().ToUpper().Equals("NO"))
            {
                DateTime newDate = DateTime.Now;
                ApptTime = newDate.AddHours(pickTime);
            }


            if (IsNoInBranchAboveMaxNo(ApptTime, PreferredBranch, maxNoForBranch) == true)
            {
                if (ReqType == 2)//for statement only
                {
                    xmlstring = "<Response>";
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>Slot filled for Pick up time for your Preferred Branch. Please choose another Branch</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }
                else
                {
                    ApptTime = ApptTime.Value.AddHours(1);
                }
            }

            string[] chrgAcct = ChargeAcct.Trim().Split('/');
            int bcode = Convert.ToInt32(chrgAcct[0].ToString());
            int CNum = Convert.ToInt32(chrgAcct[1].ToString());
            int Curcode = Convert.ToInt32(chrgAcct[2].ToString());
            int LedCode = Convert.ToInt32(chrgAcct[3].ToString());
            int SubAcct = Convert.ToInt32(chrgAcct[4].ToString());

            //check if account is funded first!
            DataSet dsFund = new DataSet();
            DataTable dtFund = new DataTable();
            double amt = 0;
            dsFund = basis.ExecuteBasisQuery(GTBEncryptLib.EncryptText(string.Format("select navailbal({0},{1},{2},{3},{4}) from dual", bcode, CNum, Curcode, LedCode, SubAcct)), 1);
            if (dsFund != null && dsFund.Tables.Count > 0)
            {
                dtFund = dsFund.Tables[0];
                double availBal = Convert.ToDouble(dtFund.Rows[0][0]);
                amt = ReqType == 1 ? ChrgeAmt + Convert.ToDouble(TransactionAmt) : ChrgeAmt;

                if (availBal < amt)
                {
                    xmlstring = xmlstring + "<Response>";
                    xmlstring = xmlstring + "<CODE>1090</CODE>";
                    xmlstring = xmlstring + "<Error>Account is not funded for this transaction!</Error>";
                    xmlstring = xmlstring + "</Response>";
                    ErrHandler.WriteError(string.Format("IRequire: {0} with available balance:{1} not funded for {2}", ChargeAcct, availBal, amt));
                    return xmlstring;
                }
            }

            if (ReqType == 1)
            {
                string rs = "";

                string[] details = null;
                string blockFundCode = ConfigurationManager.AppSettings["IREQ_BLOCKFUND_CODE"];
                rs = basis.BlockFunds_PM(bcode.ToString(), CNum.ToString(), Curcode.ToString(), LedCode.ToString(), SubAcct.ToString(), "I-REQUIRE CASH WITHDRAWAL", TransactionAmt.ToString(), ApptTime.Value.ToString(), "9938", "1", blockFundCode);
                ErrHandler.WriteError("iRequire -> Block fund response for Acct: " + ChargeAcct + "==>" + rs);
                if (!string.IsNullOrEmpty(rs))
                {
                    blkresponse = tokenresult(rs);
                }
                if (blkresponse != "1000")
                {
                    xmlstring = xmlstring + "<Response>";
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>Unable to complete request. Please try again later!</Error>";
                    xmlstring = xmlstring + "</Response>";
                    //ErrHandler.WriteError("An Error Occurred; Could Not Place A Block for the amount specified");
                    return xmlstring;
                }
                if (blkresponse == "1000")
                {
                    blkmess = tokenMess(rs);
                }
                details = blkmess.Trim().Split('-');
                blqcode = Convert.ToInt32(details[1].ToString());
            }

            if (ChrgeAmt > 0)
            {
                string chgRmrk = string.IsNullOrEmpty(reqTypeName) ? "IRequire Charge" : string.Format("IRequire Charge for {0}", reqTypeName);

                res = eone.TransferFunds_TranSeqCommit(ChargeAcct, iReqAcct, ChrgeAmt, "COMM", "IREQ", 44, chgRmrk, 999, "IREQ", 0, 9938, "");

                retcode = tokenresult(res);
                if (retcode != "1000")
                {
                    xmlstring = xmlstring + "<Response>";
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    if (res.ToLower().Contains("restriction"))
                    {
                        xmlstring = xmlstring + "<Error>Unable to complete request. Account has restrictions!</Error>";
                    }
                    else
                        xmlstring = xmlstring + "<Error>Your account could not be charged for this transaction!</Error>";

                    xmlstring = xmlstring + "</Response>";
                    ErrHandler.WriteError(string.Format("IRequire: {0} ==> Response from Posting Charges:{1}", ChargeAcct, retcode));


                    //IF ITS CASH WITHDRAWAL
                    if (ReqType == 1)
                    {
                        int blkResult = basis.DeleteBlockImmediate(bracode, cusnum, Curcode, LedCode, SubAcct, blqcode, Convert.ToDouble(TransactionAmt), 9938);
                        ErrHandler.WriteError(string.Format("Response releasing funds ==> {0} due to unable to debit IRequire customer with Acct ==> {1}/{2}/{3}/{4}/{5}", blkResult, bracode, cusnum, Curcode, LedCode, SubAcct));
                    }
                    return xmlstring;
                }
            }


            using (conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {
                //open connection
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                comm = new SqlCommand("usp_IRequestInsert", conn);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@BranchCode", bracode);
                comm.Parameters.AddWithValue("@CustomerNo", cusnum);
                comm.Parameters.AddWithValue("@Customer_Name", CusName);
                comm.Parameters.AddWithValue("@Transaction_Amount", TransactionAmt);
                comm.Parameters.AddWithValue("@Remarks", remarks);
                comm.Parameters.AddWithValue("@Pan", pan);
                comm.Parameters.AddWithValue("@NoOfLeaves", NoOfLeaves);
                comm.Parameters.AddWithValue("@ChargeAccount", ChargeAcct);
                comm.Parameters.AddWithValue("@Statement_Account", StmtAcct);
                comm.Parameters.AddWithValue("@Start_Date", StartDate);
                comm.Parameters.AddWithValue("@End_Date", EndDate);
                comm.Parameters.AddWithValue("@NoOfCopies", NoOfCopies);
                comm.Parameters.AddWithValue("@Request_Type", ReqType);
                comm.Parameters.AddWithValue("@Preferred_Branch", PreferredBranch);
                comm.Parameters.AddWithValue("@Appointment_Time", ApptTime);
                comm.Parameters.AddWithValue("@PickUp_By", pickby);
                comm.Parameters.AddWithValue("@meansID", Idmeans);
                comm.Parameters.AddWithValue("@PickUp_Name", PickName);
                comm.Parameters.AddWithValue("@Initiated_By", InitiatedBy);
                comm.Parameters.AddWithValue("@Channel", channel);
                comm.Parameters.AddWithValue("@DocAlp", docalp);
                comm.Parameters.AddWithValue("@BlkSeq", blqcode);
                comm.Parameters.AddWithValue("@RequestID", requestID);
                comm.Parameters.AddWithValue("@Pickup_Method", Pickupmethod);

                adpt = new SqlDataAdapter(comm);
                ds = new DataSet();
                adpt.Fill(ds);
            }

            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                Int64 ireqID = Convert.ToInt64(ds.Tables[0].Rows[0]["ID"]);
                if (ReqType == 2) //STATEMENT
                {
                    //then insert for each in the db, statementbyemail and statement class
                    foreach (StatementRequest stmtRequest in lstStatementRequest)
                    {
                        try
                        {
                            insertIRequestStatementDetails(ireqID, stmtRequest.AccountNumber, Convert.ToDateTime(stmtRequest.DateFrom), Convert.ToDateTime(stmtRequest.DateTo), stmtRequest.NoOfCopies);
                            // insertIntoStatementTable(stmtRequest.AccountNumber, ChargeAcct, Convert.ToDateTime(stmtRequest.DateFrom), Convert.ToDateTime(stmtRequest.DateTo), DateTime.Now,
                            // PreferredBranch.ToString(), CusName, "IBANK", "", "PENDING", stmtRequest.NoOfCopies, 2, 0, 0, pickby, PickName, Idmeans, "");
                        }
                        catch (Exception ex)
                        {
                            ErrHandler.WriteError(string.Format("Error inserting statement request. Error =={0}; Source ==> {1}; Stack Trace =={2}", ex.Message, ex.Source, ex.StackTrace));
                        }
                    }
                }

                else if (ReqType == 5) //chequebook
                {
                    string userID = string.Empty;
                    if (pickby.ToLower() == "third-party")
                    {
                        try
                        {
                            string branchResult = eone.GetBranchInfo(PreferredBranch.ToString());
                            string code = tokenresult(branchResult);
                            string branchName = PreferredBranch.ToString();
                            if (code == "1000")
                            {
                                branchName = branchName + " - " + brancMess(branchResult);
                            }
                            chqRequest.saveChequeThirdPartyPickup(InitiatedBy, ChargeAcct, requestID, branchName, PickName, Idmeans);
                        }
                        catch (Exception ex)
                        {
                            ErrHandler.WriteError(string.Format("Error inserting statement request. Error =={0}; Source ==> {1}; Stack Trace =={2}", ex.Message, ex.Source, ex.StackTrace));
                        }
                    }
                }
                if (Pickupmethod == "0")
                {
                    xmlstring = xmlstring + "<CODE>1000</CODE>";
                    xmlstring = xmlstring + "<REFCODE>" + ireqID.ToString() + "</REFCODE>";
                    xmlstring = xmlstring + string.Format("<MESSAGE>Your request has been successfully submitted. Reference Code:{0}. Your pick up time is: {1}</MESSAGE>", ireqID, ApptTime.Value.ToString("dd-MMM-yyyy hh:mm tt"));

                }
                else
                {
                    xmlstring = xmlstring + "<CODE>1000</CODE>";
                    xmlstring = xmlstring + "<REFCODE>" + ireqID.ToString() + "</REFCODE>";
                    xmlstring = xmlstring + string.Format("<MESSAGE>Your request has been successfully submitted. Reference Code:{0}. You would be notified once your item has been deposited</MESSAGE>", ireqID);

                }
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "0" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";

            if (role_sla.Trim().ToUpper().Equals("NO"))
            {
                //Send email to customer and referree       
                SendNotification(ReqType, ApptTime.Value.ToString("dd-MMM-yyy hh:mm tt"), Convert.ToInt32(ds.Tables[0].Rows[0]["ID"].ToString()), bracode, cusnum, PreferredBranch, role_sla, Pickupmethod);
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>Unable to complete request. Please try again later!</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }


    string returnIRequestType(int reqType)
    {
        string result = "";
        string query = "select RequestType from irequest_category where Request_ID = @reqID";
        using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
        {
            if (sqlConn.State != ConnectionState.Open)
            {
                sqlConn.Open();
            }

            SqlCommand comm = new SqlCommand(query, sqlConn);
            comm.CommandType = CommandType.Text;

            comm.Parameters.AddWithValue("@reqID", reqType);
            SqlDataReader reader = comm.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    result = reader[0] == DBNull.Value ? "" : reader[0].ToString();

                }
            }
            return result;
        }
    }

    void insertIRequestStatementDetails(Int64 IrequestID, string statementAccNumber, DateTime dateFrom, DateTime dateTo, int noOfCopies)
    {
        using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
        {
          if (sqlConn.State != ConnectionState.Open)
            {
                sqlConn.Open();
            }

          SqlCommand comm = new SqlCommand("usp_InsertIRequestStatementDetails", sqlConn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.AddWithValue("@IRequestID", IrequestID);
            comm.Parameters.AddWithValue("@Statement_Account", statementAccNumber);
            comm.Parameters.AddWithValue("@Start_Date", dateFrom);
            comm.Parameters.AddWithValue("@End_Date", dateTo);
            comm.Parameters.AddWithValue("@NoOfCopies", noOfCopies);

            int result = comm.ExecuteNonQuery();
        }

    }

    Int64 insertIntoStatementTable(string acct, string acctToDebit, DateTime  startDate, DateTime endDate, DateTime requestDate, string pickupBranch, 
        string userName, string source, string notificationEmail, string status, int noOfCopies, int noOfPages, decimal amtCharged, decimal charged
        , string proxyby, string proxyName, string idType, string generatedCode)
    {
        Int64 result = 0;
        string query = @"Insert into PrintStmtRequest(Account, Acccounttodebit, Startdate, Enddate, Branch, RequestDate, Username,Source,
        NotificationEmailAddress,Status,NoOfCopies,NoOfPages,AmountCharged,Charged,Proxy_By,Proxy_Name,ID_Type,Generated_code)
       values (@Account, @Acccounttodebit, @Startdate, @Enddate, @Branch, @RequestDate, @Username, @Source,
        @NotificationEmailAddress, @Status, @NoOfCopies, @NoOfPages, @AmountCharged, @Charged, @Proxy_By, @Proxy_Name, @ID_Type, @Generated_code)";
        using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["GtmailConnString"].ToString()))
        {
          if (sqlConn.State != ConnectionState.Open)
            {
                sqlConn.Open();
            }

          using (SqlCommand comm1 = new SqlCommand(query, sqlConn))
          {
              comm1.CommandType = CommandType.Text;
              comm1.Parameters.Clear();
              comm1.Parameters.AddWithValue("@Account", acct);
              comm1.Parameters.AddWithValue("@Acccounttodebit", acctToDebit);
              comm1.Parameters.AddWithValue("@Startdate", startDate);
              comm1.Parameters.AddWithValue("@Enddate", endDate);
              comm1.Parameters.AddWithValue("@Branch", pickupBranch);
              comm1.Parameters.AddWithValue("@RequestDate", requestDate);
              comm1.Parameters.AddWithValue("@Username", userName);
              comm1.Parameters.AddWithValue("@Source", source);
              comm1.Parameters.AddWithValue("@NotificationEmailAddress", "");
              comm1.Parameters.AddWithValue("@Status", status);
              comm1.Parameters.AddWithValue("@NoOfCopies", noOfCopies);
              comm1.Parameters.AddWithValue("@NoOfPages", noOfPages);
              comm1.Parameters.AddWithValue("@Charged", charged);
              comm1.Parameters.AddWithValue("@AmountCharged", amtCharged);
              comm1.Parameters.AddWithValue("@Proxy_By", proxyby);
              comm1.Parameters.AddWithValue("@Proxy_Name", proxyName);
              comm1.Parameters.AddWithValue("@ID_Type", idType);
              comm1.Parameters.AddWithValue("@Generated_code", generatedCode);

              result = comm1.ExecuteNonQuery();
          }
        }

        return result;
    }

    public DataSet ReturnIrequestStatements(long IRequestID)
    {
        DataSet dtStatment = new DataSet();
        try
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {
                //open connetion
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                using (SqlCommand comm = new SqlCommand("proc_uspIRequestStatementRetrieve", conn))
                {
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@IRequestID", IRequestID);
                    SqlDataAdapter adpt = new SqlDataAdapter(comm);
                    adpt.Fill(dtStatment);
                }
            }
        }
        catch (Exception ex)
        {

        }
        return dtStatment;
    }

    public string CancelIRequest(long RefCode, String update_by, int bracode, int cusnum, string reason, string cancel_channel)
    {
        String user_email = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        int Curcode = 0; int LedCode = 0; int SubAcct = 0; int reqType = 0;
        int prefbranch = 0;
        string remarks = ""; string chargeAcct = "";
        Int32 blockFundSeq = 0; double transAmt = 0;
        string RequestType = string.Empty;
        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
            //open connection
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("usp_IRequestUpdate_Cancel", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@Id", RefCode);
            comm.Parameters.AddWithValue("@BranchCode", bracode);
            comm.Parameters.AddWithValue("@CustomerNo", cusnum);
            comm.Parameters.AddWithValue("@Cancelled_By", update_by);
            comm.Parameters.AddWithValue("@cancel_channel", cancel_channel);
            comm.Parameters.AddWithValue("@Reason", reason);

            comm.CommandType = CommandType.StoredProcedure;
            string i = comm.ExecuteScalar().ToString();
            xmlstring = "<Response>";


            if (i == RefCode.ToString())
            {
                DataSet dsResult = ReturnIRequestByRefCode(RefCode);
                DataTable dtResult = new DataTable();
                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    dtResult = dsResult.Tables[0];
                    reqType = Convert.ToInt32(dtResult.Rows[0]["Request_type"]);
                    RequestType = dtResult.Rows[0]["RequestType"].ToString();
                    bracode = Convert.ToInt32(dtResult.Rows[0]["BranchCode"]);
                    cusnum = Convert.ToInt32(dtResult.Rows[0]["CustomerNo"]);
                    blockFundSeq = dtResult.Rows[0]["BloqSeq"] == DBNull.Value ? 0: Convert.ToInt32(dtResult.Rows[0]["BloqSeq"]);
                    chargeAcct = dtResult.Rows[0]["ChargeAccount"].ToString();
                    transAmt = Convert.ToDouble(dtResult.Rows[0]["Transaction_Amount"]);
                    prefbranch = Convert.ToInt32(dtResult.Rows[0]["Preferred_Branch"]);
                }


                if (reqType == 1) //cash withdrawal
                {
                    string[] chrgAcct = chargeAcct.Trim().Split('/');
                    bracode = Convert.ToInt32(chrgAcct[0].ToString());
                    cusnum = Convert.ToInt32(chrgAcct[1].ToString());
                    Curcode = Convert.ToInt32(chrgAcct[2].ToString());
                    LedCode = Convert.ToInt32(chrgAcct[3].ToString());
                    SubAcct = Convert.ToInt32(chrgAcct[4].ToString());

                    //Unblock the funds in the customer's account
                    int blkResult = basis.DeleteBlockImmediate(bracode, cusnum, Curcode, LedCode, SubAcct, blockFundSeq, transAmt, 9938);
                    ErrHandler.WriteError(string.Format("Response releasing funds on IRequire cancellation ==> {0} for Acct ==> {1}/{2}/{3}/{4}/{5}", blkResult, bracode, cusnum, Curcode, LedCode, SubAcct));
                }

                if (cancel_channel.ToLower() == "ibank")
                {
                    SendCancelByCustNotification(RequestType, RefCode, bracode, cusnum, prefbranch, reason);
                }

                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<REFCODE>" + i + "</REFCODE>";
                xmlstring = xmlstring + "<MESSAGE>Your request has been successfully cancelled.</MESSAGE>";
            }
            else if (i.Equals("0"))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>CODE DOES NOT EXIST</Error>";
            }
            else if (i.Equals("2"))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>CODE HAS BEEN USED</Error>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Error cancelling IRequire requests ==> " + ex.Message + ex.StackTrace);
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE><Error>Unable to cancel Request. Please try again later</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public string tokenresult(string tokenval)
    {
        tokenval = tokenval.ToUpper().Replace("&", "&amp;");
        string retcode;
        XmlDocument document = default(XmlDocument);
        XPathNavigator navigator = default(XPathNavigator);
        XPathNodeIterator snodes = default(XPathNodeIterator);
        //   XmlDocument document = 
        document = new XmlDocument();
        document.LoadXml(tokenval);
        navigator = document.CreateNavigator();

        //xmlstring = xmlstring + "<CODE>1000</CODE>";
        snodes = navigator.Select("/RESPONSE/CODE");
        snodes.MoveNext();
        retcode = snodes.Current.Value;
        return retcode;
    }

    public string tokenMess(string tokenval)
    {
        tokenval = tokenval.ToUpper().Replace("&", "&amp;");
        string retcode;
        XmlDocument document = default(XmlDocument);
        XPathNavigator navigator = default(XPathNavigator);
        XPathNodeIterator snodes = default(XPathNodeIterator);
        //   XmlDocument document = 
        document = new XmlDocument();
        document.LoadXml(tokenval);
        navigator = document.CreateNavigator();

        //xmlstring = xmlstring + "<CODE>1000</CODE>";
        snodes = navigator.Select("/RESPONSE/MESSAGE");
        snodes.MoveNext();
        retcode = snodes.Current.Value;
        return retcode;
    }

    public string brancMess(string tokenval)
    {
        tokenval = tokenval.ToUpper().Replace("&", "&amp;");
        string retcode;
        XmlDocument document = default(XmlDocument);
        XPathNavigator navigator = default(XPathNavigator);
        XPathNodeIterator snodes = default(XPathNodeIterator);
        //   XmlDocument document = 
        document = new XmlDocument();
        document.LoadXml(tokenval);
        navigator = document.CreateNavigator();

        //xmlstring = xmlstring + "<CODE>1000</CODE>";
        snodes = navigator.Select("/RESPONSE/BRANCH_NAME");
        snodes.MoveNext();
        retcode = snodes.Current.Value;
        return retcode;
    }

    public string AcknowledgeIRequest(long RefCode, String update_by, int bracode, int cusnum, int reqtype, int sla, int prefbranch, String tokenVal)
    {
        String user_email = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        string status = string.Empty;
     // string bracode, cusnum;

        DataSet dsResult = ReturnIRequestByRefCode(RefCode);
        DataTable dtResult = new DataTable();
        if (dsResult != null && dsResult.Tables.Count > 0)
        {
            dtResult = dsResult.Tables[0];
            status = dtResult.Rows[0]["Status"] == DBNull.Value? string.Empty: dtResult.Rows[0]["Status"].ToString();

            if (status.ToLower() == "cancelled")
            {
                xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Transaction has already been cancelled!</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }
        }

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("usp_IRequestUpdate_Acknowledge", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@Id", RefCode);
            comm.Parameters.AddWithValue("@BranchCode", bracode);
            comm.Parameters.AddWithValue("@CustomerNo", cusnum);
            comm.Parameters.AddWithValue("@tokenVal", tokenVal);
            comm.Parameters.AddWithValue("@Acknowledged_By", update_by);

            comm.CommandType = CommandType.StoredProcedure;
            string i = comm.ExecuteScalar().ToString();
            xmlstring = "<Response>";

            if (i == RefCode.ToString())
            {

                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<REFCODE>" + i + "</REFCODE>";
                //SendNotificationOpsHead(reqtype, RefCode, bracode, cusnum, update_by, prefbranch);  
            }
            else if (i.Equals("0"))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "CODE DOES NOT EXIST" + "</Error>";
            }
            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public string ConfirmsIRequest(int reqtype, long RefCode, String update_by, string tellerTill, int opsHeadBraCode, int tellerBasisID, int supervisorBasisID)
    {
        int bracode = 0; int cusnum = 0; int Curcode = 0; int LedCode = 0; int SubAcct = 0;
        int prefbranch =0;
        String user_email = ""; string remarks = ""; string chargeAcct = ""; string status = ""; 
        string cusName = string.Empty;
        Int32 blockFundSeq = 0; double transAmt = 0;
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DateTime apptTime = new DateTime();
        xmlstring = "<Response>";

        try
        {
            DataSet dsResult = ReturnIRequestByRefCode(RefCode);
            DataTable dtResult = new DataTable();
            if(dsResult != null && dsResult.Tables.Count > 0)
            {
                dtResult = dsResult.Tables[0];
                bracode = Convert.ToInt32(dtResult.Rows[0]["BranchCode"]);
                cusnum = Convert.ToInt32(dtResult.Rows[0]["CustomerNo"]);
                //custName = dtResult.Rows[0]["Customer_Name"].ToString();
                prefbranch  = Convert.ToInt32(dtResult.Rows[0]["Preferred_Branch"]);
                remarks = dtResult.Rows[0]["Remarks"].ToString();
                blockFundSeq = Convert.ToInt32(dtResult.Rows[0]["BloqSeq"]);
                chargeAcct= dtResult.Rows[0]["ChargeAccount"].ToString();
                transAmt = Convert.ToDouble(dtResult.Rows[0]["Transaction_Amount"]);
                apptTime = Convert.ToDateTime(dtResult.Rows[0]["Appointment_Time"]);
                status = dtResult.Rows[0]["Status"] == DBNull.Value ? string.Empty : dtResult.Rows[0]["Status"].ToString();
                cusName = dtResult.Rows[0]["Customer_Name"] == DBNull.Value ? string.Empty : dtResult.Rows[0]["Customer_Name"].ToString();

                if (status.ToLower() == "cancelled")
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>Transaction has already been cancelled!</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }
            }
             
            if (reqtype == 1)
            {
                string[] chrgAcct = chargeAcct.Trim().Split('/');
                string[] tellerAcct = tellerTill.Trim().Split('/');
                bracode = Convert.ToInt32(chrgAcct[0].ToString());
                cusnum = Convert.ToInt32(chrgAcct[1].ToString());
                Curcode = Convert.ToInt32(chrgAcct[2].ToString());
                LedCode = Convert.ToInt32(chrgAcct[3].ToString());
                SubAcct = Convert.ToInt32(chrgAcct[4].ToString());

                //Unblock the funds in the customer's account first
                int blkResult = basis.DeleteBlockImmediate(bracode, cusnum, Curcode, LedCode, SubAcct, blockFundSeq, transAmt, 9938);

                remarks = string.IsNullOrEmpty(remarks) ? string.Format("Cash withdrawal - {0}", cusName) : string.Format("{0} - {1}", remarks, cusName);
               
                if (blkResult == 0)
                {
                    string t_to = tellerAcct[0].PadLeft(4, '0') + tellerAcct[1].PadLeft(7, '0') + tellerAcct[2].PadLeft(3, '0') + tellerAcct[3].PadLeft(4, '0') + tellerAcct[4].PadLeft(3, '0');
                    string t_from = chrgAcct[0].PadLeft(4, '0') + chrgAcct[1].PadLeft(7, '0') + chrgAcct[2].PadLeft(3, '0') + chrgAcct[3].PadLeft(4, '0') + chrgAcct[4].PadLeft(3, '0');

                    string postResult = eone.TransferFunds_TranSeqCommit(chargeAcct, tellerTill, transAmt, "COMM", "IREQ", 2, remarks, opsHeadBraCode, "IREQ", supervisorBasisID, tellerBasisID, RefCode.ToString()); 

                     string retcode = tokenresult(postResult);
                     if (retcode != "1000")
                     {
                         //block funds again
                         string blkresponse = string.Empty;
                         string blkmess = string.Empty;
                         string[] details = null;
                         int blqcode = 0;
                         string blockFundCode = ConfigurationManager.AppSettings["IREQ_BLOCKFUND_CODE"];
                         string rs = basis.BlockFunds_PM(chrgAcct[0], chrgAcct[1], chrgAcct[2], chrgAcct[3], chrgAcct[4], "I-REQUIRE CASH WITHDRAWAL", transAmt.ToString(), apptTime.Date.ToString(), "9938", "1", blockFundCode);
                         ErrHandler.WriteError("IRequire -> Block fund response for Acct: " + chargeAcct + "==>" + rs);
                         if (!string.IsNullOrEmpty(rs))
                         {
                             blkresponse = tokenresult(rs);
                         }

                         if (blkresponse == "1000")
                         {
                             blkmess = tokenMess(rs);
                         }
                         details = blkmess.Trim().Split('-');
                         blqcode = Convert.ToInt32(details[1].ToString());

                         //then update the table
                         UpdateBlockSeq(RefCode, blqcode);

                         //then update the sequence on basis
                         xmlstring = xmlstring + "<CODE>1001</CODE>";
                         xmlstring = xmlstring + string.Format("<Error>IRequire->Unable to debit Customer. Reason:{0}!</Error></Response>", postResult);
                         return xmlstring;
                     }                   
                }
                else
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    if (blkResult == 3523)
                    {
                        xmlstring = xmlstring + "<Error>Error! Unable to unblock funds. Block does not exist!</Error></Response>";
                    }
                    else
                        xmlstring = xmlstring + string.Format("<Error>Error! Unable to unblock funds. Reason:{0}!</Error></Response>", blkResult);
                    return xmlstring;
                }               
            }
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("usp_IRequestUpdate_Confirm", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@Id", RefCode);
            comm.Parameters.AddWithValue("@BranchCode", bracode);
            comm.Parameters.AddWithValue("@CustomerNo", cusnum);
            comm.Parameters.AddWithValue("@Confirmed_By", update_by);

            comm.CommandType = CommandType.StoredProcedure;
            string i = comm.ExecuteScalar().ToString();

            xmlstring = "<Response>";


            if (i == RefCode.ToString())
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<REFCODE>" + i + "</REFCODE>";
                //send mail to teller
                if (reqtype == 1)
                {
                    SendNotificationToTeller(RefCode, cusName, tellerBasisID, transAmt, chargeAcct);
                }
                // SendNotificationOpsHead(reqtype, RefCode, bracode, cusnum, update_by, prefbranch);
            }
            else if (i.Equals("0"))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "CODE DOES NOT EXIST" + "</Error>";
            }
            else if (i.Equals("2"))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "CODE HAS BEEN USED" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public DataTable RetriveIRequest_Branch(int branch, int request_type)
    {
        String user_email = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataTable dt = null;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("usp_IRequestSelect_Branch", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@branch", branch);
            comm.Parameters.AddWithValue("@reqtype", request_type);
          
            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            dt = new DataTable();
            adpt.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                return dt;
            }
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
        }
        return dt;
    }

    public DataSet RetreiveIRequest_UserID(int branch, int cusnum)
    {

        String user_email = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds = new DataSet();
        SqlDataAdapter adpt;
        DataTable dt = null;
        // string bracode, cusnum;
        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("usp_IRequestSelect_UserID", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@branchcode", branch);
            comm.Parameters.AddWithValue("@cusnum", cusnum);

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            
            adpt.Fill(ds);
            return ds;
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
        }

        return ds;
    }

    public DataSet RetreiveIRequest_ByDate(int branch, int cusnum, DateTime fromdate, DateTime todate)
    {
        String user_email = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds = new DataSet();
        SqlDataAdapter adpt;
        DataTable dt = null;
        try
        {
            
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("usp_IRequestSelect_ByDate", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@branchcode", branch);
            comm.Parameters.AddWithValue("@cusnum", cusnum);
            comm.Parameters.AddWithValue("@fromdate", fromdate);
            comm.Parameters.AddWithValue("@todate", todate);

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);

            adpt.Fill(ds);
            return ds;
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
        }

        return ds;
    }

    public string CheckSLA(int reqtype)
    {

        String sla_Role = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        // string bracode, cusnum;
        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("Select Role_Enabled from IRequest_Category where Request_ID = @reqtype ", conn);
            comm.CommandType = CommandType.Text;
            comm.Parameters.AddWithValue("@reqtype", reqtype);
           
            comm.CommandType = CommandType.Text;
            SqlDataReader rdr = comm.ExecuteReader();

            if (rdr.HasRows)
            {
                rdr.Read();
                sla_Role = rdr["Role_Enabled"].ToString();
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
        }

        return sla_Role;
    }

    public DataTable RetrieveSLADetails(int reqtype)
    {
        DataTable dtResult = new DataTable();
        // string bracode, cusnum;
        try
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {
                //open connetion
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }
                SqlCommand comm = new SqlCommand("Select * from IRequest_Category where Request_ID = @reqtype", conn);
                comm.CommandType = CommandType.Text;
                comm.Parameters.AddWithValue("@reqtype", reqtype);

                comm.CommandType = CommandType.Text;
                SqlDataAdapter adpt = new SqlDataAdapter(comm);
                adpt.Fill(dtResult);
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
        }

        return dtResult;
    }

    public String GetOpsHeadMail(string username, int branch)
    {
        String sla_Role = "";
        string opsHeadRole = ConfigurationManager.AppSettings["OPS_HEAD_ROLE"].ToString();
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        string res = "";
        string query = "";
        try
        {
            if (string.IsNullOrEmpty(username))
            {
                query = string.Format("select email from admin_users where branch_code = {0} and status = 'A' and role_id = {1}", branch, opsHeadRole);
                
            }
            else
            {
                query = string.Format("select email from admin_users where branch_code = {0} and user_id = {1} and role_id = {2}", branch, username, opsHeadRole);
            }
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand(query, conn);
            comm.CommandType = CommandType.Text;;
            SqlDataReader rdr = comm.ExecuteReader();

            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    res = res + "," + rdr["email"].ToString();
                }

                res = res.TrimStart(new char[] { ',' });
            }

        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
        }
        return res;
    }

    public bool CheckDuplicate(string query)
    {
        String sla_Role = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        bool res = false;
        // string bracode, cusnum;


        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand(query, conn);
            comm.CommandType = CommandType.Text;
           

            comm.CommandType = CommandType.Text;
            SqlDataReader rdr = comm.ExecuteReader();

            if (rdr.HasRows)
            {
                res = true;

            }
            else
            {
                res = false;
            }


        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
        }

        return res;
    }

    public bool IsNoInBranchAboveMaxNo(DateTime? dt, int prefBranch, int maxNo)
    {
        bool res = false;
        int rs = 0;
        DataTable dtCount = new DataTable();
        try
        {
               // string query = "select count(request_Type) from Irequest where Preferred_Branch = @prefBranch and Appointment_Time = @AppointmentTime and status in ('PENDING', 'ACKNOWLEDGED')";
                //"select count(request_Type) from Irequest where Preferred_Branch = "+ prefBranch  +" and Appointment_Time = "'+ dt + '" and status in ('PENDING', 'ACKNOWLEDGED')";
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {
                //open connetion
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }
                SqlCommand comm = new SqlCommand("usp_IRequestBranchCount", conn);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@prefBranch", prefBranch);
                comm.Parameters.AddWithValue("@AppointmentTime", dt.Value.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                SqlDataAdapter adpt = new SqlDataAdapter(comm);
                adpt.Fill(dtCount);

                if (dtCount != null && dtCount.Rows.Count > 0)
                {
                    int Count = dtCount.Rows[0]["NoInHour"] == DBNull.Value ? 0 : Convert.ToInt32(dtCount.Rows[0]["NoInHour"]);
                    if (Count >= maxNo)
                    {
                        res = true;
                    }
                }
                //rs = (int)comm.ExecuteScalar();
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
        }

        return res;
    }

    public void SendNotificationToTeller(long refcode, string cusName, int basisID, double transAmt, string custAcctNo)
    {
        string userName = string.Empty;
        string tellerEmail = string.Empty;
        StringBuilder strBuilder = new StringBuilder();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {
                string query = "select user_id, email from admin_users where basis_id = @basisID";
                if (sqlConn.State == ConnectionState.Closed)
                {
                    sqlConn.Open();
                }
                
                SqlCommand comm = new SqlCommand(query, sqlConn);
                comm.CommandType = CommandType.Text;
                comm.Parameters.AddWithValue("@basisID", basisID);

                SqlDataReader reader = comm.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        userName = reader["user_id"] == DBNull.Value ? string.Empty : reader["user_id"].ToString();
                        tellerEmail = reader["email"] == DBNull.Value ? string.Empty : reader["email"].ToString();
                    }
                }


                if (!string.IsNullOrEmpty(tellerEmail))
                {
                    String mailfrom = ConfigurationManager.AppSettings["SenderEmail"].ToString();
                    string subject = string.Format("NOTIFICATION OF IREQUIRE CASH WITHDRAWAL FOR {0}", cusName.ToUpper());

                    strBuilder.AppendLine(string.Format("Dear {0},</br><br/>", userName.Replace(".", " ").ToUpper()));
                    strBuilder.AppendLine("Funds for IRequire Cash Withdrawal has been posted to your Till with the following details <br/><br/>");
                    strBuilder.AppendLine(string.Format("Customer Name: {0} <br/><br/>", cusName));
                    strBuilder.AppendLine(string.Format("Customer Account Number: {0} <br/><br/>", custAcctNo));
                    strBuilder.AppendLine(string.Format("Amount: {0} <br/><br/>", transAmt));
                    strBuilder.AppendLine(string.Format("Request Code: {0} <br/><br/>", refcode));
                    strBuilder.AppendLine("Best regards.");

                    Email email = new Email();
                    string resp = email.SendEmail_HTML(mailfrom, tellerEmail, subject, strBuilder.ToString(), "");
                }
                else
                {
                    ErrHandler.WriteError(string.Format("Error sending IRequire Mail for basisID {0}. No email was retrieved", basisID));
                }
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(string.Format("Error sending IRequire Mail to teller: {0}. Error =={1}; Source ==> {2}; Stack Trace =={3}", basisID, ex.Message, ex.Source, ex.StackTrace));
        }
    }

    public void SendNotification(int reqtype, string apTime, long refcode, int bracode, int cusnum, int prefbranch, string roleb, string Pickupmethod)
    {
        try
        {
            string emailCC = ConfigurationManager.AppSettings["IREQ_CC_EMAIL"].ToString();
            String mailfrom = ConfigurationManager.AppSettings["IREQ_SENDER_EMAIL"].ToString();

            OracleCommand cmd = null;
            Email email = new Email();
            OracleDataReader reader;
            String custEmail = "";
            string opheadmail = "";

            string name = string.Empty;
            DataTable dt;
            string[] cusNameAndEmail = getCustomerNameAndEmail(bracode, cusnum);
            if (cusNameAndEmail != null)
            {
                custEmail = cusNameAndEmail[0];
                name = cusNameAndEmail[1];
            }

            dt = RetreiveIRequest_ID(refcode, reqtype, bracode, cusnum);
            if (dt != null && dt.Rows.Count > 0)
            {
                opheadmail = GetOpsHeadMail(string.Empty, prefbranch);
                string custEmailBody = string.Empty;
                string notificationEmailBody = "";
                string mailsubject = "";
                if (Pickupmethod == "0")
                {

                    custEmailBody = custEmailBody + "Dear " + name + ",</br></br>";//Environment.NewLine + Environment.NewLine;
                    custEmailBody = custEmailBody + "Thank you for using our I-require service and please find below details on the service request initiated.</br></br>";// Environment.NewLine;
                    custEmailBody = custEmailBody + "Request Type: " + dt.Rows[0]["RequestType"].ToString() + "</br></br>";//Environment.NewLine;
                    custEmailBody = custEmailBody + "Preferred Branch for pick up: " + dt.Rows[0]["PickUp_BranchName"].ToString() + "</br></br>";//Environment.NewLine;
                    custEmailBody = custEmailBody + "Reference Code: " + refcode.ToString() + "</br></br>";//Environment.NewLine;
                    custEmailBody = custEmailBody + "Request Delivery is " + apTime + "</br></br>";//Environment.NewLine;
                    custEmailBody = custEmailBody + "Please request to see the Operations Head at your preferred pick up branch" + "</br></br>";//Environment.NewLine;
                    custEmailBody = custEmailBody + "For further enquiries, please call GTConnect; our fully interactive 24 hours self-service Contact Centre, on 0700-GTCONNECT (0700-482666328), 01-4480000, 0802-9002900 or 0803-9003900.</br></br>";
                    custEmailBody = custEmailBody + "Thank you.";

                    notificationEmailBody = notificationEmailBody + "Dear Sir/Ma," + "</br></br>";
                    notificationEmailBody = notificationEmailBody + "An I-Require request has been made by " + name + " on Internet Banking with the following details:</br></br>"; //+ name + Environment.NewLine;
                    notificationEmailBody = notificationEmailBody + "Request Type: " + dt.Rows[0]["RequestType"].ToString() + "</br></br>";// + Environment.NewLine;
                    notificationEmailBody = notificationEmailBody + "Preferred Branch for pick up: " + dt.Rows[0]["PickUp_BranchName"].ToString() + "</br></br>";//+ Environment.NewLine;
                    notificationEmailBody = notificationEmailBody + "Pick-Up Time: " + apTime + "</br></br>";
                    notificationEmailBody = notificationEmailBody + "Kindly log on to E_ONE to treat";

                    mailsubject = "NOTIFICATION OF I-REQUIRE REQUEST";
                }
                else
                {
                    custEmailBody = custEmailBody + "Dear " + name + ",</br></br>";//Environment.NewLine + Environment.NewLine;
                    custEmailBody = custEmailBody + "Thank you for using our I-require service and please find below details on the service request initiated.</br></br>";// Environment.NewLine;
                    custEmailBody = custEmailBody + "Request Type: " + dt.Rows[0]["RequestType"].ToString() + "</br></br>";//Environment.NewLine;
                    custEmailBody = custEmailBody + "Preferred Branch for pick up: " + dt.Rows[0]["PickUp_BranchName"].ToString() + "</br></br>";//Environment.NewLine;
                    custEmailBody = custEmailBody + "Reference Code: " + refcode.ToString() + "</br></br>";//Environment.NewLine;
                    //custEmailBody = custEmailBody + "Request Delivery is " + apTime + "</br></br>";//Environment.NewLine;
                    custEmailBody = custEmailBody + "Please visit the orange locker at your preferred pick up branch" + "</br></br>";//Environment.NewLine;
                    custEmailBody = custEmailBody + "For further enquiries, please call GTConnect; our fully interactive 24 hours self-service Contact Centre, on 0700-GTCONNECT (0700-482666328), 01-4480000, 0802-9002900 or 0803-9003900.</br></br>";
                    custEmailBody = custEmailBody + "Thank you.";

                    notificationEmailBody = notificationEmailBody + "Dear Sir/Ma," + "</br></br>";
                    notificationEmailBody = notificationEmailBody + "An I-Require request has been made by " + name + " on Internet Banking with the following details:</br></br>"; //+ name + Environment.NewLine;
                    notificationEmailBody = notificationEmailBody + "Request Type: " + dt.Rows[0]["RequestType"].ToString() + "</br></br>";// + Environment.NewLine;
                    notificationEmailBody = notificationEmailBody + "Preferred Branch for pick up: " + dt.Rows[0]["PickUp_BranchName"].ToString() + "</br></br>";//+ Environment.NewLine;
                    //notificationEmailBody = notificationEmailBody + "Pick-Up Time: " + apTime + "</br></br>";
                    notificationEmailBody = notificationEmailBody + "Orange locker request</br></br>";
                    notificationEmailBody = notificationEmailBody + "Kindly log on to E_ONE to treat";

                    mailsubject = "NOTIFICATION OF I-REQUIRE REQUEST";
                }
                string custEmailResp = string.Empty;
                string opsHeadEmailResp = string.Empty;
                if (roleb.Trim().ToUpper().Equals("NO"))
                {
                    try
                    {
                        if (string.IsNullOrEmpty(custEmail))
                        {
                            ErrHandler.WriteError(string.Format("Unable to send IRequire Email to Customer ==> {0}/{1}. Reason: Could not find Email Address!", bracode, cusnum));
                        }
                        else
                        {
                            custEmailResp = email.SendEmail_HTML(mailfrom, custEmail, mailsubject, custEmailBody, "");
                            ErrHandler.WriteError(string.Format("IRequire Email Response: {0} for ==> {1}", custEmailResp, custEmail));
                        }

                        if (string.IsNullOrEmpty(opheadmail) || string.IsNullOrEmpty(emailCC))
                        {
                            ErrHandler.WriteError(string.Format("Unable to send IRequire Email Notification for Customer==> {0}/{1} to OpsHead of branch:{2}. Reason: Could not find Email Address!", bracode, cusnum, prefbranch));
                        }
                        else
                        {
                            //add the tsg branch email
                            if (reqtype == 1)
                            {
                                emailCC = string.Format("{0},{1},{2}", getTsgBranchEmail(prefbranch), getRegionalCordEmail(prefbranch), emailCC);
                            }
                            else
                            {
                                emailCC = string.Format("{0},{1},{2}", getTsgBranchEmail(prefbranch),getRegionalCordEmail(prefbranch), emailCC);
                            }

                            opsHeadEmailResp = email.SendEmail_HTML(mailfrom, opheadmail, mailsubject, notificationEmailBody, emailCC);
                            ErrHandler.WriteError(string.Format("IRequire Email Response for Opshead:{0}  ==> {1}", opsHeadEmailResp, opheadmail));
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrHandler.WriteError(string.Format("Error sending IRequire Mail for {0}. Error ==>{1}; Source ==> {2}; Stack Trace =={3}", custEmail, ex.Message, ex.Source, ex.StackTrace));
                    }
                }
                if (roleb.Trim().ToUpper().Equals("YES"))
                {
                    try
                    {
                        email.SendEmail_HTML(mailfrom, opheadmail, mailsubject, notificationEmailBody, emailCC);
                    }
                    catch (Exception ex)
                    {
                        ErrHandler.WriteError(string.Format("Error sending IRequire Mail to {0}. Error =={1}; Source ==> {2}; Stack Trace =={3}", opheadmail, ex.Message, ex.Source, ex.StackTrace));
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(string.Format("Error sending IRequire Mail  Error ==> {0}; Source ==> {1}; Stack Trace =={2}", ex.Message, ex.Source, ex.StackTrace));
        }

    }

    public void SendCancelByCustNotification(string requestType, long refcode, int bracode, int cusnum, int prefbranch, string cancellationReason)
    {
        string custEmail = string.Empty;
        string name = string.Empty;
        string opsHeadEmail = string.Empty;
        string emailCC = string.Empty;
        string emailSubject = "NOTIFICATION OF I-REQUIRE REQUEST CANCELLATION"; 
        StringBuilder strBuilder = new StringBuilder();
        Email email = new Email();

        try
        {       
            string cisCentralEmail = ConfigurationManager.AppSettings["IREQ_CC_EMAIL"].ToString();
            String mailfrom = ConfigurationManager.AppSettings["IREQ_SENDER_EMAIL"].ToString();

            string[] cusNameAndEmail = getCustomerNameAndEmail(bracode, cusnum);
            if (cusNameAndEmail != null)
            {
                custEmail = cusNameAndEmail[0];
                name = cusNameAndEmail[1];

                opsHeadEmail = GetOpsHeadMail(string.Empty, prefbranch);
                emailCC = string.Format("{0},{1},{2}", opsHeadEmail, getRegionalCordEmail(prefbranch), cisCentralEmail);

                if (string.IsNullOrEmpty(opsHeadEmail) || string.IsNullOrEmpty(cisCentralEmail))
                {
                    ErrHandler.WriteError(string.Format("Unable to send IRequire Cancellation Email Notification for Customer==> {0}/{1} to OpsHead of branch:{2}. Reason: Could not find Email Address!", bracode, cusnum, prefbranch));
                    return;
                }


                strBuilder.Append("Dear Sir/Ma, <br><br>");
                strBuilder.Append(string.Format("An I-Require request made by {0} on Internet Banking has been cancelled by the Customer. Please find request details below: <br/><br/>", name));
                strBuilder.Append(string.Format("Request Type: {0}  <br/><br/>", requestType));
                strBuilder.Append(string.Format("Request Code: {0} <br/><br/>", refcode));
                strBuilder.Append(string.Format("Cancellation Reason: {0} <br/><br/>", cancellationReason));
                strBuilder.Append(string.Format("Best regards", name));

                string emailResp = email.SendEmail_HTML(mailfrom, opsHeadEmail, emailSubject, strBuilder.ToString(), emailCC);
                ErrHandler.WriteError(string.Format("IRequire Email Response for IRequire cancellation:{0}  ==> {1},{2}", emailResp, opsHeadEmail, emailCC));
            }         
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(string.Format("Error sending IRequire Mail  Error ==> {0}; Source ==> {1}; Stack Trace =={2}", ex.Message, ex.Source, ex.StackTrace));
        }
    }


    internal string SendCancelBySystemNotification(string requestType, long refcode, int bracode, int cusnum, string branchName, string dateInitiated, string reqDeliveryDate)
    {
        string custEmail = string.Empty;
        string name = string.Empty;
        string opsHeadEmail = string.Empty;
        string emailCC = string.Empty;
        string mailsubject = "NOTIFICATION OF I-REQUIRE CANCELLATION";
        StringBuilder strBuilder = new StringBuilder();
        string custEmailResp = string.Empty;
        Email email = new Email();

        try
        {
            string cisCentralEmail = ConfigurationManager.AppSettings["IREQ_CC_EMAIL"].ToString();
            String mailfrom = ConfigurationManager.AppSettings["IREQ_SENDER_EMAIL"].ToString();

            string[] cusNameAndEmail = getCustomerNameAndEmail(bracode, cusnum);
            if (cusNameAndEmail != null)
            {
                custEmail = cusNameAndEmail[0];
                name = cusNameAndEmail[1];

                strBuilder.Append(string.Format("Dear {0}, <br><br>", name));
                strBuilder.Append("Thank you for using our I-Require Service. <br><br>");
                strBuilder.Append(string.Format("Please note that your I-Require service request initiated on {0} has been cancelled due to failure to pick the request at your preferred branch before close of business. See request details below:<br/><br/>", dateInitiated));
                strBuilder.Append(string.Format("Request Type: {0}  <br/><br/>", requestType));
                strBuilder.Append(string.Format("Preferred Branch for pick up: {0}  <br/><br/>", branchName));
                strBuilder.Append(string.Format("Reference Code: {0} <br/><br/>", refcode));
                strBuilder.Append(string.Format("Request Delivery is: {0} <br/><br/>", reqDeliveryDate));
                strBuilder.Append("For further enquiries, please call GTConnect; our fully interactive 24 hours self-service Contact Centre, on 0700-GTCONNECT (0700-482666328), 01-4480000, 0802-9002900 or 0803-9003900.");
                custEmailResp = email.SendEmail_HTML(mailfrom, custEmail, mailsubject, strBuilder.ToString(), string.Empty);

                ErrHandler.WriteError(string.Format("IRequire Email Response for IRequire cancellation by Customer:{0}  ==> {1}", custEmailResp, custEmail));
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(string.Format("Error sending IRequire Mail  Error ==> {0}; Source ==> {1}; Stack Trace =={2}", ex.Message, ex.Source, ex.StackTrace));
        }
        return custEmailResp;
    }

    string[] getCustomerNameAndEmail(int braCode, int cusNum)
    {
        string[] details =new string[2];
        using (OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"].ToString())))
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            string query_str = "SELECT email,get_name2(" + braCode + "," + cusNum + ",0,0,0) name  " + " FROM address where bra_code=" + braCode.ToString() + " and cus_num=" + cusNum.ToString();
            OracleCommand cmd = new OracleCommand(query_str, oraconn);
            OracleDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                details[0] = reader["email"].ToString();
                details[1] = reader["name"].ToString();
                reader.Close();
                reader = null;
            }
        }
        return details;
    }

    string getTsgBranchEmail(int braCode)
    {
        return string.Format("tsg{0}@gtbank.com", braCode);
    }
 

    string getRegionalCordEmail(int braCode)
    {
        string coordinatorEmail = string.Empty;
        try
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                using (SqlCommand comm = new SqlCommand("proc_SelectRegCordEmail", conn))
                {
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Branch_code", braCode);
                   
                    SqlDataReader reader = comm.ExecuteReader();
                   if(reader.HasRows == true)
                   {
                       while (reader.Read())                  
                       {
                           coordinatorEmail = reader["email"]== DBNull.Value ? string.Empty: reader["email"].ToString();
                       }
                   }
                }
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(string.Format("Error retrieving Regional Cord Email ==> {0}; Source ==> {1}; Stack Trace =={2}", ex.Message, ex.Source, ex.StackTrace));
        }
        return coordinatorEmail;
    }

    public void SendNotificationOpsHead(int reqtype,  long refcode, int bracode, int cusnum, string userid,  int prefbranch)
    {
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"].ToString()));
        oraconn.Open();
        OracleCommand cmd = null;
        OracleDataReader reader;
        String emailstr = "";
        string name = string.Empty;
        DataTable dt;
        String query_str = "SELECT email,get_name2(" + bracode + "," + cusnum + ",0,0,0) name  " + " FROM address where bra_code=" + bracode.ToString() + " and cus_num=" + cusnum.ToString();
        cmd = new OracleCommand(query_str, oraconn);
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
            reader.Read();
            emailstr = reader["email"].ToString();
            name = reader["name"].ToString();
            reader.Close();
            reader = null;
        }
        dt = RetreiveIRequest_ID(refcode, reqtype, bracode, cusnum);
        emailstr = GetOpsHeadMail(userid, prefbranch);

        if (dt.Rows.Count > 0)
        {
            if (dt.Rows.Count == 1)
            {

            }
        }

        if (oraconn.State != ConnectionState.Closed)
        {
            oraconn.Close();

            string refferedEmail = "";

            refferedEmail = refferedEmail + "Dear sir/ma" + Environment.NewLine + Environment.NewLine;
            refferedEmail = refferedEmail + "I-Require " + Environment.NewLine;
            refferedEmail = refferedEmail + "Find below the details of the i-Request made by " + dt.Rows[0]["Customer_Name"].ToString() + Environment.NewLine;
            refferedEmail = refferedEmail + "Request Type: " + dt.Rows[0]["Request_Type"].ToString() + Environment.NewLine;
            refferedEmail = refferedEmail + "Preferred Branch: " + dt.Rows[0]["Preferred_Branch"].ToString() + Environment.NewLine;
            refferedEmail = refferedEmail + "Pick-Up Time: " + dt.Rows[0]["Appointment_Time"].ToString() + Environment.NewLine;
            refferedEmail = refferedEmail + "Status: " + dt.Rows[0]["Status"].ToString() + Environment.NewLine;
            refferedEmail = refferedEmail + "Kindly log on to e_one to treat";


            String mailfrom = ConfigurationManager.AppSettings["SenderEmail"].ToString();
            String mailsubject = "I-REQUEST";
            // String mailmessagerefered = "Hello, \n\nPlease note that you have been referred by your friend. \n\n Thank you.";
            Email email = new Email();
         //   email.SendEmail_HTML(mailfrom, emailstr, mailsubject, reffererEmail, "");
            email.SendEmail_HTML(mailfrom, emailstr, mailsubject, refferedEmail, "");
            oraconn = null;
            cmd = null;
        }
    }

    public DataTable  RetreiveIRequest_ID(long refcode, int request_type, int bracode, int cusnum)
    {
        String user_email = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataTable dt = null;
        // string bracode, cusnum;
        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("usp_IRequestSelect_ReqID", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@refid", refcode);
            comm.Parameters.AddWithValue("@reqtype", request_type);
            comm.Parameters.AddWithValue("@branchcode", bracode);
            comm.Parameters.AddWithValue("@cusnum", cusnum);

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            dt = new DataTable();
            adpt.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                return dt;
            }

        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
        }
        return dt;
    }

    public String  IRequestBranchProfile(int bracode, string userid, string status)
    {

        String user_email = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataTable dt = null;
        string ProfiledStatus = "";
        // string bracode, cusnum;


        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            ProfiledStatus = CheckProfileBranch(bracode);
            if (!String.IsNullOrEmpty(ProfiledStatus))
            {
                if (status.Trim().ToUpper().Equals("A"))
                {
                    if (ProfiledStatus.Trim().ToUpper().Equals("A"))
                    {
                        xmlstring = "<Response>";
                        xmlstring = xmlstring + "<CODE>1001</CODE>";
                        xmlstring = xmlstring + "<Error>Branch " + bracode.ToString() + " has been profiled already for I-Require</Error>";
                        xmlstring = xmlstring + "</Response>";
                        return xmlstring;
                    }
                }
                if (status.Trim().ToUpper().Equals("I"))
                {
                     if (ProfiledStatus.Trim().ToUpper().Equals("I"))
                    {
                        xmlstring = "<Response>";
                        xmlstring = xmlstring + "<CODE>1001</CODE>";
                        xmlstring = xmlstring + "<Error>Branch " + bracode.ToString() + " has been disabled already for I-Require</Error>";
                        xmlstring = xmlstring + "</Response>";
                        return xmlstring;
                    }
                }
            }

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("usp_IRequestBranch_Profile", conn);
            comm.CommandType = CommandType.StoredProcedure;
           
            comm.Parameters.AddWithValue("@branchcode", bracode);
            comm.Parameters.AddWithValue("@Status", status);

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            dt = new DataTable();
            adpt.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "</Response>";

               if(status.Trim().ToUpper().Equals("A"))
               {
                   Audit(userid, "Profile", "Profiled Branch " + bracode.ToString() + " as an IRequire Branch");
               }
               if (status.Trim().ToUpper().Equals("I"))
               {
                   Audit(userid, "Disable", "Disabled Branch " + bracode.ToString() + " as an IRequire Branch");
               }
              
            }

        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
        }

        return xmlstring;
    }

    public DataSet IRequestBranchRetrieve(string status, int method)
    {

        String user_email = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds = new DataSet();
        SqlDataAdapter adpt;
        String proc = "";

        try
        {
            if (method == 0)
            {
                proc = "usp_IRequestBranch_Retrieve";
            }
            if (method == 1)
            {
                proc = "usp_OrangLocBranch_Retrieve";
            }
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }


            comm = new SqlCommand(proc, conn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.AddWithValue("@Status", status);

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);

            adpt.Fill(ds);

        }
        catch (Exception ex)
        {

            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
            ds = null;
        }

        return ds;
    }


    public string Audit(String userid, String Action, string description)
    {

        String user_email = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        string i = "";
        // string bracode, cusnum;


        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("usp_IRequestAuditInsert", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@UserID", userid.ToString());
            comm.Parameters.AddWithValue("@Action", Action);
            comm.Parameters.AddWithValue("@Description", description);
            

            comm.CommandType = CommandType.StoredProcedure;
             i = comm.ExecuteScalar().ToString();

          
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return i;
    }

    public string CheckProfileBranch(int bracode)
    {

        String profiled = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        // string bracode, cusnum;


        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("Select IRequestEnabled from branches where Branch_Code = @bracode ", conn);
            comm.CommandType = CommandType.Text;
            comm.Parameters.AddWithValue("@bracode", bracode);

            comm.CommandType = CommandType.Text;
            SqlDataReader rdr = comm.ExecuteReader();

            if (rdr.HasRows)
            {
                rdr.Read();
                profiled = rdr["IRequestEnabled"].ToString();
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
        }

        return profiled;
    }

    public DataSet ReturnIRequest(long? refCode, int? braCode, string dateFrom, string dateTo, int? ReqType, string status)
    {
        DataSet dsResult = new DataSet();
        SqlCommand comm;
        SqlDataAdapter adpt;

        try
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {
                //open connetion
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                comm = new SqlCommand("usp_SelectIRequest", conn);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@BranchCode", braCode == 0 ? null: braCode);
                comm.Parameters.AddWithValue("@DateFrom", string.IsNullOrEmpty(dateFrom) ? null : dateFrom);
                comm.Parameters.AddWithValue("@DateTo", string.IsNullOrEmpty(dateTo) ? null : dateTo);
                comm.Parameters.AddWithValue("@ReqType", ReqType == 0 ? null: ReqType);
                comm.Parameters.AddWithValue("@ReqCode", refCode == 0 ? null: refCode);
                comm.Parameters.AddWithValue("@Status", string.IsNullOrEmpty(status) ? null : status);

                adpt = new SqlDataAdapter(comm);

                comm.CommandType = CommandType.StoredProcedure;
                adpt.Fill(dsResult);
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
            dsResult = null;
        }
        return dsResult;
    }

    public DataSet ReturnIRequestByRefCode(long refCode)
    {
        DataSet dsResult = new DataSet();
        SqlCommand comm;
        SqlDataAdapter adpt;

        try
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {
                //open connetion
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                comm = new SqlCommand("usp_SelectIRequestByRefCode", conn);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@RefCode", refCode);
                adpt = new SqlDataAdapter(comm);

                adpt.Fill(dsResult);
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
            dsResult = null;
        }
        return dsResult;
    }

    public DataSet ReturnIRequestCategories()
    {
        DataSet dsResult = new DataSet();
        SqlCommand comm;
        SqlDataAdapter adpt;

        try
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {
                //open connetion
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                comm = new SqlCommand("Select * from IRequest_Category", conn);
                comm.CommandType = CommandType.Text;
                adpt = new SqlDataAdapter(comm);

                adpt.Fill(dsResult);
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
            dsResult = null;
        }
        return dsResult;
    }

    public string UpdateBlockSeq(long RefCode,  int blkseq)
    {

        String user_email = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        string i = string.Empty;
        // string bracode, cusnum;


        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            comm = new SqlCommand("Update IRequest set BloqSeq = @blkseq where Id = @Id", conn);
            comm.CommandType = CommandType.Text;
            comm.Parameters.AddWithValue("@Id", RefCode);
            comm.Parameters.AddWithValue("@blkseq", blkseq);
            
             i = comm.ExecuteNonQuery().ToString();

             conn.Close();              
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
        }

        return i;
    }

    

   
    
     




}