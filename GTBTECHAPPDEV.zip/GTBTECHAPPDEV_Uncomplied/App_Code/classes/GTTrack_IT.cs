﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.OracleClient;
using System.Globalization;
using System.Web;

public class GTTrack_IT
{
    public GTTrack_IT()
    {
    }

    OracleConnection OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

    private String xmlstring = null;
    string sqlconn = ConfigurationManager.AppSettings["e_oneConnString"];

    public DataTable TrackIt(string trackId, string requestType, string dateFrom, string dateTo)
    {
        DataTable request = new DataTable();
        DataTable request1 = new DataTable();
        DataTable dtable = new DataTable();
        dtable.TableName = "Track";
        BASIS callBasis = new BASIS();


        if (string.IsNullOrEmpty(dateFrom) || string.IsNullOrEmpty(dateTo))
        {
            try
            {
                SqlConnection Conn = new SqlConnection();
                SqlConnection Conn1 = new SqlConnection();

                string tId = null;
                string rType = null;
                string bCod = null;
                string cCode = null;
                string DateFrom = null;
                string DateTo = null;

                rType = requestType;
                tId = trackId;
                DateFrom = dateFrom;
                DateTo = dateTo;

                //DataTable request = new DataTable();
                SqlDataAdapter adpt;
                string query = "";

                if (rType == "Card Request")
                {
                    Conn.ConnectionString = ConfigurationManager.ConnectionStrings["BankcardConnString"].ConnectionString;
                    try
                    {
                        if (tId.Length == 10)
                        {
                            Conn.Open();
                            tId = callBasis.ConvertToOldAccountNumber(trackId);
                            bCod = tId.Substring(0, 3);
                            cCode = tId.Substring(4, 6);
                            query = "SELECT [TrackingID],[CustomerID],[RequestDescription],[Request_Date],[Status],Convert(nvarchar,[PickUp_BranchCode]) + '-' + BranchName as PickUp_BranchCode,[ReasonForCancelRequest]  FROM [dbo].[vwGTTrackingWithBranchName] where Branch_Code = '" + bCod + "' and Customer_No ='" + cCode + "' and requestdescription = 'Card Replacement' order by Request_Date desc";
                            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
                            SqlDataReader rdr = CommCheck1.ExecuteReader();
                            if (rdr.HasRows)
                                dtable.Load(rdr);
                            Conn.Close();
                        }

                        else
                        {
                            Conn.Open();
                            query = "SELECT [CustomerID],[RequestDescription],[Request_Date],[Status],Convert(nvarchar,[PickUp_BranchCode]) + '-' + BranchName as PickUp_BranchCode,[ReasonForCancelRequest]  FROM [dbo].[vwGTTrackingWithBranchName] where TrackingID = '" + tId + "' and requestdescription = 'Card Replacement' order by Request_Date desc";
                            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
                            SqlDataReader rdr = CommCheck1.ExecuteReader();
                            if (rdr.HasRows)
                                dtable.Load(rdr);

                            Conn.Close();
                        }
                    }
                    catch (Exception ex)
                    {

                    }

                    return dtable;
                }

                if (rType == "Cheque Request")
                {
                    Conn.ConnectionString = ConfigurationManager.ConnectionStrings["BankcardConnString"].ConnectionString;
                    
                    try
                    {
                        if (tId.Length == 10)
                        {
                            Conn.Open();
                            tId = callBasis.ConvertToOldAccountNumber(trackId);
                            bCod = tId.Substring(0, 3);
                            cCode = tId.Substring(4, 6);
                            query = "SELECT [TrackingID],[CustomerID],[RequestDescription],[Request_Date],[Status],Convert(nvarchar,[PickUp_BranchCode]) + '-' + BranchName as PickUp_BranchCode,[ReasonForCancelRequest]  FROM [dbo].[vwGTTrackingWithBranchName] where Branch_Code = '" + bCod + "' and Customer_No ='" + cCode + "' and requestdescription = 'Cheque Book' order by Request_Date desc";
                            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
                            SqlDataReader rdr = CommCheck1.ExecuteReader();
                            if (rdr.HasRows)
                                dtable.Load(rdr);

                            Conn.Close();
                        }

                        else
                        {
                            Conn.Open();
                            query = "SELECT [CustomerID],[RequestDescription],[Request_Date],[Status],Convert(nvarchar,[PickUp_BranchCode]) + '-' + BranchName as PickUp_BranchCode,[ReasonForCancelRequest]  FROM [dbo].[vwGTTrackingWithBranchName] where TrackingID = '" + tId + "' and requestdescription = 'Cheque Book' order by Request_Date desc";
                            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
                            SqlDataReader rdr = CommCheck1.ExecuteReader();
                            if (rdr.HasRows)
                                dtable.Load(rdr);

                            Conn.Close();
                        }
                    }
                    catch (Exception ex)
                    {

                    }

                    //}

                    return dtable;
                }


                if (rType == "Dispense Error")
                {
                    Conn.ConnectionString = ConfigurationManager.ConnectionStrings["DispenseConn"].ConnectionString;

                    try
                    {
                        if (tId.Length == 10)
                        {
                            Conn.Open();
                            tId = callBasis.ConvertToOldAccountNumber(trackId);
                            bCod = tId.Substring(0, 3);
                            cCode = tId.Substring(4, 6);
                            query = "SELECT  [TrackingID],[Originatingbracode],[CustomerNumber],[Bank],[datelogged],[Status],[Merchant]  FROM [dbo].[DispenseErrorLog] where BranchCode =  '" + bCod + "' and CustomerNumber = '" + cCode + "'order by datelogged desc";
                            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
                            SqlDataReader rdr = CommCheck1.ExecuteReader();
                            if (rdr.HasRows)
                                dtable.Load(rdr);

                            Conn.Close();
                        }

                        else
                        {
                            Conn.Open();
                            query = "SELECT  [Originatingbracode],[CustomerNumber],[Bank],[datelogged],[Status],[Merchant]  FROM [dbo].[DispenseErrorLog] where TrackingID = '" + tId + "' order by datelogged desc";
                            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
                            SqlDataReader rdr = CommCheck1.ExecuteReader();
                            if (rdr.HasRows)
                                dtable.Load(rdr);

                            Conn.Close();
                        }
                    }

                    catch (Exception ex)
                    {

                    }

                    return dtable;
                }

                if (rType == "All")
                {
                    Conn.ConnectionString = ConfigurationManager.ConnectionStrings["BankcardConnString"].ConnectionString;
                    Conn1.ConnectionString = ConfigurationManager.ConnectionStrings["DispenseConn"].ConnectionString;
                    
                    try
                    {
                        if (tId.Length == 10)
                        {
                            Conn.Open();
                            Conn1.Open();
                            tId = callBasis.ConvertToOldAccountNumber(trackId);
                            bCod = tId.Substring(0, 3);
                            cCode = tId.Substring(4, 6);
                            query = "SELECT [TrackingID],[CustomerID],[RequestDescription],[Request_Date],[Status],Convert(nvarchar,[PickUp_BranchCode]) + '-' + BranchName as PickUp_BranchCode  FROM [dbo].[vwGTTrackingWithBranchName] where Branch_Code = '" + bCod + "' and Customer_No ='" + cCode + "' order by Request_Date desc";
                            string query1 = "SELECT  [TrackingID], branchcode + customernumber + '01' as CustomerID, 'Dispense Error' as RequestDescription, DateLogged as Request_Date, [Status],'NA' as PickUp_BranchCode FROM [dbo].[DispenseErrorLog] where BranchCode =  '" + bCod + "' and CustomerNumber = '" + cCode + "'order by datelogged desc";
                            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
                            SqlCommand CommCheck2 = new SqlCommand(query1, Conn1);
                            SqlDataReader rdr = CommCheck1.ExecuteReader();
                            SqlDataReader rdr1 = CommCheck2.ExecuteReader();
                            if (rdr.HasRows)
                                request.Load(rdr);
                            if (rdr1.HasRows)
                                request1.Load(rdr1);
                            //DataTable dtable;
                            request.Merge(request1);
                            request.AcceptChanges();
                            dtable = request;
                            Conn.Close();
                        }

                        else
                        {
                            Conn.Open();
                            Conn1.Open();
                            query = "SELECT [TrackingID],[CustomerID],[RequestDescription],[Request_Date],[Status],Convert(nvarchar,[PickUp_BranchCode]) + '-' + BranchName as PickUp_BranchCode  FROM [dbo].[vwGTTrackingWithBranchName] where TrackingID = '" + tId + "' order by Request_Date desc";
                            string query1 = "SELECT  [TrackingID], branchcode + customernumber + '01' as CustomerID, 'Dispense Error' as RequestDescription, DateLogged as Request_Date, [Status],'NA' as PickUp_BranchCode FROM [dbo].[DispenseErrorLog] where TrackingID = '" + tId + "' order by datelogged desc";
                            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
                            SqlCommand CommCheck2 = new SqlCommand(query1, Conn1);
                            SqlDataReader rdr = CommCheck1.ExecuteReader();
                            SqlDataReader rdr1 = CommCheck2.ExecuteReader();
                            if (rdr.HasRows)
                                request.Load(rdr);
                            if (rdr1.HasRows)
                                request1.Load(rdr1);
                            //DataTable dtable;
                            request.Merge(request1);
                            request.AcceptChanges();
                            dtable = request;
                            Conn.Close();
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                    return dtable;
                }
            }

            catch (Exception ex)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR>" + ex.Message + "</ERROR>";
                xmlstring = xmlstring + "</Response>";
            }
        }


        else
        {
            try
            {
                SqlConnection Conn = new SqlConnection();
                SqlConnection Conn1 = new SqlConnection();

                string tId = null;
                string rType = null;
                string bCod = null;
                string cCode = null;
                string DateFrom = null;
                string DateTo = null;

                rType = requestType;
                tId = trackId;
                DateFrom = dateFrom;
                DateTo = dateTo;

                //DataTable request = new DataTable();
                SqlDataAdapter adpt;
                string query = "";

                if (rType == "Card Request")
                {
                    Conn.ConnectionString = ConfigurationManager.ConnectionStrings["BankcardConnString"].ConnectionString;
                    
                    try
                    {
                        if (tId.Length == 10)
                        {
                            Conn.Open();
                            tId = callBasis.ConvertToOldAccountNumber(trackId);
                            bCod = tId.Substring(0, 3);
                            cCode = tId.Substring(4, 6);
                            query = "SELECT [TrackingID],[CustomerID],[RequestDescription],[Request_Date],[Status],Convert(nvarchar,[PickUp_BranchCode]) + '-' + BranchName as PickUp_BranchCode,[ReasonForCancelRequest]  FROM [dbo].[vwGTTrackingWithBranchName] where Branch_Code = '" + bCod + "' and Customer_No ='" + cCode + "' and requestdescription = 'Card Replacement' and convert(date,Request_Date)  between'" + DateFrom + "' and  '" + DateTo + "' order by Request_Date desc";
                            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
                            SqlDataReader rdr = CommCheck1.ExecuteReader();
                            if (rdr.HasRows)
                                dtable.Load(rdr);
                            Conn.Close();
                        }

                        else
                        {
                            Conn.Open();
                            query = "SELECT [CustomerID],[RequestDescription],[Request_Date],[Status],Convert(nvarchar,[PickUp_BranchCode]) + '-' + BranchName as PickUp_BranchCode,[ReasonForCancelRequest]  FROM [dbo].[vwGTTrackingWithBranchName] where TrackingID = '" + tId + "' and requestdescription = 'Card Replacement' and convert(date,Request_Date)  between'" + DateFrom + "' and  '" + DateTo + "' order by Request_Date desc";
                            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
                            SqlDataReader rdr = CommCheck1.ExecuteReader();
                            if (rdr.HasRows)
                                dtable.Load(rdr);
                            Conn.Close();
                        }
                    }
                    catch (Exception ex)
                    {

                    }

                    return dtable;
                }

                if (rType == "Cheque Request")
                {
                    Conn.ConnectionString = ConfigurationManager.ConnectionStrings["BankcardConnString"].ConnectionString;
                    
                    try
                    {
                        if (tId.Length == 10)
                        {
                            Conn.Open();
                            tId = callBasis.ConvertToOldAccountNumber(trackId);
                            bCod = tId.Substring(0, 3);
                            cCode = tId.Substring(4, 6);
                            query = "SELECT [TrackingID],[CustomerID],[RequestDescription],[Request_Date],[Status],Convert(nvarchar,[PickUp_BranchCode]) + '-' + BranchName as PickUp_BranchCode,[ReasonForCancelRequest]  FROM [dbo].[vwGTTrackingWithBranchName] where Branch_Code = '" + bCod + "' and Customer_No ='" + cCode + "' and requestdescription = 'Cheque Book' and convert(date,Request_Date)  between'" + DateFrom + "' and  '" + DateTo + "' order by Request_Date desc";
                            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
                            SqlDataReader rdr = CommCheck1.ExecuteReader();
                            if (rdr.HasRows)
                                dtable.Load(rdr);

                            Conn.Close();
                        }

                        else
                        {
                            Conn.Open();
                            query = "SELECT [CustomerID],[RequestDescription],[Request_Date],[Status],Convert(nvarchar,[PickUp_BranchCode]) + '-' + BranchName as PickUp_BranchCode,[ReasonForCancelRequest]  FROM [dbo].[vwGTTrackingWithBranchName] where TrackingID = '" + tId + "' and requestdescription = 'Cheque Book' and convert(date,Request_Date)  between'" + DateFrom + "' and  '" + DateTo + "' order by Request_Date desc";
                            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
                            SqlDataReader rdr = CommCheck1.ExecuteReader();
                            if (rdr.HasRows)
                                dtable.Load(rdr);

                            Conn.Close();
                        }
                    }
                    catch (Exception ex)
                    {

                    }

                    //}

                    return dtable;
                }


                if (rType == "Dispense Error")
                {
                    Conn.ConnectionString = ConfigurationManager.ConnectionStrings["DispenseConn"].ConnectionString;
                    
                    try
                    {
                        if (tId.Length == 10)
                        {
                            Conn.Open();
                            tId = callBasis.ConvertToOldAccountNumber(trackId);
                            bCod = tId.Substring(0, 3);
                            cCode = tId.Substring(4, 6);
                            query = "SELECT [TrackingID],[Originatingbracode],[CustomerNumber],[Bank],[datelogged],[Status],[Merchant]  FROM [dbo].[DispenseErrorLog] where BranchCode =  '" + bCod + "' and CustomerNumber = '" + cCode + "' and convert(date,DateLogged)  between'" + DateFrom + "' and  '" + DateTo + "' order by datelogged desc";
                            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
                            SqlDataReader rdr = CommCheck1.ExecuteReader();
                            if (rdr.HasRows)
                                dtable.Load(rdr);

                            Conn.Close();
                        }

                        else
                        {
                            Conn.Open();
                            query = "SELECT [Originatingbracode],[CustomerNumber],[Bank],[datelogged],[Status],[Merchant]  FROM [dbo].[DispenseErrorLog] where TrackingID = '" + tId + "' and convert(date,DateLogged)  between'" + DateFrom + "' and  '" + DateTo + "'order by datelogged desc";
                            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
                            SqlDataReader rdr = CommCheck1.ExecuteReader();
                            if (rdr.HasRows)
                                dtable.Load(rdr);

                            Conn.Close();
                        }
                    }

                    catch (Exception ex)
                    {

                    }

                    return dtable;
                }

                if (rType == "All")
                {
                    Conn.ConnectionString = ConfigurationManager.ConnectionStrings["BankcardConnString"].ConnectionString;
                    Conn1.ConnectionString = ConfigurationManager.ConnectionStrings["DispenseConn"].ConnectionString;
                    
                    try
                    {
                        if (tId.Length == 10)
                        {
                            Conn.Open();
                            Conn1.Open();

                            tId = callBasis.ConvertToOldAccountNumber(trackId);
                            bCod = tId.Substring(0, 3);
                            cCode = tId.Substring(4, 6);
                            query = "SELECT [TrackingID],[CustomerID],[RequestDescription],[Request_Date],[Status],Convert(nvarchar,[PickUp_BranchCode]) + '-' + BranchName as PickUp_BranchCode FROM [dbo].[vwGTTrackingWithBranchName] where Branch_Code = '" + bCod + "' and Customer_No ='" + cCode + "' and convert(date,Request_Date)  between'" + DateFrom + "' and  '" + DateTo + "' order by Request_Date desc";
                            string query1 = "SELECT  [TrackingID], branchcode + customernumber + '01' as CustomerID, 'Dispense Error' as RequestDescription, DateLogged as Request_Date, [Status],'NA' as PickUp_BranchCode FROM [dbo].[DispenseErrorLog] where BranchCode =  '" + bCod + "' and CustomerNumber = '" + cCode + "' and convert(date,DateLogged)  between'" + DateFrom + "' and  '" + DateTo + "' order by DateLogged desc";
                            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
                            SqlCommand CommCheck2 = new SqlCommand(query1, Conn1);
                            SqlDataReader rdr = CommCheck1.ExecuteReader();
                            SqlDataReader rdr1 = CommCheck2.ExecuteReader();
                            if (rdr.HasRows)
                                request.Load(rdr);
                            if (rdr1.HasRows)
                                request1.Load(rdr1);
                            request.Merge(request1);
                            request.AcceptChanges();
                            dtable = request;
                            Conn.Close();
                            Conn1.Close();
                        }

                        else
                        {
                            Conn.Open();
                            Conn1.Open();

                            query = "SELECT [TrackingID],[CustomerID],[RequestDescription],[Request_Date],[Status],Convert(nvarchar,[PickUp_BranchCode]) + '-' + BranchName as PickUp_BranchCode  FROM [dbo].[vwGTTrackingWithBranchName] where TrackingID = '" + tId + "' and convert(date,Request_Date)  between'" + DateFrom + "' and  '" + DateTo + "' order by request_date desc";
                            string query1 = "SELECT  [TrackingID], branchcode + customernumber + '01' as CustomerID, 'Dispense Error' as RequestDescription, DateLogged as Request_Date, [Status],'NA' as PickUp_BranchCode FROM [dbo].[DispenseErrorLog] where TrackingID = '" + tId + "' and convert(date,DateLogged)  between'" + DateFrom + "' and  '" + DateTo + "' order by datelogged desc";
                            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
                            SqlCommand CommCheck2 = new SqlCommand(query1, Conn1);
                            SqlDataReader rdr = CommCheck1.ExecuteReader();
                            SqlDataReader rdr1 = CommCheck2.ExecuteReader();
                            if (rdr.HasRows)
                                request.Load(rdr);
                            if (rdr1.HasRows)
                                request1.Load(rdr1);
                            request.Merge(request1);
                            request.AcceptChanges();
                            dtable = request;
                            Conn.Close();
                            Conn1.Close();
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                    return dtable;
                }
            }

            catch (Exception ex)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR>" + ex.Message + "</ERROR>";
                xmlstring = xmlstring + "</Response>";
            }
        }

        return dtable;
    }
}



