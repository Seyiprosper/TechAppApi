using System;
using System.Collections.Specialized;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.DirectoryServices;
using System.Security.Cryptography;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data.OracleClient;
using System.IO;
using APPDEVDLL;
using Vanso.WMP;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.XPath;
using System.Collections;
using Microsoft.VisualBasic;
using MT940Generator;
using System.Globalization;
using System.Net;
using EncryptionLib;

/// <summary>
/// Summary description for Eone
/// </summary>
public class Eone
{
    private String xmlstring = null;
    private ReturnValue rt = new ReturnValue();
    BASIS chann = new BASIS();
    ProcessMaker PM = new ProcessMaker();

	public Eone()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public String ValidateAdminUsr2(String id, String pswd)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataRow dr, dr_app, dr_tokenflag;
        String xmlrep = null;
        String xmlschema = null;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ccms"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("Ag_Bkg_AuthenticateAdminUser", conn);
            comm.Parameters.AddWithValue("@UserName", id);
            comm.Parameters.AddWithValue("@userPassword", pswd);


            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);
            ds.DataSetName = "RESPONSE";

            xmlrep = ds.GetXml();
            xmlschema = ds.GetXmlSchema();
            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].TableName = "USER";
                ds.Tables[1].TableName = "ROLE";
                ds.Tables[2].TableName = "MENUS";
                //  ds.Tables[3].TableName = "ACTIONS";

                dr = ds.Tables[0].Rows[0];
                // dr_app = ds.Tables[4].Rows[0];

                //if (Convert.ToInt32(dr["PWD"]) != 1)
                //{
                //    xmlstring = xmlstring + "<CODE>1001</CODE>";
                //    xmlstring = xmlstring + "<Error>" + "INVALID USERNAME OR PASSWORD" + "</Error>";
                //}
                //else if (dr["confirmed"].ToString() != "1")
                //{
                //    xmlstring = xmlstring + "<CODE>1003</CODE>";
                //    xmlstring = xmlstring + "<Error>" + "USER NOT CONFIRMED" + "</Error>";
                //}
                //else if (dr_app["Active"].ToString() != "1")
                //{
                //    xmlstring = xmlstring + "<CODE>1002</CODE>";
                //    xmlstring = xmlstring + "<Error>" + "APPLICATION IS TEMPORARILY NOT AVAILABLE" + "</Error>";
                //}


                {
                    xmlstring = xmlstring + "<CODE>1000</CODE>";
                    // dr_tokenflag = ds.Tables[5].Rows[0];

                    //GET USER
                    xmlstring = xmlstring + "<USER>";
                    xmlstring = xmlstring + "<NAME>" + dr["Username"] + "</NAME>";
                    xmlstring = xmlstring + "<FIRSTNAME>" + dr["FirstName"] + "</FIRSTNAME>";
                    xmlstring = xmlstring + "<LASTNAME>" + dr["LastName"] + "</LASTNAME>";
                    xmlstring = xmlstring + "<USERSTATUS>" + dr["userstatus"] + "</USERSTATUS>";
                    xmlstring = xmlstring + "<LOCKED>" + dr["locked"] + "</LOCKED>";
                    xmlstring = xmlstring + "<TRYCOUNT>" + dr["trycount"] + "</TRYCOUNT>";
                    xmlstring = xmlstring + "<USETOKEN>" + dr["UseToken"] + "</USETOKEN>";
                    xmlstring = xmlstring + "<ROLEID>" + dr["RoleID"] + "</ROLEID>";
                    xmlstring = xmlstring + "<EMAIL>" + dr["email"] + "</EMAIL>";
                    //xmlstring = xmlstring + "<PWDEXPIRE>" + dr["Expiry"].ToString() + "</PWDEXPIRE>";
                    xmlstring = xmlstring + "<PWDEXPIRE>0</PWDEXPIRE>";
                    //GET TOKEN ID
                    //if (dr["TokenId"] != DBNull.Value)
                    //    xmlstring = xmlstring + "<TOKENID>" + dr["TokenId"].ToString() + "</TOKENID>";
                    //else
                    //    xmlstring = xmlstring + "<TOKENID>" + "0" + "</TOKENID>";
                    xmlstring = xmlstring + "</USER>";
                    //GET ROLE
                    xmlstring = xmlstring + "<ROLE>";
                    dr = ds.Tables[1].Rows[0];
                    xmlstring = xmlstring + "<RID>" + dr["ROLE_ID"] + "</RID>";
                    xmlstring = xmlstring + "<RNAME>" + dr["ROLE_DESC"] + "</RNAME>";
                    xmlstring = xmlstring + "</ROLE>";

                    //GET MENUS
                    xmlstring = xmlstring + "<MENUS>";
                    foreach (DataRow dr1 in ds.Tables[2].Rows)
                    {
                        xmlstring = xmlstring + "<MENU>";
                        xmlstring = xmlstring + "<MID>" + dr1["MENU_ID"] + "</MID>";
                        xmlstring = xmlstring + "<MCATEGORY>" + dr1["MENU_CATEGORY"] + "</MCATEGORY>";
                        xmlstring = xmlstring + "<MCAPTION>" + dr1["MENU_CAPTION"] + "</MCAPTION>";
                        xmlstring = xmlstring + "<MURL>" + dr1["RESOURCE"] + "</MURL>";
                        xmlstring = xmlstring + "</MENU>";
                    }
                    xmlstring = xmlstring + "</MENUS>";

                    //GET ACTIONS
                    //xmlstring = xmlstring + "<ACTIONS>";
                    //foreach (DataRow dr1 in ds.Tables[3].Rows)
                    //{
                    //    xmlstring = xmlstring + "<ACTION>";
                    //    xmlstring = xmlstring + "<ACTIONCODE>" + dr1["ACTION_CODE"] + "</ACTIONCODE>";
                    //    xmlstring = xmlstring + "<ACTIONDESC>" + dr1["ACTION_DESC"] + "</ACTIONDESC>";
                    //    xmlstring = xmlstring + "</ACTION>";
                    //}
                    //xmlstring = xmlstring + "</ACTIONS>";
                }
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "INVALID USERNAME OR PASSWORD, OR ACCESS DENIED" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + "Could not retrieve user details: " + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
        //return xmlrep;
    }

    public String PopulateDetails(string nubannumber)
    {


        String Remark = string.Empty, query_str;
        Char[] charsep = { '+' };
        String[] outputStr = { "A", "B" };
        char[] delim = new char[] { '/' };

        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        try
        {
            xmlstring = "<Response>";

            // create the connection

            // create the command for the function
            // query_str = "select cus_sho_name from address where bra_code=" + bracode.ToString() + " and cus_num=" + cusnum.ToString() + " and cur_code=0 and led_code=0 and sub_acct_code=0";

            query_str = "select a.bra_code, a.cus_num, get_nameline1(a.bra_code,a.cus_num,a.cur_code,a.led_code,a.sub_acct_code) last_name, " +
       "get_nameline2(a.bra_code,a.cus_num,a.cur_code,a.led_code,a.sub_acct_code) first_name, " +
       "get_mobile(a.bra_code,a.cus_num,a.cur_code,a.led_code,a.sub_acct_code) mobile, " +
       "get_email(a.bra_code,a.cus_num,a.cur_code,a.led_code,a.sub_acct_code) email, " +
       "get_addressline1(a.bra_code,a.cus_num,a.cur_code,a.led_code,a.sub_acct_code) addr1, " +
       "get_addressline2(a.bra_code,a.cus_num,a.cur_code,a.led_code,a.sub_acct_code) addr2 " +
       "from map_acct a where a.map_acc_no = '" + nubannumber + "'";

            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }

            OracleCommand cmd = new OracleCommand(query_str, oraconn);
            OracleDataReader reader;

            // execute the function
            reader = cmd.ExecuteReader();
            if (reader.HasRows == true)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                reader.Read();

                //get current balance
                xmlstring = xmlstring + "<CUSTOMERNAME>" + reader["first_name"].ToString() + " " + reader["last_name"].ToString() + "</CUSTOMERNAME>";
                xmlstring = xmlstring + "<LASTNAME>" + reader["last_name"].ToString() + "</LASTNAME>";
                xmlstring = xmlstring + "<FIRSTNAME>" + reader["first_name"].ToString() + "</FIRSTNAME>";
                xmlstring = xmlstring + "<MOBILE>" + reader["mobile"].ToString() + "</MOBILE>";
                xmlstring = xmlstring + "<EMAIL>" + reader["email"].ToString() + "</EMAIL>";
                xmlstring = xmlstring + "<ADDR1>" + reader["addr1"].ToString() + "</ADDR1>";
                xmlstring = xmlstring + "<ADDR2>" + reader["addr2"].ToString() + "</ADDR2>";

            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR>ACCOUNT DOES NOT EXIST</ERROR>";
            }

            reader.Close();
            reader = null;
            cmd = null;
            if (oraconn.State == ConnectionState.Open)
            {
                oraconn.Close();
            }
            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            // ErrHandler.WriteError("Error" + ex.ToString);
            if (oraconn.State == ConnectionState.Open)
            {
                oraconn.Close();
            }
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public string SafeSqlLiteral(System.Object theValue, System.Object theLevel)
    {


        // intLevel represent how thorough the value will be checked for dangerous code
        // intLevel (1) - Do just the basic. This level will already counter most of the SQL injection attacks
        // intLevel (2) -   (non breaking space) will be added to most words used in SQL queries to prevent unauthorized access to the database. Safe to be printed back into HTML code. Don't use for usernames or passwords

        string strValue = (string)theValue;
        int intLevel = (int)theLevel;

        if (strValue != null)
        {
            if (intLevel > 0)
            {
                strValue = strValue.Replace("'", "''"); // Most important one! This line alone can prevent most injection attacks
                strValue = strValue.Replace("--", "");
                strValue = strValue.Replace("[", "[[]");
                strValue = strValue.Replace("%", "[%]");
            }
            if (intLevel > 1)
            {
                string[] myArray = new string[] { "xp_ ", "update ", "insert ", "select ", "drop ", "alter ", "create ", "rename ", "delete ", "replace ", "shutdown " };
                int i = 0;
                int i2 = 0;
                int intLenghtLeft = 0;
                for (i = 0; i < myArray.Length; i++)
                {
                    string strWord = myArray[i];
                    Regex rx = new Regex(strWord, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                    MatchCollection matches = rx.Matches(strValue);
                    i2 = 0;
                    foreach (Match match in matches)
                    {
                        GroupCollection groups = match.Groups;
                        intLenghtLeft = groups[0].Index + myArray[i].Length + i2;
                        strValue = strValue.Substring(0, intLenghtLeft - 1) + "&nbsp;" + strValue.Substring(strValue.Length - (strValue.Length - intLenghtLeft), strValue.Length - intLenghtLeft);
                        i2 += 5;
                    }
                }
            }
            return strValue;
        }
        else
        {
            return strValue;
        }
    }

    public string UpdateIRefer(long RefCode, String update_by, string nuban)
    {

        String user_email = "";
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        string bracode, cusnum;


        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("UpdateIRefer", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@refcode", RefCode);
            comm.Parameters.AddWithValue("@updated_by", update_by);
            comm.Parameters.AddWithValue("@referred_NUBAN", nuban);

            comm.CommandType = CommandType.StoredProcedure;
            string i = (string)comm.ExecuteScalar();

            xmlstring = "<Response>";


            if (i == RefCode.ToString())
            {

                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<REFCODE>" + i + "</REFCODE>";

            }
            else if (i.Equals("0"))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "CODE DOES NOT EXIST" + "</Error>";
            }
            else if (i.Equals("2"))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "CODE HAS BEEN USED" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public int GetActiveFEPCards(string branchcode, string cusnum)
    {
        DataTable dtSelect = new DataTable();
        SqlCommand cmdSQLselect = new SqlCommand();
        //Dim drSQLselect As SqlClient.SqlDataReader
        SqlCommand cmdselect = new SqlCommand();
        SqlDataAdapter daSelect = default(SqlDataAdapter);

        //Dim UserParam As New SqlClient.SqlParameter("@UserId", Session["mUserId"])
        SqlConnection ConPostCard = new SqlConnection(ConfigurationManager.AppSettings["CnnPostcard"].ToString());
        try
        {
            if (ConPostCard.State == ConnectionState.Closed)
            {
                ConPostCard.Open();
            }
            // cmdselect.Parameters.Add(UserParam)
            cmdselect.Connection = ConPostCard;
            cmdselect.CommandText = "GTB_get_active_card_count";
            cmdselect.Parameters.AddWithValue("@customer_id", branchcode + cusnum);
            cmdselect.CommandType = CommandType.StoredProcedure;
            dynamic resp = Convert.ToInt32(cmdselect.ExecuteScalar());
            return resp;
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + "%%%%" + ex.StackTrace + "%%%%" + ex.Source + "%%%%" + ex.ToString() + "%%%%" + ex.Data);
            return -1;
            
            //MessageAlert("Unable to connect: Server may be busy or not currently available;Please try again later")
        }
        finally
        {
            if (ConPostCard.State == ConnectionState.Open)
            {
                ConPostCard.Close();
            }
        }
    }

    public string UpdateSalaryAdvanceStatus(string uuid, string caseid, string status, int delindex)
    {

        SqlConnection conn;

        SqlCommand comm;



        try
        {

            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneIbank"].ToString());



            string id = caseid + "-" + uuid;

            //open connetion

            if (conn.State != ConnectionState.Open)
            {

                conn.Open();

            }

            xmlstring = xmlstring + "<Response>";

            comm = new SqlCommand("usp_IbankUpdateSADProcessMaker", conn);

            comm.Parameters.AddWithValue("@CaseID", id);

            comm.Parameters.AddWithValue("@Status", status);

            comm.Parameters.AddWithValue("@DelIndex", delindex);





            comm.CommandType = CommandType.StoredProcedure;



            int i = comm.ExecuteNonQuery();



            if (i > 0)
            {



                xmlstring = xmlstring + "<CODE>1000</CODE>";

                xmlstring = xmlstring + "<MESSAGE>SUCESS</MESSAGE>";





            }

            else
            {

                xmlstring = xmlstring + "<CODE>1001</CODE>";

                xmlstring = xmlstring + "<Error>" + "COULD NOT UPDATE REQUEST" + "</Error>";

            }



            xmlstring = xmlstring + "</Response>";

            //----------------------------------------------------------------

            //Create XML string

        }

        catch (Exception ex)
        {

            xmlstring = "<Response>";

            xmlstring = xmlstring + "<CODE>1001</CODE>";

            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";

            xmlstring = xmlstring + "</Response>";

        }



        return xmlstring;

    }

    public string GetRefferedAccount(string mobileNum)
    {

        string returnaccount = "";
        using (SqlConnection OraConn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
        {
            using (SqlCommand OraSelect = new SqlCommand())
            {
                SqlDataReader OraDrSelect;
                string ref_code = null;

                try
                {
                    if (OraConn.State == ConnectionState.Closed)
                    {
                        OraConn.Open();
                    }
                    OraSelect.Connection = OraConn;
                    string selectquery = "GetIreferCode";
                    OraSelect.Parameters.AddWithValue("@referedMobNum", mobileNum);
                    OraSelect.CommandText = selectquery;
                    OraSelect.CommandType = CommandType.StoredProcedure;
                    using (OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        int count = 0;
                        if (OraDrSelect.Read())
                        {
                            ref_code = OraDrSelect["Ref_code"].ToString();

                            returnaccount = ref_code;



                        }

                    }
                }
                catch (Exception ex)
                {

                    returnaccount = "Error|" + ex.Message;
                }
                finally
                {
                    if (OraConn.State == ConnectionState.Open)
                    {
                        OraConn.Close();
                    }
                    OraConn.Dispose();
                }
            }
            return returnaccount;
        }

    }

    public string SendSMSLubred(string mobileNum, string message, string ApplicationName)
    {

        object result = "0";
        using (OracleConnection OraConn = new OracleConnection(ConfigurationManager.AppSettings["GENSConStringSms"]))
        {
            using (OracleCommand OraSelect = new OracleCommand())
            {
                OracleDataReader OraDrSelect;
                try
                {
                    if (OraConn.State == ConnectionState.Closed)
                    {
                        OraConn.Open();
                    }
                    OraSelect.Connection = OraConn;
                    string selectquery = "insert into mbanklive.THIRD_PARTY_INTEGRATION(SOURCE_APPLICATION,PROCESSED_IND,SMS_MOBILE_NO,SMS_TEXT,ENTRY_DATE) VALUES ('" + SafeSqlLiteral(ApplicationName.ToUpper(), 2) + "','N','" + SafeSqlLiteral(mobileNum, 2) + "','" + SafeSqlLiteral(message, 2) + "',SYSDATE)";
                    OraSelect.CommandText = selectquery;
                    OraSelect.CommandType = CommandType.Text;
                    result = OraSelect.ExecuteNonQuery();

                }
                catch (Exception ex)
                {


                    result = "Error|" + ex.Message;
                }
                finally
                {
                    if (OraConn.State == ConnectionState.Open)
                    {
                        OraConn.Close();
                    }
                    OraConn.Dispose();
                }
            }
            return result.ToString();
        }

    }

    public ReturnValue ValidateBeneficiaryAcctOld(String uid, String acctStr)
    {    
        SqlDataReader reader;
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
        SqlCommand comm = new SqlCommand("SelectUserBeneficiary", conn);
        comm.Parameters.AddWithValue("@UserID", Decimal.Parse(uid));
        comm.Parameters.AddWithValue("@benacctstr", acctStr);
        comm.CommandType = CommandType.StoredProcedure;
        try
        {
            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            reader = comm.ExecuteReader();
            if (reader.HasRows == true)
            {
                rt.value = "1000";
            }
            else
            {
                rt.value = "1001";
            }

            //----------------------------------------------------------------
            //Create XML string
            xmlstring = "<Response>";
            if (rt.value != "1000")
            {
                xmlstring = xmlstring + "<Error>" + "CANNOT FIND ACCOUNT IN BENEFICIARY LIST" + "</Error>";
            }
            else
            {
                reader.Read();
                xmlstring = xmlstring + "<AccountNo>" + reader["AccountString"].ToString() + "</AccountNo>";
                xmlstring = xmlstring + "<Limit>" + reader["Limit"] + "</Limit>";
            }

            xmlstring = xmlstring + "</Response>";
            //--------------------------------------------------------------------

            rt.message = xmlstring;
        }
        catch (Exception ex)
        {
            rt.value = "1002";
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
            rt.message = xmlstring;
        }
        return rt;
    }

    public String ValidateBeneficiaryAcct(String uid, String acctStr)
    {
        SqlDataReader reader;
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
        SqlCommand comm = new SqlCommand("SelectUserBeneficiary", conn);
        String oldacctno = null;
        
        try
        {
            xmlstring = "<Response>";

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            //Check if account is nuban
            if (acctStr.Length == 10) //Validate NUBAN
            {
                Converter cnv = new Converter(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"].ToString()));
                if (cnv.verifyNubanCheckDigit("058", acctStr) == true)
                {
                    oldacctno = cnv.ConvertToOldAccountNumber(acctStr);
                    acctStr = oldacctno.Replace("/","");
                }
                else
                {
                    acctStr = "0";
                }
            }

            if (acctStr.Length < 12)
            {
                acctStr = "0";
            }

            comm.Parameters.AddWithValue("@UserID", Decimal.Parse(uid));
            comm.Parameters.AddWithValue("@benacctstr", acctStr);
            comm.CommandType = CommandType.StoredProcedure;
            reader = comm.ExecuteReader();
            if (reader.HasRows == true)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                reader.Read();
                xmlstring = xmlstring + "<BENEFICIARY>";
                xmlstring = xmlstring + "<AccountNo>" + reader["AccountString"].ToString() + "</AccountNo>";
                xmlstring = xmlstring + "<Limit>" + reader["Limit"] + "</Limit>";
                xmlstring = xmlstring + "</BENEFICIARY>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "CANNOT RETRIEVE BENEFICIARY INFORMATION" + "</Error>";
            }
            reader.Close();
            reader = null;
   
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'","") + "</Error>";
        }

        xmlstring = xmlstring + "</Response>";

        return xmlstring;
    }

    public String GetAccountBalanceTrandate(int bra_code, int cus_num)
    {
        string Result = string.Empty;
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        DataTable dt;
        CustDetRetVal custretval = null;
        int i = 0;

        String query_str = null;

        try
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

            // create the command for the function
            query_str = " select bra_code || '/'|| cus_num || '/'|| cur_code || '/'|| led_code || '/'|| sub_acct_code as accountnumber, crnt_bal,replace(to_chAR(las_tra_date,'dd-Mon-yyyy'),',',',  ') las_tra_date from account where bra_code= " + bra_code + " and cus_num = " + cus_num + " and led_code = 52";

            oraconn.Open();
            cmd = new OracleCommand(query_str, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            dt = new DataTable();

            ora_adpt.Fill(dt);

            xmlstring = "<Response>";

            if (dt.Rows.Count > 0)
            {
                custretval = new CustDetRetVal();
                custretval.picture = new object[dt.Rows.Count];
                custretval.Mandates = new string[dt.Rows.Count];
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<ACCOUNTS>";
                foreach (DataRow dr in dt.Rows)
                {
                    //GET ROLE
                    xmlstring = xmlstring + "<ACCOUNT>";
                    xmlstring = xmlstring + "<ACCOUNTNUMBER>" + dr["ACCOUNTNUMBER"] + "</ACCOUNTNUMBER>";
                    xmlstring = xmlstring + "<CURRENT_BAL>" + dr["crnt_bal"] + "</CURRENT_BAL>";
                    xmlstring = xmlstring + "<LAS_TRA_DATE>" + dr["las_tra_date"] + "</LAS_TRA_DATE>";


                    xmlstring = xmlstring + "</ACCOUNT>";
                    i = i + 1;
                }
                xmlstring = xmlstring + "</ACCOUNTS>";
                xmlstring = xmlstring + "</Response>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "NO RECORDS" + "</Error>";
                xmlstring = xmlstring + "</Response>";
            }


            
            oraconn.Close();
        }
        catch (Exception ex)
        {
            custretval.Accounts = null;
        }

        return xmlstring;
       
    }

    public int HotlistCard(string pPAN, long pCustomerID, string pExpiry, string pSeqNo, int pResponseCode, string uniqueCode = default(string))
    {
        string classmethod = "Eone|HotlistCard";

        ErrHandler.Log(classmethod, pCustomerID.ToString(), "Succesfully entered hostlist method");
        Int64 userId = default(Int64);
         string pCustomerId = pCustomerID.ToString();
        if (pCustomerID.ToString().Length > 4)
        {
            userId = Convert.ToInt64(pCustomerId);
        }
        else
        {
            userId = Convert.ToInt64(pCustomerId);
        }
        if (uniqueCode == default(string))
        {
        }
        else
        {
            pCustomerId = uniqueCode;
        }

        int functionReturnValue = 0;
        SqlCommand sqlSelect = new SqlCommand();
        Random RandomNo = new Random();
        SqlParameter pmPAN = new SqlParameter("@Pan", pPAN);
        SqlParameter pmExpiry = new SqlParameter("@Expiry", pExpiry);
        SqlParameter pmSeqNo = new SqlParameter("@SeqNo", pSeqNo.PadLeft(3, '0'));
        //Dim pmBranchCode As New SqlParameter("@BranchCode", pBranchCode)
        SqlParameter pmCustomerId = new SqlParameter("@CustomerID", pCustomerId.ToString());
        //Dim pmCardTable As New SqlParameter("@CardTable", pCardTable)
        SqlParameter pmResponseCode = new SqlParameter("@ResponseCode", pResponseCode);
        SqlParameter pmUpdatedBy = new SqlParameter("@UpdatedBy", userId);
        SqlParameter pmHotlistInactive = new SqlParameter("@hotlistInactive", 1);
        string errStr = null;
        int mResponse = 0;
        string Sql = "";
        // Set the LinkButton's CommandArgument property with the
        // row's index.
        SqlConnection ConPostcard = new SqlConnection(ConfigurationManager.AppSettings["CnnPostcard"].ToString());
        try
        {
            
            sqlSelect.Parameters.Add(pmPAN);
            sqlSelect.Parameters.Add(pmExpiry);
            sqlSelect.Parameters.Add(pmSeqNo);
            //sqlSelect.Parameters.Add(pmBranchCode)
            sqlSelect.Parameters.Add(pmCustomerId);
            //sqlSelect.Parameters.Add(pmCardTable)
            sqlSelect.Parameters.Add(pmResponseCode);
            sqlSelect.Parameters.Add(pmUpdatedBy);
            sqlSelect.Parameters.Add(pmHotlistInactive);

            // Set the LinkButton's CommandArgument property with the
            if (ConPostcard.State == ConnectionState.Closed)
            {
                ConPostcard.Open();
            }
            // row's index.
            sqlSelect.Connection = ConPostcard;
            //sqlSelect.CommandText = " update pc_cards_1_b set hold_rsp_Code=" & pResponseCode & ",last_updated_user='" & Session["mTellerID"].ToString & "', & last_updated_date='" & Format(Today.Date, "yyyy-MM-dd") & "' where PAN='" & pPAN & "' and Customer_ID=" & pCustomerID & _
            //" and Expiry_Date='" & pExpiry & "'" & " and Seq_nr='" & pSeqNo & "'"
            sqlSelect.CommandText = "Hotlist_Cards";
            sqlSelect.CommandType = CommandType.StoredProcedure;
            functionReturnValue = (int)sqlSelect.ExecuteScalar();

            ErrHandler.WriteError("Hotlist Procedure return  " + functionReturnValue + " "+ pCustomerID);

            ErrHandler.Log(classmethod, pCustomerID.ToString(), " Functional return value is "+ functionReturnValue);

        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Hotlist virtual Card " + ex.Message);

            ErrHandler.Log(classmethod, pCustomerID.ToString(), "Error occured hotlisting card " + ex.Message);
            // ErrLog.AppLogWrite(ex.ToString, true);
            errStr = ex.Message;

            functionReturnValue = 7;
            // Error
            //   MessageAlert(errStr);
        }
        finally
        {
            if (ConPostcard.State == ConnectionState.Open)
            {
                ConPostcard.Close();
            }
        }
        return functionReturnValue;
    }

    public String HotlistCard_ivr(string pPAN, String pCustomerID, string pExpiry, int hotlistReason)
    {
        try
        {
            //Fetch Sequence number using the customer's account number, last 4 digit of PAN and expiry
            int mBranchCode = Convert.ToInt32(pCustomerID.Substring(0, 3));
            int mCustomerNo = Convert.ToInt32(pCustomerID.Substring(3, 6));
            Int64 CustomerID = Convert.ToInt64(mBranchCode.ToString() + mCustomerNo.ToString());
            int pResponseCode = hotlistReason;
            string pan1encrypt = string.Empty;
            string cardidvalueencrypt = string.Empty;
            string seqno = string.Empty;
            string expiry = string.Empty;
            string cardid = string.Empty;
            string pan1 = string.Empty;
            string CardIDD_ = string.Empty;
            string CardIDD_Value = string.Empty;
            string cardidvalue = string.Empty;
            string CardExpiry = string.Empty;
            string CardExp = string.Empty;
            bool found_card = false;
            xmlstring = "<Response>";

            DataTable dtSelect = new DataTable();
            ListItem result = new ListItem();
            EncryptionLib.Encrypt enc = new EncryptionLib.Encrypt();
            using (SqlConnection Cnn_BankCard = new SqlConnection(ConfigurationManager.ConnectionStrings["BankcardConnString"].ToString()))
            {
                if (Cnn_BankCard.State == ConnectionState.Closed)
                {
                    Cnn_BankCard.Open();
                }
                SqlDataAdapter daSQLselect = new SqlDataAdapter("select PAN1,CardIDD_Value,SeqNo,Card_ID,Expiry,Customer_No,CardProgram from Cards_Mastercard where CardStatusid in (6,1,4,8,14,22,24,26,21,40,42,44,45,46,15,47,49,50,8) and  branch_code=" + mBranchCode + " and customer_No=" + mCustomerNo + " AND CONVERT(datetime, 20" + pExpiry.Substring(2, 2) + pExpiry.Substring(0, 2) + "+ right(convert(nvarchar,getdate(),2),2)) >  GETDATE() ", Cnn_BankCard);
                daSQLselect.Fill(dtSelect);
            }
            if (dtSelect.Rows.Count > 0)
            {
                CardExpiry = pExpiry.Substring(0, 2) + pExpiry.Substring(2, 2);
                CardExp = pExpiry.Substring(2, 2) + pExpiry.Substring(0, 2);

                foreach (DataRow row in dtSelect.Rows)
                {
                    if (row["PAN1"] != System.DBNull.Value)
                    {
                        pan1encrypt = row["PAN1"].ToString();
                    }
                    if (row["SeqNo"] != System.DBNull.Value)
                    {
                        seqno = row["SeqNo"].ToString();
                    }
                    if (row["Expiry"] != System.DBNull.Value)
                    {
                        expiry = row["Expiry"].ToString();
                    }
                    if (row["CardIDD_Value"] != System.DBNull.Value)
                    {
                        CardIDD_Value = row["CardIDD_Value"].ToString();
                    }
                    if (!string.IsNullOrEmpty(pan1encrypt))
                    {
                        pan1 = enc.Decrypt_TrpDes(pan1encrypt);
                    }
                    if (!string.IsNullOrEmpty(CardIDD_Value))
                    {
                        CardIDD_ = enc.Decrypt_TrpDes(CardIDD_Value).ToString().Substring(0, 6);
                    }
                    if (pan1.Substring(6, 4) == pPAN.Trim() && expiry == CardExpiry)
                    {
                        found_card = true;
                        break;
                    }
                }
            }

            if (found_card == false)
            {
                return xmlstring + "<CODE>1004</CODE><MESSAGE>Card does not exist</MESSAGE></Response>";
            }
            else
            {
                int functionReturnValue = HotlistCard_IVR(CardIDD_ + pan1, CustomerID, CardExp, seqno, pResponseCode);

                if (functionReturnValue == 5)
                {
                    bool updateRes = UpdateCardStatusBankCard(pan1, mBranchCode, mCustomerNo, CardExpiry, seqno, pResponseCode);
                    if (updateRes)
                    {
                        xmlstring = xmlstring + "<CODE>1000</CODE>";
                        xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                    }
                    else
                    {
                        xmlstring = xmlstring + "<CODE>1000</CODE>";
                        xmlstring = xmlstring + "<MESSAGE>Card has been hotlisted but bankcard was not updated.</MESSAGE>";
                    }
                }
                else if (functionReturnValue == 6)
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<MESSAGE>Already Hotlisted</MESSAGE>";
                }
                else if (functionReturnValue == 4)
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<MESSAGE>Card does not exist</MESSAGE>";
                }
                else
                {
                    xmlstring = xmlstring + "<CODE>1004</CODE>";
                    xmlstring = xmlstring + "<MESSAGE>UNABLE TO HOTLIST CARD-" + functionReturnValue + "</MESSAGE>";
                }
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message);
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<MESSAGE>ERROR HOTLISTING CARD</MESSAGE>";
        }
        return xmlstring + "</Response>";
    }

    private bool UpdateCardStatusBankCard(string pPAN, int pBranchCode, int pCustomerNo, string pExpiry, string pSeqNo, int pResponseCode)
    {
        bool functionReturnValue = false;
        SqlCommand sqlSelect = new SqlCommand();
        Random RandomNo = new Random();



        //SqlConnection Cnn_BankCard = new SqlConnection(ConfigurationManager.ConnectionStrings["BankCard_New"].ToString());
        EncryptionLib.Encrypt enc = new EncryptionLib.Encrypt();
        string pan1 = enc.Encrypt_TrpDes(pPAN);
        //string cardid = enc.Encrypt_TrpDes(pPAN.Substring(0, 13));
        string errStr = null;
        string Sql = "";

        try
        {
            using (SqlConnection Cnn_BankCard = new SqlConnection(ConfigurationManager.ConnectionStrings["BankcardConnString"].ToString()))
            {
                if (Cnn_BankCard.State == ConnectionState.Closed)
                {
                    Cnn_BankCard.Open();
                }

                Sql = "Update Cards_Mastercard set CardStatusID=" + pResponseCode + "," + "Hotlisted_By=" + Convert.ToInt32(pCustomerNo) + "," + " Date_Hotlisted='" + Strings.Format(DateTime.Now, "yyyy-MM-dd") + "'" + " where  pan1 ='" + pan1 + "'" + " and Expiry='" + pExpiry + "' and Seqno='" + pSeqNo + "' and Branch_Code=" + pBranchCode + " and customer_no=" + pCustomerNo;

                if (Cnn_BankCard.State == ConnectionState.Closed)
                {
                    Cnn_BankCard.Open();
                }
                sqlSelect.Connection = Cnn_BankCard;

                sqlSelect.CommandText = Sql;

                sqlSelect.CommandType = CommandType.Text;

                if (sqlSelect.ExecuteNonQuery() > 0)
                {
                    functionReturnValue = true;
                }
                else
                {
                    functionReturnValue = false;
                }
            }
        }
        catch (Exception ex)
        {
            functionReturnValue = false;
            ErrHandler.WriteError(ex.Message);
        }
        finally
        {
            sqlSelect.Dispose();
        }
        return functionReturnValue;
    }

    public int HotlistCard_IVR(string pPAN, long pCustomerID, string pExpiry, string pSeqN, int pResponseCode)
    {
        string pSeqNo = pSeqN.PadLeft(3, '0');
        int functionReturnValue = 0;
        SqlCommand sqlSelect = new SqlCommand();
        Random RandomNo = new Random();
        SqlParameter pmPAN = new SqlParameter("@Pan", pPAN);
        SqlParameter pmExpiry = new SqlParameter("@Expiry", pExpiry);
        SqlParameter pmSeqNo = new SqlParameter("@SeqNo", pSeqNo);
        //Dim pmBranchCode As New SqlParameter("@BranchCode", pBranchCode)
        SqlParameter pmCustomerId = new SqlParameter("@CustomerID", pCustomerID);
        //Dim pmCardTable As New SqlParameter("@CardTable", pCardTable)
        SqlParameter pmResponseCode = new SqlParameter("@ResponseCode", pResponseCode);
        SqlParameter pmUpdatedBy = new SqlParameter("@UpdatedBy", pCustomerID.ToString().Substring(3, 6));
        //Dim pmPickUpBranch As New SqlParameter("@PickUp_BranchCode", pPickUpBranch)
        string errStr = null;
        int mResponse = 0;
        string Sql = "";
        // Set the LinkButton's CommandArgument property with the
        // row's index.
        SqlConnection ConPostcard = new SqlConnection(ConfigurationManager.AppSettings["CnnPostcard"].ToString());
        try
        {
            sqlSelect.Parameters.Add(pmPAN);
            sqlSelect.Parameters.Add(pmExpiry);
            sqlSelect.Parameters.Add(pmSeqNo);
            //sqlSelect.Parameters.Add(pmBranchCode)
            sqlSelect.Parameters.Add(pmCustomerId);
            //sqlSelect.Parameters.Add(pmCardTable)
            sqlSelect.Parameters.Add(pmResponseCode);
            sqlSelect.Parameters.Add(pmUpdatedBy);



            // Set the LinkButton's CommandArgument property with the
            if (ConPostcard.State == ConnectionState.Closed)
            {
                ConPostcard.Open();
            }
            // row's index.
            sqlSelect.Connection = ConPostcard;
            //sqlSelect.CommandText = " update pc_cards_1_b set hold_rsp_Code=" & pResponseCode & ",last_updated_user='" & Session["mTellerID"].ToString & "', & last_updated_date='" & Format(Today.Date, "yyyy-MM-dd") & "' where PAN='" & pPAN & "' and Customer_ID=" & pCustomerID & _
            //" and Expiry_Date='" & pExpiry & "'" & " and Seq_nr='" & pSeqNo & "'"
            sqlSelect.CommandText = "Hotlist_Cards";
            sqlSelect.CommandType = CommandType.StoredProcedure;
            functionReturnValue = (int)sqlSelect.ExecuteScalar();

        }
        catch (Exception ex)
        {

            //  ErrorWriter.WriteError(Session["muserid"].ToString() + ex.Message);

            // ErrLog.AppLogWrite(ex.ToString, true);
            errStr = ex.Message;

            functionReturnValue = 7;
            // Error
            //   MessageAlert(errStr);
        }
        finally
        {
            if (ConPostcard.State == ConnectionState.Open)
            {
                ConPostcard.Close();
            }
        }
        return functionReturnValue;
    }

 //   public int HotlistCard(string pPAN, long pCustomerID, string pExpiry, string pSeqNo, int pResponseCode)
 //{
 //    int functionReturnValue = 0;
 //    SqlCommand sqlSelect = new SqlCommand();
 //    Random RandomNo = new Random();
 //    SqlParameter pmPAN = new SqlParameter("@Pan", pPAN);
 //    SqlParameter pmExpiry = new SqlParameter("@Expiry", pExpiry);
 //    SqlParameter pmSeqNo = new SqlParameter("@SeqNo", pSeqNo);
 //    //Dim pmBranchCode As New SqlParameter("@BranchCode", pBranchCode)
 //    SqlParameter pmCustomerId = new SqlParameter("@CustomerID", pCustomerID);
 //    //Dim pmCardTable As New SqlParameter("@CardTable", pCardTable)
 //    SqlParameter pmResponseCode = new SqlParameter("@ResponseCode", pResponseCode);
 //    SqlParameter pmUpdatedBy = new SqlParameter("@UpdatedBy", pCustomerID.ToString().Substring(3, 6));
 //    //Dim pmPickUpBranch As New SqlParameter("@PickUp_BranchCode", pPickUpBranch)
 //    string errStr = null;
 //    int mResponse = 0;
 //    string Sql = "";
 //    // Set the LinkButton's CommandArgument property with the
 //    // row's index.
 //    SqlConnection ConPostcard = new SqlConnection(ConfigurationManager.AppSettings["CnnPostcard"].ToString());
 //    try
 //    {
 //        sqlSelect.Parameters.Add(pmPAN);
 //        sqlSelect.Parameters.Add(pmExpiry);
 //        sqlSelect.Parameters.Add(pmSeqNo);
 //        //sqlSelect.Parameters.Add(pmBranchCode)
 //        sqlSelect.Parameters.Add(pmCustomerId);
 //        //sqlSelect.Parameters.Add(pmCardTable)
 //        sqlSelect.Parameters.Add(pmResponseCode);
 //        sqlSelect.Parameters.Add(pmUpdatedBy);



 //        // Set the LinkButton's CommandArgument property with the
 //        if (ConPostcard.State == ConnectionState.Closed)
 //        {
 //            ConPostcard.Open();
 //        }
 //        // row's index.
 //        sqlSelect.Connection = ConPostcard;
 //        //sqlSelect.CommandText = " update pc_cards_1_b set hold_rsp_Code=" & pResponseCode & ",last_updated_user='" & Session["mTellerID"].ToString & "', & last_updated_date='" & Format(Today.Date, "yyyy-MM-dd") & "' where PAN='" & pPAN & "' and Customer_ID=" & pCustomerID & _
 //        //" and Expiry_Date='" & pExpiry & "'" & " and Seq_nr='" & pSeqNo & "'"
 //        sqlSelect.CommandText = "Hotlist_Cards";
 //        sqlSelect.CommandType = CommandType.StoredProcedure;
 //        functionReturnValue = (int)sqlSelect.ExecuteScalar();

 //    }
 //    catch (Exception ex)
 //    {

 //        //  ErrorWriter.WriteError(Session["muserid"].ToString() + ex.Message);

 //        // ErrLog.AppLogWrite(ex.ToString, true);
 //        errStr = ex.Message;

 //        functionReturnValue = 7;
 //        // Error
 //        //   MessageAlert(errStr);
 //    }
 //    finally
 //    {
 //        if (ConPostcard.State == ConnectionState.Open)
 //        {
 //            ConPostcard.Close();
 //        }
 //    }
 //    return functionReturnValue;
 //}

    public string GetCardStatus(string exp, string cardmask, string seq_nr, string bracusnum)
    {
        string returnvalue = String.Empty;
        SqlConnection ConPostcard = new SqlConnection(ConfigurationManager.AppSettings["CnnPostcard"].ToString());
        SqlCommand cmdselectUser = new SqlCommand();
        //  Dim reader As SqlDataReader
        //    Dim cmd As New SqlClient.SqlCommand
        try
        {
            if ((ConPostcard.State == ConnectionState.Closed))
            {
                ConPostcard.Open();
            }
            cmdselectUser.Parameters.AddWithValue("@pan", cardmask);
            cmdselectUser.Parameters.AddWithValue("@seq_nr", seq_nr);
            cmdselectUser.Parameters.AddWithValue("@expiry_date", exp);
            cmdselectUser.Parameters.AddWithValue("@CustomerId", bracusnum);
            cmdselectUser.Connection = ConPostcard;
            cmdselectUser.CommandText = "GTB_Get_Card_Status";
            cmdselectUser.CommandType = CommandType.StoredProcedure;
            returnvalue = (string)cmdselectUser.ExecuteScalar();
            return returnvalue;
            //   returnvalue = cmdselectUser.ExecuteReader
            // reader = cmdselectUser.ExecuteReader()
            // If reader.HasRows Then
            //     reader.Read()
            // End If
        }
        catch (Exception ex)
        {
           // ErrorWriter.WriteError((ex.Message + (" , " + ex.StackTrace())));
            //       MessageAlert(ex.Message)
        }
        finally
        {
            ConPostcard.Close();
        }
        return returnvalue;
    }

    //public String ValidateAdminUsr(String id, String pswd, int appid, string ipAddress)
    //{
    //    SqlConnection conn;
    //    SqlCommand comm;
    //    DataSet ds;
    //    SqlDataAdapter adpt;
    //    DataRow dr, dr_app, dr_tokenflag;
    //    String xmlrep = null;
    //    String xmlschema = null;

    //    try
    //    {
    //        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
            
    //        //open connetion
    //        if (conn.State != ConnectionState.Open)
    //        {
    //            conn.Open();
    //        }

    //        comm = new SqlCommand("AuthenticateAdminUser", conn);
    //        comm.Parameters.AddWithValue("@UserID", id);
    //        comm.Parameters.AddWithValue("@userPassword", pswd);
    //        comm.Parameters.AddWithValue("@ApplicationID", appid);

    //        comm.CommandType = CommandType.StoredProcedure;
    //        adpt = new SqlDataAdapter(comm);
    //        ds = new DataSet();
            
    //        adpt.Fill(ds);
    //        ds.DataSetName = "RESPONSE";          

    //        xmlrep = ds.GetXml();
    //        xmlschema = ds.GetXmlSchema();
    //        xmlstring = "<Response>";
    //        DateTime dtTimeLoggedIn = DateTime.Now;

    //        if(ds.Tables[0].Rows.Count > 0)
    //        {
    //            ds.Tables[0].TableName = "USER";
    //            ds.Tables[1].TableName = "ROLE";
    //            ds.Tables[2].TableName = "MENUS";
    //            ds.Tables[3].TableName = "ACTIONS";

    //            dr = ds.Tables[0].Rows[0];
    //            dr_app = ds.Tables[4].Rows[0];

    //            //if (Convert.ToInt32(dr["PWD"]) != 1)
    //            //{
    //            //    xmlstring = xmlstring + "<CODE>1001</CODE>";
    //            //    xmlstring = xmlstring + "<Error>" + "INVALID USERNAME OR PASSWORD" + "</Error>";
    //            //}
    //            //else if (dr["confirmed"].ToString() != "1")
    //            //{
    //            //    xmlstring = xmlstring + "<CODE>1003</CODE>";
    //            //    xmlstring = xmlstring + "<Error>" + "USER NOT CONFIRMED" + "</Error>";
    //            //}
    //            //else if (dr_app["Active"].ToString() != "1")
    //            //{
    //            //    xmlstring = xmlstring + "<CODE>1002</CODE>";
    //            //    xmlstring = xmlstring + "<Error>" + "APPLICATION IS TEMPORARILY NOT AVAILABLE" + "</Error>";
    //            //}

    //            if (dr_app["Active"].ToString() != "1")
    //            {
    //                xmlstring = xmlstring + "<CODE>1002</CODE>";
    //                xmlstring = xmlstring + "<Error>" + "APPLICATION IS TEMPORARILY NOT AVAILABLE" + "</Error>";
    //            }
    //            else
    //            {
    //                xmlstring = xmlstring + "<CODE>1000</CODE>";
    //                dr_tokenflag = ds.Tables[5].Rows[0];

    //                //GET USER
    //                xmlstring = xmlstring + "<USER>";
    //                xmlstring = xmlstring + "<ID>" + dr["BASIS_ID"] + "</ID>";
    //                xmlstring = xmlstring + "<NAME>" + dr["User_name"] + "</NAME>";
    //                xmlstring = xmlstring + "<BRANCH>" + dr["branch_code"] + "</BRANCH>";
    //                xmlstring = xmlstring + "<EMAIL>" + dr["email"] + "</EMAIL>";
    //                //xmlstring = xmlstring + "<PWDEXPIRE>" + dr["Expiry"].ToString() + "</PWDEXPIRE>";
    //                xmlstring = xmlstring + "<PWDEXPIRE>0</PWDEXPIRE>";
    //                xmlstring = xmlstring + "<DOMAINID>" + dr["User_id"].ToString() + "</DOMAINID>";
    //                xmlstring = xmlstring + "<USETOKEN>" + dr_tokenflag["flag"].ToString() + "</USETOKEN>";
    //        //GET TOKEN ID
    //        if (dr["TokenId"] != DBNull.Value)
    //                    xmlstring = xmlstring + "<TOKENID>" + dr["TokenId"].ToString() + "</TOKENID>";
    //                else
    //                    xmlstring = xmlstring + "<TOKENID>" + "0" + "</TOKENID>";
    //        if (ds.Tables[6] != null && ds.Tables[6].Rows.Count > 0)
    //        {
    //            DataRow dwRow = ds.Tables[6].Rows[0];
    //            DateTime dtLastLoginDate = new DateTime();
    //            String strResponse = string.Empty;
    //            dtLastLoginDate = dwRow[0] == DBNull.Value ? dtLastLoginDate : Convert.ToDateTime(dwRow[0]);
    //            if (dtLastLoginDate.Date != DateTime.MinValue)
    //            {
    //                strResponse = String.Format("{0} at {1}", dtLastLoginDate.Date.ToString("dd-MMM-yyyy"), dtLastLoginDate.ToString("h:mm:ss tt"));
    //            }

    //            xmlstring = xmlstring + "<LASTLOGINDATE>" + strResponse + "</LASTLOGINDATE>";
    //        }
    //                xmlstring = xmlstring + "</USER>";
    //                //GET ROLE
    //                xmlstring = xmlstring + "<ROLE>";
    //                dr = ds.Tables[1].Rows[0];
    //                xmlstring = xmlstring + "<RID>" + dr["ROLE_ID"] + "</RID>";
    //                xmlstring = xmlstring + "<RNAME>" + dr["ROLE_DESC"] + "</RNAME>";
    //                xmlstring = xmlstring + "</ROLE>";

    //                //GET MENUS
    //                xmlstring = xmlstring + "<MENUS>";
    //                foreach (DataRow dr1 in ds.Tables[2].Rows)
    //                {
    //                    xmlstring = xmlstring + "<MENU>";
    //                    xmlstring = xmlstring + "<MID>" + dr1["MENU_ID"] + "</MID>";
    //                    xmlstring = xmlstring + "<MCATEGORY>" + dr1["MENU_CATEGORY"] + "</MCATEGORY>";
    //                    xmlstring = xmlstring + "<MCAPTION>" + dr1["MENU_CAPTION"] + "</MCAPTION>";
    //                    xmlstring = xmlstring + "<MURL>" + dr1["RESOURCE"] + "</MURL>";
    //                    xmlstring = xmlstring + "<MOFFSITEID>" + dr1["OffSiteMenuId"] + "</MOFFSITEID>";
    //                    bool isVisible = dr1["IsVisible"] == DBNull.Value ? true : Convert.ToBoolean(dr1["IsVisible"]);
    //                    xmlstring = xmlstring + "<ISVISIBLE>" + isVisible.ToString() + "</ISVISIBLE>";
    //                    xmlstring = xmlstring + "</MENU>";
    //                }
    //                xmlstring = xmlstring + "</MENUS>";

    //                //GET ACTIONS
    //                xmlstring = xmlstring + "<ACTIONS>";
    //                foreach (DataRow dr1 in ds.Tables[3].Rows)
    //                {
    //                    xmlstring = xmlstring + "<ACTION>";
    //                    xmlstring = xmlstring + "<ACTIONCODE>" + dr1["ACTION_CODE"] + "</ACTIONCODE>";
    //                    xmlstring = xmlstring + "<ACTIONDESC>" + dr1["ACTION_DESC"] + "</ACTIONDESC>";
    //                    xmlstring = xmlstring + "</ACTION>";
    //                }
    //                xmlstring = xmlstring + "</ACTIONS>";
    //                InsertAppLoginDetails(id, appid, dtTimeLoggedIn, ipAddress);
    //            }
    //        }
    //        else
    //        {
    //            xmlstring = xmlstring + "<CODE>1001</CODE>";
    //            xmlstring = xmlstring + "<Error>" + "INVALID USERNAME OR PASSWORD, OR ACCESS DENIED" + "</Error>";
    //        }

    //        xmlstring = xmlstring + "</Response>";
    //        //----------------------------------------------------------------
    //        //Create XML string
    //    }
    //    catch (Exception ex)
    //    {
    //        xmlstring = "<Response>";
    //        xmlstring = xmlstring + "<CODE>1001</CODE>";
    //        xmlstring = xmlstring + "<Error>" + "Could not retrieve user details: " + ex.Message + "</Error>";
    //        xmlstring = xmlstring + "</Response>";
    //        ErrHandler.WriteError("Error validating Admin User: "+ ex.Message);
    //    }

    //    return xmlstring;
    //    //return xmlrep;
    //}

    internal Int64 InsertAppLoginDetails(String user_id, int appid, DateTime dtLoginTime, string ipAddress)
    {
        Int64 result = 0;
        try
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                SqlCommand comm = new SqlCommand("proc_InsertApplicationLogin", conn);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@User_ID", user_id.ToLower());
                comm.Parameters.AddWithValue("@App_ID", appid);
                comm.Parameters.AddWithValue("@Login_Date", dtLoginTime);
                comm.Parameters.AddWithValue("@ip_address", ipAddress);
                result = Convert.ToInt64(comm.ExecuteScalar());

                if (result <= 0)
                {
                    ErrHandler.WriteError(string.Format("Unsuccessful Insert of Login Details for Application:{0} for User:{1} at {2}", appid, user_id, dtLoginTime));
                }
               
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Error inserting into Application Login Log ==> " + ex.Message);
        }
        return result;
    }

    public String ValidateEncryptedAdminUsrOffSite(String id, String pswd, int appid)
    {
        String result = null;
        String adserver = ConfigurationManager.AppSettings["ADServer"].ToString();
        //Use Active Drectory

        //Dim Entry As DirectoryEntry = New DirectoryEntry("LDAP://gtbank.com", "test.mail", "test123")
        //DirectoryEntry Entry  = new DirectoryEntry("LDAP://gtbank.com", id, pswd);

        //Dim Entry As DirectoryEntry = New DirectoryEntry("LDAP://gtbank.com", "test.mail", "test123")

        //new

        adserver = "LDAP://" + adserver;
        DirectoryEntry Entry = new DirectoryEntry(adserver, id, pswd);

        DirectorySearcher Searcher = new DirectorySearcher(Entry);
        SearchResult result1;

        try
        {
            //Searcher.Filter = ("(anr=taiwo.aluko)")
               Searcher.Filter = ("(anr=" + id + ")");
               result1 = Searcher.FindOne();
               if (result1 != null)
                {
            result = ValidateAdminUsr(id, pswd, appid, "");
               }
              else
              {
                 xmlstring = "<Response>";
                  xmlstring = xmlstring + "<CODE>1001</CODE>";
                   xmlstring = xmlstring + "<Error>User Does Not Exist</Error>";
                   xmlstring = xmlstring + "</Response>";
                   result = xmlstring;
               }
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + "Could not retrieve user details: " + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
            result = xmlstring;
        }

        return result;
    }

    public String ValidateAdminUsrOffSite(String id, String pswd, int appid)
    {
        String result = null;
        String adserver = ConfigurationManager.AppSettings["ADServer"].ToString();
        //Use Active Drectory

        //Dim Entry As DirectoryEntry = New DirectoryEntry("LDAP://gtbank.com", "test.mail", "test123")
        //DirectoryEntry Entry  = new DirectoryEntry("LDAP://gtbank.com", id, pswd);

        //Dim Entry As DirectoryEntry = New DirectoryEntry("LDAP://gtbank.com", "test.mail", "test123")
     
        

	    adserver = "LDAP://" + adserver;
        DirectoryEntry Entry = new DirectoryEntry(adserver, id, pswd);

        DirectorySearcher Searcher = new DirectorySearcher(Entry);
        SearchResult result1;

        try
        {
            //'Searcher.Filter = ("(anr=taiwo.aluko)")
            Searcher.Filter = ("(anr=" + id + ")");
            result1 = Searcher.FindOne();
            if (result1 != null)
            {
                result = ValidateAdminUsr(id, pswd, appid, "");
            }
            else
            {
                xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>User Does Not Exist</Error>";
                xmlstring = xmlstring + "</Response>";
                result = xmlstring;
            }
        }
        catch(Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + "Could not retrieve user details: " + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
            result = xmlstring;
        }

        return result;
    }

    public String ValidateUser(String uid, String pswd)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        int count = 0;

        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("IVR_USER_ACCOUNTS", conn);
            comm.Parameters.AddWithValue("@u_id", uid);
            comm.Parameters.AddWithValue("@u_pwd", long.Parse(pswd));

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();
            adpt.Fill(ds);

            if (ds.Tables[0].Rows.Count > 0)
            {
                DataRow drt = (DataRow)ds.Tables[0].Rows[0];
                if (drt["pwd"].ToString() == "1")
                {
                    xmlstring = xmlstring + "<CODE>1000</CODE>";
                    xmlstring = xmlstring + "<USERID>" + drt["user_id"].ToString() + "</USERID>";
                    xmlstring = xmlstring + "<ACCOUNTS>";
                    foreach (DataRow dr1 in ds.Tables[1].Rows)
                    {
                        xmlstring = xmlstring + "<ACCOUNT>" + dr1[0].ToString() + "</ACCOUNT>";
                    }
                    xmlstring = xmlstring + "</ACCOUNTS>";

                    //Only send login email if Send_loginEmail is 1
                    String sendlogin = drt["send_loginEmail"].ToString();
                    String username = drt["user_name"].ToString();
                    String useremail = drt["email"].ToString();
                    if (sendlogin == "1")
                    {
                        Email email = new Email();
                        email.SendLoginMail(username, useremail);
                        email = null;
                    }
                }
                else
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>" + "INVALID USERNAME OR PASSWORD" + "</Error>";
                }
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "INVALID USERNAME OR PASSWORD" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
        //ret.value = "1000";
        //ret.message = xmlstring;
        //return ret;
    }

    public String GetTurnover(String uid)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        int count = 0;

        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("IVR_TURNOVER", conn);
            comm.Parameters.AddWithValue("@u_id", uid);

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();
            adpt.Fill(ds);

            if (ds.Tables[0].Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                foreach (DataRow dr1 in ds.Tables[0].Rows)
                {
                    xmlstring = xmlstring + "<TURNOVER>" + dr1[0].ToString() + "</TURNOVER>";
                }
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "INVALID USERNAME OR PASSWORD" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
        //ret.value = "1000";
        //ret.message = xmlstring;
        //return ret;
    }

    public String GetCustomerDetails(String uid)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        Account[] accts;
        int count = 0;

        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("IVR_USER_DETAILS2", conn);
            comm.Parameters.AddWithValue("@u_id", uid);
            
            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();
            adpt.Fill(ds);

            if (ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = (DataRow)ds.Tables[0].Rows[0];
                
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<DETAILS>";
                xmlstring = xmlstring + "<EMAIL>" + dr["EMAIL"].ToString() + "</EMAIL>";
                xmlstring = xmlstring + "<PHONE>" + dr["PHONE"].ToString() + "</PHONE>";
                xmlstring = xmlstring + "<PARTYID>" + dr["PARTYID"].ToString() + "</PARTYID>";
                xmlstring = xmlstring + "</DETAILS>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "INVALID USERNAME OR PASSWORD" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
        //ret.value = "1000";
        //ret.message = xmlstring;
        //return ret;
    }

    public String ResetUserPassword(String uid)
    {
        ReturnValue ret = null;
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataReader dr;
        SqlDataAdapter adpt;
        Account[] accts;

        String sentemail;
        Email email = new Email();
        String sub_mess;
        String main_mess;
        String selectqry = null;
        string emailaddress = "none@gtbank.com";
        string username = "";

        int count = 0;

        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            if (uid.Length == 9)
                uid = uid + "01";

            selectqry = "select user_id,email from users where user_id=" + uid;
            comm = new SqlCommand(selectqry, conn);
            dr = comm.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                if (!dr.IsDBNull(1))
                {
                    username = dr["user_id"].ToString();
                    //emailaddress = dr.GetString(1);
                    emailaddress = dr["email"].ToString();
                    dr.Close();
                }
                else
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>EMAIL ADDRESS IS NOT VALID</Error>";
                    xmlstring = xmlstring + "</Response>";
                    dr.Close();
                    return xmlstring;
                }
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>UNABLE TO RETRIEVE USER EMAIL ADDRESS</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }
            dr = null;
            //get a new password
            String password = null;
            password = GeneratePassword2();

            comm = new SqlCommand("updatePassCode", conn);
            comm.Parameters.AddWithValue("@u_id", long.Parse(uid));
            comm.Parameters.AddWithValue("@p_code", long.Parse(password));
            comm.Parameters.AddWithValue("@p_type", Int32.Parse("0"));

            comm.CommandType = CommandType.StoredProcedure;
            count = comm.ExecuteNonQuery();
            if (count > 0)
            {
                sub_mess = "GTBank IVR - Your new passcode";
                main_mess = "";
                main_mess = main_mess + "Dear " + username + ",";
                main_mess = main_mess + "\n" + "Find below your new password. Please note that you will be required to change your password the next time you login to internet banking.";
                main_mess = "\n" + password + "\n";
                main_mess = main_mess + "\n" + "Thank you." + "\n";
                
                try
                {
                    sentemail = email.SendEmail(emailaddress, sub_mess, main_mess, "");
                    xmlstring = xmlstring + "<CODE>1000</CODE>";
                    xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                }
                catch (Exception ex)
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
                }
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "UNABLE TO UPDATE PASSWORD" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }
    public String ResetUserPasswordOther(String uid)
    {
        ReturnValue ret = null;
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataReader dr;
        SqlDataAdapter adpt;
        Account[] accts;

        String sentemail;
        Email email = new Email();
        String sub_mess;
        String main_mess;
        String selectqry = null;
        string emailaddress = "none@gtbank.com";
        string username = "";

        int count = 0;

        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            if (uid.Length == 9)
                uid = uid + "01";

            selectqry = "select user_id,User_Name, email from users where user_id=" + uid;
            comm = new SqlCommand(selectqry, conn);
            dr = comm.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                if (!dr.IsDBNull(1))
                {
                    username = dr["User_Name"].ToString();
                    //emailaddress = dr.GetString(1);
                    emailaddress = dr["email"].ToString();
                    dr.Close();
                }
                else
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>EMAIL ADDRESS IS NOT VALID</Error>";
                    xmlstring = xmlstring + "</Response>";
                    dr.Close();
                    return xmlstring;
                }
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>UNABLE TO RETRIEVE USER EMAIL ADDRESS</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }
            dr = null;
            //get a new password
            String password = null;
            password = GeneratePassword2();

            comm = new SqlCommand("updatePassCode", conn);
            comm.Parameters.AddWithValue("@u_id", long.Parse(uid));
            comm.Parameters.AddWithValue("@p_code", long.Parse(password));
            comm.Parameters.AddWithValue("@p_type", Int32.Parse("0"));

            comm.CommandType = CommandType.StoredProcedure;
            count = comm.ExecuteNonQuery();
            if (count > 0)
            {
                sub_mess = string.Format("GTBank - Your new passcode");
                main_mess = "";
                main_mess = main_mess + "Dear " + username + ",";
                main_mess = main_mess + "\n" + "\n" + "Find below your new password:";
                main_mess = main_mess + "\n" + password;
                main_mess = main_mess + "\n" + "\n" + "Please note that you will be required to change your password the next time you login to internet banking.";
                main_mess = main_mess + "\n" + "\n" + "Thank you,";
                main_mess = main_mess + "\n" + "Guaranty Trust Bank Plc.";

                try
                {
                    sentemail = email.SendEmail("", emailaddress, sub_mess, main_mess);
                    xmlstring = xmlstring + "<CODE>1000</CODE>";
                    xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                }
                catch (Exception ex)
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
                }
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "UNABLE TO UPDATE PASSWORD" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    private string GeneratePassword2()
    {
        char[] chars = new char[62];
        //chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".ToCharArray();
        chars = "1234567890".ToCharArray();

        byte[] data = new byte[1];
        RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider();
        crypto.GetNonZeroBytes(data);
        data = new byte[6];
        crypto.GetNonZeroBytes(data);
        StringBuilder result = new StringBuilder(6);
        foreach (byte b in data)
        {
            result.Append(chars[b % (chars.Length - 1)]);
        }
        return result.ToString();
    }

    public String ChangeUserPassword(String uid, String password)
    {
        SqlConnection conn;
        SqlCommand comm;
        Email email = new Email();
        
        int count = 0;

        if (password.Trim().Length < 6)
        {
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + "Password must be at least 6 characters" + "</Error>";
            return xmlstring;
        }

        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("updatePassCode", conn);
            comm.Parameters.AddWithValue("@u_id", long.Parse(uid));
            comm.Parameters.AddWithValue("@p_code", long.Parse(password));
            comm.Parameters.AddWithValue("@p_type", Int32.Parse("0"));

            comm.CommandType = CommandType.StoredProcedure;
            count = comm.ExecuteNonQuery();
            if (count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>1000</MESSAGE>";   
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "UNABLE TO UPDATE PASSWORD" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String TransferFunds(String Acct_fro, String Acct_to, Double Amount, String type, String channel, String Remarks)
    {
        String t_from, t_to, Req_code, ResultStr;
        Char[] charsep = { '+' };
        Double T_amt;
        int Expl_code = 102;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        Boolean chk_bal = false;
        String Remarks1 = null;

        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = checkAccountFormat(Acct_fro.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to debit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";  
                return xmlstring;
            }

            chk_bal = checkAccountFormat(Acct_to.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to credit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";  
                return xmlstring;
            }


            tempstr = Acct_to.Split(delim);

            string[] temp1 = Acct_fro.Split(delim);
            if (tempstr[2] != "1" && (temp1[1] != tempstr[1]))
            {
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<ERROR>FX transfer not allowed</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }


            t_to = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');
            tempstr = Acct_fro.Split(delim);
            t_from = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');

            Amount = Math.Round(Amount, 2);

            T_amt = Amount;

            Req_code = "32";

            if (type == "OWN")
            {
                Expl_code = 100;
                Remarks1 = channel + " - OWN Account Transfer from " + Acct_fro + " to " + Acct_to;
            }
            else if (type == "PRE")
            {
                Expl_code = 102;
                Remarks1 = channel + " - PRE-REGISTERED Account Transfer from " + Acct_fro + " to " + Acct_to;
            }
            else if (type == "ANY")
            {
                Expl_code = 102;
                Remarks1 = channel + " - ANY Account Transfer from " + Acct_fro + " to " + Acct_to;
            }
            else if (type == "OTH")
            {
                Expl_code = 102;
                Remarks1 = Remarks;
            }
            else if (type == "OTHNOCHARGE")
            {
                Expl_code = 302;
                Remarks1 = Remarks;
            }
            else if (type == "DEPOSIT") // Cash Deposit
            {
                Expl_code = 642;
                Remarks1 = Remarks;
            }
            else if (type == "WITHDRAWAL") // Cash Withdrawal
            {
                Expl_code = 641;
                Remarks1 = Remarks;
            }
            else if (type == "GTMAX") // Cash GTMAX Account
            {
                Expl_code = 983;
                Remarks1 = Remarks;
            }


            ResultStr = this.PostToBasis(t_from, t_to, T_amt, Expl_code, Remarks1, Req_code);

            if (ResultStr.CompareTo("@ERR7@") == 0 || ResultStr.CompareTo("@ERR19@") == 0)
            {
                //log output
                if (type == "OWN" || type == "PRE" || type == "ANY")
                {
                    LogTransfer(Acct_fro.Replace("/", "").Substring(0, 9), Acct_fro, Acct_to, Convert.ToDecimal(T_amt), channel, Remarks1);
                }
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1002</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else
            {
                //get basis return error
                xmlstring = xmlstring + "<CODE>1004</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";  
        }

        return xmlstring;
    }

    public String TransferFunds2(String Acct_fro, String Acct_to, Double Amount, String type, String channel, int Expl_code, String Remarks, int bracode)
    {
        String t_from, t_to, Req_code, ResultStr;
        Char[] charsep = { '+' };
        Double T_amt;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        Boolean chk_bal = false;
        String Remarks1 = null;

        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = checkAccountFormat(Acct_fro.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to debit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            chk_bal = checkAccountFormat(Acct_to.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to credit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            tempstr = Acct_to.Split(delim);

            string[] temp1 = Acct_fro.Split(delim);
            if (tempstr[2] != "1" && (temp1[1] != tempstr[1]))
            {
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<ERROR>FX transfer not allowed</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }


            t_to = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');
            tempstr = Acct_fro.Split(delim);
            t_from = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');

            Amount = Math.Round(Amount, 2);

            T_amt = Amount;

            Req_code = "32";

            if (type == "OWN")
            {
                //Expl_code = 100;
                Remarks1 = channel + " - OWN Account Transfer from " + Acct_fro + " to " + Acct_to;
            }
            else if (type == "PRE")
            {
                //Expl_code = 102;
                Remarks1 = channel + " - PRE-REGISTERED Account Transfer from " + Acct_fro + " to " + Acct_to;
            }
            else if (type == "ANY")
            {
                //Expl_code = 102;
                Remarks1 = channel + " - ANY Account Transfer from " + Acct_fro + " to " + Acct_to;
            }
            else
            {
                //Expl_code = 102;
                Remarks1 = Remarks;
            }
            
            ResultStr = this.PostToBasis2(t_from, t_to, T_amt, Expl_code, Remarks1, Req_code, bracode);

            if (ResultStr.CompareTo("@ERR7@") == 0 || ResultStr.CompareTo("@ERR19@") == 0)
            {
                //log output
                if (type == "OWN" || type == "PRE" || type == "ANY")
                {
                    LogTransfer(Acct_fro.Replace("/", "").Substring(0, 9), Acct_fro, Acct_to, Convert.ToDecimal(T_amt), channel, Remarks1);
                }
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1002</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else
            {
                //get basis return error
                xmlstring = xmlstring + "<CODE>1004</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    //public String TransferFunds2_OBT(String Acct_fro, String Acct_to, Double Amount, String chg_Acct, String vat_Acct, int EXPL_CODE, String docnum, int identifier, String channel, String Remarks)
    //{
    //    String t_from, t_to, t_chg, t_vat, Req_code, ResultStr, ResultStr_chg;
    //    Char[] charsep = { '+' };
    //    Double T_amt;
    //    Char[] delim = new char[] { '/' };
    //    String[] tempstr;
    //    Boolean chk_bal = false;
    //    String Remarks1 = null;
    //    String charge_flg = "0";
    //    String depositor_type = "0";

    //    try
    //    {
    //        xmlstring = "<Response>";

    //        //Check account format
    //        chk_bal = checkAccountFormat(Acct_fro.Trim());
    //        if (chk_bal == false)
    //        {
    //            xmlstring = xmlstring + "<CODE>1003</CODE>";
    //            xmlstring = xmlstring + "<Error>Transaction failed: Format of account to debit is wrong or account does not exist in BASIS.</Error>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }

    //        chk_bal = checkAccountFormat(Acct_to.Trim());
    //        if (chk_bal == false)
    //        {
    //            xmlstring = xmlstring + "<CODE>1003</CODE>";
    //            xmlstring = xmlstring + "<Error>Transaction failed: Format of account to credit is wrong or account does not exist in BASIS.</Error>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }

    //        tempstr = Acct_to.Split(delim);
    //        t_to = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');

    //        tempstr = Acct_fro.Split(delim);
    //        t_from = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');

    //        tempstr = chg_Acct.Split(delim);
    //        t_chg = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');

    //        vat_Acct = t_from.Substring(1, 3) + "/" + vat_Acct;
    //        tempstr = vat_Acct.Split(delim);
    //        t_vat = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');

    //        Amount = Math.Round(Amount, 2);

    //        T_amt = Amount;

    //        String take_bankNEFTfee = ConfigurationManager.AppSettings["take_bankNEFTfee"].ToString();

    //        Decimal bankNEFTfee = 0M;
    //        if (take_bankNEFTfee == "YES")
    //            bankfee = getBankNEFTFee(Convert.ToDecimal(T_amt));
    //        else
    //            bankNEFTfee = 0M;

    //        Decimal chg_Amount = getChargeAmount(Convert.ToDecimal(T_amt));
    //        Decimal total_chg_Amount = chg_Amount + bankNEFTfee;
    //        Decimal vat_Amount = 0.05M * total_chg_Amount;

    //        //Check if account is funded above total amount
    //        Decimal total_amt = Convert.ToDecimal(T_amt) + total_chg_Amount + vat_Amount;
    //        tempstr = Acct_fro.Split(delim);
    //        String acct_f = CheckAccountFunded(Convert.ToInt32(tempstr[0]), Convert.ToInt32(tempstr[1]), Convert.ToInt32(tempstr[2]), Convert.ToInt32(tempstr[3]), Convert.ToInt32(tempstr[4]), total_amt);
    //        String[] param = acct_f.Split(delim);
    //        //depositor_type = param[1];
    //        depositor_type = "0";

    //        if (param[0] == "0")
    //        {
    //            xmlstring = xmlstring + "<CODE>1004</CODE>";
    //            xmlstring = xmlstring + "<Error>Account Balance Not Enough For This Tranasction</Error>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }
    //        else if (param[0] == "2")
    //        {
    //            xmlstring = xmlstring + "<CODE>1005</CODE>";
    //            xmlstring = xmlstring + "<Error>Error: Cannot Retrieve Account Details</Error>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }
    //        else if (param[0] == "3")
    //        {
    //            xmlstring = xmlstring + "<CODE>1005</CODE>";
    //            xmlstring = xmlstring + "<Error>Error: " + param[1] + "</Error>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }
    //        else
    //        {
    //            depositor_type = param[1];
    //        }

    //        charge_flg = ConfigurationManager.AppSettings["chargeflg"].ToString();

    //        AppDevService appdev = new AppDevService();
    //        appdev.Url = ConfigurationManager.AppSettings["EoneWebService"].ToString();

    //        Req_code = "32";

    //        //ResultStr = this.PostToBasis(t_from, t_to, T_amt, EXPL_CODE, Remarks, Req_code);
    //        if (charge_flg == "1" && (depositor_type != "23" && depositor_type != "110"))
    //        {
    //            ResultStr = appdev.TransferFund_Prin_Comm_VAT(Acct_fro, Acct_to, T_amt, EXPL_CODE, Remarks, Req_code, "0", 0, vat_Acct, chg_Acct, total_chg_Amount, vat_Amount, 44, 44);
    //            GetResponseMsg(ResultStr);
    //        }
    //        else
    //        {
    //            ResultStr = this.PostToBasis(t_from, t_to, T_amt, EXPL_CODE, Remarks, Req_code);
    //            if (ResultStr.CompareTo("@ERR7@") == 0 || ResultStr.CompareTo("@ERR19@") == 0)
    //            {
    //                rescode = "1000";
    //                resmsg = "SUCCESS";
    //            }
    //            else
    //            {
    //                rescode = "1001";
    //                resmsg = ErrorMsg(ResultStr);
    //            }
    //        }


    //        //if (ResultStr.CompareTo("@ERR7@") == 0 || ResultStr.CompareTo("@ERR19@") == 0)
    //        if (rescode == "1000")
    //        {
    //            //log output
    //            if (channel == "IB-NIP" || channel == "IVR")
    //                LogTransfer(userid, Acct_fro, Acct_to, Convert.ToDecimal(T_amt), channel, Remarks);

    //            //Collect Charges
    //            if (charge_flg == "1" && (depositor_type != "23" && depositor_type != "110"))
    //            {
    //                //ResultStr_chg = this.PostToBasis(t_from, t_chg, Convert.ToDouble(chg_Amount), 44, Remarks, Req_code);
    //                ResultStr_chg = "@ERR7@";
    //                if (ResultStr.CompareTo("@ERR7@") == 0 || ResultStr.CompareTo("@ERR19@") == 0)
    //                {
    //                    //log output
    //                    if (channel == "IB-NIP" || channel == "IVR")
    //                        LogTransCharges(Convert.ToInt64(userid), Acct_fro, chg_Acct, Convert.ToDecimal(T_amt), chg_Amount, "NIP Handling Charge", channel, "S", Remarks);
    //                }
    //                else
    //                {
    //                    if (channel == "IB-NIP" || channel == "IVR")
    //                        LogTransCharges(Convert.ToInt64(userid), Acct_fro, chg_Acct, Convert.ToDecimal(T_amt), chg_Amount, "NIP Handling Charge", channel, "F", Remarks);
    //                }

    //                //Collect VAT
    //                //ResultStr_chg = this.PostToBasis(t_from, t_vat, Convert.ToDouble(vat_Amount), 44, Remarks, Req_code);
    //                ResultStr_chg = "@ERR7@";
    //                if (ResultStr.CompareTo("@ERR7@") == 0 || ResultStr.CompareTo("@ERR19@") == 0)
    //                {
    //                    //log output
    //                    if (channel == "IB-NIP" || channel == "IVR")
    //                        LogTransCharges(Convert.ToInt64(userid), Acct_fro, vat_Acct, Convert.ToDecimal(T_amt), vat_Amount, "NIP VAT", channel, "S", Remarks);
    //                }
    //                else
    //                {
    //                    if (channel == "IB-NIP" || channel == "IVR")
    //                        LogTransCharges(Convert.ToInt64(userid), Acct_fro, vat_Acct, Convert.ToDecimal(T_amt), vat_Amount, "NIP VAT", channel, "F", Remarks);
    //                }
    //            }

    //            xmlstring = xmlstring + "<CODE>1000</CODE>";
    //            xmlstring = xmlstring + "<MESSAGE>SUCESS</MESSAGE>";
    //        }
    //        else
    //        {
    //            //get basis return error
    //            xmlstring = xmlstring + "<CODE>1001</CODE>";
    //            xmlstring = xmlstring + "<Error> " + resmsg + "</Error>";
    //        }

    //        xmlstring = xmlstring + "</Response>";
    //    }
    //    catch (Exception ex)
    //    {
    //        xmlstring = "<Response>";
    //        xmlstring = xmlstring + "<CODE>1002</CODE>";
    //        xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
    //        xmlstring = xmlstring + "</Response>";
    //    }

    //    return xmlstring;
    //}

    public string PostToBasis_Prin_Comm_VAT(string Acct_from, string Acct_to, double Tra_amt, int Expl_code, string Remark, string Req_code, string docnum, int identifier, string VATAccount, string commacct, decimal comm, decimal vat, int commexpl, int vatexpl)
    {
        String ResultStr = "";

        xmlstring = "<Response>";

        string[] fromacct = Acct_from.Split('/');   //Split account to debit
        int FRM_BRA_CODE = Convert.ToInt32(fromacct[0]);
        int FRM_CUS_NUM = Convert.ToInt32(fromacct[1]);
        int FRM_CUR_CODE = Convert.ToInt32(fromacct[2]);
        int FRM_LED_CODE = Convert.ToInt32(fromacct[3]);
        int FRM_SUB_ACCT_CODE = Convert.ToInt32(fromacct[4]);

        string[] Toacct = Acct_to.Split('/');       //Split account to credit
        int TO_BRA_CODE = Convert.ToInt32(Toacct[0]);
        int TO_CUS_NUM = Convert.ToInt32(Toacct[1]);
        int TO_CUR_CODE = Convert.ToInt32(Toacct[2]);
        int TO_LED_CODE = Convert.ToInt32(Toacct[3]);
        int TO_SUB_ACCT_CODE = Convert.ToInt32(Toacct[4]);

        if (VATAccount.Equals(""))
        {
            VATAccount = "0/0/0/0/0";
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + "Format of VAT account not correct" + "</Error>";
            xmlstring = xmlstring + "</Response>";
            return xmlstring;
        }

        string[] VATacct = VATAccount.Split('/');
        int VAT_BRA_CODE = Convert.ToInt32(VATacct[0]);
        int VAT_CUS_NUM = Convert.ToInt32(VATacct[1]);
        int VAT_CUR_CODE = Convert.ToInt32(VATacct[2]);
        int VAT_LED_CODE = Convert.ToInt32(VATacct[3]);
        int VAT_SUB_ACCT_CODE = Convert.ToInt32(VATacct[4]);

        if (commacct.Equals(""))
        {
            commacct = "0/0/0/0/0";
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + "Format of Commission account not correct" + "</Error>";
            xmlstring = xmlstring + "</Response>";
            return xmlstring;
        }

        string[] comacct = commacct.Split('/');
        int COM_BRA_CODE = Convert.ToInt32(comacct[0]);
        int COM_CUS_NUM = Convert.ToInt32(comacct[1]);
        int COM_CUR_CODE = Convert.ToInt32(comacct[2]);
        int COM_LED_CODE = Convert.ToInt32(comacct[3]);
        int COM_SUB_ACCT_CODE = Convert.ToInt32(comacct[4]);


        //string a = string.Empty;
        string Result = string.Empty;
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("EONEPKG.GTBVCR21", oraconn);

        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {

            //objConn.Open("Provider='SQLOLEDB';Data Source='MyServer'; Initial Catalog='MyDataBase';", UserName, Password, intConnectionMode)

            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }

            oracomm.Parameters.Add("FRM_BRA_CODE", OracleType.Number, 15).Value = FRM_BRA_CODE;
            oracomm.Parameters.Add("FRM_CUS_NUM", OracleType.Number, 15).Value = FRM_CUS_NUM;
            oracomm.Parameters.Add("FRM_CUR_CODE", OracleType.Number, 15).Value = FRM_CUR_CODE;
            oracomm.Parameters.Add("FRM_LED_CODE", OracleType.Number, 15).Value = FRM_LED_CODE;
            oracomm.Parameters.Add("FRM_SUB_ACCT_CODE", OracleType.Number, 15).Value = FRM_SUB_ACCT_CODE;
            oracomm.Parameters.Add("IN_TRA_AMT", OracleType.Number, 15).Value = Tra_amt;
            oracomm.Parameters.Add("TO_BRA_CODE", OracleType.Number, 15).Value = TO_BRA_CODE;
            oracomm.Parameters.Add("TO_CUS_NUM", OracleType.Number, 15).Value = TO_CUS_NUM;
            oracomm.Parameters.Add("TO_CUR_CODE", OracleType.Number, 15).Value = TO_CUR_CODE;
            oracomm.Parameters.Add("TO_LED_CODE", OracleType.Number, 15).Value = TO_LED_CODE;
            oracomm.Parameters.Add("TO_SUB_ACCT_CODE", OracleType.Number, 15).Value = TO_SUB_ACCT_CODE;
            oracomm.Parameters.Add("INP_TELL_ID", OracleType.Number, 15).Value = 9938;
            oracomm.Parameters.Add("inp_doc_num", OracleType.Number, 15).Value = 0;
            oracomm.Parameters.Add("inp_doc_ALP", OracleType.VarChar, 15).Value = "3";
            oracomm.Parameters.Add("INP_EXPL_CODE", OracleType.Number, 15).Value = Expl_code;
            oracomm.Parameters.Add("INP_REMARKS", OracleType.VarChar, 200).Value = Remark;
            oracomm.Parameters.Add("INP_VAT_BRA_CODE", OracleType.Number, 15).Value = VAT_BRA_CODE;
            oracomm.Parameters.Add("INP_VAT_CUS_NUM", OracleType.Number, 15).Value = VAT_CUS_NUM;
            oracomm.Parameters.Add("INP_VAT_LED_CODE", OracleType.Number, 15).Value = VAT_LED_CODE;
            oracomm.Parameters.Add("INP_VAT_SUB_CODE", OracleType.Number, 15).Value = VAT_SUB_ACCT_CODE;
            oracomm.Parameters.Add("INP_COMM_BRA_CODE", OracleType.Number, 15).Value = COM_BRA_CODE;
            oracomm.Parameters.Add("INP_COMM_CUS_NUM", OracleType.Number, 15).Value = COM_CUS_NUM;
            oracomm.Parameters.Add("INP_COMM_LED_CODE", OracleType.Number, 15).Value = COM_LED_CODE;
            oracomm.Parameters.Add("INP_COMM_SUB_CODE", OracleType.Number, 15).Value = COM_SUB_ACCT_CODE;
            oracomm.Parameters.Add("COMM_AMNT", OracleType.Number, 15).Value = comm;
            oracomm.Parameters.Add("VAT_AMNT", OracleType.Number, 15).Value = vat;
            oracomm.Parameters.Add("EXP_WHT", OracleType.Number, 15).Value = commexpl;
            oracomm.Parameters.Add("EXP_VAT", OracleType.Number, 15).Value = vatexpl;
            oracomm.Parameters.Add("WHTREMARKS", OracleType.VarChar, 200).Value = Remark;

            oracomm.Parameters.Add("RETURN_STATUS", OracleType.Number, 100).Direction = ParameterDirection.InputOutput;
            oracomm.ExecuteNonQuery();
            ResultStr = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
            oraconn.Close();

            if (ResultStr.CompareTo("0") == 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }
            else
            {
                //get basis return error
                xmlstring = xmlstring + "<CODE>1004</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
            //return ex.Message;
        }


        return xmlstring;

    }

    public int PostToBASIS_Block(int bra_code, int cus_Num, int cur_code, int led_code, int sub_acct_code, double Amount)
    {

        int Result = -1;



        using (OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"].ToString())))
        {

            using (OracleCommand oracomm = new OracleCommand("BLK_FUNDS", oraconn))
            {

                oracomm.CommandType = CommandType.StoredProcedure;

                try
                {

                    if (oraconn.State == ConnectionState.Closed)
                    {

                        oraconn.Open();

                    }

                    oracomm.Parameters.Add("INP_BRA_CODE", OracleType.Number, 15).Value = bra_code;

                    oracomm.Parameters.Add("INP_CUS_NUM", OracleType.Number, 15).Value = cus_Num;

                    oracomm.Parameters.Add("INP_CUR_CODE", OracleType.Number, 15).Value = cur_code;

                    oracomm.Parameters.Add("INP_LED_CODE", OracleType.Number, 15).Value = led_code;

                    oracomm.Parameters.Add("INP_SUB_ACCT_CODE", OracleType.Number, 15).Value = sub_acct_code;

                    oracomm.Parameters.Add("INP_BLO_AMT", OracleType.Number, 15).Value = Amount;



                    oracomm.Parameters.Add("return_status", OracleType.Number, 15).Direction = ParameterDirection.Output;



                    oracomm.ExecuteNonQuery();



                    Result = Convert.ToInt32(oracomm.Parameters["return_status"].Value.ToString());



                }
                catch (Exception ex)
                {

                    //ErrorWriter.WriteError(ex.Message);

                    //ErrLog.AppLogWrite(ex.Message, true);

                }
                finally
                {

                    oraconn.Close();

                }

                return Result;

            }

        }

    }

    public String Transfer(String Acct_fro, String Acct_to, Double Amount, int expl_code, String Remarks)
    {
        String t_from, t_to, Req_code, ResultStr;
        Char[] charsep = { '+' };
        Double T_amt;
        int Expl_code = 102;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        Boolean chk_bal = false;
        String Remarks1 = null;

        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = checkAccountFormat(Acct_fro.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to debit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            chk_bal = checkAccountFormat(Acct_to.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to credit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            tempstr = Acct_to.Split(delim);

            string[] temp1 = Acct_fro.Split(delim);
            if (tempstr[2] != "1" && (temp1[1] != tempstr[1]))
            {
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<ERROR>FX transfer not allowed</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }


            t_to = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');
            tempstr = Acct_fro.Split(delim);
            t_from = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');

            Amount = Math.Round(Amount, 2);

            T_amt = Amount;

            Req_code = "32";

            ResultStr = this.PostToBasis(t_from, t_to, T_amt, expl_code, Remarks, Req_code);

            if (ResultStr.CompareTo("@ERR7@") == 0 || ResultStr.CompareTo("@ERR19@") == 0)
            {
                //log output
                //if (type == "OWN" || type == "PRE" || type == "ANY")
                //{
                //    LogTransfer(Acct_fro.Replace("/", "").Substring(0, 9), Acct_fro, Acct_to, Convert.ToDecimal(T_amt), channel, Remarks1);
                //}
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCESS</MESSAGE>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1002</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else
            {
                //get basis return error
                xmlstring = xmlstring + "<CODE>1004</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<ERROR>" + ex.Message + "</ERROR>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String TransferFunds_Cross(String Acct_fro, String Acct_to, Double Amount, Double Rate, Double CrossRate, String type, String channel, String Remarks)
    {
        String t_from, t_to, Req_code, ResultStr;
        Char[] charsep = { '+' };
        Double T_amt;
        int Expl_code = 102;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        Boolean chk_bal = false;
        String Remarks1 = null;

        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = checkAccountFormat(Acct_fro.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to debit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            chk_bal = checkAccountFormat(Acct_to.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to credit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

 
            tempstr = Acct_to.Split(delim);
            t_to = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');
            tempstr = Acct_fro.Split(delim);
            t_from = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');

            Amount = Math.Round(Amount, 2);

            T_amt = Amount;

            Req_code = "32";

            if (type == "OWN")
            {
                Expl_code = 100;
                Remarks1 = channel + " - OWN Account Transfer from " + Acct_fro + " to " + Acct_to;
            }
            else if (type == "PRE")
            {
                Expl_code = 102;
                Remarks1 = channel + " - PRE-REGISTERED Account Transfer from " + Acct_fro + " to " + Acct_to;
            }
            else if (type == "ANY")
            {
                Expl_code = 102;
                Remarks1 = channel + " - ANY Account Transfer from " + Acct_fro + " to " + Acct_to;
            }
            else if (type == "FX_SALES")
            {
                Expl_code = 241;
                Remarks1 = channel + " - FX Purchase from " + Acct_fro + " to " + Acct_to + " " + Remarks;
            }
            else if (type == "OTH")
            {
                Expl_code = 102;
                Remarks1 = Remarks;
            }
            else if (type == "OTHNOCHARGE")
            {
                Expl_code = 302;
                Remarks1 = Remarks;
            }

            ResultStr = this.PostToBasis_Cross(t_from, t_to, T_amt, Expl_code, Remarks1, Req_code, Rate, CrossRate);

            if (ResultStr.CompareTo("@ERR7@") == 0 || ResultStr.CompareTo("@ERR19@") == 0)
            {
                //log output
                if (type == "OWN" || type == "PRE" || type == "ANY")
                {
                    LogTransfer(Acct_fro.Replace("/", "").Substring(0, 9), Acct_fro, Acct_to, Convert.ToDecimal(T_amt), channel, Remarks1);
                }
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCESS</MESSAGE>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1002</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else
            {
                //get basis return error
                xmlstring = xmlstring + "<CODE>1004</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String TransferCheques(String Acct_fro, String Acct_to, Double Amount, String type, String channel, String Remarks, String docnum, Int16 identifier, Int16 bankcode, Int16 days)
    {
        String t_from, Req_code, ResultStr;
        String t_to = "";
        Char[] charsep = { '+' };
        Double T_amt;
        int Expl_code;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        Boolean chk_bal = false;
        String Remarks1 = null;

        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = checkAccountFormat(Acct_fro.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to debit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            chk_bal = checkAccountFormat(Acct_to.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to credit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }
            tempstr = Acct_to.Split(delim);
            if (type.Equals("33"))   //System Account
            {
                t_to = tempstr[0].PadLeft(3, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(2, '0');
            }
            else if (type.Equals("34"))   //Customer Account
            {
                t_to = tempstr[0].PadLeft(3, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(2, '0') + tempstr[3].PadLeft(2, '0') + tempstr[4].PadLeft(2, '0');
            }
            tempstr = Acct_fro.Split(delim);
            t_from = tempstr[0].PadLeft(3, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(2, '0') + tempstr[3].PadLeft(2, '0') + tempstr[4].PadLeft(2, '0');

            Amount = Math.Round(Amount, 2);

            T_amt = Amount;

            Req_code = type;
            Expl_code = 953;
            identifier = 4;
            
            Remarks1 = channel + " - DivPay:: Transfer from " + Acct_fro + " to " + Acct_to;


            //if (type == "OWN")
            //{
            //    Expl_code = 100;
            //    Remarks1 = channel + " - OWN Account Transfer from " + Acct_fro + " to " + Acct_to;
            //}
            //else if (type == "PRE")
            //{
            //    Expl_code = 102;
            //    Remarks1 = channel + " - PRE-REGISTERED Account Transfer from " + Acct_fro + " to " + Acct_to;
            //}
            //else if (type == "ANY")
            //{
            //    Expl_code = 102;
            //    Remarks1 = channel + " - ANY Account Transfer from " + Acct_fro + " to " + Acct_to;
            //}
            //else if (type == "OTH")
            //{
            //    Expl_code = 102;
            //    Remarks1 = Remarks;
            //}
            //else if (type == "OTHNOCHARGE")
            //{
            //    Expl_code = 302;
            //    Remarks1 = Remarks;
            //}

            ResultStr = this.PostToBasis_Cheque(t_from, t_to, T_amt, Expl_code, Remarks1, Req_code, docnum, identifier, bankcode, days);

            if (ResultStr.CompareTo("@ERR7@") == 0 || ResultStr.CompareTo("@ERR19@") == 0)
            {
                //log output
                //if (type == "33" || type == "34" || type == "ANY")
                //{
                //    LogTransfer(Acct_fro.Replace("/", "").Substring(0, 9), Acct_fro, Acct_to, Convert.ToDecimal(T_amt), channel, Remarks1);
                //}
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCESS</MESSAGE>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1002</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else
            {
                //get basis return error
                xmlstring = xmlstring + "<CODE>1004</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String TransferGTBCheques(String Acct_fro, String Acct_to, Double Amount, String type, String channel, String Remarks, String docnum, Int16 identifier, Int16 bankcode, Int16 days)
    {
        String t_from, Req_code, ResultStr;
        String t_to = "";
        Char[] charsep = { '+' };
        Double T_amt;
        int Expl_code;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        Boolean chk_bal = false;

        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = checkAccountFormat(Acct_fro.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to debit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            chk_bal = checkAccountFormat(Acct_to.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to credit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }
            tempstr = Acct_to.Split(delim);

            t_to = tempstr[0].PadLeft(3, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(2, '0');
            tempstr = Acct_fro.Split(delim);
            t_from = tempstr[0].PadLeft(3, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(2, '0') + tempstr[3].PadLeft(2, '0') + tempstr[4].PadLeft(2, '0');

            Amount = Math.Round(Amount, 2);

            T_amt = Amount;

            Req_code = type;
            //Expl_code = 953;
            Expl_code = 647;
            //identifier = 4;

            ResultStr = this.PostToBasis_Cheque(t_from, t_to, T_amt, Expl_code, Remarks, Req_code, docnum, identifier, bankcode, days);

            if (ResultStr.CompareTo("@ERR7@") == 0 || ResultStr.CompareTo("@ERR19@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCESS</MESSAGE>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            
            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String InitiateStandingInstruction(String acctno, int pFreq, DateTime p1stPayDate, Decimal Amount, DateTime pLastPayDate, String pAcctToCredit, String pRemarks)
    {
        char[] delim = new char[] { '/' };
        String[] tempstr1, tempstr2;
        String t_from, t_to, ResultStr;
        Boolean chk_bal = false;

        String inst_seq = "0";  //Not Determined
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataReader reader;

        String query_str = null;
        
        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = checkAccountFormat(acctno.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to debit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            tempstr1 = acctno.Split(delim);
            tempstr2 = pAcctToCredit.Split(delim);
            t_from = tempstr2[0].PadLeft(4, '0') + tempstr2[1].PadLeft(7, '0') + tempstr2[2].PadLeft(3, '0') + tempstr2[3].PadLeft(4, '0') + tempstr2[4].PadLeft(3, '0');

            Amount = Math.Round(Amount, 2);

            ResultStr = this.PostStandinInstruction(Convert.ToInt32(tempstr1[0]), Convert.ToInt32(tempstr1[1]), Convert.ToInt32(tempstr1[2]), Convert.ToInt32(tempstr1[3]), Convert.ToInt32(tempstr1[4]), pFreq, p1stPayDate, Amount, pLastPayDate, t_from, pRemarks);

            if (ResultStr == "0")
            {
                //Get the sequence for the standing Inst
                try
                {
                    oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

                    query_str = "select max(inst_seq) as SEQ from stan_ins where bra_code=" + tempstr1[0] + " and cus_num= " + tempstr1[1] + " and cur_code=" + tempstr1[2] + " and led_code=" + tempstr1[3] + " and sub_acct_code=" + tempstr1[4] + " and cre_acct='" + t_from + "' and pay_amt=" + Amount.ToString() + " and tell_id=9938 and remarks like '%" + pRemarks + "%'";
                    oraconn.Open();
                    cmd = new OracleCommand(query_str, oraconn);
                    reader = cmd.ExecuteReader();

                    if (reader.HasRows)
                    {
                        reader.Read();
                        inst_seq = reader["SEQ"].ToString();
                    }
                    else
                    {
                        inst_seq = "0"; //Not Determined
                    }

                    reader.Close();
                    reader = null;
                    cmd = null;
                    if (oraconn.State != ConnectionState.Closed) oraconn.Close();
                }
                catch (Exception ex)
                {
                    inst_seq = "0"; //Not Determined
                }

                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "<SEQUENCE>" + inst_seq + "</SEQUENCE>";
            }
            else
            {
                //get basis return error
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
                xmlstring = xmlstring + "<SEQUENCE>0</SEQUENCE>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "<SEQUENCE>0</SEQUENCE>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String InitiateStandingInstruction_Charge(String acctno, int pFreq, DateTime p1stPayDate, Decimal Amount, DateTime pLastPayDate, String pAcctToCredit, String pRemarks)
    {
        char[] delim = new char[] { '/' };
        String[] tempstr1, tempstr2, tempstr3;
        String[] SI_exempt_ledgers;
        String SI_exempt_ledgers_list = "";
        Boolean exempt_ledgers_to = false;

        String t_from, t_from_credit, t_to, t_comm, t_vat, ResultStr="", ResultStr_comm, ResultStr_vat;
        Boolean chk_bal = false, post_comm=false, post_vat=false;
        String Acct_comm, Acct_vat;
        String comm_amtstr = "0", vat_amtstr = "0";
        Decimal comm_amt = 0M, vat_amt = 0M;
        Decimal availbal = 0M;
        Decimal amtRqd = 0M;
        String ChargeStatus = "";

        String inst_seq = "0";  //Not Determined
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataReader reader;

        String query_str = null;
        String deptype = null;
        String p1stdate_str = p1stPayDate.Day.ToString().PadLeft(2,'0') + p1stPayDate.Month.ToString().PadLeft(2,'0') + p1stPayDate.Year.ToString().PadLeft(4,'0');
        String pLstdate_str = pLastPayDate.Day.ToString().PadLeft(2,'0') + pLastPayDate.Month.ToString().PadLeft(2,'0') + pLastPayDate.Year.ToString().PadLeft(4,'0');

        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = checkAccountFormat(acctno.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to debit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            if (p1stPayDate >= pLastPayDate)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Standing Instruction start date must be less that end date</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            tempstr1 = acctno.Split(delim);
            tempstr2 = pAcctToCredit.Split(delim);
            t_from_credit = tempstr2[0].PadLeft(4, '0') + tempstr2[1].PadLeft(7, '0') + tempstr2[2].PadLeft(3, '0') + tempstr2[3].PadLeft(4, '0') + tempstr2[4].PadLeft(3, '0');

            //Check if account to debit should be exempted for SKS
            SI_exempt_ledgers_list = ConfigurationManager.AppSettings["StandIns_Exempt_Ledgers"].ToString();
            SI_exempt_ledgers = SI_exempt_ledgers_list.Split(',');
            foreach (String str_val in SI_exempt_ledgers)
            {
                if (str_val == tempstr2[3])
                {
                    exempt_ledgers_to = true;
                    break;
                }
            }

            Amount = Math.Round(Amount, 2);

            String take_bankStandInsfee = ConfigurationManager.AppSettings["take_bankStandInsfee"].ToString();

            Acct_comm = ConfigurationManager.AppSettings["StandIns_COMM_account"].ToString();
            Acct_vat = ConfigurationManager.AppSettings["StandIns_VAT_account"].ToString();

            if (take_bankStandInsfee == "YES")
                comm_amtstr = ConfigurationManager.AppSettings["StandIns_COMM_amount"].ToString();
            else
                comm_amtstr = "0.00";

            Acct_comm = Acct_comm.Replace("xxx", acctno.Substring(0, 3));
            Acct_vat = Acct_vat.Replace("xxx", acctno.Substring(0, 3));

            tempstr2 = Acct_comm.Split(delim);
            tempstr3 = Acct_vat.Split(delim);
            t_from = tempstr1[0].PadLeft(4, '0') + tempstr1[1].PadLeft(7, '0') + tempstr1[2].PadLeft(3, '0') + tempstr1[3].PadLeft(4, '0') + tempstr1[4].PadLeft(3, '0');
            t_comm = tempstr2[0].PadLeft(4, '0') + tempstr2[1].PadLeft(7, '0') + tempstr2[2].PadLeft(3, '0') + tempstr2[3].PadLeft(4, '0') + tempstr2[4].PadLeft(3, '0');
            t_vat = tempstr3[0].PadLeft(4, '0') + tempstr3[1].PadLeft(7, '0') + tempstr3[2].PadLeft(3, '0') + tempstr3[3].PadLeft(4, '0') + tempstr3[4].PadLeft(3, '0');

            //Amount = Math.Round(Amount, 2);

            comm_amt = Convert.ToDecimal(comm_amtstr);
            vat_amt = comm_amt * 5M / 100M;

            amtRqd = comm_amt + vat_amt;

            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
            oraconn.Open();

            String param_str = tempstr1[0] + "," + tempstr1[1] + "," + tempstr1[2] + "," + tempstr1[3] + "," + tempstr1[4];

            //---------------------------------------------------------------------------------
            //Check if standing instruction with this detail already exist
            query_str = "select inst_seq as SEQ from stan_ins where bra_code=" + tempstr1[0] + " and cus_num=" + tempstr1[1] + " and cur_code=" + tempstr1[2] + " and led_code=" + tempstr1[3] + " and sub_acct_code=" + tempstr1[4] + " and pay_freq = " + pFreq.ToString() + " and cre_acct = '" + t_from_credit + "' and pay_amt=" + Amount.ToString() + " and tell_id=9938 and fst_pay_date = '" + p1stdate_str + "' and las_pay_date = '" + pLstdate_str + "'";  // and remarks like '%" + pRemarks + "%'";

            cmd = new OracleCommand(query_str, oraconn);
            //OracleDataReader reader;

            // execute the function
            reader = cmd.ExecuteReader();
            if (reader.HasRows == true)
            {
                reader.Read();
                inst_seq = reader["SEQ"].ToString();

                //get available balance
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "<SEQUENCE>" + inst_seq + "</SEQUENCE>";
                xmlstring = xmlstring + "<POSTCOMM>TRUE</POSTCOMM>";
                xmlstring = xmlstring + "<POSTVAT>TRUE</POSTVAT>";
                xmlstring = xmlstring + "<CHARGESTATUS>Standing instruction already exist for the supplied details. Record will be updated accordingly</CHARGESTATUS>";
                xmlstring = xmlstring + "</Response>";

                reader.Close();
                //if (oraconn.State != ConnectionState.Closed) oraconn.Close();
                return xmlstring;
            }
                        
            //---------------------------------------------------------------------------------
            
            //Check account balance and determine if account to debit os funded
            query_str = "select navailbal(" + param_str + ") as Avail_Bal, a.cle_bal, a.crnt_bal, b.type_of_dep from account a, customer b where a.bra_code=b.bra_code and a.cus_num=b.cus_num and a.bra_code=" + tempstr1[0] + " and a.cus_num=" + tempstr1[1] + " and a.cur_code=" + tempstr1[2] + " and a.led_code=" + tempstr1[3] + " and a.sub_acct_code=" + tempstr1[4];

            cmd = new OracleCommand(query_str, oraconn);
            //OracleDataReader reader;

            // execute the function
            reader = cmd.ExecuteReader();
            if (reader.HasRows == true)
            {
                reader.Read();

                //get available balance
                availbal = Convert.ToDecimal(reader["Avail_Bal"].ToString());
                availbal = Math.Round(availbal, 2);

                //get dep type
                deptype = reader["type_of_dep"].ToString();
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Cannot determine customer status.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                if (oraconn.State != ConnectionState.Closed) oraconn.Close();
                return xmlstring;
            }

            reader.Close();
            //oraconn.Close();
            if ((availbal < amtRqd) && (exempt_ledgers_to == false))
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Customer account is not funded for charges</ERROR>";
                xmlstring = xmlstring + "</Response>";
                if (oraconn.State != ConnectionState.Closed) oraconn.Close();
                return xmlstring;
            }

            
            ResultStr = this.PostStandinInstruction(Convert.ToInt32(tempstr1[0]), Convert.ToInt32(tempstr1[1]), Convert.ToInt32(tempstr1[2]), Convert.ToInt32(tempstr1[3]), Convert.ToInt32(tempstr1[4]), pFreq, p1stPayDate, Amount, pLastPayDate, t_from_credit, pRemarks);

            if (ResultStr == "0")
            {
                //Get the sequence for the standing Inst
                try
                {
                    //oraconn = new OracleConnection(ConfigurationManager.AppSettings["BASISConString_eone"]);

                    query_str = "select max(inst_seq) as SEQ from stan_ins where bra_code=" + tempstr1[0] + " and cus_num= " + tempstr1[1] + " and cur_code=" + tempstr1[2] + " and led_code=" + tempstr1[3] + " and sub_acct_code=" + tempstr1[4] + " and cre_acct='" + t_from_credit + "' and pay_amt=" + Amount.ToString() + " and tell_id=9938 and remarks like '%" + pRemarks + "%'";
                    if (oraconn.State != ConnectionState.Open) oraconn.Open();
                    cmd = new OracleCommand(query_str, oraconn);
                    reader = cmd.ExecuteReader();

                    if (reader.HasRows)
                    {
                        reader.Read();
                        inst_seq = reader["SEQ"].ToString();
                    }
                    else
                    {
                        inst_seq = "0"; //Not Determined
                    }

                    reader.Close();
                    reader = null;
                    cmd = null;
                    
                }
                catch (Exception ex)
                {
                    inst_seq = "0"; //Not Determined
                }

                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "<SEQUENCE>" + inst_seq + "</SEQUENCE>";

                if (oraconn.State != ConnectionState.Closed) oraconn.Close();

                //Take charges
                try
                {
                    String Req_code = "32";

                    if (take_bankStandInsfee == "YES" && ( (deptype != "23" && deptype != "110" && deptype != "112") && (exempt_ledgers_to == false) ) ) 
                    {
                        ResultStr_comm = this.PostToBasis(t_from, t_comm, Convert.ToDouble(comm_amt), 44, "Comm. on StandIns", Req_code);

                        if (ResultStr_comm.CompareTo("@ERR7@") == 0 || ResultStr_comm.CompareTo("@ERR19@") == 0)
                        {
                            post_comm = true;

                            ResultStr_vat = this.PostToBasis(t_from, t_vat, Convert.ToDouble(vat_amt), 44, "VAT on StandIns Comm.", Req_code);

                            if (ResultStr_vat.CompareTo("@ERR7@") == 0 || ResultStr_vat.CompareTo("@ERR19@") == 0)
                            {
                                post_vat = true;
                                ChargeStatus = "SUCCESS";
                            }
                            else
                            {
                                ChargeStatus = "COMM. POSTED BUT VAT NOT POSTED";
                            }
                        }
                        else
                        {
                            ChargeStatus = "CHARGES NOT POSTED";
                        }
                    }
                    else
                    {
                        ChargeStatus = "CHARGES NOT POSTED BECAUSE CUSTOMER IS EXEMPTED FROM CHARGES";
                    }

                    xmlstring = xmlstring + "<POSTCOMM>" + post_comm.ToString().ToUpper() + "</POSTCOMM>";
                    xmlstring = xmlstring + "<POSTVAT>" + post_vat.ToString().ToUpper() + "</POSTVAT>";
                    xmlstring = xmlstring + "<CHARGESTATUS>" + ChargeStatus.ToUpper() + "</CHARGESTATUS>";

                }
                catch (Exception ex1)
                {
                    xmlstring = xmlstring + "<POSTCOMM>" + post_comm.ToString().ToUpper() + "</POSTCOMM>";
                    xmlstring = xmlstring + "<POSTVAT>" + post_vat.ToString().ToUpper() + "</POSTVAT>";
                    xmlstring = xmlstring + "<CHARGESTATUS>" + ex1.Message.Replace("'", "").ToUpper() + "</CHARGESTATUS>";
                }

                
            }
            else
            {
                //get basis return error
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr).ToUpper() + "</ERROR>";
                xmlstring = xmlstring + "<POSTCOMM>" + post_comm.ToString().ToUpper() + "</POSTCOMM>";
                xmlstring = xmlstring + "<POSTVAT>" + post_vat.ToString().ToUpper() + "</POSTVAT>";
                xmlstring = xmlstring + "<CHARGESTATUS>CHARGE NOT POSTED</CHARGESTATUS>";
                xmlstring = xmlstring + "<SEQUENCE>0</SEQUENCE>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<ERROR>" + ex.Message + "</ERROR>";
            xmlstring = xmlstring + "<SEQUENCE>0</SEQUENCE>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    
    public String CancelStandingInstruction(String acctno, int pSeq)
    {
        Boolean chk_bal = false;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        String ResultStr;

        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = checkAccountFormat(acctno.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            tempstr = acctno.Split(delim);

            ResultStr = this.CancelStandinIns(Convert.ToInt32(tempstr[0]), Convert.ToInt32(tempstr[1]), Convert.ToInt32(tempstr[2]), Convert.ToInt32(tempstr[3]), Convert.ToInt32(tempstr[4]), pSeq);

            if (ResultStr == "0")
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }
            else
            {
                //get basis return error
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }


        return xmlstring;
    }

    public String GetAccountBalance(int bracode, int cusnum, int curcode, int ledcode, int subacctcode)
    {
        String Remark = string.Empty, query_str;
        Char[] charsep = { '+' };
        String[] outputStr = { "A", "B" };
        char[] delim = new char[] { '/' };
        String param_str = null;
        Double amt = 0.0;

        try
        {
            xmlstring = "<Response>";

            // create the connection
            OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
            param_str = bracode.ToString() + "," + cusnum.ToString() + "," + curcode.ToString() + "," + ledcode.ToString() + "," + subacctcode.ToString();
            // create the command for the function
            query_str = "select navailbal(" + param_str + ") as Avail_Bal, cle_bal, crnt_bal from account where bra_code=" + bracode.ToString() + " and cus_num=" + cusnum.ToString() + " and cur_code=" + curcode.ToString() + " and led_code=" + ledcode.ToString() + " and sub_acct_code=" + subacctcode.ToString();

            oraconn.Open();
            OracleCommand cmd = new OracleCommand(query_str, oraconn);
            OracleDataReader reader;

            // execute the function
            reader = cmd.ExecuteReader();
            if (reader.HasRows == true)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                reader.Read();

                //get current balance
                amt = Convert.ToDouble(reader["crnt_bal"]);
                amt = Math.Round(amt, 2);
                xmlstring = xmlstring + "<BOOKBALANCE>" + amt.ToString("N").Replace(",","") + "</BOOKBALANCE>";
               
                //get available balance
                amt = Convert.ToDouble(reader["Avail_Bal"]);
                amt = Math.Round(amt, 2);
                xmlstring = xmlstring + "<AVAILABLEBALANCE>" + amt.ToString("N").Replace(",","") + "</AVAILABLEBALANCE>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR>ACCOUNT DOES NOT EXIST</ERROR>";
            }

            reader.Close();
            reader = null;
            cmd = null;
            oraconn.Close();
            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'","") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String GetCustomerName(int bracode, int cusnum)
    {
        String Remark = string.Empty, query_str;
        Char[] charsep = { '+' };
        String[] outputStr = { "A", "B" };
        char[] delim = new char[] { '/' };
        

        try
        {
            xmlstring = "<Response>";

            // create the connection
            OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
            // create the command for the function
            query_str = "select cus_sho_name from address where bra_code=" + bracode.ToString() + " and cus_num=" + cusnum.ToString() + " and cur_code=0 and led_code=0 and sub_acct_code=0";

            oraconn.Open();
            OracleCommand cmd = new OracleCommand(query_str, oraconn);
            OracleDataReader reader;

            // execute the function
            reader = cmd.ExecuteReader();
            if (reader.HasRows == true)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                reader.Read();

                //get current balance
                xmlstring = xmlstring + "<CUSTOMERNAME>" + reader["cus_sho_name"].ToString() + "</CUSTOMERNAME>";

            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR>ACCOUNT DOES NOT EXIST</ERROR>";
            }

            reader.Close();
            reader = null;
            cmd = null;
            oraconn.Close();
            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String GetTransactionDetails(int bracode, int cusnum, int curcode, int ledcode, int subacctcode, int notrans)
    {
        String Remark = string.Empty, query_str;
        Char[] charsep = { '+' };
        String[] outputStr = { "A", "B" };
        char[] delim = new char[] { '/' };
        DateTime last_tra_date, last_tra_date_month;
        int newnotrans = 0;
        String start_date, end_date;
        Double amt = 0.0;

        try
        {
            xmlstring = "<Response>";

            // create the connection
            OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
            oraconn.Open();
            OracleCommand cmd = null;
            OracleDataAdapter adpt = null;
            DataSet ds, dsfinal = null;

            OracleDataReader reader;

            query_str = "SELECT las_tra_date FROM account where bra_code=" + bracode.ToString() + " and cus_num=" + cusnum.ToString() + " and cur_code=" + curcode.ToString() + " and led_code=" + ledcode.ToString() + " and sub_acct_code=" + subacctcode.ToString();
            cmd = new OracleCommand(query_str, oraconn);
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                last_tra_date = Convert.ToDateTime(reader["las_tra_date"]);
                reader.Close();
                reader = null;
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR>ACCOUNT DOES NOT EXIST</ERROR>";
                xmlstring = xmlstring + "</Response>";
                reader.Close();
                reader = null;
                return xmlstring;
            }
            
            // create the command for the function
            query_str = "SELECT TRA_DATE, TRA_AMT, DECODE(DEB_CRE_IND,1,'DEB',2,'CRE') AS STATUS, ORIGT_BRA_CODE, UPD_TIME FROM tell_act where bra_code=" + bracode.ToString() + " and cus_num=" + cusnum.ToString() + " and cur_code=" + curcode.ToString() + " and led_code=" + ledcode.ToString() + " and sub_acct_code=" + subacctcode.ToString() + " ORDER BY TRA_DATE DESC, UPD_TIME DESC";
            cmd = new OracleCommand(query_str, oraconn);
            adpt = new OracleDataAdapter(cmd);
            dsfinal = new DataSet();
            adpt.Fill(dsfinal);

            if (dsfinal.Tables[0].Rows.Count < notrans)
            {
                newnotrans = notrans - dsfinal.Tables[0].Rows.Count; ;
                while (newnotrans > 0)
                {
                    last_tra_date_month = last_tra_date.AddMonths(-1);
                    end_date = last_tra_date.Day.ToString().PadLeft(2, '0') + last_tra_date.Month.ToString().PadLeft(2, '0') + last_tra_date.Year.ToString().PadLeft(4, '0');
                    start_date = last_tra_date_month.Day.ToString().PadLeft(2, '0') + last_tra_date_month.Month.ToString().PadLeft(2, '0') + last_tra_date_month.Year.ToString().PadLeft(4, '0');
                    query_str = "SELECT TRA_DATE, TRA_AMT, DECODE(DEB_CRE_IND,1,'DEB',2,'CRE') AS STATUS, ORIGT_BRA_CODE, UPD_TIME FROM transact where bra_code=" + bracode.ToString() + " and cus_num=" + cusnum.ToString() + " and cur_code=" + curcode.ToString() + " and led_code=" + ledcode.ToString() + " and sub_acct_code=" + subacctcode.ToString() + " AND TRA_DATE BETWEEN '" + start_date + "' AND '" + end_date + "' ORDER BY TRA_DATE DESC, UPD_TIME DESC";
                    cmd = new OracleCommand(query_str, oraconn);
                    adpt = new OracleDataAdapter(cmd);
                    ds = new DataSet();
                    adpt.Fill(ds);
                    newnotrans = newnotrans - ds.Tables[0].Rows.Count;
                    last_tra_date = last_tra_date.AddMonths(-1);
                    dsfinal.Merge(ds.Tables[0], false, MissingSchemaAction.Error);

                }
            }

            oraconn.Close();
            oraconn = null;
            adpt = null;
            cmd = null;

            // execute the function
            if (dsfinal.Tables[0].Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<TRANSACTIONS>";
                foreach (DataRow dr in dsfinal.Tables[0].Rows)
                {
                    xmlstring = xmlstring + "<TRANSACTION>";
                    xmlstring = xmlstring + "<TRADATE>" + Convert.ToDateTime(dr["TRA_DATE"]).ToShortDateString() + "</TRADATE>";
                    amt = Math.Round(Math.Abs(Convert.ToDouble(reader["Avail_Bal"])), 2);
                    xmlstring = xmlstring + "<TRAAMT>" + amt.ToString() + "</TRAAMT>";
                    xmlstring = xmlstring + "<TRASTATUS>" + dr["STATUS"].ToString() + "</TRASTATUS>";
                    xmlstring = xmlstring + "<TRABRACODE>" + dr["ORIGT_BRA_CODE"].ToString() + "</TRABRACODE>";
                    xmlstring = xmlstring + "</TRANSACTION>";
                }
                xmlstring = xmlstring + "</TRANSACTIONS>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR>COULD NOT RETRIEVE TRANSACTIONS</ERROR>";
            }
            dsfinal = null;
            cmd = null;
            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String GetLastTransactionDetails(int bracode, int cusnum, int curcode, int ledcode, int subacctcode)
    {
        String Remark = string.Empty;
        Char[] charsep = { '+' };
        String[] outputStr = { "A", "B" };
        char[] delim = new char[] { '/' };
        Double amt = 0.0;
        OracleDataAdapter adpt = null;
        DataSet ds, dsfinal = null;
        DateTime dt;
        String datestr = null;

        try
        {
            OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_ivr"]));
            xmlstring = "<Response>";
            OracleCommand oracomm = new OracleCommand("IVRTRANS.TRANSACTS", oraconn);
            oracomm.CommandType = CommandType.StoredProcedure;
            try
            {
                if (oraconn.State == ConnectionState.Closed)
                {
                    oraconn.Open();
                }
                oracomm.Parameters.Add("bra", OracleType.Number).Value = bracode;
                oracomm.Parameters.Add("cusnum", OracleType.Number).Value = cusnum;
                oracomm.Parameters.Add("cur", OracleType.Number).Value = curcode;
                oracomm.Parameters.Add("led", OracleType.Number).Value = ledcode;
                oracomm.Parameters.Add("sub", OracleType.Number).Value = subacctcode;
                oracomm.Parameters.Add("results", OracleType.Cursor).Direction = ParameterDirection.Output;

                adpt = new OracleDataAdapter(oracomm);
                dsfinal = new DataSet();
                adpt.Fill(dsfinal);
                oraconn.Close();
                //Result = "@ERR7@";
            }
            catch (Exception ex)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR>" + ex.Message.Replace("'","") + "</ERROR>";
                xmlstring = xmlstring + "</Response>";
                //reader.Close();
                //reader = null;
                return xmlstring;
            }
            // create the connection
            
            oraconn.Close();
            oraconn = null;

            if (dsfinal.Tables[0].Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<TRANSACTIONS>";
                foreach (DataRow dr in dsfinal.Tables[0].Rows)
                {
                    xmlstring = xmlstring + "<TRANSACTION>";
                    dt = Convert.ToDateTime(dr["TRA_DATE"]);
                    datestr = dt.Year.ToString().PadLeft(4, '0') + "-" + dt.Month.ToString().PadLeft(2, '0') + "-" + dt.Day.ToString().PadLeft(2, '0');
                    xmlstring = xmlstring + "<TRADATE>" + datestr + "</TRADATE>";
                    amt = Math.Abs(Convert.ToDouble(dr["amt"]));
                    amt = Math.Round(Math.Abs(amt), 2);
                    xmlstring = xmlstring + "<TRAAMT>" + amt.ToString("N").Replace(",","") + "</TRAAMT>";
                    xmlstring = xmlstring + "<TRASTATUS>" + GetIVRPrompt(dr["EXPL_CODE"].ToString()) + "</TRASTATUS>";
                    xmlstring = xmlstring + "<TRABRACODE>" + dr["ORIGT_BRA_CODE"].ToString() + "</TRABRACODE>";
                    xmlstring = xmlstring + "<PROMPTFILE>" + GetIVRPrompt("BR" + dr["ORIGT_BRA_CODE"].ToString()) + "</PROMPTFILE>";
                    xmlstring = xmlstring + "</TRANSACTION>";
                }
                xmlstring = xmlstring + "</TRANSACTIONS>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR>COULD NOT RETRIEVE TRANSACTIONS</ERROR>";
            }
            dsfinal = null;
            oracomm = null;
            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String GetLastAccountStatement(int bracode, int cusnum, int curcode, int ledcode, int subacctcode, String custemail)
    {
        String Remark = string.Empty, status_str;
        Char[] charsep = { '+' };
        String[] outputStr = { "A", "B" };
        char[] delim = new char[] { '/' };
        String sentemail;
        Email email = new Email();
        String sub_mess;
        String main_mess;
        Double amt = 0.0;

        OracleDataAdapter adpt = null;
        DataSet dsfinal = null;

        try
        {
            OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_ivr"]));
            xmlstring = "<Response>";
            OracleCommand oracomm = new OracleCommand("IVRTRANS.TRANSACTS", oraconn);
            oracomm.CommandType = CommandType.StoredProcedure;
            try
            {
                if (oraconn.State == ConnectionState.Closed)
                {
                    oraconn.Open();
                }
                oracomm.Parameters.Add("bra", OracleType.Number).Value = bracode;
                oracomm.Parameters.Add("cusnum", OracleType.Number).Value = cusnum;
                oracomm.Parameters.Add("cur", OracleType.Number).Value = curcode;
                oracomm.Parameters.Add("led", OracleType.Number).Value = ledcode;
                oracomm.Parameters.Add("sub", OracleType.Number).Value = subacctcode;
                oracomm.Parameters.Add("results", OracleType.Cursor).Direction = ParameterDirection.Output;

                adpt = new OracleDataAdapter(oracomm);
                dsfinal = new DataSet();
                adpt.Fill(dsfinal);
                oraconn.Close();
                //Result = "@ERR7@";
            }
            catch (Exception ex)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR>" + ex.Message.Replace("'", "") + "</ERROR>";
                xmlstring = xmlstring + "</Response>";
                //reader.Close();
                //reader = null;
                return xmlstring;
            }
            // create the connection

            oraconn.Close();
            oraconn = null;

            if (dsfinal.Tables[0].Rows.Count > 0)
            {
                try
                {
                    sub_mess = "GTBank IVR - Your statement by email";
                    sub_mess = sub_mess + " (" + bracode.ToString() + "/" + cusnum.ToString() + "/" + curcode.ToString() + "/" + ledcode.ToString() + "/" + subacctcode.ToString() + ")";
                    main_mess = "\n" + "S/No".PadRight(5) + "Transaction Amount".PadRight(20) + "Transaction Date".PadRight(20) + "\n";

                    foreach (DataRow dr in dsfinal.Tables[0].Rows)
                    {
                        amt = Math.Abs(Convert.ToDouble(dr["AMT"]));
                        amt = Math.Round(Math.Abs(amt), 2);
                        if (dr["DEB_CRE_IND"].ToString() == "1")
                            status_str = amt.ToString("N") + "(DR)";
                        else
                            status_str = amt.ToString("N") + "(CR)";

                        main_mess = main_mess + "\n" + dr["ROWNUM"].ToString().PadRight(5) + status_str.PadRight(20) + Convert.ToDateTime(dr["TRA_DATE"]).ToShortDateString().PadRight(20);

                    }
                    sentemail = email.SendEmail(custemail, sub_mess, main_mess, "");

                    xmlstring = xmlstring + "<CODE>1000</CODE>";
                    xmlstring = xmlstring + "</MESSAGE>SUCCESS</MESSAGE>";

                }
                catch (Exception ex)
                {
                    xmlstring = xmlstring + "<CODE>1010</CODE>";
                    xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
                }     
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR>COULD NOT RETRIEVE TRANSACTIONS</ERROR>";
            }
            dsfinal = null;
            oracomm = null;
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
        }

        xmlstring = xmlstring + "</Response>";
        return xmlstring;
    }

    public String StopCheque(int bracode, int cusnum, int curcode, int ledcode, int subacctcode, int startno, int endno, String amt)
    {
        string Result = string.Empty;
        Decimal Amount = 0;
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_ivr"]));
        OracleCommand oracomm = new OracleCommand("ivrstopay", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        xmlstring = "<Response>";
        try
        {
            Amount = Convert.ToDecimal(amt);
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("BRA", OracleType.Number).Value = bracode;
            oracomm.Parameters.Add("CUSNUM", OracleType.Number).Value = cusnum;
            oracomm.Parameters.Add("CUR", OracleType.Number).Value = curcode;
            oracomm.Parameters.Add("LED", OracleType.Number).Value = ledcode;
            oracomm.Parameters.Add("SUB", OracleType.Number).Value = subacctcode;
            oracomm.Parameters.Add("DOCNUMFROM", OracleType.Number).Value = startno;
            oracomm.Parameters.Add("DOCNUMTO", OracleType.Number).Value = endno;
            oracomm.Parameters.Add("CHQAMT", OracleType.Number).Value = Amount;
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.Number).Direction = ParameterDirection.Output;

            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
            oraconn.Close();

            if (Result == "0")
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR>STOP CHEQUE FAILED WITH RESULT CODE:" + Result + "</ERROR>";
            }
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<ERROR>STOP CHEQUE FAILED WITH BASIS ERROR:" + ex.Message.Replace("'","") + "</ERROR>";
        }

        oraconn.Close();
        oracomm = null;
        xmlstring = xmlstring + "</Response>";

        return xmlstring;
    }

    public String GetRoleUsers(int id, int appid)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataTable dt;
        DataRow dr;
        String xmlrep = null;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("GetApplicationRoleUsers", conn);
            comm.Parameters.AddWithValue("@RoleID", id);
            comm.Parameters.AddWithValue("@ApplicationID", appid);

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();
            adpt.Fill(ds);

            xmlstring = "<Response>";
            xmlrep = ds.GetXml(); 
            if (ds.Tables[0].Rows.Count > 0)
            {
                dr = ds.Tables[0].Rows[0];
                
                xmlstring = xmlstring + "<CODE>1000</CODE>";

                //GET USER
                xmlstring = xmlstring + "<USER>";
                xmlstring = xmlstring + "<ID>" + dr["User_id"] + "</ID>";
                xmlstring = xmlstring + "<NAME>" + dr["User_name"] + "</NAME>";
                xmlstring = xmlstring + "<BRANCH>" + dr["branch_code"] + "</BRANCH>";
                xmlstring = xmlstring + "<EMAIL>" + dr["email"].ToString() + "</EMAIL>";
                xmlstring = xmlstring + "</USER>";
                
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "COULD NOT RETRIEVE USERS" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'","") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    private String GetIVRPrompt(String code)
    {
        String uname = null;
        SqlDataReader reader;
        //SqlConnection conn = new SqlConnection(TTrackerDAL.Properties.Settings.Default.E_OneDB);
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
        string queryString = "Select description, code, file_name From promptsetup where code = '" + code + "'";

        SqlCommand comm = new SqlCommand(queryString, conn);
        comm.CommandType = CommandType.Text;
        //open connetion
        if (conn.State != ConnectionState.Open)
        {
            conn.Open();
        }
        reader = comm.ExecuteReader();
        if (reader.HasRows)
        {
            reader.Read();
            uname = reader["file_name"].ToString();
        }
        else
        {
            uname = "plural.wav";
        }
        reader.Close();
        reader = null;
        conn.Close();
        conn = null;
        return uname;
    }
    public String GetAdminUserName(String userid)
    {
        String uname = null;
        SqlDataReader reader;
        //SqlConnection conn = new SqlConnection(TTrackerDAL.Properties.Settings.Default.E_OneDB);
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
        string queryString = "Select user_name From admin_users where user_id=" + userid;

        SqlCommand comm = new SqlCommand(queryString, conn);
        comm.CommandType = CommandType.Text;
        //open connetion
        if (conn.State != ConnectionState.Open)
        {
            conn.Open();
        }
        reader = comm.ExecuteReader();
        reader.Read();
        uname = reader["user_name"].ToString();
        reader.Close();
        reader = null;
        conn.Close();
        conn = null;
        return uname;
    }


    //private string PostToBasis(string Acct_from, string Acct_to, double Tra_amt, int Expl_code, string Remark, string Req_code)
    //{
    //    string Result = string.Empty;

    //    //Round the amount to 2 decimal places
    //    Tra_amt = Math.Round(Tra_amt, 2, MidpointRounding.AwayFromZero);

    //    OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
    //    OracleCommand oracomm = new OracleCommand("GTBPBSC0_FULL", oraconn);
    //    oracomm.CommandType = CommandType.StoredProcedure;
    //    try
    //    {
    //        if (oraconn.State == ConnectionState.Closed)
    //        {
    //            oraconn.Open();
    //        }
    //        oracomm.Parameters.Add("INP_ACCT_FROM", OracleType.VarChar, 21).Value = Acct_from.Trim();
    //        oracomm.Parameters.Add("INP_ACCT_TO", OracleType.VarChar, 21).Value = Acct_to.Trim();
    //        oracomm.Parameters.Add("INP_TRA_AMT", OracleType.Number, 15).Value = Tra_amt;
    //        oracomm.Parameters.Add("INP_EXPL_CODE", OracleType.Number, 15).Value = Expl_code;
    //        oracomm.Parameters.Add("INP_REMARKS", OracleType.VarChar, 200).Value = Remark;
    //        oracomm.Parameters.Add("INP_RQST_CODE", OracleType.VarChar, 15).Value = Req_code.Trim();
    //        //oracomm.Parameters.Add("INP_TELL_ID", OracleType.Number, 15).Value = 9015;
    //        oracomm.Parameters.Add("OUT_RETURN_STATUS", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

    //        oracomm.ExecuteNonQuery();
    //        Result = oracomm.Parameters["OUT_RETURN_STATUS"].Value.ToString();
    //        oraconn.Close();
    //        //Result = "@ERR7@";
    //    }
    //    catch (Exception ex)
    //    {
    //        return ex.Message;
    //    }

    //    //if (Result.CompareTo("@ERR7@") == 0 || Result.CompareTo("@ERR19@") == 0)
    //    //{
    //    return Result;
    //    //}
    //    //else
    //    //{
    //    //    //get basis return error
    //    //    return ErrorMsg(Result);
    //    //}
    //}


    public string PostToBasis(string Acct_from, string Acct_to, double Tra_amt, int Expl_code, string Remark, string Req_code)
    {
        string Result = string.Empty;

        if (Acct_from.Trim() == Acct_to.Trim())
        {
            return "@ERR-74@";
        }

        //Round the amount to 2 decimal places
        Tra_amt = Math.Round(Tra_amt, 2, MidpointRounding.AwayFromZero);

        using (OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
        {
            OracleTransaction transaction;
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            transaction = oraconn.BeginTransaction(IsolationLevel.ReadCommitted);

            try
            {
                OracleCommand oracomm = oraconn.CreateCommand();
                oracomm.CommandType = CommandType.StoredProcedure;
                oracomm.CommandTimeout = 60;
                //Start a local transaction and assign transaction object for a pending local transaction                
                oracomm.Transaction = transaction;
                oracomm.CommandText = "gtbpbsc0_full_ibank";

                oracomm.Parameters.Add("INP_ACCT_FROM", OracleType.VarChar, 21).Value = Acct_from;
                oracomm.Parameters.Add("INP_ACCT_TO", OracleType.VarChar, 21).Value = Acct_to;
                oracomm.Parameters.Add("INP_TRA_AMT", OracleType.Double, 20).Value = Tra_amt;
                oracomm.Parameters.Add("INP_EXPL_CODE", OracleType.Int32, 15).Value = Expl_code;
                oracomm.Parameters.Add("INP_REMARKS", OracleType.VarChar, 200).Value = Remark;
                oracomm.Parameters.Add("INP_RQST_CODE", OracleType.VarChar, 15).Value = Req_code;
                oracomm.Parameters.Add("OUT_RETURN_STATUS", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                oracomm.ExecuteNonQuery();
                Result = oracomm.Parameters["OUT_RETURN_STATUS"].Value.ToString();

                if (Result.Trim().CompareTo("@ERR7@") == 0 || Result.Trim().CompareTo("@ERR19@") == 0)
                {
                    transaction.Commit();
                    ErrHandler.WriteError("Commit successful for transaction with details INP_ACCT_FROM = " + Acct_from + " || INP_ACCT_TO = " + Acct_to + " || INP_REMARKS = " + Remark + " || OUT_RETURN_STATUS = " + Result);
                    return Result;
                }
                else
                {
                    transaction.Rollback();
                    ErrHandler.WriteError("Rollback for transaction with details INP_ACCT_FROM = " + Acct_from + " || INP_ACCT_TO = " + Acct_to + " || INP_REMARKS = " + Remark + " || OUT_RETURN_STATUS = " + Result);
                    return Result;
                }
            }
            catch (Exception ex)
            {
                Result = "-2";
                transaction.Rollback();
                ErrHandler.WriteError("Error Posting to Basis, issued a rollback : with details INP_ACCT_FROM = " + Acct_from + " || INP_ACCT_TO = " + Acct_to + " || INP_REMARKS = " + Remark + " || OUT_RETURN_STATUS = " + Result + " ERROR = " + ex.Message);
                return Result;
            }
            finally
            {
                oraconn.Close();
            }
        }
    }





    private string PostToBasis2(string Acct_from, string Acct_to, double Tra_amt, int Expl_code, string Remark, string Req_code, int bracode)
    {
        string Result = string.Empty;

        //Round the amount to 2 decimal places
        Tra_amt = Math.Round(Tra_amt, 2, MidpointRounding.AwayFromZero);

        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("EONEPKG.GTBPBSC0_FULL", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("INP_ACCT_FROM", OracleType.VarChar, 21).Value = Acct_from.Trim();
            oracomm.Parameters.Add("INP_ACCT_TO", OracleType.VarChar, 21).Value = Acct_to.Trim();
            oracomm.Parameters.Add("INP_TRA_AMT", OracleType.Number, 15).Value = Tra_amt;
            oracomm.Parameters.Add("INP_EXPL_CODE", OracleType.Number, 15).Value = Expl_code;
            oracomm.Parameters.Add("INP_REMARKS", OracleType.VarChar, 200).Value = Remark;
            oracomm.Parameters.Add("INP_RQST_CODE", OracleType.VarChar, 15).Value = Req_code.Trim();
            oracomm.Parameters.Add("INP_ORIGT_BRA_CODE", OracleType.Number, 15).Value = bracode;
            oracomm.Parameters.Add("OUT_RETURN_STATUS", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["OUT_RETURN_STATUS"].Value.ToString();
            oraconn.Close();
            //Result = "@ERR7@";
        }
        catch (Exception ex)
        {
            return ex.Message;
        }

        //if (Result.CompareTo("@ERR7@") == 0 || Result.CompareTo("@ERR19@") == 0)
        //{
        return Result;
        //}
        //else
        //{
        //    //get basis return error
        //    return ErrorMsg(Result);
        //}
    }

    private string PostToBasis_Cross(string Acct_from, string Acct_to, double Tra_amt, int Expl_code, string mReference, string Req_code, Double mRate, Double mCrossRate)
    {
        string Result = string.Empty;

        //Round the amount to 2 decimal places
        Tra_amt = Math.Round(Tra_amt, 2, MidpointRounding.AwayFromZero);

        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("GTBPBSC0_FULL_RATE", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("INP_ACCT_FROM", OracleType.VarChar, 21).Value = Acct_from.Trim();
            oracomm.Parameters.Add("INP_ACCT_TO", OracleType.VarChar, 21).Value = Acct_to.Trim();
            oracomm.Parameters.Add("INP_TRA_AMT", OracleType.Number, 15).Value = Tra_amt;
            oracomm.Parameters.Add("INP_EXPL_CODE", OracleType.Number, 15).Value = Expl_code;
            oracomm.Parameters.Add("INP_REMARKS", OracleType.VarChar, 200).Value = mReference;
            oracomm.Parameters.Add("INP_RQST_CODE", OracleType.VarChar, 15).Value = Req_code.Trim();
            oracomm.Parameters.Add("RATE", OracleType.Number, 15).Value = mRate;
            oracomm.Parameters.Add("CROSS_RATE", OracleType.Number, 15).Value = mCrossRate;
            oracomm.Parameters.Add("OUT_RETURN_STATUS", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["OUT_RETURN_STATUS"].Value.ToString();
            oraconn.Close();
            //Result = "@ERR7@";
        }
        catch (Exception ex)
        {
            return ex.Message;
        }

        //if (Result.CompareTo("@ERR7@") == 0 || Result.CompareTo("@ERR19@") == 0)
        //{
        return Result;
        //}
        //else
        //{
        //    //get basis return error
        //    return ErrorMsg(Result);
        //}
    }


    private string PostToBasis_Cheque(string Acct_from, string Acct_to, double Tra_amt, int Expl_code, string Remark, string Req_code, string docnum, int identifier, int bankcode, int days)
    {
        string Result = string.Empty;

        //Round the amount to 2 decimal places
        Tra_amt = Math.Round(Tra_amt, 2, MidpointRounding.AwayFromZero);

        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("EONEPKG.GTBPBSC_INTERFACE", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("INP_ACCT_FROM", OracleType.VarChar).Value = Acct_from.Trim();
            oracomm.Parameters.Add("INP_ACCT_TO", OracleType.VarChar).Value = Acct_to.Trim();
            oracomm.Parameters.Add("INP_TRA_AMT", OracleType.Number, 15).Value = Tra_amt;
            oracomm.Parameters.Add("INP_EXPL_CODE", OracleType.Number, 15).Value = Expl_code;
            oracomm.Parameters.Add("INP_DOC_NUM", OracleType.VarChar, 15).Value = docnum;
            oracomm.Parameters.Add("INP_IDENTIFIER", OracleType.Number, 15).Value = identifier;
            oracomm.Parameters.Add("INP_BNK_CODE", OracleType.Number, 15).Value = bankcode;
            oracomm.Parameters.Add("INP_REMARKS", OracleType.VarChar, 200).Value = Remark;
            oracomm.Parameters.Add("INP_DAYS", OracleType.VarChar, 5).Value = days;
            oracomm.Parameters.Add("INP_RQST_CODE", OracleType.Number, 15).Value = Req_code.Trim(); ;
            oracomm.Parameters.Add("OUT_RETURN_STATUS", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["OUT_RETURN_STATUS"].Value.ToString();
            oraconn.Close();
            //Result = "@ERR7@";
        }
        catch (Exception ex)
        {
            return ex.Message;
        }

        //if (Result.CompareTo("@ERR7@") == 0 || Result.CompareTo("@ERR19@") == 0)
        //{
        return Result;
        //}
        //else
        //{
        //    //get basis return error
        //    return ErrorMsg(Result);
        //}
    }

    private string PostStandinInstruction(int pBranchCode, int pCustomerNo, int pCurrency, int pLedger, int pSubAcctCode, int pFreq, DateTime p1stPayDate, Decimal Amount, DateTime pLastPayDate, String pAcctToCredit, String pRemarks)
    {
        string Result = string.Empty;
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("eonepkg.stan_ins_add", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("BRA", OracleType.Number).Value = pBranchCode;
            oracomm.Parameters.Add("CUS", OracleType.Number).Value = pCustomerNo;
            oracomm.Parameters.Add("CUR", OracleType.Number).Value = pCurrency;
            oracomm.Parameters.Add("LED", OracleType.Number).Value = pLedger;
            oracomm.Parameters.Add("SUB", OracleType.Number).Value = pSubAcctCode;
            oracomm.Parameters.Add("NPAY_FREQ", OracleType.Number).Value = pFreq;
            oracomm.Parameters.Add("DFST_PAY_DATE", OracleType.DateTime).Value = p1stPayDate;
            oracomm.Parameters.Add("NFST_PAY_AMT", OracleType.Number).Value = Amount;
            oracomm.Parameters.Add("DLAS_PAY_DATE", OracleType.DateTime).Value = pLastPayDate;
            oracomm.Parameters.Add("SCRE_ACCT", OracleType.VarChar).Value = pAcctToCredit;
            oracomm.Parameters.Add("SREMARKS", OracleType.VarChar).Value = pRemarks;
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.Number).Direction = ParameterDirection.Output;

            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
            oraconn.Close();
            //Result = "@ERR7@";
        }
        catch (Exception ex)
        {
            return ex.Message;
        }

        //if (Result.CompareTo("@ERR7@") == 0 || Result.CompareTo("@ERR19@") == 0)
        //{
        return Result;
        //}
        //else
        //{
        //    //get basis return error
        //    return ErrorMsg(Result);
        //}
    }

    private string CancelStandinIns(int pBranchCode, int pCustomerNo, int pCurrency, int pLedger, int pSubAcctCode, int pSeq)
    {
        string Result = string.Empty;
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("eonepkg.stan_ins_del", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("BRA", OracleType.Number).Value = pBranchCode;
            oracomm.Parameters.Add("CUS", OracleType.Number).Value = pCustomerNo;
            oracomm.Parameters.Add("CUR", OracleType.Number).Value = pCurrency;
            oracomm.Parameters.Add("LED", OracleType.Number).Value = pLedger;
            oracomm.Parameters.Add("SUB", OracleType.Number).Value = pSubAcctCode;
            oracomm.Parameters.Add("NINST_SEQ", OracleType.Number).Value = pSeq;
            
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.Number).Direction = ParameterDirection.Output;

            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
            oraconn.Close();
            //Result = "@ERR7@";
        }
        catch (Exception ex)
        {
            return ex.Message;
        }

        //if (Result.CompareTo("@ERR7@") == 0 || Result.CompareTo("@ERR19@") == 0)
        //{
        return Result;
        //}
        //else
        //{
        //    //get basis return error
        //    return ErrorMsg(Result);
        //}
    }
    
    public string ErrorMsg(string errorCode)
    {
        string errorDescription = string.Empty;
        switch (errorCode.Replace("-", ""))
        {
            case "@ERR1@":
                errorDescription = "Invalid Source Account";
                break;
            case "@ERR2@":
                errorDescription = "Source Account has restrictions";
                break;
            case "@ERR3@":
                errorDescription = "Invalid Target Account";
                break;
            case "@ERR4@":
                errorDescription = "Target Account has restrictions";
                break;
            case "@ERR5@":
                errorDescription = "Invalid Amount";
                break;
            case "@ERR6@":
                errorDescription = "Unknown Error: Transaction Unsuccessful!";
                break;
            case "@ERR7@":
                errorDescription = "Operation Successful!";
                break;
            case "@ERR8@":
                errorDescription = "Unknown Error: Transaction Unsuccessful!";
                break;
            case "@ERR9@":
                errorDescription = "Transfer cannot be Executed";
                break;
            case "@ERR10@":
                errorDescription = "Invalid Account";
                break;
            case "@ERR11@":
                errorDescription = "Invalid Password";
                break;
            case "@ERR12@":
                errorDescription = "Invalid Branch";
                break;
            case "@ERR13@":
                errorDescription = "Invalid Check Number!";
                break;
            case "@ERR14@":
                errorDescription = "Cheque Cashed";
                break;
            case "@ERR15@":
                errorDescription = "Invalid Sub Account";
                break;
            case "@ERR16@":
                errorDescription = "Invalid Customer number";
                break;
            case "@ERR17@":
                errorDescription = "Customer has no PBS Account";
                break;
            case "@ERR18@":
                errorDescription = "Request Already Exists";
                break;
            case "@ERR19@":
                errorDescription = "Request accepted for further processing";
                break;
            case "@ERR20@":
                errorDescription = "Accounts involved do not belong to the same branch";
                break;
            case "@ERR21@":
                errorDescription = "Accounts involved do not belong to the same customer";
                break;
            case "@ERR22@":
                errorDescription = "Accounts involved are not of the same currency";
                break;
            case "@ERR23@":
                errorDescription = "Transfer amount exceeds accounts allowed transfer limit";
                break;
            case "@ERR24@":
                errorDescription = "Transfer Amount exceeds Accounts available balance";
                break;
            case "@ERR25@":
                errorDescription = "One of the Branches Involved is not on the network";
                break;
            case "@ERR26@":
                errorDescription = "No Data Retrieved";
                break;
            case "@ERR27@":
                errorDescription = "Not a checking Account";
                break;
            case "@ERR28@":
                errorDescription = "Source Account is Dormant";
                break;
            case "@ERR29@":
                errorDescription = "Target Account is Dormant";
                break;
            case "@ERR30@":
                errorDescription = "Source Account is Closed";
                break;
            case "@ERR31@":
                errorDescription = "Target Account is closed";
                break;
            case "@ERR32@":
                errorDescription = "External Transactions are not allowed on Source Account";
                break;
            case "@ERR33@":
                errorDescription = "External Transactions are not allowed on Target Account";
                break;
            case "@ERR58@":
                errorDescription = "Either the Source or the Target Account Has Restriction";
                break;
				case "@ERR844@":
                errorDescription = "Cheque is not within customer series";
                break;
			case "@ERR845@":
                errorDescription = "Cheque Has Been Processed Before";
                break;
            default:
                errorDescription = "Error occurred: Transaction Unsuccessful!";
                break;
        }
        return errorDescription;
    }

    public Boolean checkAccountFormat(String acctno)
    {
        char[] delim = new char[] { '/' };
        String[] tempstr;

        tempstr = acctno.Split(delim);
        if (tempstr.GetLength(0) != 5)
            return false;
        else if (tempstr[0].Length != 3)
            return false;
        else
            return true;
    }

    private Boolean existsInBasis(String acctno)
    {
        String query_str, Remark = string.Empty;

        char[] delim = new char[] { '/' };
        String[] tempstr;
        //Double comamt, vatamt;
        //String commstr, vatstr;

        try
        {
            tempstr = acctno.Split(delim);

            // create the connection
            OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

            // create the command for the function
            query_str = "select bra_code from account where bra_code=" + tempstr[0].Trim() + " and cus_num=" + tempstr[1].Trim() + " and cur_code=" + tempstr[2].Trim() + " and led_code=" + tempstr[3].Trim() + " and sub_acct_code=" + tempstr[4].Trim();

            oraconn.Open();
            OracleCommand cmd = new OracleCommand(query_str, oraconn);
            OracleDataReader reader;

            // execute the function
            reader = cmd.ExecuteReader();
            if (reader.HasRows == true)
            {
                reader = null;
                cmd = null;
                oraconn.Close();
                return true;
            }
            else
            {
                reader = null;
                cmd = null;
                oraconn.Close();
                return false;
            }
        }
        catch (Exception ex)
        {
            return false;
        }
    }

    private String GetAccountFromBasis(String acctno)
    {
        string Result = string.Empty;
        string Result1 = string.Empty;
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_ivr"]));
        OracleCommand oracomm = new OracleCommand("IVRCHECKACCOUNT", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("INP_ACCT", OracleType.VarChar, 21).Value = acctno.Trim();
            oracomm.Parameters.Add("OUT_ACCT", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
            oracomm.Parameters.Add("OUT_RETURN_STATUS", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["OUT_RETURN_STATUS"].Value.ToString();
            if (Result == "0")
            {
                Result1 = oracomm.Parameters["OUT_ACCT"].Value.ToString();
            }
            else
            {
                Result1 = "INVALID";
            }
            oraconn.Close();
            //Result = "@ERR7@";
        }
        catch (Exception ex)
        {
            Result1 = ex.Message;
            Result1 = "INVALID";
        }

        oracomm = null;
        oraconn = null;
        return Result1;
    }

    public String ValidateAccountNuber(String uid, String acctno)
    {
        String finalstr = null;
        String limit = null;
        String oldacctno = null;

        try
        {
            xmlstring = "<Response>";

            //Parse Account, check for NUBAN
            if (acctno.Length == 10) //Validate NUBAN
            {
                Converter cnv = new Converter(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
                if (cnv.verifyNubanCheckDigit("058", acctno) == true)
                {
                    oldacctno = cnv.ConvertToOldAccountNumber(acctno);
                    acctno = oldacctno.Replace("/","");
                }
                else
                {
                    acctno = "0";
                }
            }

            if (acctno.Length < 12)
            {
                acctno = "0";
            }
           
            finalstr = GetAccountFromBasis(acctno);
            if (finalstr != "INVALID")
            {
                //get aggregated limit
                limit = CheckDailyLimit(uid);
                if (limit == "ERROR")
                    limit = "0";

                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<BENEFICIARY>";
                xmlstring = xmlstring + "<AccountNo>" + finalstr + "</AccountNo>";
                xmlstring = xmlstring + "<Limit>" + limit + "</Limit>";
                xmlstring = xmlstring + "</BENEFICIARY>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<Error>" + "INVALID ACCOUNT NUMBER" + "</Error>";
            }
            
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
        }

        xmlstring = xmlstring + "</Response>";
        return xmlstring;
    }

    public String CheckUserFlag(String uid)
    {
        SqlConnection conn = null;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        int count = 0;

        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("CheckUserflag", conn);
            comm.Parameters.AddWithValue("@UserID", uid);

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();
            adpt.Fill(ds);

            if (ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = (DataRow)ds.Tables[0].Rows[0];
                count = Convert.ToInt32(dr["mins"]);
                
                if (dr["pwdreq"].ToString() == "1" && count < 5)
                {
                    xmlstring = xmlstring + "<CODE>1000</CODE>";
                    xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                }
                else
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<ERROR>USER FLAG NOT SET</ERROR>";
                }

                dr = null;
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "INVALID USERNAME OR PASSWORD" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        ds = null;
        adpt = null;
        comm = null;
        conn.Close();
        conn = null;
        return xmlstring;

    }

    public String ResetUserFlag(String uid)
    {
        SqlConnection conn = null;
        SqlCommand comm;
        int count = 0;

        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("ResetUserflag", conn);
            comm.Parameters.AddWithValue("@UserID", uid);

            comm.CommandType = CommandType.StoredProcedure;
            comm.ExecuteNonQuery();
            xmlstring = xmlstring + "<CODE>1000</CODE>";
            xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        comm = null;
        conn.Close();
        conn = null;
        return xmlstring;
    }

    private String CheckDailyLimit(String userid)
    {
        String res = null;
        SqlDataReader reader;
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
        SqlCommand comm = new SqlCommand("Check_Daily_Limit2", conn);
        comm.Parameters.AddWithValue("@User_Id", Decimal.Parse(userid));
        comm.CommandType = CommandType.StoredProcedure;
        try
        {
            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            reader = comm.ExecuteReader();
            if (reader.HasRows == true)
            {
                reader.Read();
                res = reader["limit"].ToString();
            }
            else
            {
                res = "ERROR";
            }
            reader.Close();
            reader = null;

        }
        catch (Exception ex)
        {
            res = "ERROR";
        }

        return res;
    }

    public int CheckBeneficiaryTransferLimit(String userid, String ben_acct_no)
    {
        int res = 0;
        SqlDataReader reader;
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
        SqlCommand comm = new SqlCommand("dbo.GTB_BeneficiaryTransfer", conn);
        comm.Parameters.AddWithValue("@User_Id", Decimal.Parse(userid));
        comm.Parameters.AddWithValue("@Beneficiary_Acct_No", ben_acct_no);

        comm.CommandType = CommandType.StoredProcedure;
        try
        {
            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            reader = comm.ExecuteReader();
            if (reader.HasRows == true)
            {
                reader.Read();
                res = Convert.ToInt32(reader[0]);
            }
            else
            {
                res = 0;
            }
            reader.Close();
            reader = null;

        }
        catch (Exception ex)
        {
            res = 0;
        }

        return res;
    }

    public int CheckDailyLimit(long pUserId, Double pAmount, int ledgercode)
    {
        int res = 0;
        //SqlDataReader reader;
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
        SqlCommand comm = new SqlCommand("dbo.Check_Daily_limit", conn);
        comm.Parameters.AddWithValue("@User_Id", Convert.ToInt64(pUserId));
        comm.Parameters.AddWithValue("@Amount", pAmount);
        comm.Parameters.AddWithValue("@LedgerCode", ledgercode);

        comm.CommandType = CommandType.StoredProcedure;
        try
        {
            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            res = Convert.ToInt32(comm.ExecuteScalar());
            //if (reader.HasRows == true)
            //{
            //    reader.Read();
            //    res = Convert.ToInt32(reader[0]);
            //}
            //else
            //{
            //    res = 0;
            //}
            //reader.Close();
            //reader = null;

        }
        catch (Exception ex)
        {
            //Error occured
            res = 1;
        }

        return res;
    }

    private void LogTransfer(String userid, String fromacct, String toacct, Decimal amount, String medium, String Remarks)
    {
        String res = null;
        String from, to;
        char[] delim = new char[] { '/' };
        String[] tempstr;

        tempstr = fromacct.Split(delim);
        //from = tempstr[0]
        SqlDataReader reader;
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
        SqlCommand comm = new SqlCommand("Log_Transfer", conn);
        comm.Parameters.AddWithValue("@User_Id", Decimal.Parse(userid));
        comm.Parameters.AddWithValue("Source_Acct_No", fromacct.Trim());
        comm.Parameters.AddWithValue("@Beneficiary_Acct_No", toacct.Trim());
        comm.Parameters.AddWithValue("@Amount", amount);
        comm.Parameters.AddWithValue("@Medium", medium.Trim());
        comm.Parameters.AddWithValue("@Remarks", Remarks.Trim());

        comm.CommandType = CommandType.StoredProcedure;
        try
        {
            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            reader = comm.ExecuteReader();
            //if (reader.HasRows == true)
            //{
            //    reader.Read();
            //    res = reader["limit"].ToString();
            //}
            //else
            //{
            //    res = "ERROR";
            //}
            reader.Close();
            reader = null;

        }
        catch (Exception ex)
        {
            res = ex.Message;
        }

        return;
    }

    public String LogUserAction(int appid, String userid, long staffid, String actiondesc)
    {
        SqlConnection conn = null;
        SqlCommand comm;
        int count = 0, res = 0;

        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("LogUserAction", conn);
            comm.Parameters.AddWithValue("@AppID", appid);
            comm.Parameters.AddWithValue("@UserID", userid);
            comm.Parameters.AddWithValue("@StaffID", staffid);
            comm.Parameters.AddWithValue("@ActionDesc", actiondesc);

            comm.CommandType = CommandType.StoredProcedure;
            res = comm.ExecuteNonQuery();

            if (res > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "</Response>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Could not insert new record</Error>";
                xmlstring = xmlstring + "</Response>";
            }
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        comm = null;
        conn.Close();
        conn = null;
        return xmlstring;

    }

    public String AddNewAdminUser(String UserID, int BASISID, String Username, String staffid, String password, int branch_code, String emailaddress, String roleid, String status)
    {
        SqlConnection conn = null;
        SqlCommand comm;
        int count = 0, res = 0;

        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("AddNewAdminUser", conn);
            comm.Parameters.AddWithValue("@User_Id", UserID);
            comm.Parameters.AddWithValue("@basis_id", BASISID);
            comm.Parameters.AddWithValue("@UserName", Username);
            comm.Parameters.AddWithValue("@StaffId", staffid);
            comm.Parameters.AddWithValue("@Password", password);
            comm.Parameters.AddWithValue("@BranchCode", branch_code);
            comm.Parameters.AddWithValue("@Email", emailaddress);
            comm.Parameters.AddWithValue("@RoleID", roleid);
            comm.Parameters.AddWithValue("@Status", status);

            comm.CommandType = CommandType.StoredProcedure;
            res = comm.ExecuteNonQuery();

            if (res > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "</Response>";
            }
            else if (res == -1)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Role does not exist</Error>";
                xmlstring = xmlstring + "</Response>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Could not insert new record</Error>";
                xmlstring = xmlstring + "</Response>";
            }
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        comm = null;
        conn.Close();
        conn = null;
        return xmlstring;


    }

    public String UpdateAdminUser(String UserID, int BASISID, String Username, String staffid, int branch_code, String emailaddress, String roleid)
    {
        SqlConnection conn = null;
        SqlCommand comm;
        int count = 0, res = 0;

        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("UpdateAdminUser", conn);
            comm.Parameters.AddWithValue("@User_Id", UserID);
            comm.Parameters.AddWithValue("@basis_id", BASISID);
            comm.Parameters.AddWithValue("@UserName", Username);
            comm.Parameters.AddWithValue("@StaffId", staffid);
            comm.Parameters.AddWithValue("@BranchCode", branch_code);
            comm.Parameters.AddWithValue("@Email", emailaddress);
            comm.Parameters.AddWithValue("@RoleID", roleid);

            comm.CommandType = CommandType.StoredProcedure;
            res = comm.ExecuteNonQuery();

            if (res > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "</Response>";
            }
            else if (res == -1)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Role does not exist</Error>";
                xmlstring = xmlstring + "</Response>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Could not insert new record</Error>";
                xmlstring = xmlstring + "</Response>";
            }
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        comm = null;
        conn.Close();
        conn = null;
        return xmlstring;

    }

    public String GetAdminUserDetails(String userid)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataRow dr, dr_app;
        String xmlrep = null;
        String xmlschema = null;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("GetAdminUserDetails", conn);
            comm.Parameters.AddWithValue("@UserID", userid);
            
            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);
            ds.DataSetName = "RESPONSE";

            xmlrep = ds.GetXml();
            xmlschema = ds.GetXmlSchema();
            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].TableName = "USER";
                
                dr = ds.Tables[0].Rows[0];
                                
                xmlstring = xmlstring + "<CODE>1000</CODE>";

                //GET USER
                xmlstring = xmlstring + "<USER>";
                xmlstring = xmlstring + "<ID>" + dr["User_id"] + "</ID>";
                xmlstring = xmlstring + "<BASISID>" + dr["basis_id"].ToString() + "</BASISID>";
                xmlstring = xmlstring + "<NAME>" + dr["User_name"] + "</NAME>";
                xmlstring = xmlstring + "<STAFFID>" + dr["staff_id"] + "</STAFFID>";
                xmlstring = xmlstring + "<BRANCH>" + dr["branch_code"] + "</BRANCH>";
                xmlstring = xmlstring + "<EMAIL>" + dr["email"] + "</EMAIL>";
                xmlstring = xmlstring + "<ROLE_ID>" + dr["ROLE_ID"] + "</ROLE_ID>";
                xmlstring = xmlstring + "<DATE_CREATED>" + Convert.ToDateTime(dr["registration_date"]).ToShortDateString() + "</DATE_CREATED>";             
                xmlstring = xmlstring + "<STATUS>" + dr["status"] + "</STATUS>";
                xmlstring = xmlstring + "<MOBILENO>" + dr["mobileno"] + "</MOBILENO>";
                xmlstring = xmlstring + "<SUGNO>" + dr["sugno"] + "</SUGNO>";
                
                //xmlstring = xmlstring + "<CONFIRMED>" + dr["confirmed"] + "</CONFIRMED>";
                //xmlstring = xmlstring + "<LOCKED>" + dr["locked"] + "</LOCKED>";
                xmlstring = xmlstring + "<LAST_MODIFIED>" + Convert.ToDateTime(dr["last_modified_date"]).ToShortDateString() + "</LAST_MODIFIED>";
                
                xmlstring = xmlstring + "</USER>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "INVALID USER" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
        //return xmlrep;
    }

    public DataTable GetAdminUserDetails2(String userid)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataTable ds = new DataTable("USER");
        SqlDataAdapter adpt;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("GetAdminUserDetails", conn);
            comm.Parameters.AddWithValue("@UserID", userid);

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);

            adpt.Fill(ds);

            if (ds.Rows.Count > 0)
            {

            }
            else
            {

            }


        }
        catch (Exception ex)
        {

        }


        return ds;
    }

    public String SearchAdminUser(String searchstr)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataRow dr_app;
        String xmlrep = null;
        String xmlschema = null;
        String search = null;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            search = searchstr.Replace("*", "%");
            //search = search;
            comm = new SqlCommand("SearchAdminUser", conn);
            comm.Parameters.AddWithValue("@searchstr", search);

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);
            ds.DataSetName = "RESPONSE";

            xmlrep = ds.GetXml();
            xmlschema = ds.GetXmlSchema();
            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].TableName = "USER";
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<USERS>";
                xmlstring = xmlstring + "<COUNT>" + ds.Tables[0].Rows.Count.ToString() + "</COUNT>";
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    //GET USER
                    xmlstring = xmlstring + "<USER>";
                    xmlstring = xmlstring + "<ID>" + dr["User_id"] + "</ID>";
                    xmlstring = xmlstring + "<STAFFID>" + dr["staff_id"] + "</STAFFID>";
                    //xmlstring = xmlstring + "<NAME>" + dr["User_name"].ToString().Replace("&", "&amp;") + "</NAME>";
                    //xmlstring = xmlstring + "<BRANCH>" + dr["branch_code"] + "</BRANCH>";
                    xmlstring = xmlstring + "<EMAIL>" + dr["email"] + "</EMAIL>";
                    //xmlstring = xmlstring + "<ROLE_ID>" + dr["ROLE_ID"] + "</ROLE_ID>";
                    //xmlstring = xmlstring + "<DATE_CREATED>" + Convert.ToDateTime(dr["registration_date"]).ToShortDateString() + "</DATE_CREATED>";
                    xmlstring = xmlstring + "<STATUS>" + dr["status"] + "</STATUS>";
                    //xmlstring = xmlstring + "<CONFIRMED>" + dr["confirmed"] + "</CONFIRMED>";
                    //xmlstring = xmlstring + "<LOCKED>" + dr["locked"] + "</LOCKED>";
                    //xmlstring = xmlstring + "<LAST_MODIFIED>" + Convert.ToDateTime(dr["last_modified"]).ToShortDateString() + "</LAST_MODIFIED>";

                    xmlstring = xmlstring + "</USER>";
                }
                xmlstring = xmlstring + "</USERS>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "NO USER" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
        //return xmlrep;
    }

    public String GetAllRoles()
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataRow dr_app;
        String xmlrep = null;
        String xmlschema = null;
        
        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("GetAllRoles", conn);
            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);
            ds.DataSetName = "RESPONSE";

            xmlrep = ds.GetXml();
            xmlschema = ds.GetXmlSchema();
            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].TableName = "USER";
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<ROLES>";
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    //GET USER
                    xmlstring = xmlstring + "<ROLE>";
                    xmlstring = xmlstring + "<ROLE_ID>" + dr["role_id"] + "</ROLE_ID>";
                    xmlstring = xmlstring + "<ROLE_NAME>" + dr["idm_role"].ToString().Replace("&", "&amp;") + "</ROLE_NAME>";
                    xmlstring = xmlstring + "</ROLE>";
                }
                xmlstring = xmlstring + "</ROLES>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "NO ROLES" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
        //return xmlrep;
    }

    public String GetTellerTillAcct(String userid, int appid)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        String xmlrep = null;
        String xmlschema = null;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("GetTellerTillAcct", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@user_id", userid);
            comm.Parameters.AddWithValue("@app_id", appid);

            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);
            ds.DataSetName = "RESPONSE";

            xmlrep = ds.GetXml();
            xmlschema = ds.GetXmlSchema();
            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].TableName = "TILL_ACCOUNT";
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    //GET TILL ACCOUNT
                    xmlstring = xmlstring + "<TILL_ACCOUNT_NO>" + dr["till_account"] + "</TILL_ACCOUNT_NO>";
                }
               
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "0/0/0/0/0" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
        //return xmlrep;
    }

    public String GetBranchInfo(String branch)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        String xmlrep = null;
        String xmlschema = null;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("GetBranchInfo", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@branchcode", branch);
            

            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);
            ds.DataSetName = "RESPONSE";

            xmlrep = ds.GetXml();
            xmlschema = ds.GetXmlSchema();
            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].TableName = "BRANCH_INFO";
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    //GET BRANCH INFO
                    xmlstring = xmlstring + "<BRANCH_CODE>" + dr["branch_code"] + "</BRANCH_CODE>";
                    xmlstring = xmlstring + "<BRANCH_NAME>" + dr["branch_name"] + "</BRANCH_NAME>";
                }

            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "NO BRANCH INFO FOR THE SUPPLIED CODE" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
        //return xmlrep;
    }

    public String GetBasisTellerTillAcct(String bracode, string tellerid, string curcode)
    {

        try
        {

            using (OracleCommand oracomm = new OracleCommand())
            {

                using (OracleConnection OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationSettings.AppSettings["BASISConString_eone"])))
                {

                    oracomm.Connection = OraConn;

                    //oracomm.CommandText = "select b.bra_code || '/' || b.cus_num || '/' || b.cur_code || '/' ||  b.led_code || '/' || b.sub_acct_code acct_key from teller a, account b where a.tell_id = " + tellerid + " and cur_code = " + curcode + " and a.bra_code = " + bracode + "  and a.cus_num = b.cus_num and a.bra_code = b.bra_Code  and led_code = 31";
                    
                    oracomm.CommandText = "select distinct b.bra_code || '/' || b.cus_num || '/' || b.cur_code || '/' ||  b.led_code || '/' || a.cash_sub_acct acct_key from teller a, account b where a.tell_id = " + tellerid + " and cur_code = " + curcode + " and a.bra_code = " + bracode + "  and a.cus_num = b.cus_num and a.bra_code = b.bra_Code  and led_code = 31 and b.cus_num > 180 and b.cus_num < 201";
                    oracomm.CommandType = CommandType.Text;

                    if (OraConn.State == ConnectionState.Closed)
                    {

                        OraConn.Open();

                    }

                    using (OracleDataReader dr = oracomm.ExecuteReader(CommandBehavior.CloseConnection))
                    {

                        if (dr.Read())
                        {

                            //string a = "Posting Teller:" + dr["PostingTellerId"].ToString();

                            //a = a + ", Teller Bra Code " + dr["OriginatingBraCode"].ToString();

                            return dr["acct_key"].ToString();

                        }

                        else
                        {

                            return "0/0/0/0/0";

                        }

                    }

                }

            }

        }

        catch (Exception ex)
        {

            return "0/0/0/0";



        }



        finally { }

    }

    public String GetBasisTellerTillAcct2(String admin_user_name, String bracode, string curcode)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataRow dr_1;
        String tellerid = "0";

        try
        {

            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("GetAdminUserDetails", conn);
            comm.Parameters.AddWithValue("@UserID", admin_user_name);
            
            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);

            if (ds.Tables[0].Rows.Count > 0)
            {
                dr_1 = ds.Tables[0].Rows[0];
                //GET USER
                tellerid = dr_1["BASIS_ID"].ToString();
            }
            dr_1 = null;
            ds = null;
            comm = null;
            conn.Close();
            conn = null;

            using (OracleCommand oracomm = new OracleCommand())
            {

                using (OracleConnection OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationSettings.AppSettings["BASISConString_eone"])))
                {

                    oracomm.Connection = OraConn;

                    //oracomm.CommandText = "select b.bra_code || '/' || b.cus_num || '/' || b.cur_code || '/' ||  b.led_code || '/' || b.sub_acct_code acct_key from teller a, account b where a.tell_id = " + tellerid + " and cur_code = " + curcode + " and a.bra_code = " + bracode + "  and a.cus_num = b.cus_num and a.bra_code = b.bra_Code  and led_code = 31";
                    
                    oracomm.CommandText = "select distinct b.bra_code || '/' || b.cus_num || '/' || b.cur_code || '/' ||  b.led_code || '/' || a.cash_sub_acct acct_key from teller a, account b where a.tell_id = " + tellerid + " and cur_code = " + curcode + " and a.bra_code = " + bracode + "  and a.cus_num = b.cus_num and a.bra_code = b.bra_Code  and led_code = 31 and b.cus_num > 180 and b.cus_num < 201";
                    oracomm.CommandType = CommandType.Text;

                    if (OraConn.State == ConnectionState.Closed)
                    {

                        OraConn.Open();

                    }

                    using (OracleDataReader dr = oracomm.ExecuteReader(CommandBehavior.CloseConnection))
                    {

                        if (dr.Read())
                        {

                            //string a = "Posting Teller:" + dr["PostingTellerId"].ToString();

                            //a = a + ", Teller Bra Code " + dr["OriginatingBraCode"].ToString();

                            return dr["acct_key"].ToString();

                        }

                        else
                        {

                            return "0/0/0/0/0";

                        }

                    }

                }

            }

        }

        catch (Exception ex)
        {

            return "0/0/0/0";



        }



        finally { }

    }

    public String GetAllBranches()
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataRow dr_app;
        String xmlrep = null;
        String xmlschema = null;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("GetAllBranches", conn);
            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);
            ds.DataSetName = "RESPONSE";

            xmlrep = ds.GetXml();
            xmlschema = ds.GetXmlSchema();
            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].TableName = "USER";
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<BRANCHES>";
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    //GET USER
                    xmlstring = xmlstring + "<BRANCH>";
                    xmlstring = xmlstring + "<BRANCH_CODE>" + dr["branch_code"] + "</BRANCH_CODE>";
                    xmlstring = xmlstring + "<BRANCH_NAME>" + dr["branch_name"].ToString().Replace("&", "&amp;") + "</BRANCH_NAME>";
                    xmlstring = xmlstring + "</BRANCH>";
                }
                xmlstring = xmlstring + "</BRANCHES>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "NO ROLES" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
        //return xmlrep;
    }

    public string ChangeAdminUserPasscode(String userid, String password)
    {
        SqlConnection conn;
        SqlCommand comm;
        Email email = new Email();

        int count = 0;

        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("updateAdminPassCode", conn);
            comm.Parameters.AddWithValue("@u_id", userid);
            comm.Parameters.AddWithValue("@p_code", password);
            comm.Parameters.AddWithValue("@p_type", Int32.Parse("1"));

            comm.CommandType = CommandType.StoredProcedure;
            count = comm.ExecuteNonQuery();
            if (count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>1000</MESSAGE>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "UNABLE TO UPDATE PASSWORD" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public string ActivateAdminUser(String userid)
    {
        SqlConnection conn;
        SqlCommand comm;
        Email email = new Email();

        int count = 0;

        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("ActivateAdminUser", conn);
            comm.Parameters.AddWithValue("@userid", userid);
            
            comm.CommandType = CommandType.StoredProcedure;
            count = comm.ExecuteNonQuery();
            if (count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "UNABLE TO ACTIVATE USER" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public string DeactivateAdminUser(String userid)
    {
        SqlConnection conn;
        SqlCommand comm;
        Email email = new Email();

        int count = 0;

        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("DeactivateAdminUser", conn);
            comm.Parameters.AddWithValue("@userid", userid);

            comm.CommandType = CommandType.StoredProcedure;
            count = comm.ExecuteNonQuery();
            if (count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "UNABLE TO UPDATE PASSWORD" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public string AddAdminRole(String rolename)
    {
        SqlConnection conn;
        SqlCommand comm;
        Email email = new Email();

        int count = 0;

        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("AddAdminRole", conn);
            comm.Parameters.AddWithValue("@rolename", rolename);

            comm.CommandType = CommandType.StoredProcedure;
            count = comm.ExecuteNonQuery();
            if (count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "UNABLE TO ADD ROLE" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public string GetZoneAcct(int branch_code, int appid)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        String xmlrep = null;
        String xmlschema = null;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("GetZoneAcct", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@branch_code", branch_code);
            comm.Parameters.AddWithValue("@app_id", appid);

            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);
            ds.DataSetName = "RESPONSE";

            xmlrep = ds.GetXml();
            xmlschema = ds.GetXmlSchema();
            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].TableName = "ZONE_ACCOUNT";
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    //GET TILL ACCOUNT
                    xmlstring = xmlstring + "<ZONE_ACCOUNT_NO>" + dr["zone_account"] + "</ZONE_ACCOUNT_NO>";
                }

            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "0/0/0/0/0" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public string GetBranchAcct(String user_id, int appid)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        String xmlrep = null;
        String xmlschema = null;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("GetBranchAcct", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@user_id", user_id);
            comm.Parameters.AddWithValue("@app_id", appid);

            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);
            ds.DataSetName = "RESPONSE";

            xmlrep = ds.GetXml();
            xmlschema = ds.GetXmlSchema();
            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].TableName = "BRANCH_ACCOUNT";
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    //GET BRANCH ACCOUNT
                    xmlstring = xmlstring + "<BRANCH_ACCOUNT_NO>" + dr["branch_till_acct"] + "</BRANCH_ACCOUNT_NO>";
                }

            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "0/0/0/0/0" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String GetIPAndLocation(String branch, String ipadd)
    {
        string Result = string.Empty;
        SqlCommand cmd;
        SqlConnection conn;
        SqlDataAdapter ora_adpt;
        DataSet dt;
        String ipstr = "";
        String branchInfo = "Unknown Location";

        String query_str = null;
        dt = new DataSet();

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            // create the command for the function
            query_str = "select SUBNET from branchip where bra_code=" + branch;

            conn.Open();
            cmd = new SqlCommand("GetBranchIPAndUserLocation", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@bracode", branch);
            cmd.Parameters.AddWithValue("@ipadd", ipadd);

            ora_adpt = new SqlDataAdapter(cmd);

            ora_adpt.Fill(dt);

            xmlstring = "<Response>";

            if (dt.Tables[0].Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                foreach (DataRow dr in dt.Tables[0].Rows)
                {
                    //GET IP Address
                    if (ipstr == "")
                        ipstr = ipstr + dr["SUBNET"].ToString();
                    else
                        ipstr = ipstr + "," + dr["SUBNET"].ToString();
                }
                xmlstring = xmlstring + "<IPADDRESS>" + ipstr + "</IPADDRESS>";

                if (dt.Tables[1].Rows.Count > 0)
                {
                    branchInfo = dt.Tables[1].Rows[0]["BRA_CODE"].ToString() + " - " + dt.Tables[1].Rows[0]["DES_ENG"].ToString();
                }
                xmlstring = xmlstring + "<LOCATION>" + branchInfo + "</LOCATION>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "NO IPADDRESS" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";

            dt = null;
            ora_adpt = null;
            cmd = null;
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String GetBranchIPAddress(String branch)
    {
        string Result = string.Empty;
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        DataTable dt;
        String ipstr = "";

        String query_str = null;
        dt = new DataTable();

        try
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

            // create the command for the function
            query_str = "select SUBNET from ipfilter_branch where bra_code=" + branch;

            oraconn.Open();
            cmd = new OracleCommand(query_str, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            
            ora_adpt.Fill(dt);

            xmlstring = "<Response>";

            if (dt.Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                foreach (DataRow dr in dt.Rows)
                {
                    //GET IP Address
                    if(ipstr == "")
                        ipstr = ipstr + dr["SUBNET"].ToString();
                    else
                        ipstr = ipstr + "," + dr["SUBNET"].ToString();
                }
                xmlstring = xmlstring + "<IPADDRESS>" + ipstr + "</IPADDRESS>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "NO IPADDRESS" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";

            dt = null;
            ora_adpt = null;
            cmd = null;
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String GetBranchIPAddress2(String User_ID)
    {
        Eone eone = null;
        string Result = string.Empty;
        String RetVal = null;

        try
        {

            //Get the branch code if the customer first
            eone = new Eone();
            DataTable dt1 = eone.GetAdminUserDetails2(User_ID);

            if (dt1.Rows.Count > 0)
            {
                RetVal = GetBranchIPAddress(dt1.Rows[0]["branch_code"].ToString());
            }

        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";

            RetVal = xmlstring;
        }

        return RetVal;
    }

    public String GetUserBranchIPAndLocation(String User_ID, String locip)
    {
        Eone eone = null;
        string Result = string.Empty;
        String RetVal = null;

        try
        {

            //Get the branch code if the customer first
            eone = new Eone();
            DataTable dt1 = eone.GetAdminUserDetails2(User_ID);

            if (dt1.Rows.Count > 0)
            {
                //RetVal = GetBranchIPAddress(dt1.Rows[0]["branch_code"].ToString());
                RetVal = GetIPAndLocation(dt1.Rows[0]["branch_code"].ToString(), locip);
            }

        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";

            RetVal = xmlstring;
        }

        return RetVal;
    }

    public String GetAllAdminUsers()
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataRow dr_app;
        String xmlrep = null;
        String xmlschema = null;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("GetAllAdminUsers", conn);
            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);
            ds.DataSetName = "RESPONSE";

            xmlrep = ds.GetXml();
            xmlschema = ds.GetXmlSchema();
            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].TableName = "USERS";
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<USERS>";
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    //GET USER
                    xmlstring = xmlstring + "<USER>";
                    xmlstring = xmlstring + "<USER_ID>" + dr["user_id"] + "</USER_ID>";
                    xmlstring = xmlstring + "<STAFF_ID>" + dr["staff_id"] + "</STAFF_ID>";
                    xmlstring = xmlstring + "<USER_NAME>" + dr["user_name"] + "</USER_NAME>";
                    xmlstring = xmlstring + "</USER>";
                }
                xmlstring = xmlstring + "</USERS>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "NO USERS" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
        //return xmlrep;
    }

    public String InitiatePopup(String customerno, String ivrinfostr)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataRow dr_app;
        String xmlrep = null;
        String xmlschema = null;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("IVR_InsertIVRINFO", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@customercode", customerno);
            comm.Parameters.AddWithValue("@infostr", ivrinfostr);
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);
            ds.DataSetName = "RESPONSE";

            xmlrep = ds.GetXml();
            xmlschema = ds.GetXmlSchema();
            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].TableName = "IVRINFO";
                xmlstring = xmlstring + "<CODE>1000</CODE>";
		xmlstring = xmlstring + "<SNO>" + ds.Tables[0].Rows[0]["SNO"].ToString().PadLeft(12,'0') + "</SNO>";
                //xmlstring = xmlstring + "<SNO>" + ds.Tables[0].Rows[0]["SNO"].ToString() + "</SNO>";
                //foreach (DataRow dr in ds.Tables[0].Rows)
                //{
                //    //GET USER
                //    xmlstring = xmlstring + "<USER>";
                //    xmlstring = xmlstring + "<USER_ID>" + dr["user_id"] + "</USER_ID>";
                //    xmlstring = xmlstring + "<STAFF_ID>" + dr["staff_id"] + "</STAFF_ID>";
                //    xmlstring = xmlstring + "<USER_NAME>" + dr["user_name"] + "</USER_NAME>";
                //    xmlstring = xmlstring + "</USER>";
                //}
                //xmlstring = xmlstring + "</USERS>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "0" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String GetPopupInfo(String customerno)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataRow dr_app;
        String xmlrep = null;
        String xmlschema = null;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("IVR_GETIVRINFO", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@customercode", customerno);
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);
            ds.DataSetName = "RESPONSE";

            xmlrep = ds.GetXml();
            xmlschema = ds.GetXmlSchema();
            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].TableName = "IVRINFO";
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<IVRINFO>" + ds.Tables[0].Rows[0]["IVRINFO"].ToString() + "</IVRINFO>";
                //foreach (DataRow dr in ds.Tables[0].Rows)
                //{
                //    //GET USER
                //    xmlstring = xmlstring + "<USER>";
                //    xmlstring = xmlstring + "<USER_ID>" + dr["user_id"] + "</USER_ID>";
                //    xmlstring = xmlstring + "<STAFF_ID>" + dr["staff_id"] + "</STAFF_ID>";
                //    xmlstring = xmlstring + "<USER_NAME>" + dr["user_name"] + "</USER_NAME>";
                //    xmlstring = xmlstring + "</USER>";
                //}
                //xmlstring = xmlstring + "</USERS>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "0" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String GetPopupInfo2(String customerno)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataRow dr_app;
        String xmlrep = null;
        String xmlschema = null;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("IVR_GETIVRINFO2", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@customercode", customerno);
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);
            ds.DataSetName = "RESPONSE";

            xmlrep = ds.GetXml();
            xmlschema = ds.GetXmlSchema();
            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].TableName = "IVRINFO";
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<IVRINFO>" + ds.Tables[0].Rows[0]["IVRINFO"].ToString() + "</IVRINFO>";
                //foreach (DataRow dr in ds.Tables[0].Rows)
                //{
                //    //GET USER
                //    xmlstring = xmlstring + "<USER>";
                //    xmlstring = xmlstring + "<USER_ID>" + dr["user_id"] + "</USER_ID>";
                //    xmlstring = xmlstring + "<STAFF_ID>" + dr["staff_id"] + "</STAFF_ID>";
                //    xmlstring = xmlstring + "<USER_NAME>" + dr["user_name"] + "</USER_NAME>";
                //    xmlstring = xmlstring + "</USER>";
                //}
                //xmlstring = xmlstring + "</USERS>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "0" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String DeletePopupInfo(String customerno)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataRow dr_app;
        String xmlrep = null;
        String xmlschema = null;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("IVR_DeleteIVRINFO", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@customercode", customerno);
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);
            ds.DataSetName = "RESPONSE";

            xmlrep = ds.GetXml();
            xmlschema = ds.GetXmlSchema();
            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].TableName = "IVRINFO";
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<IVRINFO>" + ds.Tables[0].Rows[0]["CODE"].ToString() + "</IVRINFO>";
                //foreach (DataRow dr in ds.Tables[0].Rows)
                //{
                //    //GET USER
                //    xmlstring = xmlstring + "<USER>";
                //    xmlstring = xmlstring + "<USER_ID>" + dr["user_id"] + "</USER_ID>";
                //    xmlstring = xmlstring + "<STAFF_ID>" + dr["staff_id"] + "</STAFF_ID>";
                //    xmlstring = xmlstring + "<USER_NAME>" + dr["user_name"] + "</USER_NAME>";
                //    xmlstring = xmlstring + "</USER>";
                //}
                //xmlstring = xmlstring + "</USERS>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "0" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public string SendSMS(string pMessage, string MobileNum)
    {

        string functionReturnValue = null;



        SMS MySMS = new SMS();

        //Simplewire.SMS

        //Dim ReturnNo

        bool isInternational = false;

        bool isSA_num = false;



        try
        {



            MySMS.ServerName = "wmp";

            MySMS.ServerDomain = "gtbplc.com";

            MySMS.SubscriberID = "174-541-908-12371";

            MySMS.SubscriberPassword = "VqONrtWl";

            //Check Phone number format
            //-----------------------------------------------------------------------------------------------------------

            if (MobileNum.StartsWith("234") || MobileNum.StartsWith("08") || MobileNum.StartsWith("07"))
            {
                if (MobileNum.StartsWith("234"))
                {
                    if (MobileNum.Length == 14)
                        MobileNum = "234" + MobileNum.Trim().Substring(4, 10);
                    else if (MobileNum.Length == 13)
                        MobileNum = "234" + MobileNum.Trim().Substring(3, 10);
                }
                else
                {
                    if (MobileNum.Length == 11)
                        MobileNum = "234" + MobileNum.Trim().Substring(1, 10);
                }

            }
            else if (MobileNum.StartsWith("+") || MobileNum.StartsWith("009") || MobileNum.Length >= 10)
            {
                if (MobileNum.StartsWith("+"))
                {
                    MobileNum = MobileNum.Trim().Substring(1);
                    if (MobileNum.Substring(0, 2) != "27")
                        isInternational = true;
                    else
                        isSA_num = true; //South Africa number
                }
                else if (MobileNum.StartsWith("009"))
                {
                    MobileNum = MobileNum.Trim().Substring(3);
                    if (MobileNum.Substring(0, 2) != "27")
                        isInternational = true;
                    else
                        isSA_num = true;    //South Africa number
                }
                else
                {
                    MobileNum = MobileNum.Trim();
                    if (MobileNum.Substring(0, 2) != "27")
                        isInternational = true;
                    else
                        isSA_num = true;    //South Africa number
                }
            }
            //else if (MobileNum.Length >= 7)
            //MobileNum = MobileNum;

            //-----------------------------------------------------------------------------------------------

            //MySMS.SourceAddress = new Address("GTBANK", AddressType.Alphanumeric);
            if (isInternational == false || isSA_num == true)
                MySMS.SourceAddress = new Address("GTBANK", AddressType.Alphanumeric);
            else
                MySMS.SourceAddress = new Address("08039003900", AddressType.Alphanumeric);

            MySMS.DestinationAddress = new Address(MobileNum, AddressType.International);

            MySMS.MessageText = pMessage;

            if ((MySMS.Submit()))
            {
                functionReturnValue = MySMS.TicketID + "," + MobileNum;
            }

            else
            {
                functionReturnValue = "";

                //MsgBox("Message undelivered")

                functionReturnValue = "Error Code: " + MySMS.ErrorCode.ToString() + " Error Description: " + MySMS.ErrorDescription;

            }

        }

        catch (Exception ex)
        {
            functionReturnValue = "Exception Occured when sending SMS response to customer: " + ex.Message;

        }

        return functionReturnValue;

    }

    public string SendSMS2(string pMessage, string MobileNum, String Application, String sendername)
    {
        String functionReturnValue = String.Empty;
        SqlConnection conn = null;
        SqlCommand comm = null;
        String qrystr = String.Empty;
        String response = String.Empty;
        int res;

        try
        {

            response = SendSMS(pMessage, MobileNum, sendername);

            qrystr = "insert into SMSLog(appid, sms_msg, mobileno, sendername, response, date) values('" + Application + "','" + pMessage + "','" + MobileNum + "','" + sendername + "','" + response + "', getdate())";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
            conn.Open();
            comm = new SqlCommand(qrystr, conn);
            res = comm.ExecuteNonQuery();

            comm = null;
            conn.Close();

            functionReturnValue = response;
        }

        catch (Exception ex)
        {
            functionReturnValue = "Exception Occured when sending SMS response to customer: " + ex.Message;

        }
        finally
        {
            comm = null;
            conn.Close();
            conn = null;
        }

        return functionReturnValue;

    }

    public string SendSMS(string pMessage, string MobileNum, string sendername)
    {

        string functionReturnValue = null;



        SMS MySMS = new SMS();

        //Simplewire.SMS

        //Dim ReturnNo

        bool isInternational = false;

        bool isSA_num = false;



        try
        {



            MySMS.ServerName = "wmp";

            MySMS.ServerDomain = "gtbplc.com";

            MySMS.SubscriberID = "174-541-908-12371";

            MySMS.SubscriberPassword = "VqONrtWl";

            //Check Phone number format
            //-----------------------------------------------------------------------------------------------------------

            if (MobileNum.StartsWith("234") || MobileNum.StartsWith("08") || MobileNum.StartsWith("07"))
            {
                if (MobileNum.StartsWith("234"))
                {
                    if (MobileNum.Length == 14)
                        MobileNum = "234" + MobileNum.Trim().Substring(4, 10);
                    else if (MobileNum.Length == 13)
                        MobileNum = "234" + MobileNum.Trim().Substring(3, 10);
                }
                else
                {
                    if (MobileNum.Length == 11)
                        MobileNum = "234" + MobileNum.Trim().Substring(1, 10);
                }

            }
            else if (MobileNum.StartsWith("+") || MobileNum.StartsWith("009") || MobileNum.Length >= 10)
            {
                if (MobileNum.StartsWith("+"))
                {
                    MobileNum = MobileNum.Trim().Substring(1);
                    if (MobileNum.Substring(0, 2) != "27")
                        isInternational = true;
                    else
                        isSA_num = true; //South Africa number
                }
                else if (MobileNum.StartsWith("009"))
                {
                    MobileNum = MobileNum.Trim().Substring(3);
                    if (MobileNum.Substring(0, 2) != "27")
                        isInternational = true;
                    else
                        isSA_num = true;    //South Africa number
                }
                else
                {
                    MobileNum = MobileNum.Trim();
                    if (MobileNum.Substring(0, 2) != "27")
                        isInternational = true;
                    else
                        isSA_num = true;    //South Africa number
                }
            }
            //else if (MobileNum.Length >= 7)
            //MobileNum = MobileNum;

            //-----------------------------------------------------------------------------------------------

            //MySMS.SourceAddress = new Address("GTBANK", AddressType.Alphanumeric);
            if (isInternational == false || isSA_num == true)
                MySMS.SourceAddress = new Address(sendername, AddressType.Alphanumeric);
            else
                MySMS.SourceAddress = new Address("08039003900", AddressType.Alphanumeric);

            MySMS.DestinationAddress = new Address(MobileNum, AddressType.International);

            MySMS.MessageText = pMessage;

            if ((MySMS.Submit()))
            {
                functionReturnValue = MySMS.TicketID + "," + MobileNum;
            }

            else
            {
                functionReturnValue = "";

                //MsgBox("Message undelivered")

                functionReturnValue = "Error Code: " + MySMS.ErrorCode.ToString() + " Error Description: " + MySMS.ErrorDescription;

            }

        }

        catch (Exception ex)
        {
            functionReturnValue = "Exception Occured when sending SMS response to customer: " + ex.Message;

        }

        return functionReturnValue;

    }

    private Decimal getChargeAmount(Decimal amt)
    {
        Decimal ret_val = 0;

        if (amt < 500000M)
            ret_val = 35M;
        else if (amt >= 500000M && amt < 1000000M)
            ret_val = 100M;
        else if (amt >= 1000000M && amt < 10000000M)
            ret_val = 400M;
        else if (amt >= 10000000M)
            ret_val = 400M;
        else
            ret_val = 0;


        return ret_val;
    }

    private Decimal getBankNEFTFee(Decimal amt)
    {
        Decimal ret_val = 0;

        if (amt < 500000M)
            ret_val = 70M;
        else if (amt >= 500000M && amt <= 10000000M)
            ret_val = 100M;
        else if (amt > 10000000M)
            ret_val = 500M;
        //else if (amt >= 10000000M)
        //    ret_val = 400M;
        else
            ret_val = 0;


        return ret_val;
    }

    public string SendHtmlMessageToUser(long uid)
    {
        string functionReturnValue = null;
        SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
        string commstr = "";
        string err_text = null;
        string useremailaddy = "none@gtbank.com";
        String StartUpPath = HttpContext.Current.Server.MapPath("~");
        string message2 = "";

        long pcode = getNewPassCode();
        updateUserPassCode(Convert.ToInt64(uid), pcode, 0);

        String mailsubj = "GTBANK INTERNET BANKING SERVICE";

        StartUpPath = HttpContext.Current.Server.MapPath("~");
        String text = File.ReadAllText(StartUpPath + "\\HTMLFiles\\Welcome\\welcomeletter.html");

        String mailmess = text;

        String userno = uid.ToString().Substring(9, 2);
        if (userno == "01")
        {
            userno = uid.ToString().Substring(0, 9);
            mailmess = mailmess.Replace("{USERID}", userno);
            mailmess = mailmess.Replace("{PASSCODE}", pcode.ToString());
        }
        else 
        {
            mailmess = mailmess.Replace("{USERID}", uid.ToString());
            mailmess = mailmess.Replace("{PASSCODE}", pcode.ToString());
        }

            //''''''''''Send mail message here '''''''''''''''''''''''''''''''''''''''
            //'result = sendMailToUser(uid, mailsubj, mailmess, 0)
            //result = SendHtmlMessageToUser(uid, 0, mailsubj, mailmess)

        commstr = "select * from users where user_id = " + Convert.ToString(uid) + " UNION select * from tempusers where user_id = " + Convert.ToString(uid);

        SqlCommand comm = new SqlCommand(commstr);
        Conn.Open();
        comm.Connection = Conn;
        SqlDataReader dr = default(SqlDataReader);
        dr = comm.ExecuteReader();
        if (dr.HasRows)
        {
            dr.Read();
            if (dr["EMAIL"].ToString().ToUpper() != "NONE@GTBPLC.COM")
            {
                useremailaddy = dr["EMAIL"].ToString();
                err_text = "OK";
            }
            else
            {
                err_text = "OK";
                return err_text;
            }
        }
        else
        {
            err_text = "User is unknown";
        }
        Conn.Close();


        try
        {
            AlternateView htmlView = System.Net.Mail.AlternateView.CreateAlternateViewFromString(mailmess, null, "text/html");


            MailMessage message__2 = new MailMessage();
            message__2.Subject = mailsubj;
            message__2.From = new MailAddress(ConfigurationManager.AppSettings["EoneSenderEmail"].ToString());

            if (useremailaddy.Trim().Length > 0)
            {
                foreach (string addr in useremailaddy.Split(';'))
                {
                    //MailAddress cc = new MailAddress(copyTo);}
                    if (!string.IsNullOrEmpty(addr))
                    {
                        message__2.To.Add(new MailAddress(addr));
                    }
                }
            }

            //Attach all files
            AttachImage(ref htmlView, StartUpPath + "\\HtmlFiles\\Welcome\\images\\divider-line_10.png", "image/png", "dividerline10");
            AttachImage(ref htmlView, StartUpPath + "\\HtmlFiles\\Welcome\\images\\divider-line_10.png", "image/png", "dividerline10");
            //AttachImage(htmlView, StartUpPath + "\HtmlFiles\Welcome\images\downloadicon.png", "image/png")
            AttachImage(ref htmlView, StartUpPath + "\\HtmlFiles\\Welcome\\images\\email.png", "image/png", "email");
            AttachImage(ref htmlView, StartUpPath + "\\HtmlFiles\\Welcome\\images\\facebook2.png", "image/png", "facebook2");
            //AttachImage(htmlView, StartUpPath + "\HtmlFiles\Welcome\images\fb.png", "image/png")
            //AttachImage(htmlView, StartUpPath + "\HtmlFiles\Welcome\images\flicker.png", "image/png")
            //AttachImage(htmlView, StartUpPath + "\HtmlFiles\Welcome\images\footer.jpg", "image/jpg")
            //AttachImage(htmlView, StartUpPath + "\HtmlFiles\Welcome\images\Gtconnect-small.png", "image/png")
            AttachImage(ref htmlView, StartUpPath + "\\HtmlFiles\\Welcome\\images\\img_05.png", "image/png", "img05");
            //AttachImage(htmlView, StartUpPath + "\HtmlFiles\Welcome\images\shadowbot.jpg", "image/jpg")
            //AttachImage(htmlView, StartUpPath + "\HtmlFiles\Welcome\images\shadowtop.jpg", "image/jpg")
            AttachImage(ref htmlView, StartUpPath + "\\HtmlFiles\\Welcome\\images\\spend-anywhere_03.png", "image/png", "spendanywhere03");
            AttachImage(ref htmlView, StartUpPath + "\\HtmlFiles\\Welcome\\images\\square.gif", "image/gif", "square");
            AttachImage(ref htmlView, StartUpPath + "\\HtmlFiles\\Welcome\\images\\top-banner_01.png", "image/png", "topbanner01");
            //AttachImage(htmlView, StartUpPath + "\HtmlFiles\Welcome\images\twitter.png", "image/png")
            AttachImage(ref htmlView, StartUpPath + "\\HtmlFiles\\Welcome\\images\\twitter2.png", "image/png", "twitter2");
            AttachImage(ref htmlView, StartUpPath + "\\HtmlFiles\\Welcome\\images\\webnphone.png", "image/png", "webnphone");
            //AttachImage(htmlView, StartUpPath + "\HtmlFiles\Welcome\images\website.png", "image/png")
            //AttachImage(htmlView, StartUpPath + "\HtmlFiles\Welcome\images\yt.png", "image/png")

            //Dim scamalert As New System.Net.Mail.LinkedResource(GetImage(StartUpPath + "\HtmlFiles\animated_ad.gif"), "image/gif")
            //scamalert.ContentId = "scamalertlogo"
            //htmlView.LinkedResources.Add(scamalert)

            message__2.AlternateViews.Add(htmlView);


            //If copyTo.Trim().Length > 0 Then
            //    For Each addr As String In copyTo.Split(";"c)
            //        'MailAddress cc = new MailAddress(copyTo);}
            //        If Not String.IsNullOrEmpty(addr) Then
            //            message__2.Bcc.Add(New MailAddress(addr))
            //        End If
            //    Next
            //End If

            // create smtp client at mail server location
            SmtpClient client = new SmtpClient(ConfigurationManager.AppSettings["EmailServer"].ToString());

            // add credentials
            client.UseDefaultCredentials = false;

            // send message
            client.Send(message__2);

            //Return "Message sent to " + sendTo + " at " + DateTime.Now.ToString() + "."
            functionReturnValue = "OK";
        }
        catch (Exception ex)
        {
            //SendHtmlMessageOnError(copyTo, sendFrom, sendFrom, "This email was not sent!!!", message2)
            //Return ex.Message.ToString()
            functionReturnValue = ex.Message;
        }

        return functionReturnValue;
    }

    private void AttachImage(ref AlternateView vw, string impath, string imtype, string contentname)
    {
        System.Net.Mail.LinkedResource gtbimage = new System.Net.Mail.LinkedResource(GetImage(impath), imtype);
        gtbimage.ContentId = contentname;
        vw.LinkedResources.Add(gtbimage);
    }

    public MemoryStream GetImage(string Imagepath__1)
    {
        String StartUpPath = HttpContext.Current.Server.MapPath("~");
        String imagepath__2 = Imagepath__1;

        FileStream fs = File.OpenRead(imagepath__2);
        byte[] data = new byte[fs.Length];
        fs.Read(data, 0, data.Length);

        // MemoryStream ms = new MemoryStream(data);
        // Bitmap bmp = new Bitmap(ms);

        return new System.IO.MemoryStream(data);
    }

    public long getNewPassCode()
    {
        long MyValue = 0;
        string strval = null;
        Random RND = new Random();  //Randomize();
        // Initialize random-number generator.
        MyValue = Convert.ToInt64(999999 * RND.Next(0,9) + 100000);
        // Generate random value between 100000 and 999999.
        strval = Convert.ToString(MyValue);
        if (strval.Length > 6)
        {
            strval = strval.Remove(4, 1);
            MyValue = Convert.ToInt64(strval);
        }
        return MyValue;
    }

    public void updateUserPassCode(long uid, long pc, int ty)
    {
        SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
        if (Conn.State != ConnectionState.Open)
            Conn.Open();
        SqlParameter para = default(SqlParameter);
        SqlParameter para2 = default(SqlParameter);
        SqlParameter para3 = default(SqlParameter);
        SqlCommand com = new SqlCommand();
        int cnt = 0;

        com.Connection = Conn;
        com.CommandType = CommandType.StoredProcedure;
        com.CommandText = "updatePassCode";
        para = new SqlParameter();
        para2 = new SqlParameter();
        para3 = new SqlParameter();

        para.Value = uid;
        para.Direction = ParameterDirection.Input;
        para.ParameterName = "@u_id";
        para.DbType = DbType.Int64;
        para.Size = 10;
        para2.Value = pc;
        para2.Direction = ParameterDirection.Input;
        para2.ParameterName = "@p_code";
        para2.DbType = DbType.String;
        para2.Size = 10;
        para3.Value = ty;
        para3.Direction = ParameterDirection.Input;
        para3.ParameterName = "@p_type";
        para3.DbType = DbType.Int16;
        para3.Size = 10;

        com.Parameters.Add(para);
        com.Parameters.Add(para2);
        com.Parameters.Add(para3);

        cnt = com.ExecuteNonQuery();
        com = null;
        Conn.Close();
        Conn = null;

    }

    public String RetrieveCustomerCardPIN(string userid, string PANDigits, string CardExpiry)
    {
        String ret_val = "";    //Test "<Response><CODE>1000</CODE><PIN>1234</PIN><MESSAGE>SUCCESS</MESSAGE></Response>"
        String err_msg = "";
        Boolean found_card = false;

        string pan1encrypt = string.Empty;
        string cardidvalueencrypt = string.Empty;
        string seqno = string.Empty;
        string expiry = string.Empty;
        string cardid = string.Empty;
        string pan1 = string.Empty;
        string cardidvalue = string.Empty;

        int T = 0;

        int mBranchCode;
        int mCustomerNo;

        SqlConnection Cnn_BankCard = new SqlConnection(ConfigurationManager.ConnectionStrings["BankcardConnString"].ToString());
        Cnn_BankCard.Open();

        DataTable dtSelect = new DataTable();
        ListItem result = new ListItem();
        EncryptionLib.Encrypt enc = new EncryptionLib.Encrypt();
        SqlDataAdapter daSQLselect;

        try
        {
            mBranchCode = Convert.ToInt32(userid.Substring(0, 3));
            mCustomerNo = Convert.ToInt32(userid.Substring(3, 6));

            daSQLselect = new SqlDataAdapter("select PAN1,CardIDD_Value,SeqNo,Card_ID,Expiry,Customer_No,CardProgram from Cards_Mastercard where CardStatusid in (6,1,4,8,14,22,24,26,21,40,42,44,45,46,15,47,49,50,8) and  branch_code=" + mBranchCode + " and customer_No=" + mCustomerNo + " AND CONVERT(datetime,'20' +substring(Expiry,3,2) + substring(Expiry,1,2)+right(convert(nvarchar,getdate(),2),2)) >  GETDATE() ", Cnn_BankCard);

            daSQLselect.Fill(dtSelect);
            Cnn_BankCard.Close();


            if (dtSelect.Rows.Count > 0)
            {
                CardExpiry = CardExpiry.Substring(0, 2) + CardExpiry.Substring(4, 2);

                foreach (DataRow row in dtSelect.Rows)
                {
                    ListItem newvalues = new ListItem();
                    if (row["PAN1"] != System.DBNull.Value)
                    {
                        pan1encrypt = row["PAN1"].ToString();
                    }
                    if (row["CardIDD_Value"] != System.DBNull.Value)
                    {
                        cardidvalueencrypt = row["CardIDD_Value"].ToString();
                    }
                    if (row["SeqNo"] != System.DBNull.Value)
                    {
                        seqno = row["SeqNo"].ToString();
                    }
                    if (row["Card_ID"] != System.DBNull.Value)
                    {
                        cardid = row["Card_ID"].ToString();
                    }
                    if (row["Expiry"] != System.DBNull.Value)
                    {
                        expiry = row["Expiry"].ToString();
                    }


                    if (!string.IsNullOrEmpty(pan1encrypt))
                    {
                        pan1 = enc.Decrypt_TrpDes(pan1encrypt);
                    }
                    if (!string.IsNullOrEmpty(cardidvalueencrypt))
                    {
                        cardidvalue = enc.Decrypt_TrpDes(cardidvalueencrypt);
                    }


                    if (pan1.Substring(6, 4) == PANDigits.Trim() && expiry == CardExpiry)
                    {
                        found_card = true;
                        break;
                    }

                }

                if (found_card == false)
                    ret_val = "<Response><CODE>1001</CODE><Error>Invalid Card Details</Error></Response>";
                else
                {

                    SecureData secure = new SecureData();

                    try
                    {
                        TwigService newpinservice = new TwigService();

                        string newpin = "";
                        String custid = mBranchCode.ToString() + mCustomerNo.ToString();

                        string cardpinurl = ConfigurationManager.AppSettings["cardpinwebservice"].ToString();
                        newpinservice.Url = cardpinurl;

                        //Live
                        expiry = expiry.Substring(2, 2) + expiry.Substring(0, 2);
                        newpin = newpinservice.TWIGPINWEBP(custid, pan1.Substring(6, 4), expiry, seqno, "1", custid);

                        ////Test
                        //newpin = "00********";

                        if (string.IsNullOrEmpty(newpin))
                        {
                            ret_val = "<Response><CODE>1001</CODE><Error>Unable to retrieve PIN</Error></Response>";

                        }
                        else if (newpin.Substring(0, 2).ToString().Equals("00"))
                        {
                            string encryptedpin;
                            string decryptedpin;

                            //Live
                            encryptedpin = newpin.Substring(2);
                            decryptedpin = GTBSecure.Secure.DecryptString(encryptedpin);

                            ////Test
                            //decryptedpin = "3649";

                            //Encrypt PIN
                            //Int64 encryptedpin_return = (Convert.ToInt64(decryptedpin) * 100) - 450 + 350 - 432;
                            Int64 encryptedpin_return = (Convert.ToInt64("100" + decryptedpin) * 100) + 457865 - 355477 + 4324396;

                            ret_val = "<Response><CODE>1000</CODE><PIN>" + encryptedpin_return.ToString() + "</PIN><MESSAGE>SUCCESS</MESSAGE></Response>";

                            //Send email to admin user
                            String email_resp;
                            String mail_subject = "PIN Re-issuance request on your debit card";
                            String mail_mess = "";
                            String mail_from = "intops@gtbank.com";
                            String customer_email = "";

                            mail_mess = mail_mess + "Hello,";

                            mail_mess = mail_mess + "<BR><BR>This is to notify you that your debit card PIN was re-issued to you via GTConnect based on your request on " + DateTime.Now.ToString("dd/MM/yyyy HH:mm") + "GMT(+1)";

                            mail_mess = mail_mess + "<BR>Please report to Information Security Group (itsecurity@gtbank.com) if the request was not initiated by you.";

                            mail_mess = mail_mess + "<BR><BR>Thank you.";

                            //GetCustomer email address
                            try
                            {
                                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

                                //open connetion
                                if (conn.State != ConnectionState.Open)
                                {
                                    conn.Open();
                                }

                                SqlCommand comm = new SqlCommand("select * from users where user_id = " + userid, conn);
                                //SqlDataAdapter adpt = new SqlDataAdapter(comm);
                                SqlDataReader reader1 = comm.ExecuteReader();


                                if (reader1.HasRows == true)
                                {
                                    reader1.Read();
                                    customer_email = reader1["email"].ToString();
                                }

                                reader1.Close();
                                reader1 = null;
                                if (conn.State != ConnectionState.Closed)
                                {
                                    conn.Close();
                                }
                                conn = null;
                                comm = null;
                            }
                            catch (Exception ex)
                            {

                            }


                            Email email = new Email();
                            email_resp = email.SendEmail_HTML(mail_from, customer_email, mail_subject, mail_mess, "");

                        }
                        else
                        {
                            ret_val = "<Response><CODE>1001</CODE><Error>Unable to retrieve PIN</Error></Response>";
                        }

                    }
                    catch (Exception ex)
                    {
                        ret_val = "<Response><CODE>1001</CODE><Error>Unable to validate PIN: " + ex.Message.Replace("'", "") + "</Error></Response>";
                    }
                }
            }
            else
            {
                ret_val = "<Response><CODE>1001</CODE><Error>Unable to retrieve Card Details</Error></Response>";

            }

        }
        catch (Exception ex)
        {
            ret_val = "<Response><CODE>1001</CODE><Error>Unable to retrieve Card Details: " + ex.Message.Replace("'", "") + "</Error></Response>";
        }

        if (Cnn_BankCard.State != ConnectionState.Closed)
            Cnn_BankCard.Close();


        Cnn_BankCard = null;
        return ret_val;
    }

    public string GetCustomerOpportunity(int braCode, int cusnum)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataRow dr_app;
        String xmlrep = null;
        String xmlschema = null;
        
        string Result = string.Empty;
        OracleConnection oraconn = new OracleConnection(ConfigurationManager.AppSettings["EXADATAConString"]);
        OracleCommand oracomm = new OracleCommand("GTB_ADVERT", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("INP_BRA_CODE", OracleType.Number, 5).Value = braCode;
            oracomm.Parameters.Add("INP_CUS_NUM", OracleType.Number, 5).Value = cusnum;
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
            if (Result == "") Result = "0;0";
            oraconn.Close();

            //get advert from eone
            String[] arr = Result.Split(';');
            if (Result != "0;0")
            {
                conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

                //open connetion
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                comm = new SqlCommand("GetAdvertForCustomer", conn);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@tabid", Convert.ToInt32(arr[0]));
                comm.Parameters.AddWithValue("@tabent", Convert.ToInt32(arr[1]));
                adpt = new SqlDataAdapter(comm);
                ds = new DataSet();

                adpt.Fill(ds);
                if (conn.State == ConnectionState.Open)
                    conn.Close();

                ds.DataSetName = "RESPONSE";

                xmlrep = ds.GetXml();
                xmlschema = ds.GetXmlSchema();
                xmlstring = "<Response>";

                if (ds.Tables[0].Rows.Count > 0)
                {
                    ds.Tables[0].TableName = "ADVERT";
                    xmlstring = xmlstring + "<CODE>1000</CODE>";
                    xmlstring = xmlstring + "<ADVERT>" + ds.Tables[0].Rows[0]["Advert_text"].ToString() + "</ADVERT>";
                    xmlstring = xmlstring + "<HASACTION>" + ds.Tables[0].Rows[0]["has_action"].ToString() + "</HASACTION>";
                    xmlstring = xmlstring + "<ACTIONCODE>" + ds.Tables[0].Rows[0]["action_code"].ToString() + "</ACTIONCODE>";
                    xmlstring = xmlstring + "<GENSCODE>" + Result.Replace(";","-") + "</GENSCODE>";
                }
                else
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>No Advert Found</Error>";
                }

                xmlstring = xmlstring + "</Response>";
            }
            else
            {
                xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>No Advert Found</Error>";
                xmlstring = xmlstring + "</Response>";
            }

        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    //public String GetAdvertForCustomer(String scenario)
    //{
    //    SqlConnection conn;
    //    SqlCommand comm;
    //    DataSet ds;
    //    SqlDataAdapter adpt;
    //    DataRow dr_app;
    //    String xmlrep = null;
    //    String xmlschema = null;
    //    String[] arr = scenario.Split(';');

    //    try
    //    {
    //        if (scenario != "0;0")
    //        {
    //            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

    //            //open connetion
    //            if (conn.State != ConnectionState.Open)
    //            {
    //                conn.Open();
    //            }

    //            comm = new SqlCommand("GetAdvertForCustomer", conn);
    //            comm.CommandType = CommandType.StoredProcedure;
    //            comm.Parameters.AddWithValue("@tabid", Convert.ToInt32(arr[0]));
    //            comm.Parameters.AddWithValue("@tabent", Convert.ToInt32(arr[1]));
    //            adpt = new SqlDataAdapter(comm);
    //            ds = new DataSet();

    //            adpt.Fill(ds);
    //            ds.DataSetName = "RESPONSE";

    //            xmlrep = ds.GetXml();
    //            xmlschema = ds.GetXmlSchema();
    //            xmlstring = "<Response>";

    //            if (ds.Tables[0].Rows.Count > 0)
    //            {
    //                ds.Tables[0].TableName = "ADVERT";
    //                xmlstring = xmlstring + "<CODE>1000</CODE>";
    //                xmlstring = xmlstring + "<ADVERT>" + ds.Tables[0].Rows[0]["Advert_text"].ToString() + "</ADVERT>";
    //            }
    //            else
    //            {
    //                xmlstring = xmlstring + "<CODE>1001</CODE>";
    //                xmlstring = xmlstring + "<Error>No Advert Found</Error>";
    //            }

    //            xmlstring = xmlstring + "</Response>";
    //        }
    //        else
    //        {
    //            xmlstring = "<Response>";
    //            xmlstring = xmlstring + "<CODE>1001</CODE>";
    //            xmlstring = xmlstring + "<Error>No Advert Found</Error>";
    //            xmlstring = xmlstring + "</Response>";
    //        }
    //        //----------------------------------------------------------------
    //        //Create XML string
    //    }
    //    catch (Exception ex)
    //    {
    //        xmlstring = "<Response>";
    //        xmlstring = xmlstring + "<CODE>1001</CODE>";
    //        xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
    //        xmlstring = xmlstring + "</Response>";
    //    }

    //    return xmlstring;
    //    //return xmlrep;
    //}


//    public string InitiateIRefer(int braCode, int cusnum, string Referred_name, string Referred_mobileno, string Referred_email, string Channel, string initiator, string nubannumber)
//    {
//        SqlConnection conn;
//        SqlCommand comm;
//        DataSet ds;
//        SqlDataAdapter adpt;
//        string accountexist = string.Empty;
//        string accountreffred = string.Empty;
//        try
//        {

//            accountexist = getLinkedAccountGENSDB(Referred_mobileno);
//            if (!string.IsNullOrEmpty(accountexist)) // this mobile number is associated with an account cannot continue
//            {
//                xmlstring = "<Response>";
//                xmlstring = xmlstring + "<CODE>1090</CODE>";
//                xmlstring = xmlstring + "<Error>Mobile Number is already associated with an existing GTBank account</Error>";
//                xmlstring = xmlstring + "</Response>";
//                return xmlstring;

//            }

//            accountreffred = GetRefferedAccount(Referred_mobileno);

//            if (!string.IsNullOrEmpty(accountreffred)) // this mobile number is associated with an account cannot continue
//            {
//                xmlstring = "<Response>";
//                xmlstring = xmlstring + "<CODE>1090</CODE>";
//                xmlstring = xmlstring + "<Error>This mobile number is already associated with an existing GTBank Account.</Error>";
//                xmlstring = xmlstring + "</Response>";
//                return xmlstring;

//            }

//            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

//            //open connetion
//            if (conn.State != ConnectionState.Open)
//            {
//                conn.Open();
//            }

//            comm = new SqlCommand("InsertIRefer", conn);
//            comm.CommandType = CommandType.StoredProcedure;
//            comm.Parameters.AddWithValue("@bracode", braCode);
//            comm.Parameters.AddWithValue("@cusnum", cusnum);
//            comm.Parameters.AddWithValue("@referred_name", Referred_name);
//            comm.Parameters.AddWithValue("@referred_mobileno", Referred_mobileno);
//            comm.Parameters.AddWithValue("@referred_email", Referred_name);
//            comm.Parameters.AddWithValue("@channel", Channel);
//            comm.Parameters.AddWithValue("@initiated_by", initiator);
//            comm.Parameters.AddWithValue("@refereeNUBAN", nubannumber);

//            adpt = new SqlDataAdapter(comm);
//            ds = new DataSet();

//            adpt.Fill(ds);

//            xmlstring = "<Response>";

//            if (ds.Tables[0].Rows.Count > 0)
//            {
//                xmlstring = xmlstring + "<CODE>1000</CODE>";
//                xmlstring = xmlstring + "<REFCODE>" + ds.Tables[0].Rows[0]["Ref_code"].ToString() + "</REFCODE>";
//            }
//            else
//            {
//                xmlstring = xmlstring + "<CODE>1001</CODE>";
//                xmlstring = xmlstring + "<Error>" + "0" + "</Error>";
//            }

//            xmlstring = xmlstring + "</Response>";
            
//            //Send email to customer and referree
//            OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"].ToString()));
//            oraconn.Open();
//            OracleCommand cmd = null;
//            OracleDataReader reader;
//            String emailstr = "";
//            string name = string.Empty;
//            String query_str = "SELECT email,get_name2(" + braCode + "," + cusnum + ",0,0,0) name  " + " FROM address where bra_code=" + braCode.ToString() + " and cus_num=" + cusnum.ToString();
//            cmd = new OracleCommand(query_str, oraconn);
//            reader = cmd.ExecuteReader();
//            if (reader.HasRows)
//            {
//                reader.Read();
//                emailstr = reader["email"].ToString();
//                name = reader["name"].ToString();
//                reader.Close();
//                reader = null;
//            }

//            if(oraconn.State != ConnectionState.Closed) oraconn.Close();





//string reffererEmail = "";
// reffererEmail = reffererEmail + "Dear " + name  + Environment.NewLine + Environment.NewLine;
// reffererEmail = reffererEmail + "Thank you for participating in the GTBank i-refer scheme." + Environment.NewLine ;  
// reffererEmail = reffererEmail + "With the GTBank i-refer scheme, you can share our world- class banking experience with your friends, families and associates. You also receive a cash reward into your account for every successful referral you make." + Environment.NewLine ;  
// reffererEmail = reffererEmail + "There is no limit to the number of people you can refer to the GTBank i-refer scheme." + Environment.NewLine ;  
// reffererEmail = reffererEmail + "Your unique code for referral under the GTBank i-refer scheme is " +ds.Tables[0].Rows[0]["Ref_code"].ToString()   + Environment.NewLine ;  
// reffererEmail = reffererEmail + "Kindly note that your GTBank account would be credited with your cash reward once your referee commences full operation of the account." + Environment.NewLine ;
// reffererEmail = reffererEmail + "For further enquiries, please call GTConnect; our fully interactive 24 hours self-service Contact Centre, on 0700-GTCONNECT (0700-482666328), 01-4480000, 0802-9002900 or 0803-9003900." + Environment.NewLine;  
            
            
//  string refferedEmail = "";          
     
// refferedEmail = refferedEmail + "Dear " + Referred_name + Environment.NewLine + Environment.NewLine;
// refferedEmail = refferedEmail + "INVITATION TO OPEN A GTBANK ACCOUNT " + Environment.NewLine;
// refferedEmail = refferedEmail + "You have been referred by " + name   + " to open a GTBank account.  " + Environment.NewLine;
// refferedEmail = refferedEmail + "At GTBank, there is �Something for Everyone� with our range of products and services to cater for all your financial needs. With our variety of individual accounts such as Smart Kids Save (SKS) account, GTTarget account, GTSave account and Seniors account, we ensure that all your individual needs are met. Our range of corporate accounts such as GTMax and GTBusiness account also guarantees the success of your business and corporate objectives. " + Environment.NewLine;
// refferedEmail = refferedEmail + "You can explore our wide range of products and services by visiting www.gtbank.com.  At your convenience, you can also visit any of our branches nationwide to open a GTBank account or by visiting https://ao.gtbank.com/aowe/start.aspx  " + Environment.NewLine;
// refferedEmail = refferedEmail + "Kindly provide the unique referral code " +  ds.Tables[0].Rows[0]["Ref_code"].ToString() + " during your account opening application. " + Environment.NewLine;
// refferedEmail = refferedEmail + "For further information on any of our products or services, you can visit the nearest GTBank branch or our website www.gtbank.com. You can also call GTConnect; our fully interactive 24 hours self-service Contact Centre, on 0700-GTCONNECT (0700-482666328), 01-4480000, 0802-9002900 or 0803-9003900. " + Environment.NewLine;
      
            
            
//            String mailfrom = ConfigurationManager.AppSettings["SenderEmail"].ToString();
//            String mailsubject = "INVITATION TO OPEN A GTBANK ACCOUNT";
//           // String mailmessagerefered = "Hello, \n\nPlease note that you have been referred by your friend. \n\n Thank you.";
//            Email email = new Email();
//          //  String ret_val = email.SendEmail(mailfrom, Referred_email, mailsubject, refferedEmail, emailstr.Replace(";", ",").Split(',')[0]);
//          //  String ret_val2 = email.SendEmail(mailfrom, emailstr, mailsubject,reffererEmail , emailstr.Replace(";", ",").Split(',')[0]);


//            oraconn = null;
//            cmd = null;

//        }
//        catch (Exception ex)
//        {
//            xmlstring = "<Response>";
//            xmlstring = xmlstring + "<CODE>1001</CODE>";
//            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
//            xmlstring = xmlstring + "</Response>";
//        }

//        return xmlstring;
//    }

    public string UpdateIRefer(long RefCode, String update_by)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("UpdateIRefer", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@refcode", RefCode);
            comm.Parameters.AddWithValue("@updated_by", update_by);

            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);

            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<REFCODE>" + ds.Tables[0].Rows[0]["Ref_code"].ToString().PadLeft(12, '0') + "</REFCODE>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "0" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }
	public string UpdateIRefer2(long RefCode, String update_by)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("UpdateIRefer", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@refcode", RefCode);
            comm.Parameters.AddWithValue("@updated_by", update_by);

            comm.CommandType = CommandType.StoredProcedure;
            string i = (string)comm.ExecuteScalar();

            // adpt = new SqlDataAdapter(comm);
            //ds = new DataSet();

            //adpt.Fill(ds);

            xmlstring = "<Response>";

            //if (ds.Tables[0].Rows.Count > 0)
            //{
            //    xmlstring = xmlstring + "<CODE>1000</CODE>";
            //    xmlstring = xmlstring + "<REFCODE>" + ds.Tables[0].Rows[0]["Ref_code"].ToString().PadLeft(12, '0') + "</REFCODE>";
            //}
            if (i == RefCode.ToString())
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<REFCODE>" + i + "</REFCODE>";
            }
            else if (i.Equals("0"))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "CODE DOES NOT EXIST" + "</Error>";
            }
            else if (i.Equals("2"))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "CODE HAS BEEN USED" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }


    public DataTable BlockedFunds(string bra_code ,string cus_num)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataTable ds = new DataTable();
        SqlDataAdapter adpt;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["PostillionOfficeConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

          //  string query = "select card_acceptor_name_loc,settle_amount_rsp,tran_amount_rsp,[0100_date], [0220_date],auth_id_rsp  from [gtb_0100_blocks] where from_account_id like '%" + bra_code + "0"+ cus_num + "%' and auth_id_rsp is NULL and [0220_date] is null";
           
             string query = "select card_acceptor_name_loc,settle_amount_rsp,tran_amount_rsp,[0100_date], [0220_date],auth_id_rsp ,b.alpha_code  from [gtb_0100_blocks] a , post_currencies b  where from_account_id like '%" + SafeSqlLiteral(bra_code.Trim(),1) + "0" + SafeSqlLiteral(cus_num.Trim(),1) + "%' and auth_id_rsp is NULL and [0220_date] is null and b.currency_code = a.tran_currency_code ";
           
            comm = new SqlCommand(query, conn);
            comm.CommandType = CommandType.Text;
          
            adpt = new SqlDataAdapter(comm);
           ds.TableName = "BlockFunds";
            adpt.Fill(ds);
          

        }
        catch (Exception ex)
        {
            ds.TableName = "BlockFunds";
        }

        return ds;
    }

    public DataTable BasisBlockFund(string bra_code, string cus_num)
    {
        OracleConnection conn;
        OracleCommand comm;
        DataTable ds = new DataTable();
        OracleDataAdapter adpt;

        try
        {
            conn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));


            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
                ErrHandler.WriteError("basis Connection opened successfully.");
            }

            string query = "select doc_num from blk_fund where bra_code='" + bra_code + "' and cus_num='" + cus_num + "' and blo_amt > 0 and rea_code='35' and tell_id='9947'and doc_num like '%9999%'";

            comm = new OracleCommand(query, conn);
            //comm.CommandType = CommandType.Text;

            adpt = new OracleDataAdapter(comm);
            ds.TableName = "BasisBlockFund";
            adpt.Fill(ds);           
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message);
        }

        return ds;

    }

    public DataTable BlockedFundsSTAN(string bra_code, string cus_num)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataTable fepTable = new DataTable();
        DataTable matchingRecordsTable = new DataTable();
        DataTable BasisTable = new DataTable();
        SqlDataAdapter adpt;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["PostillionOfficeConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
                ErrHandler.WriteError("FEP Connection opened successfully.");
            }
            //string query ="select system_trace_audit_nr,card_acceptor_name_loc,settle_amount_rsp,tran_amount_rsp,[0100_date], [0220_date],auth_id_rsp ,b.alpha_code  from [gtb_0100_blocks] a , post_currencies b  where from_account_id like '%" + SafeSqlLiteral(bra_code.Trim(),1) + "0" + SafeSqlLiteral(cus_num.Trim(),1) + "%' and auth_id_rsp='NULL' and [0220_date] = 'null' and b.currency_code = a.tran_currency_code";
            string query = "select system_trace_audit_nr,card_acceptor_name_loc,settle_amount_rsp,tran_amount_rsp,[0100_date], [0220_date],auth_id_rsp ,b.alpha_code  from [gtb_0100_blocks] a , post_currencies b  where from_account_id like '%" + SafeSqlLiteral(bra_code.Trim(), 1) + "0" + SafeSqlLiteral(cus_num.Trim(), 1) + "%' and auth_id_rsp is NULL and [0220_date] is null and b.currency_code = a.tran_currency_code";
            //string query = "select system_trace_audit_nr,card_acceptor_name_loc,settle_amount_rsp,tran_amount_rsp,[0100_date], [0220_date],auth_id_rsp ,b.alpha_code  from [data] a , post_currencies b  where from_account_id like '%" + SafeSqlLiteral(bra_code.Trim(), 1) + "0" + SafeSqlLiteral(cus_num.Trim(), 1) + "%' and auth_id_rsp is NULL and [0220_date] is null and b.curr_code = a.tran_currency_code ";
            comm = new SqlCommand(query, conn);
            comm.CommandType = CommandType.Text;

            adpt = new SqlDataAdapter(comm);
            fepTable.TableName = "BlockFunds";
            adpt.Fill(fepTable);

            matchingRecordsTable = fepTable.Clone();
            matchingRecordsTable.TableName = "MatchingData";
            BasisTable = BasisBlockFund(bra_code, cus_num);

            foreach (DataRow dds in fepTable.Rows)
            {
                foreach (DataRow dtable in BasisTable.Rows)
                {
                    if (dtable[0].ToString().Substring(0, 4) == "9999")
                    {
                        if (dds[0].ToString() == dtable[0].ToString().Substring(4))
                        {
                            matchingRecordsTable.ImportRow(dds);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message);
        }
        return matchingRecordsTable;
    }

 
    //public DataTable BasisBlockFund(string bra_code, string cus_num)
    //{
    //    OracleConnection conn;
    //    OracleCommand comm;
    //    DataTable ds = new DataTable();
    //    OracleDataAdapter adpt;

    //    try
    //    {
    //        conn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));


    //        if (conn.State != ConnectionState.Open)
    //        {
    //            conn.Open();
    //        }

    //        string query = "select doc_num from blk_fund where bra_code='" + bra_code + "' and cus_num='" + cus_num + "' and blo_amt > 0 and rea_code='35' and tell_id='9947'and doc_num like '%9999%'";

    //        comm = new OracleCommand(query, conn);
    //        comm.CommandType = CommandType.Text;

    //        adpt = new OracleDataAdapter(comm);
    //        ds.TableName = "BasisBlockFund";
    //        adpt.Fill(ds);


    //    }
    //    catch (Exception ex)
    //    {

    //    }

    //    return ds;

    //}

    //public DataTable BlockedFundsSTAN(string bra_code, string cus_num)
    //{
    //    SqlConnection conn;
    //    SqlCommand comm;
    //    DataTable ds = new DataTable();
    //    DataTable dsE = new DataTable();
    //    DataTable table = new DataTable();
    //    SqlDataAdapter adpt;

    //    try
    //    {
    //        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["PostillionOfficeConnString"].ToString());

    //        //open connetion
    //        if (conn.State != ConnectionState.Open)
    //        {
    //            conn.Open();
    //        }

    //        string query = "select system_trace_audit_nr,card_acceptor_name_loc,settle_amount_rsp,tran_amount_rsp,[0100_date], [0220_date],auth_id_rsp ,b.alpha_code  from [gtb_0100_blocks] a , post_currencies b  where auth_id_rsp is NULL and [0220_date] is null and b.currency_code = a.tran_currency_code and from_account_id like '%" + SafeSqlLiteral(bra_code.Trim(), 1) + "0" + SafeSqlLiteral(cus_num.Trim(), 1) + "%'";
    //        //string query = "select system_trace_audit_nr,card_acceptor_name_loc,settle_amount_rsp,tran_amount_rsp,[0100_date], [0220_date],auth_id_rsp ,b.alpha_code  from [data] a , post_currencies b  where from_account_id like '%" + SafeSqlLiteral(bra_code.Trim(), 1) + "0" + SafeSqlLiteral(cus_num.Trim(), 1) + "%' and auth_id_rsp is NULL and [0220_date] is null and b.curr_code = a.tran_currency_code ";
    //        comm = new SqlCommand(query, conn);
    //        comm.CommandType = CommandType.Text;

    //        adpt = new SqlDataAdapter(comm);
    //        ds.TableName = "BlockFunds";
    //        adpt.Fill(ds);
    //    }
    //    catch (Exception ex)
    //    {
           
    //    }

    //    table = BasisBlockFund(bra_code, cus_num);

    //    foreach (DataRow dds in ds.Rows)
    //    {
    //        foreach (DataRow dtable in table.Rows)
    //        {
    //            if (dtable[0].ToString().Substring(0, 4) == "9999")
    //            {
    //                if (dds[0].ToString() == dtable[0].ToString().Substring(4))
    //                {
    //                    return ds;
    //                }
    //            }
    //        }
    //    }
    //    return dsE;
    //}

    private string getLinkedAccountGENSDB(string mobileNum)
    {

        string returnaccount = "";
        using (OracleConnection OraConn = new OracleConnection(ConfigurationManager.AppSettings["GENSConString"]))
        {
           using (OracleCommand OraSelect = new OracleCommand())
            {
                OracleDataReader OraDrSelect;
                string bra_code = null;
                string cus_num = null;
                string cur_code = null;
                string led_code = null;
                string sub_acct_code = null;
                double cntbal = 0;

                try
                {
                    if (OraConn.State == ConnectionState.Closed)
                    {
                        OraConn.Open();
                    }
                    OraSelect.Connection = OraConn;
                    string selectquery = "select  bra_code,cus_num,cur_code, led_code,sub_acct_code from REFERRAL_ACCOUNT_VW  where primary_mobileno = '" + mobileNum.Trim() + "'";

                    OraSelect.CommandText = selectquery;
                    OraSelect.CommandType = CommandType.Text;
                    using (OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        int count = 0;
                      if (OraDrSelect.Read())
                        {
                            bra_code = OraDrSelect["bra_code"].ToString();
                            cus_num = OraDrSelect["cus_num"].ToString();
                            cur_code = OraDrSelect["cur_code"].ToString();
                            led_code = OraDrSelect["led_code"].ToString();
                            sub_acct_code = OraDrSelect["sub_acct_code"].ToString();
                           returnaccount = bra_code + "/" + cus_num + "/" + cur_code + "/" + led_code + "/" + sub_acct_code;
                               
                           
                           
                        }

                    }
                }
                catch (Exception ex)
                {

                   
                    returnaccount = "Error";
                }
                finally
                {
                    if (OraConn.State == ConnectionState.Open)
                    {
                        OraConn.Close();
                    }
                    OraConn.Dispose();
                }
            }
            return returnaccount;
        }

    }



    //private string GetRefferedAccount(string mobileNum)
    //{

    //    string returnaccount = "";
    //    using (SqlConnection OraConn = new SqlConnection(ConfigurationManager.AppSettings["e_oneConnString"]))
    //    {
    //        using (SqlCommand OraSelect = new SqlCommand())
    //        {
    //            SqlDataReader OraDrSelect;
    //            string ref_code = null;
               
    //            try
    //            {
    //                if (OraConn.State == ConnectionState.Closed)
    //                {
    //                    OraConn.Open();
    //                }
    //                OraSelect.Connection = OraConn;
    //                string selectquery = "SELECT [Ref_code] from  [IRefer] where referred_mobileno = '" + mobileNum.Trim() + "'";

    //                OraSelect.CommandText = selectquery;
    //                OraSelect.CommandType = CommandType.Text;
    //                using (OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
    //                {
    //                    int count = 0;
    //                    if (OraDrSelect.Read())
    //                    {
    //                        ref_code = OraDrSelect["Ref_code"].ToString();

    //                        returnaccount = ref_code;



    //                    }

    //                }
    //            }
    //            catch (Exception ex)
    //            {

    //               returnaccount = "Error";
    //            }
    //            finally
    //            {
    //                if (OraConn.State == ConnectionState.Open)
    //                {
    //                    OraConn.Close();
    //                }
    //                OraConn.Dispose();
    //            }
    //        }
    //        return returnaccount;
    //    }

    //}

    public String ActivateIbankUser(String uid)
    {
        int res = 0;
        String result;
        SqlConnection conn;
        SqlCommand comm;
        SqlDataReader dr;

        String selectqry = null;
        string emailaddress = "none@gtbank.com";
        string username = "";


        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            if (uid.Length == 9)
                uid = uid + "01";

            selectqry = "select user_id,email from users where user_id=" + uid;
            comm = new SqlCommand(selectqry, conn);
            dr = comm.ExecuteReader();

            if (dr.HasRows)
            {
                dr.Read();
                if (!dr.IsDBNull(1))
                {
                    username = dr["user_id"].ToString();
                    //emailaddress = dr.GetString(1);
                    emailaddress = dr["email"].ToString();
                    dr.Close();

                    //Activate user
                    selectqry = "update users set status = 'A' where user_id=" + uid;
                    comm = new SqlCommand(selectqry, conn);
                    res = comm.ExecuteNonQuery();

                    //Send email to user.
                    result = SendHtmlMessageToUser(Convert.ToInt64(uid));
                    if (result.ToUpper() == "OK".ToUpper())
                    {
                        xmlstring = xmlstring + "<CODE>1000</CODE>";
                        xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                    }
                    else
                    {
                        xmlstring = xmlstring + "<CODE>1003</CODE>";
                        xmlstring = xmlstring + "<Error>User activated but email notification not sent. " + result + "></Error>";
                        xmlstring = xmlstring + "</Response>";
                    }

                }
                else
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>EMAIL ADDRESS IS NOT VALID</Error>";
                    xmlstring = xmlstring + "</Response>";
                    dr.Close();
                    return xmlstring;
                }
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1002</CODE>";
                xmlstring = xmlstring + "<Error>UNABLE TO RETRIEVE USER DETAILS</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }
            dr = null;

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String ResetSecretQueAns(String uid)
    {
        int res = 0;
        String result;
        SqlConnection conn;
        SqlCommand comm;
        SqlDataReader dr;

        String selectqry = null;
        string emailaddress = "none@gtbank.com";
        string username = "";


        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }
            if (uid.Length == 9)
                uid = uid + "01";

            selectqry = "select user_id,email from users where user_id=" + uid;
            comm = new SqlCommand(selectqry, conn);
            dr = comm.ExecuteReader();

            if (dr.HasRows)
            {
                dr.Read();
                if (!dr.IsDBNull(1))
                {
                    username = dr["user_id"].ToString();
                    //emailaddress = dr.GetString(1);
                    emailaddress = dr["email"].ToString();
                    dr.Close();

                    //Activate user
                    selectqry = "update users set reminder_question = null, reminder_answer = null where user_id=" + uid;
                    comm = new SqlCommand(selectqry, conn);
                    res = comm.ExecuteNonQuery();

                    xmlstring = xmlstring + "<CODE>1000</CODE>";
                    xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                }
                else
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>EMAIL ADDRESS IS NOT VALID</Error>";
                    xmlstring = xmlstring + "</Response>";
                    dr.Close();
                    return xmlstring;
                }
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1002</CODE>";
                xmlstring = xmlstring + "<Error>UNABLE TO RETRIEVE USER DETAILS</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }
            dr = null;

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String ActivateGENsAlert(String customerid, String nuban_acct)
    {
        xmlstring = "<Response>";


        xmlstring = xmlstring + "<CODE>1000</CODE>";
        xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
        xmlstring = xmlstring + "</Response>";

        return xmlstring;
    }

    public String DeactivateGENsAlert(String customerid, String nuban_acct)
    {
        xmlstring = "<Response>";


        xmlstring = xmlstring + "<CODE>1000</CODE>";
        xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
        xmlstring = xmlstring + "</Response>";

        return xmlstring;
    }

    public String ChequebookRequest(String customerid, String nuban_acct, int startpage, int endpage, int chqLeaveVal)
    {
        //SqlClient.SqlConnection e_OneConn = new SqlClient.SqlConnection(ConfigurationManager.AppSettings("CnnStrSQLReadWrite"));
        //// Lets submit request
        //OracleCommand cmdOraSelect = new OracleCommand();
        //SqlClient.SqlCommand cmdSQLselect = new SqlClient.SqlCommand();
        ////Dim drSQLselect As SqlClient.SqlDataReader
        //StringBuilder Msg = new StringBuilder();
        //int ChequeLeaves = 0;
        //ChequeRequest ChequeRequest = new ChequeRequest();
        //Transfer Transfer = new Transfer();

        //AppDevService AppWebService = new AppDevService();
        //SecureData Secure = new SecureData();
        //string TokenRetVal = null;
        //XmlDocument Tokendocument = null;
        //XPathNavigator Tokennavigator = null;
        //XPathNodeIterator Tokensnodes = null;
        //XPathNavigator Tokennode1 = null;
        //string Tokenretcode = null;
        //string mConfirmTokenNo = string.Empty;
        //string mChkToken = string.Empty;
        //string TokenMess = string.Empty;
        //ErrHandler ErrHandler = new ErrHandler();

        //try
        //{
        //    Session["ProfileAccount"] = dpAccountNo.SelectedValue;
        //    dynamic oldAcct = dpAccountNo.SelectedValue;
        //    string[] AcctNo = oldAcct.Split('/');
        //    if (cbChequebookType.SelectedItem.Text.Equals("50 leaves USD", StringComparison.OrdinalIgnoreCase) | cbChequebookType.SelectedItem.Text.Equals("75 leaves USD", StringComparison.OrdinalIgnoreCase) | cbChequebookType.SelectedItem.Text.Equals("100 leaves USD", StringComparison.OrdinalIgnoreCase))
        //    {
        //        if (!(AcctNo(2) == 2))
        //        {
        //            MessageAlert("Account is not a Dollar Account");
        //            return;
        //        }
        //    }
        //    dynamic mAcctNature = "1";
        //    //CardHolder.GetAccountNature(AcctNo(0), AcctNo(1), AcctNo(2), AcctNo(3), AcctNo(4))

        //    if (cbChequebookType.SelectedItem.Text.Equals("50 leaves individual", StringComparison.OrdinalIgnoreCase) | cbChequebookType.SelectedItem.Text.Equals("75 leaves individual", StringComparison.OrdinalIgnoreCase) | cbChequebookType.SelectedItem.Text.Equals("100 leaves individual", StringComparison.OrdinalIgnoreCase))
        //    {
        //        if (!(mAcctNature == 1))
        //        {
        //            MessageAlert("User does not have an individual profile");
        //            return;
        //        }

        //    }
        //    else if (cbChequebookType.SelectedItem.Text.Equals("100 leaves corporate", StringComparison.OrdinalIgnoreCase) | cbChequebookType.SelectedItem.Text.Equals("75 leaves corporate", StringComparison.OrdinalIgnoreCase) | cbChequebookType.SelectedItem.Text.Equals("50 leaves corporate", StringComparison.OrdinalIgnoreCase))
        //    {
        //        if (!(mAcctNature == 4))
        //        {
        //            MessageAlert("User does not have a Corporate profile");
        //            return;
        //        }

        //    }

        //    if (AcctNo(3) == 59)
        //    {
        //        MessageAlert("Can not request for cheque for this Account");
        //        return;
        //    }

        //    string docnum = null;
        //    string detail = null;
        //    string SerialStart = string.Empty;
        //    string nubanno = dpAccountNo.SelectedItem.Text.Split("-")(0).ToString().Trim();
        //    SerialStart = GetSQLChequeDetail(nubanno);
        //    if (SerialStart == string.Empty)
        //    {
        //        //Go to BASIS
        //        docnum = ChequeDocNum(dpAccountNo.SelectedValue);
        //        SerialStart = docnum;
        //    }
        //    //detail = GenClass.GetAccountStatusAndName(AcctNo(0), AcctNo(1), AcctNo(2), AcctNo(3), AcctNo(4))
        //    //If Not (detail = "0") Then
        //    // If Not detail.ToString.Split(":")(1).ToUpper = "OPEN" Then
        //    // MessageAlert("Account Status is " & detail.ToString.Split(":")(1).ToUpper & " ")
        //    // Exit Sub
        //    // End If


        //    //Else
        //    // MessageAlert("Could not Verify Account Status")
        //    // Exit Sub
        //    //End If
        //    // lblCustomer.Text = "Customer No: " & detail.ToString.Split(":")(0)


        //    if (Secure.GetSecret(Session["muserid"]) == false)
        //    {
        //        MessageAlert("Unable to retrieve user details;Please try again later");
        //        return;
        //    }
        //    if (string.IsNullOrEmpty(Secure.SecretAnswer))
        //    {
        //        MessageAlert("Response to secret question cannot be blank; Kindly contact the nearest GTBank branch");
        //        return;
        //    }
        //    if (txtAnswer.Text.ToUpper != Secure.Decrypt_TripleDes(Secure.SecretAnswer).ToUpper)
        //    {
        //        MessageAlert("Response to secret question Invalid; Kindly respond correctly to complete the transaction");
        //        return;
        //    }

        //    if ((string.IsNullOrEmpty(txtTransCode.Text)))
        //    {
        //        MessageAlert("Please Enter the six digits generated on your token device");
        //        return;
        //    }



        //    mConfirmTokenNo = Secure.ConfirmToken(Session["mUserID"]);
        //    mChkToken = Secure.GetTokenID(Session["mUserID"]);
        //    if (string.IsNullOrEmpty(mChkToken) | Information.IsNumeric(mChkToken) == false)
        //    {
        //        TokenMess = "You must have a token attached to your profile to complete this transaction" + "\\n";
        //        TokenMess = TokenMess + "Kindly go to the nearest Guaranty Trust Bank branch to request for token";
        //        MessageAlert(TokenMess);
        //        return;
        //    }
        //    if (mConfirmTokenNo == 2 | mConfirmTokenNo == 3)
        //    {
        //        MessageAlert("Sorry, your token ID has been deactivated; Please contact your financial institution");
        //        return;
        //    }
        //    else if (mConfirmTokenNo == 0)
        //    {
        //        MessageAlert("Sorry, you need to confirm your Token ID before completing this transaction");
        //        return;

        //    }
        //    else if (mConfirmTokenNo == 1)
        //    {
        //        int chqLeaveVal = Convert.ToInt32(cbChequebookType.SelectedValue.Split(":")(0));
        //        Session["ChequeLeave"] = chqLeaveVal;
        //        chqLeaveVal = chqLeaveVal;
        //        // * CType(txtNoOfPacks.Text, Int16)

        //        string SerialEnd = Convert.ToInt32(SerialStart) + chqLeaveVal;
        //        // txtSerialStart.Text = CType(SerialStart, Integer) + 1
        //        // txtSerialStop.Text = CType(SerialStart, Integer) + chqLeaveVal
        //        //
        //        dynamic acctArray = "";


        //        int mRequestID2 = 0;
        //        dynamic chargeAmount = 100;
        //        dynamic Remarks = "Being charge for Chequebook Request";
        //        dynamic VatRemarks = "Being VAT charge for Chequebook Request";
        //        string mResponse = string.Empty;
        //        bool mTransVatTaken = false;
        //        string StrAcctTo = string.Empty;
        //        string StrAcctFrom = string.Empty;
        //        dynamic mailType = cbChequebookType.SelectedValue.Split(":")(2);
        //        chargeAmount = cbChequebookType.SelectedValue.Split(":")(1);
        //        ChequeRequest.AccountName = Session["musername"];


        //        ChequeRequest.AccountNumber = FormatAccount(Session["ProfileAccount"]);
        //        ChequeRequest.AmountCharged = chargeAmount;
        //        ChequeRequest.ChequeBookType = cbChequebookType.SelectedValue.Split(":")(3);
        //        ChequeRequest.ChequeLeaves = cbChequebookType.SelectedValue.Split(":")(0);
        //        ChequeRequest.Nuban = nubanno;
        //        ChequeRequest.PickUpBranchCode = drpPkUpBranch.SelectedValue;
        //        ChequeRequest.RequestBranch = Session["mUserId2"].ToString().Substring(0, 3);
        //        ChequeRequest.RequestBy = Session["mUserId2"].ToString().Substring(3, 6);
        //        ChequeRequest.RequestorName = Session["musername"];
        //        ChequeRequest.SerialStart = SerialStart;
        //        ChequeRequest.SerialStop = SerialEnd;
        //        ChequeRequest.Status = "Pending";
        //        ChequeRequest.Packs = "1";
        //        //mailType
        //        dynamic AccSplitted = ChequeRequest.AccountNumber.Split('-');
        //        dynamic AccNo = AccSplitted(0) + "/" + AccSplitted(1).Substring(0, 6) + "/" + AccSplitted(1).Substring(6, 1) + "/" + AccSplitted(1).Substring(7, 1) + "/" + AccSplitted(1).Substring(8, 1);
        //        //If ChequeRequest.PendingRequestExist(txtNubanNo.Text) Then
        //        // MessageAlert("Pending Request Already exist for this customer")
        //        // Exit Sub
        //        //End If

        //        //Check the pending
        //        if (ChequeRequest.PendingRequestExist(nubanno))
        //        {
        //            MessageAlert("Pending Request Already Exists");
        //            return;
        //        }

        //        //If ChequeRequest.UnclollectedChequeExist(nubanno) Then
        //        // MessageAlert("Printed but uncollected/unprofiled cheques Exists")
        //        // Exit Sub
        //        //End If



        //        ChequeRequest.GetChargeAccounts(mailType);
        //        // RequestID is used for grouping Since they now request for Packs
        //        ChequeRequest.GetLastChequeRequestID();
        //        ChequeRequest.ChequeRequestID = ChequeRequest.ChequeRequestID + 1;
        //        if (ChequeRequest.AvailableBalance(AccNo) < (chargeAmount + (chargeAmount * 0.05)))
        //        {
        //            string Message = string.Empty;
        //            if (ChequeRequest.ChequeBookType.Trim.Equals("USD", StringComparison.OrdinalIgnoreCase))
        //            {
        //                Message = "Selected Account to debit is not adequately funded; Account must be funded up to $" + chargeAmount + " plus VAT";
        //            }
        //            else
        //            {
        //                Message = "Selected Account to debit is not adequately funded; Account must be funded up to N" + chargeAmount + " plus VAT";
        //            }
        //            MessageAlert(Message);
        //            return;
        //        }
        //        ChequeRequest.TrackId = GenerateTrackId(AccSplitted(0), AccSplitted(1).Substring(0, 6));
        //        //Dim mTransAmountTaken = ChequeRequest.CheckBasis4Trans(Session["ProfileAccount"], chargeAmount, 102, Remarks)
        //        //If mTransAmountTaken = False Then
        //        string[] AcctTo = null;
        //        string[] AcctFrom = null;
        //        AcctTo = ChequeRequest.IncomeAccount.Split("/");
        //        StrAcctTo = AcctTo(0).PadLeft(4, "0") + AcctTo(1).PadLeft(7, "0") + AcctTo(2).PadLeft(3, "0") + AcctTo(3).PadLeft(4, "0") + AcctTo(4).PadLeft(3, "0");

        //        AcctFrom = Session["ProfileAccount"].Split("/");
        //        StrAcctFrom = AcctFrom(0).PadLeft(4, "0") + AcctFrom(1).PadLeft(7, "0") + AcctFrom(2).PadLeft(3, "0") + AcctFrom(3).PadLeft(4, "0") + AcctFrom(4).PadLeft(3, "0");
        //        mResponse = Transfer.PostToBASIS(StrAcctFrom, StrAcctTo, 102, 32, chargeAmount, Remarks);
        //        // Take charge
        //        if (mResponse == "@ERR7@" | mResponse == "@ERR19@")
        //        {
        //            // Take VAT charge
        //            // mTransVatTaken = ChequeRequest.CheckBasis4Trans(Session["ProfileAccount"], chargeAmount * 0.05, 157, Remarks)
        //            // If mTransVatTaken = False Then
        //            AcctTo = ChequeRequest.VATAcct.Split("/");
        //            StrAcctTo = AcctTo(0).PadLeft(4, "0") + AcctTo(1).PadLeft(7, "0") + AcctTo(2).PadLeft(3, "0") + AcctTo(3).PadLeft(4, "0") + AcctTo(4).PadLeft(3, "0");
        //            mResponse = Transfer.PostToBASIS(StrAcctFrom, StrAcctTo, 157, 32, chargeAmount * 0.05, VatRemarks);
        //            // Take charge
        //            //End If
        //            mRequestID2 = ChequeRequest.AddChequebookRequest();
        //            if (mRequestID2 != 0)
        //            {
        //                MessageAlert("Your Cheque book request has been successfully lodged. A notification will be sent via SMS, to your mobile phone number registered with the Bank when your Cheque book is ready for pick up at the GTBank branch you have specified");

        //            }
        //            else
        //            {
        //                MessageAlert("Error Occured while adding Cheque Request");
        //            }
        //            // Submit To Cheque Request Table to be newly created
        //            // Display the Pending Cheque Request with the option of Cancellation+
        //        }
        //        else
        //        {
        //            MessageAlert("An Error occured while Charging Customer. Request could not be placed.");
        //            return;
        //        }
        //        //Else
        //        //Dim loopcount As Integer = CType(txtNoOfPacks.Text, Integer)
        //        //ChequeRequest.SerialStart = txtSerialStart.Text
        //        //ChequeRequest.SerialStop = CType(txtSerialStart.Text, Integer) + CType(Session["ChequeLeave"], Integer) - 1

        //        //For index = 1 To loopcount

        //        // mRequestID2 = ChequeRequest.AddChequebookRequest()
        //        // ChequeRequest.SerialStart = ChequeRequest.SerialStop + 1
        //        //ChequeRequest.SerialStop = ChequeRequest.SerialStop + CType(Session["ChequeLeave"], Integer)
        //        //Next


        //        if (mRequestID2 != 0)
        //        {
        //            MessageAlert("Cheque Request Added Successfully");

        //        }
        //        else
        //        {
        //            MessageAlert("Error Occured while adding Cheque Request");
        //        }
        //    }
        //    else
        //    {
        //        MessageAlert("Invalid token status; Please contact your financial institution");
        //        return;
        //    }

        //}
        //catch (Exception ex)
        //{
        //    ErrHandler.WriteError("Error in chequebook request Module : " + ex.Message);
        //    MessageAlert("Sorry, we are Unable to complete your request at this time; Please try again later");

        //}
        //finally
        //{
        //    if (e_OneConn.State == ConnectionState.Open)
        //    {
        //        e_OneConn.Close();
        //    }
        //    cmdSQLselect.Dispose();

        //}

        return "1";
    }

    public String SendStatementByEmail(String customerid, String acctno, String from_date, String to_date)
    {
        return "1";
    }

    public DataTable AccountManagers(string bra_code, string cus_num, string curcode, string ledcode, string subacctcode)
    {
        OracleConnection conn;
        OracleCommand comm;
        DataTable ds = new DataTable();
        OracleDataAdapter adpt;

        try
        {
            conn = new OracleConnection(ConfigurationManager.AppSettings["EXADATAConString"]);


            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            string accountparam = bra_code + "," + cus_num + "," + curcode + "," + ledcode + "," + subacctcode;
            string teamno = getTeamNo(accountparam);

            string query = "select full_name,email_address,phone,unit from ext_hr_all_employee where pc_code = " + teamno;

            comm = new OracleCommand(query, conn);
            comm.CommandType = CommandType.Text;

            adpt = new OracleDataAdapter(comm);
            ds.TableName = "AccountManagers";
            adpt.Fill(ds);


        }
        catch (Exception ex)
        {

        }

        return ds;
    }

    private static string getTeamNo(string param)
    {
        string result = "";
        String conString = GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]);//.ConnectionString;
        OracleConnection OraConn2 = new OracleConnection(conString);

        try
        {


            OracleCommand oracom2 = new OracleCommand();
            OracleDataReader oraread2 = default(OracleDataReader);
            oracom2.Connection = OraConn2;
            string sqlcommand2 = "select  get_acctmgr(" + param + ") teamno from dual";
            oracom2.CommandText = sqlcommand2;
            oracom2.CommandType = CommandType.Text;
            if (OraConn2.State == ConnectionState.Closed)
            {
                OraConn2.Open();
            }
            oraread2 = oracom2.ExecuteReader(CommandBehavior.CloseConnection);

            if (oraread2.Read())
            {
                result = oraread2["teamno"].ToString().ToUpper().Trim();

                return result;
            }
            else
            {

                return result;
            }
        }
        catch (Exception ex)
        {

        }

        finally
        {

            if (OraConn2.State == ConnectionState.Open)
            {
                OraConn2.Close();
            }
        }


        return result;
    }

    public String InitiateAccountUpdateRequest(string RequestType, string FirstName, string LastName, string IDCard, string AddressLine1, string AddressLine2, string EmailAddress, string MobileNumber, string AccountNumber, string UserID)
    {
        SqlConnection conn = null;
        SqlCommand comm;
        int count = 0;
        UInt64 res = 0;
        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }


            comm = new SqlCommand("usp_AccountUpdateRequestInsert", conn);
            comm.Parameters.AddWithValue("@RequestType", RequestType);
            comm.Parameters.AddWithValue("@FirstName", FirstName);
            comm.Parameters.AddWithValue("@LastName", LastName);
            comm.Parameters.AddWithValue("@IDCard", IDCard);
            comm.Parameters.AddWithValue("@AddressLine1", AddressLine1);
            comm.Parameters.AddWithValue("@AddressLine2", AddressLine2);
            comm.Parameters.AddWithValue("@EmailAddress", EmailAddress);
            comm.Parameters.AddWithValue("@MobileNumber", MobileNumber);
            comm.Parameters.AddWithValue("@AccountNumber", AccountNumber);
            comm.Parameters.AddWithValue("@UserID", UserID);

            comm.CommandType = CommandType.StoredProcedure;
            //   res = Convert.ToUInt64( comm.ExecuteScalar());

            SqlDataAdapter adpt = new SqlDataAdapter(comm);
            DataTable ds = new DataTable();

            adpt.Fill(ds);


            if (ds.Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "<REFCODE>" + ds.Rows[0]["Ref_code"].ToString() + "</REFCODE>";
                xmlstring = xmlstring + "</Response>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Could not insert new record</Error>";
                xmlstring = xmlstring + "</Response>";
            }
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        comm = null;
        conn.Close();
        conn = null;
        return xmlstring;

    }

    public String RetrieveAccountUpdateDetails(string RequestReference)
    {
        SqlConnection conn = null;
        SqlCommand comm;
        int count = 0;
        UInt64 res = 0;
        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("usp_AccountUpdateRequestSelect", conn);
            comm.Parameters.AddWithValue("@RequestReference", RequestReference);
            comm.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter adpt = new SqlDataAdapter(comm);
            DataTable ds = new DataTable();

            adpt.Fill(ds);

            if (ds.Rows.Count > 0)
            {

                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<UserID>" + ds.Rows[0]["UserID"].ToString() + "</UserID>";
                xmlstring = xmlstring + "<AccountNumber>" + ds.Rows[0]["AccountNumber"].ToString() + "</AccountNumber>";
                xmlstring = xmlstring + "<RequestType>" + ds.Rows[0]["RequestType"].ToString() + "</RequestType>";
                xmlstring = xmlstring + "<FirstName>" + ds.Rows[0]["FirstName"].ToString() + "</FirstName>";
                xmlstring = xmlstring + "<LastName>" + ds.Rows[0]["LastName"].ToString() + "</LastName>";
                xmlstring = xmlstring + "<IDCard>" + ds.Rows[0]["IDCard"].ToString() + "</IDCard>";
                xmlstring = xmlstring + "<AddressLine1>" + ds.Rows[0]["AddressLine1"].ToString() + "</AddressLine1>";
                xmlstring = xmlstring + "<AddressLine2>" + ds.Rows[0]["AddressLine2"].ToString() + "</AddressLine2>";
                xmlstring = xmlstring + "<EmailAddress>" + ds.Rows[0]["EmailAddress"].ToString() + "</EmailAddress>";
                xmlstring = xmlstring + "<MobileNumber>" + ds.Rows[0]["MobileNumber"].ToString() + "</MobileNumber>";
                xmlstring = xmlstring + "<Status>" + ds.Rows[0]["Status"].ToString() + "</Status>";
                xmlstring = xmlstring + "</Response>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Could not RETRIEVE record</Error>";
                xmlstring = xmlstring + "</Response>";
            }
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        comm = null;
        conn.Close();
        conn = null;
        return xmlstring;

    }

    //public string BVNLinkerHelper(string userID, string BVN, string FirstName, string bankcode, string LastName, string PhoneNumber, string RegistrationDate, string EnrollmentBank, string channel, string nuban)
    //{
    //    try
    //    {
    //        string customerID = string.Empty;
    //        int x = 0;
    //        Int64 y = 0;
    //        int res = 0;

    //        string chan = ConfigurationManager.AppSettings["BVN_Channel"];
    //        string[] channelArr = chan.Split(',');

    //        foreach (string arr in channelArr)
    //        {
    //            if (arr.ToUpper().Trim() == channel.ToUpper().Trim())
    //            {
    //                x = 1;
    //                break;
    //            }
    //        }

    //        if (x != 1)
    //        {
    //            ErrHandler.WriteError("Invalid channel, kindly check web config, BVN_Channel; " + userID);
    //            return "<Response><CODE>1001</CODE><ERROR>Invalid channel, kindly check web config, BVN_Channel </ERROR></Response>";
    //        }

    //        if (BVN.Length != 11 || Int64.TryParse(BVN, out y) == false)
    //        {
    //            ErrHandler.WriteError("BVN is not valid, BVN must be 11 digit; " + BVN);
    //            return "<Response><CODE>1001</CODE><ERROR>BVN is not valid, BVN must be 11 digit</ERROR></Response>";
    //        }

    //        if (userID.Length < 11 && nuban.Length != 10)
    //        {
    //            ErrHandler.WriteError("UserID or Nuban is not valid. Provide a valid userID or Nuban; " + userID + ";" + nuban);
    //            return "<Response><CODE>1001</CODE><ERROR>UserID or Nuban is not valid. Provide a valid userID or Nuban</ERROR></Response>";
    //        }

    //        if (userID.Length > 8)
    //        {
    //            if (userID.EndsWith("01") == false || Int64.TryParse(userID, out y) == false)
    //            {
    //                ErrHandler.WriteError("UserID is not valid, userID should end with 01; " + userID);
    //                return
    //                    "<Response><CODE>1001</CODE><ERROR>UserID is not valid, userID should end with 01</ERROR></Response>";
    //            }
    //            customerID = userID.Substring(0, userID.Length - 2);
    //        }
    //        else
    //        {
    //            if (Int64.TryParse(nuban, out y) == false || nuban.Length != 10)
    //            {
    //                ErrHandler.WriteError("Nuban account number is not valid; " + nuban);
    //                return "<Response><CODE>1001</CODE><ERROR>Nuban account number is not valid</ERROR></Response>";
    //            }

    //            BASIS basis = new BASIS();
    //            string uID = basis.ConvertToOldAccountNumber(nuban);
    //            string[] uIDIDArr = uID.Split('/');

    //            if (uIDIDArr.GetLength(0) != 5)
    //            {
    //                ErrHandler.WriteError("Nuban account number is not valid; " + nuban);
    //                return "<Response><CODE>1001</CODE><ERROR>Nuban account number is not valid</ERROR></Response>";
    //            }

    //            userID = uIDIDArr[0] + uIDIDArr[1] + "01";
    //            customerID = uIDIDArr[0] + uIDIDArr[1];
    //        }

    //        SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["e_oneConnString"]);

    //        try
    //        {
    //            if (conn.State == ConnectionState.Closed)
    //                conn.Open();

    //            SqlCommand sqlcomm = new SqlCommand("SelectIbankBvnlinkdetails", conn);
    //            sqlcomm.CommandType = CommandType.StoredProcedure;
    //            sqlcomm.Parameters.AddWithValue("@User_Id", userID);
    //            sqlcomm.Parameters.AddWithValue("@bvn", BVN);
    //            if (sqlcomm.ExecuteReader().HasRows)
    //            {
    //                ErrHandler.WriteError("UserID and BVN are already linked on IbankBvnlinkdetails table; " + userID);
    //                return
    //                    "<Response><CODE>1001</CODE><ERROR>UserID and BVN are already linked on IbankBvnlinkdetails table</ERROR></Response>";
    //            }

    //            SqlCommand sqlcomm1 = new SqlCommand("SelectBioMetric", conn);
    //            sqlcomm1.CommandType = CommandType.StoredProcedure;
    //            sqlcomm1.Parameters.AddWithValue("@customerID", customerID);
    //            sqlcomm1.Parameters.AddWithValue("@bvn", BVN);
    //            if (sqlcomm1.ExecuteReader().HasRows)
    //            {
    //                ErrHandler.WriteError("UserID and BVN are already linked on BioMetric table; " + userID);
    //                return
    //                     "<Response><CODE>1001</CODE><ERROR>UserID and BVN are already linked on BioMetric table</ERROR></Response>";
    //            }

    //            using (SqlCommand sqlcomm2 = new SqlCommand("IBBvnlinkdetails", conn))
    //            {
    //                sqlcomm2.CommandType = CommandType.StoredProcedure;

    //                sqlcomm2.Parameters.AddWithValue("@User_Id", userID);
    //                sqlcomm2.Parameters.AddWithValue("@bvn", BVN);
    //                sqlcomm2.Parameters.AddWithValue("@bankcode", bankcode);
    //                sqlcomm2.Parameters.AddWithValue("@firstname", FirstName);
    //                sqlcomm2.Parameters.AddWithValue("@lastname", LastName);
    //                sqlcomm2.Parameters.AddWithValue("@phonenumber", PhoneNumber);
    //                sqlcomm2.Parameters.AddWithValue("@registrationdate", RegistrationDate);
    //                sqlcomm2.Parameters.AddWithValue("@enrollmentbank", EnrollmentBank);
    //                sqlcomm2.Parameters.AddWithValue("@Channel", channel);
    //                res = Convert.ToInt32(sqlcomm2.ExecuteScalar());

    //                conn.Close();

    //                if (res > 0)
    //                {
    //                    ErrHandler.WriteError("Record inserted successfully; " + userID);
    //                    return "<Response><CODE>1000</CODE><MESSAGE>Record inserted successfully</MESSAGE></Response>";
    //                }
    //            }
    //        }
    //        catch (Exception ex)
    //        {
    //            ErrHandler.WriteError(ex.Message + "; " + ex.Source);
    //        }
    //        finally
    //        {
    //            conn.Close();
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        ErrHandler.WriteError(ex.Message + "; " + ex.Source);
    //    }
    //    return "<Response><CODE>1001</CODE><ERROR>Unable to insert record</ERROR></Response>";
    //}

    

    public string GetActiveFEPCards(string pCustomerID)
    {


        int functionReturnValue = 0;
        SqlCommand sqlSelect = new SqlCommand();

        SqlParameter pmCustomerId = new SqlParameter("@CustomerID", pCustomerID);

        string errStr = null;
        int mResponse = 0;
        string result = "";
        SqlDataReader sqlreader;
        SqlConnection ConPostcard = new SqlConnection(ConfigurationManager.AppSettings["CnnPostcard"].ToString());
        try
        {

            sqlSelect.Parameters.Add(pmCustomerId);

            if (ConPostcard.State == ConnectionState.Closed)
            {
                ConPostcard.Open();
            }

            sqlSelect.Connection = ConPostcard;
            sqlSelect.CommandText = "GTB_GetActiveCard";
            sqlSelect.CommandType = CommandType.StoredProcedure;
            sqlreader = sqlSelect.ExecuteReader();

            if (sqlreader.Read())
            {

                result = (string)sqlreader[0];
            }

        }
        catch (Exception ex)
        {

            //  ErrorWriter.WriteError(Session["muserid"].ToString() + ex.Message);

            // ErrLog.AppLogWrite(ex.ToString, true);
            result = ex.Message;


            // Error
            //   MessageAlert(errStr);
        }
        finally
        {
            if (ConPostcard.State == ConnectionState.Open)
            {
                ConPostcard.Close();
            }
        }
        return result;
    }

    public DataTable InternationalTransactions(string bra_code, string cus_num)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataTable ds = new DataTable();
        SqlDataAdapter adpt;

        try
        {
            conn = new SqlConnection(ConfigurationManager.AppSettings["CnnPostcard"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            string query = "gtb_recenttrx";
            comm = new SqlCommand(query, conn);
            comm.Parameters.AddWithValue("@customer_id", bra_code + cus_num);
            comm.CommandType = CommandType.StoredProcedure;

            adpt = new SqlDataAdapter(comm);
            ds.TableName = "IntnlTrans";
            adpt.Fill(ds);


        }
        catch (Exception ex)
        {
            ds.TableName = "IntnlTrans";
        }

        return ds;
    }

    public string GetTotalInternationalSpending(string bra_code,string cus_num)
    {


      
        SqlCommand sqlSelect = new SqlCommand();

        SqlParameter pmCustomerId = new SqlParameter("@customer_id", bra_code+cus_num);

       
        string result = "0";
        SqlDataReader sqlreader;
        SqlConnection ConPostcard = new SqlConnection(ConfigurationManager.AppSettings["CnnPostcard"].ToString());
        try
        {

            sqlSelect.Parameters.Add(pmCustomerId);

            if (ConPostcard.State == ConnectionState.Closed)
            {
                ConPostcard.Open();
            }

            sqlSelect.Connection = ConPostcard;
            sqlSelect.CommandText = "gtb_getintlspend";
            sqlSelect.CommandType = CommandType.StoredProcedure;
            sqlreader = sqlSelect.ExecuteReader();

            if (sqlreader.Read())
            {

                result = (string)sqlreader[0];
            }

        }
        catch (Exception ex)
        {

            //  ErrorWriter.WriteError(Session["muserid"].ToString() + ex.Message);

            // ErrLog.AppLogWrite(ex.ToString, true);
            result = ex.Message;


            // Error
            //   MessageAlert(errStr);
        }
        finally
        {
            if (ConPostcard.State == ConnectionState.Open)
            {
                ConPostcard.Close();
            }
        }
        return result;
    }

    public String TransferFunds_TranSeqCommit(String Acct_fro, String Acct_to, Double Amount, String type, String channel, int Expl_code, String Remarks, int origtbrabracode, string docAlp, int supervisorID, int tellerID, string transUniqIndenf)
    {
        String t_from, t_to, Req_code, ResultStr;
        Char[] charsep = { '+' };
        Double T_amt;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        Boolean chk_bal = false;
        String Remarks1 = null;
        BASIS basis = new BASIS();
        

        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = checkAccountFormat(Acct_fro.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to debit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            chk_bal = checkAccountFormat(Acct_to.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to credit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            tempstr = Acct_to.Split(delim);

            string[] temp1 = Acct_fro.Split(delim);

            if (tempstr[2] != "1")
            {
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<ERROR>FX transfer not allowed</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            if (temp1[2] != "1")
            {
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<ERROR>FX transfer not allowed</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            //if (docAlp != "GTCN")
            //{
            //    if (tempstr[2] != "1" && (temp1[1] != tempstr[1]))
            //    {
            //        xmlstring = xmlstring + "<CODE>1010</CODE>";
            //        xmlstring = xmlstring + "<ERROR>FX transfer not allowed</ERROR>";
            //        xmlstring = xmlstring + "</Response>";
            //        return xmlstring;
            //    }
            //}

            t_to = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');
            tempstr = Acct_fro.Split(delim);
            t_from = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');

            Amount = Math.Round(Amount, 2);

            T_amt = Amount;

            Req_code = "32";

            if (type == "OWN")
            {
                //Expl_code = 100;
                Remarks1 = channel + " - OWN Account Transfer from " + Acct_fro + " to " + Acct_to;
            }
            else if (type == "PRE")
            {
                //Expl_code = 102;
                Remarks1 = channel + " - PRE-REGISTERED Account Transfer from " + Acct_fro + " to " + Acct_to;
            }
            else if (type == "ANY")
            {
                //Expl_code = 102;
                Remarks1 = channel + " - ANY Account Transfer from " + Acct_fro + " to " + Acct_to;
            }
            else
            {
                //Expl_code = 102;
                Remarks1 = Remarks;
            }

            ResultStr = this.PostToBasis_TranSeqCommit(t_from, t_to, T_amt, Expl_code, Remarks1, Req_code, supervisorID, tellerID, origtbrabracode, transUniqIndenf, channel, docAlp, Acct_fro, Acct_to);

            if (ResultStr.CompareTo("@ERR7@") == 0 || ResultStr.CompareTo("@ERR19@") == 0)
            {
                //log output
                if (type == "OWN" || type == "PRE" || type == "ANY")
                {
                    LogTransfer(Acct_fro.Replace("/", "").Substring(0, 9), Acct_fro, Acct_to, Convert.ToDecimal(T_amt), channel, Remarks1);
                }

                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + basis.BasisError(ResultStr) + "</ERROR>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<ERROR>" + ex.Message + "</ERROR>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public string PostToBasis_TranSeqCommit(string Acct_from, string Acct_to, double Tra_amt, int Expl_code, string Remark, string Req_code, int supervisorID, int tellerID, int origtbraCode, string transUniqIndenf, string channel, string docAlp, string debitACC, string creditACC)
    {
        string result1 = string.Empty;
        long result2 = 0;
        long result3 = 0;
        string[] tempstrDebitAcc;
        string[] tempstrCreditAcc;

        tempstrDebitAcc = debitACC.Split('/');
        tempstrCreditAcc = creditACC.Split('/');

        if (Acct_from.Trim() == Acct_to.Trim())
        {
            ErrHandler.WriteError("Acct_from = Acct_to for: " + Acct_from + "||" + Acct_to + "||" + Tra_amt.ToString() + "||" + origtbraCode + "||" + result2 + "||" + transUniqIndenf);
            return "@ERR-74@";
        }

        if (Tra_amt <= 0.0)
        {
            ErrHandler.WriteError("Tra_amt <= 0.0 for: " + Acct_from + "||" + Acct_to + "||" + Tra_amt.ToString() + "||" + origtbraCode + "||" + result2 + "||" + transUniqIndenf);
            return "@ERR-74@";
        }

        //Round the amount to 2 decimal places
        //Tra_amt = Math.Round(Tra_amt, 2, MidpointRounding.AwayFromZero);

        using (OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
        {
            OracleTransaction transaction;
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            transaction = oraconn.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                OracleCommand oracomm = oraconn.CreateCommand();
                oracomm.CommandType = CommandType.StoredProcedure;
                oracomm.CommandTimeout = 45;

                //Start a local transaction and assign transaction object for a pending local transaction                
                oracomm.Transaction = transaction;
                oracomm.CommandText = "EONEPKG.GTBPBSC0_FULL";

                oracomm.Parameters.Add("INP_ACCT_FROM", OracleType.VarChar, 21).Value = Acct_from;
                oracomm.Parameters.Add("INP_ACCT_TO", OracleType.VarChar, 21).Value = Acct_to;
                oracomm.Parameters.Add("INP_TRA_AMT", OracleType.Double, 20).Value = Tra_amt;
                oracomm.Parameters.Add("INP_EXPL_CODE", OracleType.Int32, 15).Value = Expl_code;
                oracomm.Parameters.Add("INP_REMARKS", OracleType.VarChar, 200).Value = Remark;
                oracomm.Parameters.Add("inp_rqst_code", OracleType.VarChar, 15).Value = Req_code;
                oracomm.Parameters.Add("INP_MAN_APP1", OracleType.Int32, 15).Value = supervisorID;
                oracomm.Parameters.Add("inp_tell_id", OracleType.Int32, 15).Value = tellerID;
                oracomm.Parameters.Add("INP_DOC_ALP", OracleType.VarChar, 200).Value = docAlp;
                oracomm.Parameters.Add("out_tra_seq1", OracleType.Int32, 15).Direction = ParameterDirection.Output;
                oracomm.Parameters.Add("inp_tra_seq1", OracleType.Int32, 15).Direction = ParameterDirection.Output;
                oracomm.Parameters.Add("INP_ORIGT_BRA_CODE", OracleType.Int32, 15).Value = origtbraCode;
                oracomm.Parameters.Add("out_return_status", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                oracomm.ExecuteNonQuery();
                result1 = oracomm.Parameters["OUT_RETURN_STATUS"].Value.ToString();

                if (result1.Trim().CompareTo("@ERR7@") == 0 || result1.Trim().CompareTo("@ERR19@") == 0)
                {
                    try
                    {
                        result2 = Convert.ToInt64(oracomm.Parameters["out_tra_seq1"].Value.ToString()); //Originating Transaction Sequence
                        result3 = Convert.ToInt64(oracomm.Parameters["inp_tra_seq1"].Value.ToString()); //Originating Transaction Sequence

                        if (result2 <= 0 || result3 <= 0)
                        {
                            transaction.Rollback();
                            ErrHandler.WriteError(result1 + " returned from basis but sequence is zero for transaction" + " || Rolled back transaction for: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);
                            return "@ERR-74@";
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        ErrHandler.WriteError(ex.Message + " || out_tra_seq1 or inp_tra_seq1 threw error. " + result1 + " || Rolled back transaction for: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);
                        return "@ERR-74@";
                    }

                    transaction.Commit();
                    ErrHandler.WriteError("Commit operation successful for: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);

                    InsertTraSeqTransferFund(channel, result2, result3, docAlp, Tra_amt, transUniqIndenf, debitACC, creditACC);

                    return result1;
                }
                else
                {
                    transaction.Rollback();
                    ErrHandler.WriteError(result1 + " || Rolled back transaction for: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);
                    return result1;
                }
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                ErrHandler.WriteError(ex.Message + "|| Rolled back transaction: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);
                result1 = ex.Message;
                return result1;
            }
            finally
            {
                oraconn.Close();
            }
        }
    }

    private void InsertTraSeqTransferFund(string channel, long out_tra_seq1, long inp_tra_seq1, string inp_doc_alp, double amount, string appTransUniqIndenf, string debitAcct, string creditAcct)
    {
        SqlCommand sqlSelect = new SqlCommand();
        SqlDataReader sqlreader;
        SqlConnection TranSeq = new SqlConnection(ConfigurationManager.ConnectionStrings["GTCollectionConnstr"].ToString());
        try
        {
            if (TranSeq.State == ConnectionState.Closed)
            {
                TranSeq.Open();
            }

            sqlSelect.CommandText = "TransOrigtTraSeq";
            sqlSelect.CommandType = CommandType.StoredProcedure;
            sqlSelect.Connection = TranSeq;
            sqlSelect.CommandTimeout = 120;
            sqlSelect.Parameters.AddWithValue("@out_tra_seq1", out_tra_seq1);
            sqlSelect.Parameters.AddWithValue("@inp_tra_seq1", inp_tra_seq1);
            sqlSelect.Parameters.AddWithValue("@inp_doc_alp", inp_doc_alp);
            sqlSelect.Parameters.AddWithValue("@amount", amount);
            sqlSelect.Parameters.AddWithValue("@uniqIdentifier", appTransUniqIndenf);
            sqlSelect.Parameters.AddWithValue("@debitAcct", debitAcct);
            sqlSelect.Parameters.AddWithValue("@creditAcct", creditAcct);

            int res = sqlSelect.ExecuteNonQuery();
            if (res < 1)
                ErrHandler.WriteError("Unable to transaction insert into Transfer_OrigtTraSeq.  || (channel, out_tra_seq1, inp_tra_seq1,  amount, appTransUniqIndenf) = (" + channel + "," + out_tra_seq1 + "," + inp_doc_alp + "," + amount + "," + appTransUniqIndenf + ")");

        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + "|| (channel, out_tra_seq1, inp_tra_seq1, amount, appTransUniqIndenf) = (" + channel + "," + out_tra_seq1 + "," + inp_doc_alp + "," + amount + "," + appTransUniqIndenf + ")");
        }
        finally
        {
            if (TranSeq.State == ConnectionState.Open)
            {
                TranSeq.Close();
            }
        }
    }

    public String TransferGTBChequesTransSeqCommit(String Acct_fro, String Acct_to, Double Amount, String type, String channel, String Remarks, int docnum, Int16 identifier, Int16 bankcode, Int16 days, string docAlp, int supervisorID, int tellerID, int origtbraCode, string transUniqIndenf)
    {
        String t_from, Req_code, ResultStr;
        String t_to = "";
        Char[] charsep = { '+' };
        Double T_amt;
        int Expl_code;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        Boolean chk_bal = false;
        BASIS basis = new BASIS();

        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = checkAccountFormat(Acct_fro.Trim());

            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to debit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            chk_bal = checkAccountFormat(Acct_to.Trim());

            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to credit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            tempstr = Acct_to.Split(delim);

            string[] temp1 = Acct_fro.Split(delim);

            if (tempstr[2] != "1")
            {
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<ERROR>FX transfer not allowed</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            if (temp1[2] != "1")
            {
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<ERROR>FX transfer not allowed</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            t_to = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');
            tempstr = Acct_fro.Split(delim);
            t_from = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');

            //t_to = tempstr[0].PadLeft(3, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(2, '0');
            //tempstr = Acct_fro.Split(delim);
            //t_from = tempstr[0].PadLeft(3, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(2, '0') + tempstr[3].PadLeft(2, '0') + tempstr[4].PadLeft(2, '0');

            Amount = Math.Round(Amount, 2);

            T_amt = Amount;

            Req_code = type;
            //Expl_code = 953;
            if (Req_code.ToUpper().Trim() == "OBC")
            {
                Expl_code = Convert.ToInt32(ConfigurationManager.AppSettings["EXPLOTHERBANKCHEQUE"].ToString());
            }
            else
            {
                Expl_code = 647;
            }
            //identifier = 4;

            ResultStr = this.PostToBasis_ChequeTransSeqCommit(t_from, t_to, T_amt, Expl_code, Remarks, Req_code, docnum, identifier, bankcode, days, docAlp, supervisorID, tellerID, origtbraCode, transUniqIndenf, channel, Acct_fro, Acct_to);

            if (ResultStr.CompareTo("@ERR7@") == 0 || ResultStr.CompareTo("@ERR19@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCESS</MESSAGE>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + basis.BasisError(ResultStr) + "</ERROR>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<ERROR>" + ex.Message + "</ERROR>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    private string PostToBasis_ChequeTransSeqCommit(string Acct_from, string Acct_to, double Tra_amt, int Expl_code, string Remark, string Req_code, int docnum, int identifier, int bankcode, int days, string docAlp, int supervisorID, int tellerID, int origtbraCode, string transUniqIndenf, string channel, string debitACC, string creditACC)
    {
        string result1 = string.Empty;
        long result2 = 0;
        long result3 = 0;

        if (Acct_from.Trim() == Acct_to.Trim())
        {
            return "@ERR-74@";
        }

        //Round the amount to 2 decimal places
        //Tra_amt = Math.Round(Tra_amt, 2, MidpointRounding.AwayFromZero);

        try
        {
            using (OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
            {
                OracleTransaction transaction;
                if (oraconn.State == ConnectionState.Closed)
                {
                    oraconn.Open();
                }
                transaction = oraconn.BeginTransaction(IsolationLevel.ReadCommitted);
                try
                {
                    OracleCommand oracomm = oraconn.CreateCommand();
                    oracomm.CommandType = CommandType.StoredProcedure;
                    oracomm.CommandTimeout = 45;

                    //Start a local transaction and assign transaction object for a pending local transaction                
                    oracomm.Transaction = transaction;
                    oracomm.CommandText = "EONEPKG.GTBPBSC0_FULL";

                    oracomm.Parameters.Add("INP_ACCT_FROM", OracleType.VarChar, 21).Value = Acct_from;
                    oracomm.Parameters.Add("INP_ACCT_TO", OracleType.VarChar, 21).Value = Acct_to;
                    oracomm.Parameters.Add("INP_TRA_AMT", OracleType.Double, 20).Value = Tra_amt;
                    oracomm.Parameters.Add("INP_EXPL_CODE", OracleType.Int32, 15).Value = Expl_code;
                    oracomm.Parameters.Add("INP_REMARKS", OracleType.VarChar, 200).Value = Remark;
                    oracomm.Parameters.Add("inp_rqst_code", OracleType.VarChar, 15).Value = identifier;
                    oracomm.Parameters.Add("INP_MAN_APP1", OracleType.Int32, 15).Value = supervisorID;
                    oracomm.Parameters.Add("inp_tell_id", OracleType.Int32, 15).Value = tellerID;
                    oracomm.Parameters.Add("inp_period", OracleType.Int32, 15).Value = days;
                    oracomm.Parameters.Add("inp_bnk_code", OracleType.Int32, 15).Value = bankcode;
                    oracomm.Parameters.Add("inp_doc_num", OracleType.Int32, 15).Value = docnum;
                    oracomm.Parameters.Add("INP_DOC_ALP", OracleType.VarChar, 200).Value = docAlp;
                    oracomm.Parameters.Add("out_tra_seq1", OracleType.Int32, 15).Direction = ParameterDirection.Output;
                    oracomm.Parameters.Add("inp_tra_seq1", OracleType.Int32, 15).Direction = ParameterDirection.Output;
                    oracomm.Parameters.Add("INP_ORIGT_BRA_CODE", OracleType.Int32, 15).Value = origtbraCode;
                    oracomm.Parameters.Add("out_return_status", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                    oracomm.ExecuteNonQuery();
                    result1 = oracomm.Parameters["OUT_RETURN_STATUS"].Value.ToString();

                    if (result1.Trim().CompareTo("@ERR7@") == 0 || result1.Trim().CompareTo("@ERR19@") == 0)
                    {
                        try
                        {
                            result2 = Convert.ToInt64(oracomm.Parameters["out_tra_seq1"].Value.ToString()); //Originating Transaction Sequence
                            result3 = Convert.ToInt64(oracomm.Parameters["inp_tra_seq1"].Value.ToString()); //Originating Transaction Sequence

                            if (result2 <= 0 || result3 <= 0)
                            {
                                transaction.Rollback();
                                ErrHandler.WriteError(result1 + " returned from basis but sequence is zero for transaction" + " || Rolled back transaction for: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," +  result3 + "," + transUniqIndenf);
                                return "@ERR-74@";
                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            ErrHandler.WriteError(ex.Message + " || out_tra_seq1 or inp_tra_seq1 threw error. " + result1 + " || Rolled back transaction for: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);
                            return "@ERR-74@";
                        }
                        
                        transaction.Commit();
                        ErrHandler.WriteError("Commit operation successful for: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);

                        InsertTraSeqTransferFund(channel + "_Cheque", result2, result3, docAlp, Tra_amt, transUniqIndenf, debitACC, creditACC);
                        return result1;
                    }
                    else
                    {
                        transaction.Rollback();
                        ErrHandler.WriteError(result1 + "|| Rolled back transaction for: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);
                        return result1;
                    }
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    ErrHandler.WriteError(ex.Message + "|| Rolled back transaction: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);
                    result1 = ex.Message;
                    return result1;
                }
                finally
                {
                    oraconn.Close();
                }
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message);
            return "@ERR-74@";
        }
    }

    public String TransferFunds3(String Acct_fro, String Acct_to, Double Amount, String type, String channel, int Expl_code, String Remarks)
    {
        String t_from, t_to, Req_code, ResultStr;
        Char[] charsep = { '+' };
        Double T_amt;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        Boolean chk_bal = false;
        String Remarks1 = null;

        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = checkAccountFormat(Acct_fro.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to debit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            chk_bal = checkAccountFormat(Acct_to.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to credit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            tempstr = Acct_to.Split(delim);

            string[] temp1 = Acct_fro.Split(delim);
            if (tempstr[2] != "1" && (temp1[1] != tempstr[1]))
            {
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<ERROR>FX transfer not allowed</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            t_to = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');
            string braCode = tempstr[0];
            string cusNum = tempstr[1];
            tempstr = Acct_fro.Split(delim);
            t_from = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');

            Amount = Math.Round(Amount, 2);

            T_amt = Amount;

            Req_code = "32";

            if (type == "OWN")
            {
                //Expl_code = 100;
                Remarks1 = channel + " - OWN Account Transfer ";
            }
            else if (type == "PRE")
            {
                //Expl_code = 102;
                Remarks1 = channel + " - PRE-REGISTERED Account Transfer ";
            }
            else if (type == "ANY")
            {
                //Expl_code = 102;
                Remarks1 = channel + " - ANY Account Transfer ";
            }
            else
            {
                //Expl_code = 102;
                Remarks1 = Remarks;
            }

            ResultStr = this.PostToBasis_Commit(t_from, t_to, T_amt, Expl_code, Remarks1, Req_code);

            if (ResultStr.CompareTo("@ERR7@") == 0 || ResultStr.CompareTo("@ERR19@") == 0)
            {
                //string checkbasis = "select tra_amt from transact where bra_code = " + braCode + " and cus_num

                //log output
                if (type == "OWN" || type == "PRE" || type == "ANY")
                {
                    LogTransfer(Acct_fro.Replace("/", "").Substring(0, 9), Acct_fro, Acct_to, Convert.ToDecimal(T_amt), channel, Remarks1);
                }
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }
            else
            {
                //get basis return error
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ResultStr + ": " + chann.BasisError(ResultStr) + "</ERROR>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

        
    public string PostToBasis_Commit(string Acct_from, string Acct_to, double Tra_amt, int Expl_code, string Remark, string Req_code)
    {
        string Result = string.Empty;

        if (Acct_from.Trim() == Acct_to.Trim())
        {
            return "@ERR-74@";
        }

        //Round the amount to 2 decimal places
        Tra_amt = Math.Round(Tra_amt, 2, MidpointRounding.AwayFromZero);

        using (OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
        {
            OracleTransaction transaction;
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            transaction = oraconn.BeginTransaction(IsolationLevel.ReadCommitted);

            try
            {
                OracleCommand oracomm = oraconn.CreateCommand();
                oracomm.CommandType = CommandType.StoredProcedure;
                oracomm.CommandTimeout = 60;
                //Start a local transaction and assign transaction object for a pending local transaction                
                oracomm.Transaction = transaction;
                oracomm.CommandText = "gtbpbsc0_full_ibank";

                oracomm.Parameters.Add("INP_ACCT_FROM", OracleType.VarChar, 21).Value = Acct_from;
                oracomm.Parameters.Add("INP_ACCT_TO", OracleType.VarChar, 21).Value = Acct_to;
                oracomm.Parameters.Add("INP_TRA_AMT", OracleType.Double, 20).Value = Tra_amt;
                oracomm.Parameters.Add("INP_EXPL_CODE", OracleType.Int32, 15).Value = Expl_code;
                oracomm.Parameters.Add("INP_REMARKS", OracleType.VarChar, 200).Value = Remark;
                oracomm.Parameters.Add("INP_RQST_CODE", OracleType.VarChar, 15).Value = Req_code;
                oracomm.Parameters.Add("OUT_RETURN_STATUS", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                oracomm.ExecuteNonQuery();
                Result = oracomm.Parameters["OUT_RETURN_STATUS"].Value.ToString();

                if (Result.Trim().CompareTo("@ERR7@") == 0 || Result.Trim().CompareTo("@ERR19@") == 0)
                {
                    transaction.Commit();
                    ErrHandler.WriteError("Commit successful for transaction with details INP_ACCT_FROM = " + Acct_from + " || INP_ACCT_TO = " + Acct_to + " || INP_REMARKS = " + Remark + " || OUT_RETURN_STATUS = " + Result);
                    return Result;
                }
                else
                {
                    transaction.Rollback();
                    ErrHandler.WriteError("Rollback for transaction with details INP_ACCT_FROM = " + Acct_from + " || INP_ACCT_TO = " + Acct_to + " || INP_REMARKS = " + Remark + " || OUT_RETURN_STATUS = " + Result);
                    return Result;
                }
            }
            catch (Exception ex)
            {
                Result = "-2";
                transaction.Rollback();
                ErrHandler.WriteError("Error Posting to Basis, issued a rollback : with details INP_ACCT_FROM = " + Acct_from + " || INP_ACCT_TO = " + Acct_to + " || INP_REMARKS = " + Remark + " || OUT_RETURN_STATUS = " + Result + " ERROR = " + ex.Message);
                return Result;
            }
            finally
            {
                oraconn.Close();
            }
        }
    }

    public string BVNLinkerHelper(string userID, string BVN, string FirstName, string bankcode, string LastName, string PhoneNumber, string RegistrationDate, string EnrollmentBank, string channel, string nuban, string MiddleName, string DateOfBirth, string sign, string platformid, string EnrollmentBranch)
    {
        try
        {
            string piped_resp_from_NIBSS = BVN + " || " + userID + "/" + nuban + " || " + channel + " || " + FirstName + " || " + LastName + " || " + DateOfBirth + " || " + PhoneNumber + " || " + RegistrationDate + " || " + EnrollmentBank + " || " + EnrollmentBranch;

            ErrHandler.WriteError("Received BVN = " + BVN + " || userID/Nuban = " + userID + "/" + nuban + " || channel = " + channel);
            string customerID = string.Empty;
            int x = 0;
            Int64 y = 0;
            int res = 0;
            string terminalID = string.Empty;

            if (channel.ToUpper().Contains("ATM"))
            {
                string [] chanArr = channel.Split('_');
                
                if (chanArr.GetLength(0) == 2)
                {
                    channel = chanArr[0];
                    terminalID = chanArr[1];
                }
                else
                {
                    ErrHandler.WriteError("TerminalID is " + channel + ". For BVN = " + BVN);
                }
            }

            string chan = ConfigurationManager.AppSettings["BVN_Channel"];
            string[] channelArr = chan.Split(',');

            foreach (string arr in channelArr)
            {
                if (arr.ToUpper().Trim() == channel.ToUpper().Trim())
                {
                    x = 1;
                    break;
                }
            }

            if (x != 1)
            {
                ErrHandler.WriteError("Invalid channel, kindly check web config, BVN_Channel; " + userID);
                return "<Response><CODE>1001</CODE><ERROR>Invalid channel</ERROR></Response>";
            }

            if (BVN.Length != 11 || Int64.TryParse(BVN, out y) == false)
            {
                ErrHandler.WriteError("BVN is not valid, BVN must be 11 digits; " + BVN);
                return "<Response><CODE>1001</CODE><ERROR>BVN is not valid, BVN must be 11 digits.</ERROR></Response>";
            }

            if (userID.Length < 11 && nuban.Length != 10)
            {
                ErrHandler.WriteError("UserID or Nuban is not valid. Provide a valid userID or Nuban; " + userID + ";" + nuban);
                return "<Response><CODE>1001</CODE><ERROR>Account number is not valid.</ERROR></Response>";
            }

            if (userID.Length > 8)
            {
                if (userID.EndsWith("01") == false || Int64.TryParse(userID, out y) == false)
                {
                    ErrHandler.WriteError("UserID is not valid, userID should end with 01; " + userID);
                    return
                        "<Response><CODE>1001</CODE><ERROR>Account number is not valid.</ERROR></Response>";
                }
                customerID = userID.Substring(0, userID.Length - 2);
            }
            else
            {
                if (Int64.TryParse(nuban, out y) == false || nuban.Length != 10)
                {
                    ErrHandler.WriteError("Nuban account number is not valid; " + nuban);
                    return "<Response><CODE>1001</CODE><ERROR>Account number is not valid.</ERROR></Response>";
                }

                BASIS basis = new BASIS();
                string uID = basis.ConvertToOldAccountNumber(nuban);
                string[] uIDIDArr = uID.Split('/');

                if (uIDIDArr.GetLength(0) != 5)
                {
                    ErrHandler.WriteError("Nuban account number is not valid; " + nuban);
                    return "<Response><CODE>1001</CODE><ERROR>Account number is not valid.</ERROR></Response>";
                }

                userID = uIDIDArr[0] + uIDIDArr[1] + "01";
                customerID = uIDIDArr[0] + uIDIDArr[1];
            }

            SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["e_oneConnString"]);

            try
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();

                SqlCommand sqlcomm = new SqlCommand("SelectIbankBvnlinkdetails", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlcomm.Parameters.AddWithValue("@User_Id", userID);
                sqlcomm.Parameters.AddWithValue("@bvn", BVN);
                SqlDataReader reader = null;
                reader = sqlcomm.ExecuteReader(CommandBehavior.CloseConnection);

                if (reader.HasRows)
                {
                    DataTable dTable = new DataTable();
                    dTable.Load(reader);
                    reader.Close();

                    foreach (DataRow rw in dTable.Rows)
	                {
                        string bvnOnTable = rw["bvn"].ToString();

                        if (bvnOnTable.Trim() == BVN.Trim())
                        {
                            ErrHandler.WriteError("UserID and BVN are already linked on IbankBvnlinkdetails table; userID " + userID + " New BVN = " + BVN + " || BVN_on_IbankBvnlinkdetails = " + bvnOnTable);
                            return "<Response><CODE>1001</CODE><ERROR>This BVN already exists on your account.</ERROR></Response>";
                        }
	                }

                    ErrHandler.WriteError("UserID and BVN are already linked on IbankBvnlinkdetails table; userID " + userID + " BVN = " + BVN);
                    return
                        "<Response><CODE>1001</CODE><ERROR>A different BVN already exists on your account, kindly visit a nearest branch to validate your BVN.</ERROR></Response>";
                }

                reader.Close();

                if (conn.State == ConnectionState.Closed)
                    conn.Open();

                SqlCommand sqlcomm1 = new SqlCommand("SelectBioMetric", conn);
                sqlcomm1.CommandType = CommandType.StoredProcedure;
                sqlcomm1.Parameters.AddWithValue("@customerID", customerID);
                sqlcomm1.Parameters.AddWithValue("@bvn", BVN);
                SqlDataReader reader2 = null;
                reader2 = sqlcomm1.ExecuteReader(CommandBehavior.CloseConnection);

                if (reader2.HasRows)
                {
                    DataTable dTable = new DataTable();
                    dTable.Load(reader2);
                    reader2.Close();

                    foreach (DataRow rw in dTable.Rows)
                    {
                        string bvnOnTable = rw["bvn"].ToString();

                        if (bvnOnTable.Trim() == BVN.Trim())
                        {
                            ErrHandler.WriteError("UserID and BVN are already linked on BioMetric table; customerID " + customerID + " New BVN = " + BVN + " || BVN_on_BioMetric = " + bvnOnTable);
                            return "<Response><CODE>1001</CODE><ERROR>This BVN already exists on your account.</ERROR></Response>";
                        }
                    }

                    ErrHandler.WriteError("UserID and BVN are already linked on BioMetric table; customerID " + customerID + " || BVN = " + BVN);
                    return
                         "<Response><CODE>1001</CODE><ERROR>A different BVN already exists on your account, kindly visit a nearest branch to validate your BVN.</ERROR></Response>";
                }

                reader2.Close();

                using (SqlCommand sqlcomm2 = new SqlCommand("IBBvnlinkdetails", conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();

                    sqlcomm2.CommandType = CommandType.StoredProcedure;

                    sqlcomm2.Parameters.AddWithValue("@User_Id", userID);
                    sqlcomm2.Parameters.AddWithValue("@bvn", BVN);
                    sqlcomm2.Parameters.AddWithValue("@bankcode", bankcode);
                    sqlcomm2.Parameters.AddWithValue("@firstname", FirstName);
                    sqlcomm2.Parameters.AddWithValue("@lastname", LastName);
                    sqlcomm2.Parameters.AddWithValue("@phonenumber", PhoneNumber);
                    sqlcomm2.Parameters.AddWithValue("@registrationdate", RegistrationDate);
                    sqlcomm2.Parameters.AddWithValue("@enrollmentbank", EnrollmentBank);
                    sqlcomm2.Parameters.AddWithValue("@Channel", channel);
                    sqlcomm2.Parameters.AddWithValue("@TerminalID", terminalID);
                    res = Convert.ToInt32(sqlcomm2.ExecuteScalar());

                    conn.Close();

                    if (res > 0)
                    {
                        string customerName = this.GetCustomerName(Convert.ToInt32(userID.Substring(0, 3)), Convert.ToInt32(userID.Substring(3, 6)));

                        string loginSessionID = PM.login();

                        if (!string.IsNullOrEmpty(loginSessionID))
                        {
                            NameValueCollection bvnvalues = new NameValueCollection();

                            bvnvalues.Add("nibsscode", "058");
                            bvnvalues.Add("bvn", BVN);
                            bvnvalues.Add("firstName", FirstName);
                            bvnvalues.Add("middleName", MiddleName);
                            bvnvalues.Add("lastName", LastName);
                            bvnvalues.Add("dateOfBirth", DateOfBirth);
                            bvnvalues.Add("phoneNumber", PhoneNumber);
                            bvnvalues.Add("registrationDate", RegistrationDate);
                            bvnvalues.Add("enrollmentBank", EnrollmentBank);
                            bvnvalues.Add("enrollmentBranch", EnrollmentBranch);
                            bvnvalues.Add("sign", sign);
                            bvnvalues.Add("bracode", userID.Substring(0, 3));
                            bvnvalues.Add("cusnum", userID.Substring(3, 6));
                            bvnvalues.Add("platformid", platformid);

                            ArrayList al = new ArrayList((object[])ConvertNameValueCollectionIntoArrayList(bvnvalues));
                            ParameterValue[] Params = ConvertNameValueCollectionIntoParams(al);
                            string caseid = PM.newCase(loginSessionID, Params);

                            if (!string.IsNullOrEmpty(caseid))
                            {
                                string[] caseidARR = caseid.Split('-');

                                string caseidNo = string.Empty;

                                if (caseidARR.GetLength(0) > 1)
                                {
                                    caseidNo = caseidARR[1];
                                }
                                else
                                {
                                    ErrHandler.WriteError("Error(PM caseID = " + caseid + ") Creating Case for Account : userID = " + userID + " || BVN = " + BVN + " || Response from NIBSS: " + piped_resp_from_NIBSS);
                                    return "<Response><CODE>1002</CODE><ERROR>An error occured while submitting your request, Please Try again.</ERROR></Response>";
                                }

                                string pmRoutCasResp = string.Empty;
                                pmRoutCasResp = PM.routeCase(loginSessionID, caseidNo, 1);

                                if (!string.IsNullOrEmpty(pmRoutCasResp))
                                {
                                    ErrHandler.WriteError("Successful for userID = " + userID + " || BVN = " + BVN + " || ProcessmakerRouteCase = " + pmRoutCasResp);
                                    return "<Response><CODE>1000</CODE><MESSAGE>Success</MESSAGE></Response>";
                                }
                                else
                                {
                                    ErrHandler.WriteError("Error(PM route case returned null value) Creating Case for Account: userID = " + userID + " || BVN = " + BVN + " || ProcessmakerRouteCase = " + pmRoutCasResp);
                                    return "<Response><CODE>1002</CODE><ERROR>An error occured while submitting your request, Please Try again.</ERROR></Response>";
                                }

                            }
                            else
                            {
                                ErrHandler.WriteError("Error(PM returned null caseID) Creating Case for Account : userID = " + userID + " || BVN = " + BVN + " || Response from NIBSS = " + piped_resp_from_NIBSS);
                                return "<Response><CODE>1002</CODE><ERROR>An error occured while submitting your request, Please Try again.</ERROR></Response>";
                            }
                        }
                        else
                        {
                            ErrHandler.WriteError("Error(Unable to login to PM) Creating Case for Account : userID = " + userID + " || BVN = " + BVN + " || Response from NIBSS = " + piped_resp_from_NIBSS);
                            return "<Response><CODE>1002</CODE><ERROR>An error occured while submitting your request, Please Try again.</ERROR></Response>";
                        }
                    }
                    else
                    {
                        ErrHandler.WriteError("Unable to insert into IbankBvnlinkdetails Table : userID = " + userID + " || BVN = " + BVN + " || Response from NIBSS = " + piped_resp_from_NIBSS);
                        return "<Response><CODE>1002</CODE><ERROR>An error occured while submitting your request, Please Try again.</ERROR></Response>";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrHandler.WriteError(ex.Message + "; " + ex.Source);
                return "<Response><CODE>1001</CODE><ERROR>Error occurred</ERROR></Response>";
            }
            finally
            {
                conn.Close();
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + "; " + ex.Source);
            return "<Response><CODE>1001</CODE><ERROR>Error occurred</ERROR></Response>";
        }
        return "<Response><CODE>1001</CODE><ERROR>An error occured while submitting your request, Please Try again.</ERROR></Response>";
    }

    private Array ConvertNameValueCollectionIntoArrayList(NameValueCollection nvcParams)
    {
        ArrayList aList = new ArrayList();
        string[] strNameValue = null;

        IEnumerator paramsEnum = nvcParams.GetEnumerator();

        int i = 0;
        while (paramsEnum.MoveNext())
        {
            string name = nvcParams.GetKey(i);
            string value = nvcParams[name];

            strNameValue = new string[2];
            strNameValue[0] = name;
            strNameValue[1] = value;

            aList.Add(strNameValue);
            i += 1;
        }
        return aList.ToArray();
    }

    private ParameterValue[] ConvertNameValueCollectionIntoParams(ArrayList nvp)
    {
        ParameterValue[] parameters = new ParameterValue[nvp.Count];
        for (int i = 0; i < nvp.Count; i++)
        {
            ParameterValue parameter = new ParameterValue();
            string[] strNameValuePair = (string[])nvp[i];
            parameter.Name = strNameValuePair[0];
            parameter.Value = strNameValuePair[1];
            parameters[i] = parameter;
        }
        return parameters;
    }

    public String ValidateAdminUsrOffSite(String id, String pswd, int appid, string ipAddress)
    {
        String result = null;
        String adserver = ConfigurationManager.AppSettings["ADServer"].ToString();


        adserver = "LDAP://" + adserver;
        DirectoryEntry Entry = new DirectoryEntry(adserver, id, pswd);

        DirectorySearcher Searcher = new DirectorySearcher(Entry);
        SearchResult result1;

        try
        {

            Searcher.Filter = ("(anr=" + id + ")");
            result1 = Searcher.FindOne();
            if (result1 != null)
            {
                result = ValidateAdminUsr(id, pswd, appid, ipAddress);
            }
            else
            {
                xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>User Does Not Exist</Error>";
                xmlstring = xmlstring + "</Response>";
                result = xmlstring;
            }
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + "Could not retrieve user details: " + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
            result = xmlstring;
        }

        return result;
    }

    public string GetLastLoginTime(String user_id, int appid)
    {
        string xmlstring = "<Response>";
        DateTime dtLastLoginDate = new DateTime();
        String strResponse = string.Empty;
        try
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                SqlCommand comm = new SqlCommand("proc_GetAppLastLoginDate", conn);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@User_ID", user_id);
                comm.Parameters.AddWithValue("@App_ID", appid);

                SqlDataReader reader = comm.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        dtLastLoginDate = reader["LastLoginDate"] == DBNull.Value ? dtLastLoginDate : Convert.ToDateTime(reader["LastLoginDate"]);
                    }
                }
                if (dtLastLoginDate.Date != DateTime.MinValue)
                {
                    strResponse = String.Format("{0} at {1}", dtLastLoginDate.Date.ToString("dd-MMM-yyyy"), dtLastLoginDate.ToString("h:mm:ss tt"));
                }

                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<LASTLOGINTIME>" + strResponse + "</LASTLOGINTIME>";
                xmlstring = xmlstring + "</Response>";
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Error retrieving last Login Time ==> " + ex.Message);
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + "Could not retrieve Last Login Time: " + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }
        return xmlstring;
    }

    public string BVNLinkerHelperOther(string userID, string BVN, string FirstName, string bankcode, string LastName, string PhoneNumber, string RegistrationDate, string EnrollmentBank, string channel, string nuban, string MiddleName, string DateOfBirth, string sign, string platformid, string EnrollmentBranch, string domainName, string ipAdd)
    {
        try
        {
            string piped_resp_from_NIBSS = BVN + " || " + userID + "/" + nuban + " || " + channel + " || " + FirstName + " || " + LastName + " || " + DateOfBirth + " || " + PhoneNumber + " || " + RegistrationDate + " || " + EnrollmentBank + " || " + EnrollmentBranch;

            ErrHandler.WriteError("Received BVN = " + BVN + " || userID/Nuban = " + userID + "/" + nuban + " || channel = " + channel);
            string customerID = string.Empty;
            int x = 0;
            Int64 y = 0;
            int res = 0;
            string terminalID = string.Empty;

            if (channel.ToUpper().Contains("ATM"))
            {
                string[] chanArr = channel.Split('_');

                if (chanArr.GetLength(0) == 2)
                {
                    channel = chanArr[0];
                    terminalID = chanArr[1];
                }
                else
                {
                    ErrHandler.WriteError("TerminalID is " + channel + ". For BVN = " + BVN);
                }
            }

            string chan = ConfigurationManager.AppSettings["BVN_Channel"];
            string[] channelArr = chan.Split(',');

            foreach (string arr in channelArr)
            {
                if (arr.ToUpper().Trim() == channel.ToUpper().Trim())
                {
                    x = 1;
                    break;
                }
            }

            if (x != 1)
            {
                ErrHandler.WriteError("Invalid channel, kindly check web config, BVN_Channel; " + userID);
                return "<Response><CODE>1001</CODE><ERROR>Invalid channel</ERROR></Response>";
            }

            if (BVN.Length != 11 || Int64.TryParse(BVN, out y) == false)
            {
                ErrHandler.WriteError("BVN is not valid, BVN must be 11 digits; " + BVN);
                return "<Response><CODE>1001</CODE><ERROR>BVN is not valid, BVN must be 11 digits.</ERROR></Response>";
            }

            if (userID.Length < 11 && nuban.Length != 10)
            {
                ErrHandler.WriteError("UserID or Nuban is not valid. Provide a valid userID or Nuban; " + userID + ";" + nuban);
                return "<Response><CODE>1001</CODE><ERROR>Account number is not valid.</ERROR></Response>";
            }

            if (userID.Length > 8)
            {
                if (userID.EndsWith("01") == false || Int64.TryParse(userID, out y) == false)
                {
                    ErrHandler.WriteError("UserID is not valid, userID should end with 01; " + userID);
                    return
                        "<Response><CODE>1001</CODE><ERROR>Account number is not valid.</ERROR></Response>";
                }
                customerID = userID.Substring(0, userID.Length - 2);
            }
            else
            {
                if (Int64.TryParse(nuban, out y) == false || nuban.Length != 10)
                {
                    ErrHandler.WriteError("Nuban account number is not valid; " + nuban);
                    return "<Response><CODE>1001</CODE><ERROR>Account number is not valid.</ERROR></Response>";
                }

                BASIS basis = new BASIS();
                string uID = basis.ConvertToOldAccountNumber(nuban);
                string[] uIDIDArr = uID.Split('/');

                if (uIDIDArr.GetLength(0) != 5)
                {
                    ErrHandler.WriteError("Nuban account number is not valid; " + nuban);
                    return "<Response><CODE>1001</CODE><ERROR>Account number is not valid.</ERROR></Response>";
                }

                userID = uIDIDArr[0] + uIDIDArr[1] + "01";
                customerID = uIDIDArr[0] + uIDIDArr[1];
            }

            SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["e_oneConnString"]);

            try
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();

                SqlCommand sqlcomm = new SqlCommand("SelectIbankBvnlinkdetails", conn)
                {
                    CommandType = CommandType.StoredProcedure
                };
                sqlcomm.Parameters.AddWithValue("@User_Id", userID);
                sqlcomm.Parameters.AddWithValue("@bvn", BVN);
                SqlDataReader reader = null;
                reader = sqlcomm.ExecuteReader(CommandBehavior.CloseConnection);

                if (reader.HasRows)
                {
                    DataTable dTable = new DataTable();
                    dTable.Load(reader);
                    reader.Close();

                    foreach (DataRow rw in dTable.Rows)
                    {
                        string bvnOnTable = rw["bvn"].ToString();

                        if (bvnOnTable.Trim() == BVN.Trim())
                        {
                            ErrHandler.WriteError("UserID and BVN are already linked on IbankBvnlinkdetails table; userID " + userID + " New BVN = " + BVN + " || BVN_on_IbankBvnlinkdetails = " + bvnOnTable);
                            return "<Response><CODE>1001</CODE><ERROR>This BVN already exists on your account.</ERROR></Response>";
                        }
                    }

                    ErrHandler.WriteError("UserID and BVN are already linked on IbankBvnlinkdetails table; userID " + userID + " BVN = " + BVN);
                    return
                        "<Response><CODE>1001</CODE><ERROR>A different BVN already exists on your account, kindly visit a nearest branch to validate your BVN.</ERROR></Response>";
                }

                reader.Close();

                if (conn.State == ConnectionState.Closed)
                    conn.Open();

                SqlCommand sqlcomm1 = new SqlCommand("SelectBioMetric", conn);
                sqlcomm1.CommandType = CommandType.StoredProcedure;
                sqlcomm1.Parameters.AddWithValue("@customerID", customerID);
                sqlcomm1.Parameters.AddWithValue("@bvn", BVN);
                SqlDataReader reader2 = null;
                reader2 = sqlcomm1.ExecuteReader(CommandBehavior.CloseConnection);

                if (reader2.HasRows)
                {
                    DataTable dTable = new DataTable();
                    dTable.Load(reader2);
                    reader2.Close();

                    foreach (DataRow rw in dTable.Rows)
                    {
                        string bvnOnTable = rw["bvn"].ToString();

                        if (bvnOnTable.Trim() == BVN.Trim())
                        {
                            ErrHandler.WriteError("UserID and BVN are already linked on BioMetric table; customerID " + customerID + " New BVN = " + BVN + " || BVN_on_BioMetric = " + bvnOnTable);
                            return "<Response><CODE>1001</CODE><ERROR>This BVN already exists on your account.</ERROR></Response>";
                        }
                    }

                    ErrHandler.WriteError("UserID and BVN are already linked on BioMetric table; customerID " + customerID + " || BVN = " + BVN);
                    return
                         "<Response><CODE>1001</CODE><ERROR>A different BVN already exists on your account, kindly visit a nearest branch to validate your BVN.</ERROR></Response>";
                }

                reader2.Close();

                using (SqlCommand sqlcomm2 = new SqlCommand("IBBvnlinkdetails_new", conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();

                    sqlcomm2.CommandType = CommandType.StoredProcedure;

                    sqlcomm2.Parameters.AddWithValue("@User_Id", userID);
                    sqlcomm2.Parameters.AddWithValue("@bvn", BVN);
                    sqlcomm2.Parameters.AddWithValue("@bankcode", bankcode);
                    sqlcomm2.Parameters.AddWithValue("@firstname", FirstName);
                    sqlcomm2.Parameters.AddWithValue("@lastname", LastName);
                    sqlcomm2.Parameters.AddWithValue("@phonenumber", PhoneNumber);
                    sqlcomm2.Parameters.AddWithValue("@registrationdate", RegistrationDate);
                    sqlcomm2.Parameters.AddWithValue("@enrollmentbank", EnrollmentBank);
                    sqlcomm2.Parameters.AddWithValue("@Channel", channel);
                    sqlcomm2.Parameters.AddWithValue("@TerminalID", terminalID);
                    sqlcomm2.Parameters.AddWithValue("@domain_name", domainName);
                    sqlcomm2.Parameters.AddWithValue("@ipaddress", ipAdd);
                    res = Convert.ToInt32(sqlcomm2.ExecuteScalar());

                    conn.Close();

                    if (res > 0)
                    {
                        string customerName = this.GetCustomerName(Convert.ToInt32(userID.Substring(0, 3)), Convert.ToInt32(userID.Substring(3, 6)));

                        string loginSessionID = PM.login();

                        if (!string.IsNullOrEmpty(loginSessionID))
                        {
                            NameValueCollection bvnvalues = new NameValueCollection();

                            bvnvalues.Add("nibsscode", "058");
                            bvnvalues.Add("bvn", BVN);
                            bvnvalues.Add("firstName", FirstName);
                            bvnvalues.Add("middleName", MiddleName);
                            bvnvalues.Add("lastName", LastName);
                            bvnvalues.Add("dateOfBirth", DateOfBirth);
                            bvnvalues.Add("phoneNumber", PhoneNumber);
                            bvnvalues.Add("registrationDate", RegistrationDate);
                            bvnvalues.Add("enrollmentBank", EnrollmentBank);
                            bvnvalues.Add("enrollmentBranch", EnrollmentBranch);
                            bvnvalues.Add("sign", sign);
                            bvnvalues.Add("bracode", userID.Substring(0, 3));
                            bvnvalues.Add("cusnum", userID.Substring(3, 6));
                            bvnvalues.Add("platformid", platformid);

                            ArrayList al = new ArrayList((object[])ConvertNameValueCollectionIntoArrayList(bvnvalues));
                            ParameterValue[] Params = ConvertNameValueCollectionIntoParams(al);
                            string caseid = PM.newCase(loginSessionID, Params);

                            if (!string.IsNullOrEmpty(caseid))
                            {
                                string[] caseidARR = caseid.Split('-');

                                string caseidNo = string.Empty;

                                if (caseidARR.GetLength(0) > 1)
                                {
                                    caseidNo = caseidARR[1];
                                }
                                else
                                {
                                    ErrHandler.WriteError("Error(PM caseID = " + caseid + ") Creating Case for Account : userID = " + userID + " || BVN = " + BVN + " || Response from NIBSS: " + piped_resp_from_NIBSS);
                                    return "<Response><CODE>1002</CODE><ERROR>An error occured while submitting your request, Please Try again.</ERROR></Response>";
                                }

                                string pmRoutCasResp = string.Empty;
                                pmRoutCasResp = PM.routeCase(loginSessionID, caseidNo, 1);

                                if (!string.IsNullOrEmpty(pmRoutCasResp))
                                {
                                    ErrHandler.WriteError("Successful for userID = " + userID + " || BVN = " + BVN + " || ProcessmakerRouteCase = " + pmRoutCasResp);
                                    return "<Response><CODE>1000</CODE><MESSAGE>Success</MESSAGE></Response>";
                                }
                                else
                                {
                                    ErrHandler.WriteError("Error(PM route case returned null value) Creating Case for Account: userID = " + userID + " || BVN = " + BVN + " || ProcessmakerRouteCase = " + pmRoutCasResp);
                                    return "<Response><CODE>1002</CODE><ERROR>An error occured while submitting your request, Please Try again.</ERROR></Response>";
                                }

                            }
                            else
                            {
                                ErrHandler.WriteError("Error(PM returned null caseID) Creating Case for Account : userID = " + userID + " || BVN = " + BVN + " || Response from NIBSS = " + piped_resp_from_NIBSS);
                                return "<Response><CODE>1002</CODE><ERROR>An error occured while submitting your request, Please Try again.</ERROR></Response>";
                            }
                        }
                        else
                        {
                            ErrHandler.WriteError("Error(Unable to login to PM) Creating Case for Account : userID = " + userID + " || BVN = " + BVN + " || Response from NIBSS = " + piped_resp_from_NIBSS);
                            return "<Response><CODE>1002</CODE><ERROR>An error occured while submitting your request, Please Try again.</ERROR></Response>";
                        }
                    }
                    else
                    {
                        ErrHandler.WriteError("Unable to insert into IbankBvnlinkdetails Table : userID = " + userID + " || BVN = " + BVN + " || Response from NIBSS = " + piped_resp_from_NIBSS);
                        return "<Response><CODE>1002</CODE><ERROR>An error occured while submitting your request, Please Try again.</ERROR></Response>";
                    }
                }
            }
            catch (Exception ex)
            {
                ErrHandler.WriteError(ex.Message + "; " + ex.Source);
                return "<Response><CODE>1001</CODE><ERROR>Error occurred</ERROR></Response>";
            }
            finally
            {
                conn.Close();
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + "; " + ex.Source);
            return "<Response><CODE>1001</CODE><ERROR>Error occurred</ERROR></Response>";
        }
        return "<Response><CODE>1001</CODE><ERROR>An error occured while submitting your request, Please Try again.</ERROR></Response>";
    }

    public int GTGuardEnableIntlTrx(string pPAN, string pExpiry, string pAction)
    {
        ErrHandler err = new ErrHandler();
        int functionReturnValue = 0;
        SqlCommand sqlSelect = new SqlCommand();
        Random RandomNo = new Random();
        SqlParameter pmPAN = new SqlParameter("@PAN", pPAN);
        SqlParameter pmExpiry = new SqlParameter("@ExpiryDate", pExpiry);
        SqlParameter pmAction = new SqlParameter("@Action", pAction);
        //    SqlParameter pmChannel = new SqlParameter("@Channel", pchannel);


        string errStr = null;
        int mResponse = 0;
        string Sql = "";
        SqlConnection ConPostcard = new SqlConnection(ConfigurationManager.AppSettings["CnnPostcard"].ToString());
        try
        {
            sqlSelect.Parameters.Add(pmPAN);
            sqlSelect.Parameters.Add(pmExpiry);
            sqlSelect.Parameters.Add(pmAction);
            //  sqlSelect.Parameters.Add(pmChannel);
            if (ConPostcard.State == ConnectionState.Closed)
            {
                ConPostcard.Open();
            }
            // row's index.
            sqlSelect.Connection = ConPostcard;
            sqlSelect.CommandText = "dbo.GTB_GTGuardEnableIntlTrx";
            sqlSelect.CommandType = CommandType.StoredProcedure;
            functionReturnValue = (int)sqlSelect.ExecuteScalar();

        }
        catch (Exception ex)
        {

            ErrHandler.WriteError("Stack Trace: " + ex.StackTrace + " Message: " + ex.Message + " Source:" + ex.Source);

            errStr = ex.Message;

            functionReturnValue = 7;

        }
        finally
        {
            if (ConPostcard.State == ConnectionState.Open)
            {
                ConPostcard.Close();
            }
        }
        return functionReturnValue;
    }

    public string GTGuardCardStatus(string pPAN, string pExpiry)
    {
        string result = "";
        SqlConnection conn;
        SqlCommand comm;
        DataTable ds = new DataTable();
        SqlDataAdapter adpt;
        ds.TableName = "CardStatus";
        try
        {
            using (conn = new SqlConnection(ConfigurationManager.AppSettings["CnnPostcard"].ToString()))
            {

                //open connetion
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                string query = "dbo.GTB_GTGuardGetStatus";

                comm = new SqlCommand(query, conn);
                comm.Parameters.AddWithValue("@PAN", pPAN);
                comm.Parameters.AddWithValue("@ExpiryDate", pExpiry.Substring(2) + pExpiry.Substring(0, 2));
                comm.CommandType = CommandType.StoredProcedure;

                result = comm.ExecuteScalar().ToString();
                //adpt = new SqlDataAdapter(comm);

                //adpt.Fill(ds);
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Get Card Status for GTGuard Error : " + ex.Message);
        }

        return result;
    }

    public string LocalTransfer_ATM(string benNUBAN, double amount, double charge, double vat, string acctToDebitTransfer, int expl_Code, string transRef, string chargeAcc, int expl_Code_charge, int expl_Code_Vat, string vatAcc, double vatAmount, string exemptCharge)
    {
        try
        {
            string fullAcctNum = string.Empty;
            string fullAccNo = string.Empty;
            string code = string.Empty;
            string debitCharge = string.Empty;
            string debitResul = string.Empty;
            string staCode = string.Empty;
            string debitChargeVAT = string.Empty;
            string retrnStaCode = string.Empty;
            DataSet resultDataSet = new DataSet();
            int countTable = 0;
            DataTable tResult = new DataTable();
            int cTab = 0;
            string typeofDep = string.Empty;
            bool xempt = false;
            XmlDocument document = default(XmlDocument);
            XPathNavigator navigator = default(XPathNavigator);
            XPathNodeIterator snodes = default(XPathNodeIterator);
            string[] arrExemptCharge = exemptCharge.Split(',');

            BASIS callBasis = new BASIS();

            fullAcctNum = callBasis.NubanToOldAcct(benNUBAN);
            fullAccNo = XmlReader(fullAcctNum);

            if (fullAccNo.Length > 15)
            {
                string[] arrayAcc = fullAccNo.Split('/');
                string[] arrayacctToDebitTransfer = acctToDebitTransfer.Split('/');

                if (arrayAcc.GetLength(0) != 5)
                {
                    return "1100";
                }

                string querytypeofdep = GTBEncryptLibrary.GTBEncryptLib.EncryptText("select type_of_dep from account where bra_code = " + arrayacctToDebitTransfer[0] + " and cus_num = " + arrayacctToDebitTransfer[1] + " and cur_code = " + arrayacctToDebitTransfer[2] + " and led_code = " + arrayacctToDebitTransfer[3] + " and sub_acct_code = " + arrayacctToDebitTransfer[4]);

                resultDataSet = callBasis.ExecuteBasisQuery(querytypeofdep, 1);
                countTable = resultDataSet.Tables.Count;

                if (countTable > 0)
                {
                    tResult = resultDataSet.Tables[0];
                    cTab = tResult.Rows.Count;
                    if (cTab > 0)
                    {
                        typeofDep = tResult.Rows[0]["type_of_dep"].ToString();
                    }
                }

                foreach (string item in arrExemptCharge)
                {
                    if (item == typeofDep)
                    {
                        xempt = true;
                        break;
                    }
                }

                if (xempt == false)
                {
                    string availBalResult = GetAccountBalance(Convert.ToInt32(arrayacctToDebitTransfer[0]), Convert.ToInt32(arrayacctToDebitTransfer[1]), Convert.ToInt32(arrayacctToDebitTransfer[2]), Convert.ToInt32(arrayacctToDebitTransfer[3]), Convert.ToInt32(arrayacctToDebitTransfer[4]));
                    document = new XmlDocument();
                    document.LoadXml(availBalResult);
                    navigator = document.CreateNavigator();
                    snodes = navigator.Select("/Response/AVAILABLEBALANCE");
                    snodes.MoveNext();
                    string availBal = snodes.Current.Value;

                    if (Convert.ToDouble(availBal) >= amount + charge + vat)
                    {
                        debitResul = TransferFunds3(acctToDebitTransfer, fullAccNo, amount, "ANY", "ATMNIP", expl_Code, "ATM Local Transfer " + transRef);

                        ErrHandler.WriteError("ATMNIP_LOCAL acctToDebit = " + acctToDebitTransfer + " || acctToCredit = " + fullAccNo + " || amount = " + amount + " || EXPLCODE = " + expl_Code + " || GTBTECHAPPDEVRESPONSE = " + debitResul);
                        document = new XmlDocument();
                        document.LoadXml(debitResul);
                        navigator = document.CreateNavigator();
                        snodes = navigator.Select("/Response/CODE");
                        snodes.MoveNext();
                        code = snodes.Current.Value;

                        if (code == "1000")
                        {
                            try
                            {
                                debitCharge = TransferFunds3(acctToDebitTransfer, chargeAcc, charge, "ANY", "ATMNIP", expl_Code_charge, "Commission on ATM Local Transfer " + transRef);
                                debitChargeVAT = TransferFunds3(acctToDebitTransfer, vatAcc, vatAmount, "ANY", "ATMNIP", expl_Code_Vat, "VAT on ATM Local Transfer " + transRef);
                                ErrHandler.WriteError("ATMNIP_LOCAL Transfer || Result of Commission and VAT || AccountToDebit = " + acctToDebitTransfer + " || debitCharge =" + debitCharge + " || debitChargeVAT =" + debitChargeVAT);
                            }
                            catch (Exception ex)
                            {
                                ErrHandler.WriteError("ATMNIP_LOCAL Transfer || Could not take Commission or VAT || AccountToDebit = " + acctToDebitTransfer + " || debitCharge =" + debitCharge + " || debitChargeVAT =" + debitChargeVAT + " || " + ex.Message);
                            }

                            return code;
                        }
                        else
                        {
                            snodes = navigator.Select("/Response/ERROR");
                            snodes.MoveNext();
                            retrnStaCode = snodes.Current.Value;

                            string[] splitResCode = retrnStaCode.Split(':');
                            if (splitResCode.GetLength(0) == 2 && code != "1099")
                            {
                                staCode = splitResCode[1];
                            }
                            else
                                staCode = "Unknown Error.";

                            return staCode;
                        }
                    }
                    else
                    {
                        ErrHandler.WriteError("ATMNIP_LOCAL transfer request  with refNo: " + transRef + "%%% BenNuban: " + benNUBAN + " %%% acctToDebit:" + acctToDebitTransfer + " Available Balance: " + availBal + " Total transaction amount is greater than available balance.");
                        return "1110";
                    }
                }
                else
                {
                    debitResul = TransferFunds3(acctToDebitTransfer, fullAccNo, amount, "ANY", "ATMNIP", expl_Code, "ATM Local Transfer " + transRef);

                    ErrHandler.WriteError("ATMNIP_LOCAL || The Customer is charge Exempt.|| acctToDebit = " + acctToDebitTransfer + " || acctToCredit = " + fullAccNo + " || amount = " + amount + " || EXPLCODE = " + expl_Code + " || GTBTECHAPPDEVRESPONSE = " + debitResul);
                    document = new XmlDocument();
                    document.LoadXml(debitResul);
                    navigator = document.CreateNavigator();
                    snodes = navigator.Select("/Response/CODE");
                    snodes.MoveNext();
                    code = snodes.Current.Value;

                    if (code == "1000")
                    {
                        snodes = navigator.Select("/Response/MESSAGE");
                        snodes.MoveNext();
                        staCode = snodes.Current.Value;
                        return code;
                    }
                    else
                    {
                        snodes = navigator.Select("/Response/ERROR");
                        snodes.MoveNext();
                        retrnStaCode = snodes.Current.Value;

                        string[] splitResCode = retrnStaCode.Split(':');
                        if (splitResCode.GetLength(0) == 2 && code != "1099")
                        {
                            staCode = splitResCode[1];
                        }
                        else
                            staCode = "Unknown Error.";

                        return staCode;
                    }
                }
            }
            else
                return "1100";

        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("ATMNIP_LOCAL transfer Global Error || " + ex.Message);
            return "Unknown Error";
        }
    }

    public string XmlReader(string xml)
    {
        XmlDocument document = default(XmlDocument);
        XPathNavigator navigator = default(XPathNavigator);
        XPathNodeIterator snodes = default(XPathNodeIterator);

        document = new XmlDocument();
        document.LoadXml(xml);
        navigator = document.CreateNavigator();
        snodes = navigator.Select("/Response/CODE");
        snodes.MoveNext();
        string code = snodes.Current.Value;
        string result = "00";

        if (code == "1000")
        {
            snodes = navigator.Select("/Response/MESSAGE");
            snodes.MoveNext();
            return result = snodes.Current.Value;
        }
        else
        {
            return result;
        }
    }


    public DataSet SelectSMSBankingMenus()
    {
        DataSet dsResult = new DataSet();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {
                if (sqlConn.State == ConnectionState.Closed)
                {
                    sqlConn.Open();
                }
                SqlCommand sqlComm = new SqlCommand("proc_SelectSMSBankingMenus", sqlConn);
                SqlDataAdapter adpt = new SqlDataAdapter(sqlComm);

                adpt.Fill(dsResult);
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(string.Format("Error while selecting SMS Banking Menus ==> {0}. Stack Trace ==> {1}", ex.Message, ex.StackTrace));
        }
        return dsResult;
    }


    public ServiceResponse ProfileSMSBankingMenu(string syntax, string menuName, string menuDesc, int flag, int action, Int64 sNo)
    {
        ServiceResponse resp = new ServiceResponse();
        try
        {
            //Check if the menu exists 
            if (action == 1)
            {
                if (doesSMSBankingMenuExist(syntax, menuName))
                {
                    resp.Code = 1002;
                    resp.Response = "Menu already exists!, Select from grid to update";
                    return resp;
                }
            }
            else if (action == 2)
            {
                if (sNo <= 0)
                {
                    resp.Code = 1003;
                    resp.Response = "ID not provided!";
                    return resp;
                }
            }

            using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {

                if (sqlConn.State == ConnectionState.Closed)
                {
                    sqlConn.Open();
                }

                SqlCommand sqlComm = new SqlCommand("proc_ProfileSMSBankingMenu", sqlConn);
                sqlComm.CommandType = CommandType.StoredProcedure;
                sqlComm.Parameters.AddWithValue("@Syntax", syntax);
                sqlComm.Parameters.AddWithValue("@Menu_Name", menuName);
                sqlComm.Parameters.AddWithValue("@Menu_Desc", menuDesc);
                sqlComm.Parameters.AddWithValue("@flag", flag);
                sqlComm.Parameters.AddWithValue("@action", action);
                sqlComm.Parameters.AddWithValue("@Sno", sNo);


                if (sqlComm.ExecuteScalar() == DBNull.Value)
                {
                    resp.Code = 1004;
                    resp.Response = "0";
                }
                else
                {
                    resp.Code = 1000;
                    resp.Response = Convert.ToInt64(sqlComm.ExecuteScalar()).ToString();
                }

            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(string.Format("Error while profiling SMS Banking Menus ==> {0}. Stack Trace ==> {1}", ex.Message, ex.StackTrace));
            resp.Code = 2000;
            resp.Response = "System Error has occured! Please contact your administrator";
        }
        return resp;
    }

    bool doesSMSBankingMenuExist(string syntax, string menuName)
    {
        bool resp = false;
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {
                if (sqlConn.State == ConnectionState.Closed)
                {
                    sqlConn.Open();
                }
                SqlCommand sqlComm = new SqlCommand("proc_SelectSMSBankingMenu", sqlConn);
                sqlComm.CommandType = CommandType.StoredProcedure;

                sqlComm.Parameters.AddWithValue("@Syntax", syntax);
                sqlComm.Parameters.AddWithValue("@Menu_Name", menuName);

                SqlDataReader reader = sqlComm.ExecuteReader();

                resp = reader.HasRows == true ? true : false;
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(string.Format("Error while checking if SMS Banking exists ==> {0}. Stack Trace ==> {1}", ex.Message, ex.StackTrace));
            throw;
        }
        return resp;
    }

    public String CreateSpend2Save(String strRequest)
    {
        string Result = string.Empty;
        SqlCommand cmd;
        SqlConnection conn;
        SqlDataAdapter ora_adpt;
        DataSet dt;
        int acct_count = 0;
        String acct_result = String.Empty;
        String query_str = String.Empty;
        String response = String.Empty;

        xmlstring = "<Response>";

        //strRequest = "<CreateSpend2SaveRequest><UserId>20515462801</UserId><BraCode>205</BraCode><CusNum>154628</CusNum><ExtFlag>STS</ExtFlag><CurCode>1</CurCode><opertype>0</opertype><Accounts><Account><AccountKey>205/154628/1/1/0</AccountKey><SavePercent>3</SavePercent></Account><Account><AccountKey>205/154628/1/59/0</AccountKey><SavePercent>4</SavePercent></Account></Accounts></CreateSpend2SaveRequest>";
        DataSet ds = new DataSet();

        try
        {
            using (conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                //conn.Open();

                StringReader strRd = new StringReader(strRequest);
               
                ds.ReadXml(strRd);
            }

            if (ds != null && ds.Tables.Count > 0)
            {

                // retrieve user_id
                String userid = ds.Tables[0].Rows[0]["UserID"].ToString();

                String extflag = ds.Tables[0].Rows[0]["ExtFlag"].ToString();
                int bracode = Convert.ToInt32(ds.Tables[0].Rows[0]["BraCode"]);
                int cusnum = Convert.ToInt32(ds.Tables[0].Rows[0]["CusNum"]);
                int curcode = Convert.ToInt32(ds.Tables[0].Rows[0]["CurCode"]);
                int ledcode = Convert.ToInt32(ConfigurationManager.AppSettings["SPEND2SAVELEDGER"]);
                int opertype = Convert.ToInt32(ds.Tables[0].Rows[0]["opertype"]);

                ErrHandler.WriteError("CreateSpend2Save started for user " + userid);

                //Convert loop through the account list
                if (ds.Tables["Account"].Rows.Count > 0)
                {
                    //Open Spend2Save account if account is not  already opened.
                    query_str = "select sub_acct_code from account where bra_code=" + bracode.ToString() + " and cus_num=" + cusnum.ToString() + " and cur_code=" + curcode.ToString() + " and led_code=" + ledcode.ToString();

                    OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
                    OracleCommand cmd_acct = new OracleCommand(query_str, oraconn);
                    oraconn.Open();
                    OracleDataReader reader;

                    // execute the function
                    reader = cmd_acct.ExecuteReader();
                    if (reader.HasRows == true)
                    {
                        reader.Read();
                        acct_result = reader["sub_acct_code"].ToString();
                    }
                    else
                    {
                        acct_result = OpenAdditionalAccount(bracode, cusnum, ledcode, curcode);

                        //Get sub account code

                        //acct_result = "<Response><CODE>1000</CODE><MESSAGE>SUCCESS</MESSAGE><LedgerCode>5033</LedgerCode><SubAccountCode>0</SubAccountCode></Response>";

                        XmlDocument document = null;
                        XPathNavigator navigator = null;
                        XPathNodeIterator snodes = null;
                        XPathNavigator node1 = null;
                        String retcode = null;

                        document = new XmlDocument();
                        document.LoadXml(acct_result);
                        navigator = document.CreateNavigator();

                        snodes = navigator.Select("/Response/CODE");
                        snodes.MoveNext();

                        if (snodes.Current.Value == "1000")
                        {
                            snodes = navigator.Select("/Response/SubAccountCode");
                            snodes.MoveNext();
                            acct_result = snodes.Current.Value;

                            string acctfullkey1 = Convert.ToString(bracode) + "/" + Convert.ToString(cusnum) + "/" + Convert.ToString(curcode) + "/" + Convert.ToString(ledcode) + "/" + acct_result;
                            int profile = ProfileCustomerAccountEone(Convert.ToInt64(userid), cusnum, bracode, curcode, ledcode, Convert.ToInt32(acct_result), acctfullkey1, extflag);

                            ErrHandler.WriteError("Profile response:" + profile);

                        }
                        else
                        {
                            ErrHandler.WriteError("Error checking if Spend2Save account already exist for " + userid);
                            xmlstring = xmlstring + "<CODE>1002</CODE>";
                            xmlstring = xmlstring + "<Error>" + "Unable to create SpendtoSave Account" + "</Error>";
                            xmlstring = xmlstring + "</Response>";

                            return xmlstring;
                        }

                    }



                    reader = null;
                    cmd_acct = null;
                    oraconn.Close();
                    oraconn = null;



                    foreach (DataRow dr in ds.Tables["Account"].Rows)
                    {

                        try
                        {


                            string acct1 = dr["AccountKey"].ToString();
                            string[] acctkey1 = acct1.Split('/');
                            int bracode1 = Convert.ToInt32(acctkey1[0]);
                            int cusnum1 = Convert.ToInt32(acctkey1[1]);
                            int curcode1 = Convert.ToInt32(acctkey1[2]);
                            int ledcode1 = Convert.ToInt32(acctkey1[3]);
                            int subacctcode1 = Convert.ToInt32(acctkey1[4]);



                            string basisresponse = InsertSpendToSaveDEtailsOnBasis(bracode1, cusnum1, curcode1, ledcode1, subacctcode1, Convert.ToDecimal(dr["SavePercent"]), opertype);

                            XmlDocument document = null;
                            XPathNavigator navigator = null;
                            XPathNodeIterator snodes = null;
                            XPathNavigator node1 = null;
                            String retcode = null;

                            document = new XmlDocument();
                            document.LoadXml(basisresponse);
                            navigator = document.CreateNavigator();

                            snodes = navigator.Select("/Response/CODE");
                            snodes.MoveNext();

                            if (snodes.Current.Value == "1000")
                            {

                                basisresponse = snodes.Current.Value;

                                ErrHandler.WriteError("CreateSpend2Save on basis successful for user " + userid + " and account " + dr["AccountKey"].ToString() + ": " + basisresponse);
                            }
                            else
                            {
                                //ErrHandler.WriteError("CreateSpend2Save on basis Failed for user " + userid + " and account " + dr["AccountKey"].ToString() + ": " + basisresponse);
                                //xmlstring = xmlstring + "<CODE>1002</CODE>";
                                //xmlstring = xmlstring + "<Error>" + "Error saving Spend2Save account details: " + "</Error>";
                                //xmlstring = xmlstring + "</Response>";
                                //return xmlstring;
                                return basisresponse;

                            }

                            dt = new DataSet();
                            cmd = new SqlCommand("CreateSpend2Save", conn);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@userID", Convert.ToInt64(userid));
                            cmd.Parameters.AddWithValue("@accountkey", dr["AccountKey"].ToString());
                            cmd.Parameters.AddWithValue("@spendpercent", Convert.ToDecimal(dr["SavePercent"]));

                            ora_adpt = new SqlDataAdapter(cmd);

                            ora_adpt.Fill(dt);

                            dt = null;
                            ora_adpt = null;
                            cmd = null;

                        }
                        catch (Exception ex1)
                        {
                            //log the error
                            ErrHandler.WriteError("CreateSpend2Save Failed for user " + userid + " and account " + dr["AccountKey"].ToString() + ": " + ex1.Message);
                        }

                    }
                }


                ErrHandler.WriteError("CreateSpend2Save completed for user " + userid);
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "<SubAcctCode>" + acct_result + "</SubAcctCode>";
                xmlstring = xmlstring + "<LedgerCode>" + ledcode.ToString() + "</LedgerCode>";
                xmlstring = xmlstring + "</Response>";
            }
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + "Exception on CreateSpend2Save: " + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
            return xmlstring;
        }


        return xmlstring;
    }

    public String CancelSpend2Save(String strRequest)
    {
        string Result = string.Empty;
        SqlCommand cmd;
        SqlConnection conn;
        SqlDataAdapter ora_adpt;
        DataSet dt;
        String ipstr = "";
        DataSet ds = new DataSet();
        String query_str = null;

        //strRequest = "<CancelSpend2SaveRequest><UserId>20513933601</UserId><BraCode>205</BraCode><CusNum>139336</CusNum><CurCode>1</CurCode><opertype>2</opertype><Accounts><Account><AccountKey>205/139336/1/1/0</AccountKey><SavePercent>3.5</SavePercent></Account></Accounts></CancelSpend2SaveRequest>";
        xmlstring = "<Response>";

        try
        {
            using (conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {

                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                StringReader strRd = new StringReader(strRequest);
                
                ds.ReadXml(strRd);
            }

            if (ds != null && ds.Tables.Count > 0)
            {
                // retrieve user_id
                String userid = ds.Tables[0].Rows[0]["UserID"].ToString();
                int opertype = Convert.ToInt32(ds.Tables[0].Rows[0]["opertype"]);


                ErrHandler.WriteError("CancelSpend2Save Started for user " + userid);

                //Convert loop through the account list
                foreach (DataRow dr in ds.Tables["Account"].Rows)
                {

                    try
                    {
                        //string acctKey = dr["AccountKey"].ToString();
                        string acct1 = dr["AccountKey"].ToString();
                        string[] acctkey1 = acct1.Split('/');
                        int bracode1 = Convert.ToInt32(acctkey1[0]);
                        int cusnum1 = Convert.ToInt32(acctkey1[1]);
                        int curcode1 = Convert.ToInt32(acctkey1[2]);
                        int ledcode1 = Convert.ToInt32(acctkey1[3]);
                        int subacctcode1 = Convert.ToInt32(acctkey1[4]);

                        string basisresponse = InsertSpendToSaveDEtailsOnBasis(bracode1, cusnum1, curcode1, ledcode1, subacctcode1, Convert.ToDecimal(dr["SavePercent"]), opertype);

                        XmlDocument document = null;
                        XPathNavigator navigator = null;
                        XPathNodeIterator snodes = null;
                        XPathNavigator node1 = null;
                        String retcode = null;

                        document = new XmlDocument();
                        document.LoadXml(basisresponse);
                        navigator = document.CreateNavigator();

                        snodes = navigator.Select("/Response/CODE");
                        snodes.MoveNext();

                        if (snodes.Current.Value == "1000")
                        {

                            basisresponse = snodes.Current.Value;

                            ErrHandler.WriteError("CancelSpend2Save on basis successful for user " + userid + " and account " + dr["AccountKey"].ToString() + ": " + basisresponse);
                        }
                        else
                        {
                            ErrHandler.WriteError("CancelSpend2Save on basis Failed for user " + userid + " and account " + dr["AccountKey"].ToString() + ": " + basisresponse);
                            xmlstring = xmlstring + "<CODE>1002</CODE>";
                            xmlstring = xmlstring + "<Error>" + "Error cancelling Spend2Save account details: " + "</Error>";
                            xmlstring = xmlstring + "</Response>";

                            return xmlstring;
                        }

                        dt = new DataSet();
                        cmd = new SqlCommand("CancelSpend2Save", conn);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@userID", Convert.ToInt64(userid));
                        cmd.Parameters.AddWithValue("@accountkey", acct1);

                        ora_adpt = new SqlDataAdapter(cmd);

                        ora_adpt.Fill(dt);

                        dt = null;
                        ora_adpt = null;
                        cmd = null;
                    }
                    catch (Exception ex1)
                    {
                        //log the error
                        ErrHandler.WriteError("CancelSpend2Save Failed for user " + userid + " and account " + dr["AccountKey"].ToString() + ": " + ex1.Message);
                    }

                }

                ErrHandler.WriteError("CancelSpend2Save Completed for user " + userid);
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";

                xmlstring = xmlstring + "</Response>";
            }
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + "Exception on CancelSpend2Save: " + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String OpenAdditionalAccount(int bracode, int cusnum, int ledcode, int curcode)
    {
        String Result = String.Empty;
        string SubAcctCode = String.Empty;
        string xmlstring1 = "<Response>";

        try
        {

            using (OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
            {
                ErrHandler.WriteError("About to open additional account for customer " + bracode.ToString() + cusnum.ToString() + " with ledger " + ledcode.ToString());
                OracleTransaction transaction;
                if (oraconn.State == ConnectionState.Closed)
                {
                    oraconn.Open();
                }
                //transaction = oraconn.BeginTransaction(IsolationLevel.ReadCommitted);

                try
                {
                    OracleCommand oracomm = oraconn.CreateCommand();
                    oracomm.CommandType = CommandType.StoredProcedure;
                    oracomm.CommandTimeout = 60;
                    //Start a local transaction and assign transaction object for a pending local transaction                
                    //oracomm.Transaction = transaction;
                    oracomm.CommandText = "eonepkg.gtbcir30";

                    oracomm.Parameters.Add("INP_BRA_CODE", OracleType.Int16, 15).Value = bracode;
                    oracomm.Parameters.Add("INP_CUS_NUM", OracleType.Int32, 15).Value = cusnum;
                    oracomm.Parameters.Add("INP_TELL_ID", OracleType.Double, 15).Value = 9938;
                    oracomm.Parameters.Add("INP_LED_CODE", OracleType.Int16, 15).Value = ledcode;
                    oracomm.Parameters.Add("INP_CUR_CODE", OracleType.Int16, 15).Value = curcode;
                    oracomm.Parameters.Add("OUT_SUB_ACCT_CODE", OracleType.Int16, 15).Direction = ParameterDirection.Output;
                    oracomm.Parameters.Add("OERR_FLAG", OracleType.Int16, 15).Direction = ParameterDirection.Output;

                    //oracomm.Parameters.Add("OERR_FLAG", OracleDbType.Int16, 15).Direction = ParameterDirection.Output

                    oracomm.ExecuteNonQuery();
                    Result = oracomm.Parameters["OERR_FLAG"].Value.ToString();

                    if (Result.Trim().CompareTo("0") == 0)
                    {
                        SubAcctCode = oracomm.Parameters["OUT_SUB_ACCT_CODE"].Value.ToString();
                        ErrHandler.WriteError("Aditional account opened successfully for customer " + bracode.ToString() + cusnum.ToString());
                        xmlstring1 = xmlstring1 + "<CODE>1000</CODE>";
                        xmlstring1 = xmlstring1 + "<MESSAGE>SUCCESS</MESSAGE>";
                        xmlstring1 = xmlstring1 + "<SubAccountCode>" + SubAcctCode + "</SubAccountCode>";

                    }
                    else
                    {
                        xmlstring1 = "<Response>";
                        xmlstring1 = xmlstring1 + "<CODE>1002</CODE>";
                        xmlstring1 = xmlstring1 + "<Error>Additional account could not be opened. Please try again later</Error>";
                        xmlstring1 = xmlstring1 + "</Response>";

                    }
                }
                catch (Exception ex1)
                {
                    xmlstring1 = "<Response>";
                    xmlstring1 = xmlstring1 + "<CODE>1004</CODE>";
                    xmlstring1 = xmlstring1 + "<Error>Exception on Additional account opening: " + ex1.Message + "</Error>";
                    xmlstring1 = xmlstring1 + "</Response>";

                }
                finally
                {
                    oraconn.Close();
                }
            }


            xmlstring1 = xmlstring1 + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring1 = "<Response>";
            xmlstring1 = xmlstring1 + "<CODE>1004</CODE>";
            xmlstring1 = xmlstring1 + "<Error>Exception on Additional account opening: " + ex.Message + "</Error>";
            xmlstring1 = xmlstring1 + "</Response>";
            return xmlstring1;
        }

        return xmlstring1;
    }


    public string InsertSpendToSaveDEtailsOnBasis(int bracode, int cusnum, int curcode, int ledcode, int subacctcode, decimal savepercent, int opertype)
    {
        String Result = String.Empty;
        string xmlstring1 = "<Response>";

        try
        {



            using (OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
            {
                ErrHandler.WriteError("About to update GTBSpend2Save table on basis " + bracode.ToString() + cusnum.ToString() + " with ledger " + ledcode.ToString());
                OracleTransaction transaction;
                if (oraconn.State == ConnectionState.Closed)
                {
                    oraconn.Open();
                }
                //transaction = oraconn.BeginTransaction(IsolationLevel.ReadCommitted);

                try
                {
                    OracleCommand oracomm = oraconn.CreateCommand();
                    oracomm.CommandType = CommandType.StoredProcedure;
                    oracomm.CommandTimeout = 60;
                    //Start a local transaction and assign transaction object for a pending local transaction                
                    //oracomm.Transaction = transaction;
                    oracomm.CommandText = "EONEPKG.ADD_PIGGYSAVER";

                    oracomm.Parameters.Add("INP_BRA_CODE", OracleType.Int16, 15).Value = bracode;
                    oracomm.Parameters.Add("INP_CUS_NUM", OracleType.Int32, 15).Value = cusnum;
                    oracomm.Parameters.Add("INP_CUR_CODE", OracleType.Int16, 15).Value = curcode;
                    oracomm.Parameters.Add("INP_LED_CODE", OracleType.Int16, 15).Value = ledcode;
                    oracomm.Parameters.Add("INP_SUB_ACCT_CODE", OracleType.Int16, 15).Value = subacctcode;
                    oracomm.Parameters.Add("INP_SAVEPERCENT", OracleType.Double, 20).Value = savepercent;
                    oracomm.Parameters.Add("INP_TELL_ID", OracleType.Double, 15).Value = 9938;
                    oracomm.Parameters.Add("opertype", OracleType.Int16, 15).Value = opertype;
                    oracomm.Parameters.Add("RETURN_STATUS", OracleType.Int16, 15).Direction = ParameterDirection.Output;

                    //oracomm.Parameters.Add("OERR_FLAG", OracleDbType.Int16, 15).Direction = ParameterDirection.Output

                    oracomm.ExecuteNonQuery();
                    Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();

                    if (Result.Trim().CompareTo("0") == 0)
                    {

                        ErrHandler.WriteError("Record saved sucessfully " + bracode.ToString() + cusnum.ToString());
                        xmlstring1 = xmlstring1 + "<CODE>1000</CODE>";
                        xmlstring1 = xmlstring1 + "<MESSAGE>SUCCESS</MESSAGE>";
                        xmlstring1 = xmlstring1 + "</Response>";
                        return xmlstring1;
                    }

                    else if (Result.Trim().CompareTo("3405") == 0)
                    {
                        xmlstring1 = "<Response>";
                        xmlstring1 = xmlstring1 + "<CODE>1001</CODE>";
                        xmlstring1 = xmlstring1 + "<Error>Account already exist</Error>";
                        xmlstring1 = xmlstring1 + "</Response>";
                        return xmlstring1;
                    }
                    else if (Result.Trim().CompareTo("-1") == 0)
                    {
                        xmlstring1 = "<Response>";
                        xmlstring1 = xmlstring1 + "<CODE>1001</CODE>";
                        xmlstring1 = xmlstring1 + "<Error>Account already exist</Error>";
                        xmlstring1 = xmlstring1 + "</Response>";
                        return xmlstring1;
                    }
                    else
                    {
                        xmlstring1 = "<Response>";
                        xmlstring1 = xmlstring1 + "<CODE>1002</CODE>";
                        xmlstring1 = xmlstring1 + "<Error>Account setup Failed; Please try again</Error>";
                        xmlstring1 = xmlstring1 + "</Response>";
                        return xmlstring1;
                    }
                }
                catch (Exception ex1)
                {
                    xmlstring1 = "<Response>";
                    xmlstring1 = xmlstring1 + "<CODE>1004</CODE>";
                    xmlstring1 = xmlstring1 + "<Error>Exception on Basis Update " + ex1.Message + "</Error>";
                    xmlstring1 = xmlstring1 + "</Response>";
                    return xmlstring1;
                }
                finally
                {
                    oraconn.Close();
                }
            }


            //xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring1 = "<Response>";
            xmlstring1 = xmlstring1 + "<CODE>1004</CODE>";
            xmlstring1 = xmlstring1 + "<Error>Exception on Basis Update " + ex.Message + "</Error>";
            xmlstring1 = xmlstring1 + "</Response>";
            return xmlstring1;
        }

        return xmlstring1;
    }

    public int ProfileCustomerAccountEone(long pUser_id, int pCusNo, int pBraCode, int pCurCode, int pledCode, int pSubAcctCode, string pAccountFullName, string pExtFlag)
    {

        int result = 0;
        //string result = string.Empty;

        using (SqlConnection sqlconn = new SqlConnection(ConfigurationManager.AppSettings["e_oneConnString"]))
        {
            using (SqlCommand sqlcomm = new SqlCommand("ProfileCustomerAccountEone", sqlconn))
            {
                sqlcomm.CommandType = CommandType.StoredProcedure;
                try
                {
                    //xmlstring = "<Response>";

                    if (sqlconn.State == ConnectionState.Closed)
                    {
                        sqlconn.Open();
                    }
                    sqlcomm.Parameters.AddWithValue("@user_id", pUser_id);
                    sqlcomm.Parameters.AddWithValue("@customerNo", pCusNo);
                    sqlcomm.Parameters.AddWithValue("@BraCode", pBraCode);
                    sqlcomm.Parameters.AddWithValue("@CurCode", pCurCode);
                    sqlcomm.Parameters.AddWithValue("@LedCode", pledCode);
                    sqlcomm.Parameters.AddWithValue("@subAcctCode", pSubAcctCode);
                    sqlcomm.Parameters.AddWithValue("@AccountFullName", pAccountFullName);
                    sqlcomm.Parameters.AddWithValue("@ExtFlag", pExtFlag);

                    result = sqlcomm.ExecuteNonQuery();

                    //if (result == 0)
                    //{                      
                    //    xmlstring = xmlstring + "<CODE>1000</CODE>";
                    //    xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";

                    //}
                    //else
                    //{
                    //    xmlstring = "<Response>";
                    //    xmlstring = xmlstring + "<CODE>1002</CODE>";
                    //    xmlstring = xmlstring + "<Error>Account profiled for customer</Error>";
                    //    xmlstring = xmlstring + "</Response>";
                    //}

                }
                catch (Exception ex)
                {

                    ErrHandler.WriteError(ex.Message);
                }
                finally
                {
                    sqlconn.Close();
                }
                return result;
            }
        }
    }

    public String TransferFunds_mob(String Acct_fro, String Acct_to, Double Amount, String type, String channel, String Remarks, String Remarks_2)
    {
        String t_from, t_to, Req_code, ResultStr;
        Char[] charsep = { '+' };
        Double T_amt;
        int Expl_code = 102;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        Boolean chk_bal = false;
        String Remarks1 = null;

        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = checkAccountFormat(Acct_fro.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to debit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            chk_bal = checkAccountFormat(Acct_to.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to credit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            tempstr = Acct_to.Split(delim);

            //if ((channel.ToUpper() == "IVR" || channel.ToUpper() == "IBANK" || channel.ToUpper() == "MBANKING" || channel.ToUpper() == "MBANK") && (tempstr[2] != "1"))
            string[] temp1 = Acct_fro.Split(delim);
            if (tempstr[2] != "1" && (temp1[1] != tempstr[1]))
            {
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<ERROR>FX transfer not allowed</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }




            t_to = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');
            tempstr = Acct_fro.Split(delim);
            t_from = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');

            Amount = Math.Round(Amount, 2);

            T_amt = Amount;

            Req_code = "32";

            if (type == "OWN")
            {
                Expl_code = 100;
                Remarks1 = channel + " - OWN Account Transfer ";
            }
            else if (type == "PRE")
            {
                Expl_code = 102;
                Remarks1 = channel + " - " + Remarks_2 + " PRE-REGISTERED Account Transfer ";
            }
            else if (type == "ANY")
            {
                Expl_code = 102;
                Remarks1 = channel + " - " + Remarks_2 + " ANY Account Transfer ";
            }
            //else if (type == "NEFT")
            //{
            //    Expl_code = 640;
            //    string[] array = Remarks.Split('|');
            //    Remarks1 = array[1];
            //    Remarks = array[0];
            //}
            //else if (type == "NEFT_COMM_VAT")
            //{
            //    Expl_code = 44;
            //    string[] array = Remarks.Split('|');
            //    Remarks1 = array[1];
            //    Remarks = array[0];
            //}
            else if (type == "NEFT")
            {
                Expl_code = 640;
                string[] array = Remarks_2.Split('|');
                Remarks1 = array[1];
                Remarks = array[0];
            }
            else if (type == "NEFT_COMM_VAT")
            {
                Expl_code = 44;
                string[] array = Remarks_2.Split('|');
                Remarks1 = array[1];
                Remarks = array[0];
            }
            else if (type == "OTH")
            {
                Expl_code = 102;
                Remarks1 = Remarks;
            }
            else if (type == "OTHNOCHARGE")
            {
                Expl_code = 302;
                Remarks1 = Remarks;
            }
            else if (type == "DEPOSIT") // Cash Deposit
            {
                Expl_code = 642;
                Remarks1 = Remarks;
            }
            else if (type == "WITHDRAWAL") // Cash Withdrawal
            {
                Expl_code = 641;
                Remarks1 = Remarks;
            }
            else if (type == "CARD") // Card commission
            {
                Expl_code = 1227;
                Remarks1 = Remarks;
            }
            else if (type == "CARD-VAT") // Card commission
            {
                Expl_code = 157;
                Remarks1 = Remarks;
            }

            ErrHandler.WriteError("Received A Request:- Amt:" + T_amt + ", Expl_code: " + Expl_code + ", From: " + t_from + ", To: " + t_to);
            ResultStr = this.PostToBasis(t_from, t_to, T_amt, Expl_code, Remarks1, Req_code);

            if (ResultStr.CompareTo("@ERR7@") == 0 || ResultStr.CompareTo("@ERR19@") == 0)
            {
                //log output
                if (type == "OWN" || type == "PRE" || type == "ANY" || type == "NEFT")
                {
                    LogTransfer(Acct_fro.Replace("/", "").Substring(0, 9), Acct_fro, Acct_to, Convert.ToDecimal(T_amt), channel, Remarks1);
                }
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1002</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else
            {
                //get basis return error
                xmlstring = xmlstring + "<CODE>1004</CODE>";
                xmlstring = xmlstring + "<ERROR> " + ErrorMsg(ResultStr) + "</ERROR>";
                ErrHandler.WriteError("An Error Occurred: " + xmlstring);
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
            ErrHandler.WriteError("An Error Occurred: " + xmlstring);
        }

        ErrHandler.WriteError("An Error Occurred: " + xmlstring);
        return xmlstring;
    }

    public DataSet GetInternationalSpendingLimit(string bra_code, string cus_num)
    {

        SqlConnection conn;
        SqlCommand comm;
        DataSet ds = new DataSet();
        SqlDataAdapter adpt;

        SqlParameter pmCustomerId = new SqlParameter("@customer_id", bra_code + cus_num);

        try
        {
            conn = new SqlConnection(ConfigurationManager.AppSettings["CnnPostcard1"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            string query = "gtb_get_intl_spend";
            comm = new SqlCommand(query, conn);
            comm.Parameters.AddWithValue("@customer_id", bra_code + cus_num);
            comm.CommandType = CommandType.StoredProcedure;

            adpt = new SqlDataAdapter(comm);
            ds.DataSetName = "IntnlSpend";
            adpt.Fill(ds);


        }
        catch (Exception ex)
        {
            ds.DataSetName = "IntnlSpend";
        }

        return ds;
    }

    public string FXBlotterInsert(string trans_deal_slip, string form_no, int sell_buy, string transtype, string currency1, string fcy_acct, decimal fcy_amt, string ngn_acct, decimal ngn_equiv, string lc_ba_no, string source_fund, DateTime deal_date, DateTime settlement_date, string prod_type, string gl_id_no, string cus_name, string client_cat, string status, string channel, decimal rate, string currency2, decimal fcy_amt2, string fcy_acct2, decimal crossRate, decimal usd_equ, decimal calypsoRate)
    {
        try
        {
            string bal = string.Empty;
            string position = string.Empty;
            string position2 = string.Empty;

            bool channelExist = false;
            string response = string.Empty;

            channelExist = ValidateListofValues(ConfigurationManager.AppSettings["FXCHANNEL"], 1, channel);

            if (currency1 == currency2)
            {
                ErrHandler.WriteError("InsertFXReuterTrans || Currency1 and Currency2 cannot be equal. trans_deal_slip = " + trans_deal_slip + "%%% currency1: " + currency1 + " %%% currency2: " + currency2 + " || fcy_amt = " + fcy_amt + " || fcy_amt2 = " + fcy_amt2 + " || sell_buy = " + sell_buy + " || channel = " + channel + " || cus_name = " + cus_name + " || deal_date = " + deal_date);
                return "<Response><CODE>1001</CODE><ERROR>Currency1 and Currency2 cannot be equal.</ERROR><POSITION>" + position + "</POSITION><POSITION2>" + position2 + "</POSITION2></Response>";
            }

            if (currency1 == "NGN" || currency2 == "NGN")
            {
                ErrHandler.WriteError("InsertFXReuterTrans || Currency1 and Currency2 cannot be equal. trans_deal_slip = " + trans_deal_slip + "%%% currency1: " + currency1 + " %%% currency2: " + currency2 + " || fcy_amt = " + fcy_amt + " || fcy_amt2 = " + fcy_amt2 + " || sell_buy = " + sell_buy + " || channel = " + channel + " || cus_name = " + cus_name + " || deal_date = " + deal_date);
                return "<Response><CODE>1001</CODE><ERROR>Currency1 or Currency2 cannot be NGN.</ERROR><POSITION>" + position + "</POSITION><POSITION2>" + position2 + "</POSITION2></Response>";
            }

            if (currency1.Length != 3)
            {
                ErrHandler.WriteError("InsertFXReuterTrans || Length of currency should be 3. trans_deal_slip = " + trans_deal_slip + "%%% currency1: " + currency1 + " %%% currency2: " + currency2 + " || fcy_amt = " + fcy_amt + " || fcy_amt2 = " + fcy_amt2 + " || sell_buy = " + sell_buy + " || channel = " + channel + " || cus_name = " + cus_name + " || deal_date = " + deal_date);
                return "<Response><CODE>1001</CODE><ERROR>Length of currency should be 3.</ERROR><POSITION>" + position + "</POSITION><POSITION2>" + position2 + "</POSITION2></Response>";
            }

            if (channelExist == false)
            {
                ErrHandler.WriteError("InsertFXReuterTrans || Channel is Not Valid. trans_deal_slip = " + trans_deal_slip + "%%% currency1: " + currency1 + " %%% currency2: " + currency2 + " || fcy_amt = " + fcy_amt + " || fcy_amt2 = " + fcy_amt2 + " || sell_buy = " + sell_buy + " || channel = " + channel + " || cus_name = " + cus_name + " || deal_date = " + deal_date);
                return "<Response><CODE>1001</CODE><ERROR>Channel is not valid.</ERROR><POSITION>" + position + "</POSITION><POSITION2>" + position2 + "</POSITION2></Response>";
            }

            //if (channel.ToUpper() == "IBANK" && (sell_buy != -1 || status != "1"))
            //{
            //    ErrHandler.WriteError("InsertFXReuterTrans || Channel Ibank must have sell_buy = -1 and status = 1 " + trans_deal_slip + "%%% currency1: " + currency1 + " %%% currency2: " + currency2 + " || fcy_amt = " + fcy_amt + " || fcy_amt2 = " + fcy_amt2 + " || sell_buy = " + sell_buy + " || channel = " + channel + " || cus_name = " + cus_name + " || deal_date = " + deal_date);
            //    return "<Response><CODE>1001</CODE><ERROR>Channel Ibank must have sell_buy = -1 and status = 1.</ERROR><POSITION>" + position + "</POSITION><POSITION2>" + position2 + "</POSITION2></Response>";
            //}

            if (sell_buy != 1 && sell_buy != -1)
            {
                ErrHandler.WriteError("InsertFXReuterTrans || sell_buy must either be -1 or 1. ||  trans_deal_slip = " + trans_deal_slip + "%%% currency1: " + currency1 + " %%% currency2: " + currency2 + " || fcy_amt = " + fcy_amt + " || fcy_amt2 = " + fcy_amt2 + " || sell_buy = " + sell_buy + " || channel = " + channel + " || cus_name = " + cus_name + " || deal_date = " + deal_date);
                return "<Response><CODE>1001</CODE><ERROR>sell_buy must either be -1 or 1.</ERROR><POSITION>" + position + "</POSITION><POSITION2>" + position2 + "</POSITION2></Response>";
            }

            using (SqlConnection conn1 = new SqlConnection(ConfigurationManager.AppSettings["e_oneConnString"]))
            {
                ErrHandler.WriteError("About to log the Procedure FXBlotterInsert using: " + conn1.ConnectionString.ToString());
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "FXBlotterInsert";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn1;
                cmd.CommandTimeout = 60;
                cmd.Parameters.AddWithValue("@Trans_Deal_Slip", trans_deal_slip);
                cmd.Parameters.AddWithValue("@Form_No", form_no);
                cmd.Parameters.AddWithValue("@Sell_Buy", sell_buy);
                cmd.Parameters.AddWithValue("@Currency", currency1);
                cmd.Parameters.AddWithValue("@FCY_Acct", fcy_acct);
                cmd.Parameters.AddWithValue("@FCY_Amt", fcy_amt);
                cmd.Parameters.AddWithValue("@NGN_Acct", ngn_acct);
                cmd.Parameters.AddWithValue("@NGN_Equiv", ngn_equiv);
                cmd.Parameters.AddWithValue("@TransType", transtype);
                cmd.Parameters.AddWithValue("@LC_BA_No", lc_ba_no);
                cmd.Parameters.AddWithValue("@Source_Fund", source_fund);
                cmd.Parameters.AddWithValue("@Deal_Date", deal_date);
                cmd.Parameters.AddWithValue("@Settlement_Date", settlement_date);
                cmd.Parameters.AddWithValue("@Prod_Type", prod_type);
                cmd.Parameters.AddWithValue("@GL_ID_No", gl_id_no);
                cmd.Parameters.AddWithValue("@Cus_Name", cus_name);
                cmd.Parameters.AddWithValue("@Client_Cat", client_cat);
                cmd.Parameters.AddWithValue("@Status", status);
                cmd.Parameters.AddWithValue("@Reversal", 0);
                cmd.Parameters.AddWithValue("@channel", channel);
                cmd.Parameters.AddWithValue("@rate", rate);
                cmd.Parameters.AddWithValue("@currency2", currency2);
                cmd.Parameters.AddWithValue("@FCY_Amt2", fcy_amt2);
                cmd.Parameters.AddWithValue("@FCY_Acct2", fcy_acct2);
                cmd.Parameters.AddWithValue("@CrossRate", crossRate);
                cmd.Parameters.AddWithValue("@Usd_equ", usd_equ);
                cmd.Parameters.AddWithValue("@CalypsoRate", calypsoRate);

                try
                {
                    if (conn1.State == ConnectionState.Closed)
                    {
                        conn1.Open();
                    }

                    SqlDataReader reader;

                    reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                    if (reader.HasRows && reader.FieldCount == 2)
                    {
                        reader.Read();

                        position = reader["Position1"].ToString();
                        position2 = reader["Position2"].ToString();
                        reader.Close();
                        response = "<Response><CODE>1000</CODE><MESSAGE>SUCCESS</MESSAGE><POSITION>" + position + "</POSITION><POSITION2>" + position2 + "</POSITION2></Response>";
                        ErrHandler.WriteError("InsertFXReuterTrans Successfully inserted. Trans_Deal_Slip: " + trans_deal_slip + "%%% currency1: " + currency1 + " %%% currency2: " + currency2 + " || fcy_amt = " + fcy_amt + " || fcy_amt2 = " + fcy_amt2 + " || sell_buy = " + sell_buy + " || channel = " + channel + " || cus_name = " + cus_name + " || deal_date = " + deal_date);
                        return response;
                    }
                    else
                    {
                        reader.Close();

                        if (conn1.State == ConnectionState.Closed)
                        {
                            conn1.Open();
                        }

                        SqlCommand cmdelete1 = new SqlCommand("delete BlotterPosition where Trans_Deal_Slip = '" + trans_deal_slip + "'", conn1);
                        cmdelete1.CommandTimeout = 20;
                        int dele1 = cmdelete1.ExecuteNonQuery();

                        SqlCommand cmdelete = new SqlCommand("delete fxblotter where Trans_Deal_Slip = '" + trans_deal_slip + "' and currency = '" + currency1 + "'", conn1);
                        cmdelete.CommandTimeout = 20;
                        int dele = cmdelete.ExecuteNonQuery();

                        ErrHandler.WriteError("1003 InsertFXReuterTrans Insert Failed. Trans_Deal_Slip: " + trans_deal_slip + "%%% currency1: " + currency1 + " %%% currency2: " + currency2 + " || fcy_amt = " + fcy_amt + " || fcy_amt2 = " + fcy_amt2 + " || sell_buy = " + sell_buy + " || cmdel = " + dele + " || cmdel1 = " + dele1 + " || channel = " + channel + " || cus_name = " + cus_name + " || deal_date = " + deal_date);
                        return "<Response><CODE>1003</CODE><ERROR>Insert Failed.</ERROR><POSITION>" + position + "</POSITION><POSITION2>" + position2 + "</POSITION2></Response>";
                    }
                }
                catch (Exception ex)
                {
                    ErrHandler.WriteError("1002 InsertFXReuterTrans: Trans_Deal_Slip: " + trans_deal_slip + "%%% currency1: " + currency1 + " %%% currency2: " + currency2 + " || fcy_amt = " + fcy_amt + " || fcy_amt2 = " + fcy_amt2 + " || sell_buy = " + sell_buy + " || channel = " + channel + " || cus_name = " + cus_name + " || deal_date = " + deal_date + " || could not be logged. Exception Message = " + ex.Message);
                    return "<Response><CODE>1002</CODE><ERROR>An error occurred." + ex.Message.Replace("'", "") + "</ERROR><POSITION>" + position + "</POSITION><POSITION2>" + position2 + "</POSITION2></Response>";
                }
                finally
                {
                    if (conn1.State != ConnectionState.Closed)
                        conn1.Close();
                }
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + " InsertFXReuterTrans || Global Exception Trans_Deal_Slip: " + trans_deal_slip + "%%% currency1: " + currency1 + " %%% currency2: " + currency2 + " || fcy_amt = " + fcy_amt + " || fcy_amt2 = " + fcy_amt2 + " || sell_buy = " + sell_buy + " || channel = " + channel + " || cus_name = " + cus_name + " || deal_date = " + deal_date);
            return "<Response><CODE>1002</CODE><ERROR>An error occurred." + ex.Message.Replace("'", "") + "</ERROR><POSITION></POSITION><POSITION2></POSITION2></Response>";
        }
    }

    public string FXBlotterPosition(string currency1, string channel)
    {
        try
        {
            string bal = string.Empty;
            string position = string.Empty;
            string position2 = string.Empty;

            bool channelExist = false;
            string response = string.Empty;

            channelExist = ValidateListofValues(ConfigurationManager.AppSettings["FXCHANNEL"], 1, channel);

            if (currency1 == "NGN")
            {
                return "<Response><CODE>1001</CODE><ERROR>Currency cannot be NGN.</ERROR><POSITION>" + position + "</POSITION></Response>";
            }

            if (currency1.Length != 3)
            {
                return "<Response><CODE>1001</CODE><ERROR>Length of currency should be 3.</ERROR><POSITION>" + position + "</POSITION></Response>";
            }

            if (channelExist == false)
            {
                return "<Response><CODE>1001</CODE><ERROR>Channel is not valid.</ERROR><POSITION>" + position + "</POSITION></Response>";
            }

            using (SqlConnection conn1 = new SqlConnection(ConfigurationManager.AppSettings["e_oneConnString"]))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "FXBlotterPosition";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn1;
                cmd.CommandTimeout = 45;
                cmd.Parameters.AddWithValue("@Currency", currency1);

                try
                {
                    if (conn1.State == ConnectionState.Closed)
                    {
                        conn1.Open();
                    }

                    SqlDataReader reader;

                    reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                    if (reader.HasRows)
                    {
                        reader.Read();

                        position = reader["Position"].ToString();
                        reader.Close();
                        response = "<Response><CODE>1000</CODE><MESSAGE>SUCCESS</MESSAGE><POSITION>" + position + "</POSITION></Response>";
                        return response;
                    }
                    else
                    {
                        return "<Response><CODE>1003</CODE><ERROR>Insert Failed.</MESSAGE><POSITION>" + position + "</POSITION></Response>";
                    }
                }
                catch (Exception ex)
                {
                    return "<Response><CODE>1002</CODE><ERROR>An error occurred." + ex.Message.Replace("'", "") + "</ERROR><POSITION>" + position + "</POSITION></Response>";
                }
                finally
                {
                    if (conn1.State != ConnectionState.Closed)
                        conn1.Close();
                }
            }
        }
        catch (Exception ex)
        {
            return "<Response><CODE>1002</CODE><ERROR>An error occurred." + ex.Message.Replace("'", "") + "</ERROR><POSITION></POSITION></Response>";
        }
    }

    public bool ValidateListofValues(string list, int splitChar, string valueToValidate)
    {
        bool exist = false;
        string[] arrList = null;

        if (splitChar == 1)
        {
            arrList = list.ToUpper().Split(',');
        }
        else if (splitChar == 2)
        {
            arrList = list.ToUpper().Split('/');
        }
        else if (splitChar == 3)
        {
            arrList = list.ToUpper().Split('-');
        }
        else if (splitChar == 4)
        {
            arrList = list.ToUpper().Split('~');
        }
        else if (splitChar == 5)
        {
            arrList = list.ToUpper().Split('|');
        }
        else
        {
            return false;
        }

        foreach (string item in arrList)
        {
            if (item == valueToValidate.ToUpper())
            {
                exist = true;
                break;
            }
        }

        return exist;
    }

    private Boolean getDormantStatus(int braCode, int cusnum)
    {
        Boolean boolResp = false;
        string returnaccount = "";
        using (OracleConnection OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
        {
            using (OracleCommand OraSelect = new OracleCommand())
            {
                //Oracledat
                OracleDataReader OraDrSelect;
                string bra_code = null;
                string cus_num = null;
                string cur_code = null;
                string led_code = null;
                string sub_acct_code = null;
                double cntbal = 0;
                Int16 counter = 0;

                try
                {
                    if (OraConn.State == ConnectionState.Closed)
                    {
                        OraConn.Open();
                    }
                    OraSelect.Connection = OraConn;
                    string selectquery = "select count(1) count from Account  where bra_code = '" + braCode + "' and cus_num ='" + cusnum + "' and sta_code =3";

                    OraSelect.CommandText = selectquery;
                    OraSelect.CommandType = CommandType.Text;
                    using (OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        int count = 0;
                        if (OraDrSelect.Read())
                        {
                            //OraDrSelect.
                            counter = Convert.ToInt16(OraDrSelect["count"].ToString());
                            if (counter > 0)
                            {
                                boolResp = true;
                            }
                        }

                    }
                }
                catch (Exception ex)
                {


                    returnaccount = "Error";
                }
                finally
                {
                    if (OraConn.State == ConnectionState.Open)
                    {
                        OraConn.Close();
                    }
                    OraConn.Dispose();
                }
            }
            return boolResp;
        }

    }

    //public string InitiateIRefer(int braCode, int cusnum, string Referred_name, string Referred_mobileno, string Referred_email, string Channel, string initiator, string nubannumber)
    //{
    //    SqlConnection conn;
    //    SqlCommand comm;
    //    DataSet ds;
    //    SqlDataAdapter adpt;
    //    string accountexist = string.Empty;
    //    string accountreffred = string.Empty;
    //    Boolean dormantAcctStatus = false;

    //    try
    //    {

    //        dormantAcctStatus = getDormantStatus(braCode, cusnum);
    //        if (dormantAcctStatus == false)
    //        {

    //            accountexist = getLinkedAccountGENSDB(Referred_mobileno);
    //            if (!string.IsNullOrEmpty(accountexist)) // this mobile number is associated with an account cannot continue
    //            {
    //                xmlstring = "<Response>";
    //                xmlstring = xmlstring + "<CODE>1090</CODE>";
    //                xmlstring = xmlstring + "<Error>Mobile Number is already associated with an existing GTBank account</Error>";
    //                xmlstring = xmlstring + "</Response>";
    //                return xmlstring;

    //            }

    //            accountreffred = GetRefferedAccount(Referred_mobileno);

    //            if (!string.IsNullOrEmpty(accountreffred)) // this mobile number is associated with an account cannot continue
    //            {
    //                xmlstring = "<Response>";
    //                xmlstring = xmlstring + "<CODE>1090</CODE>";
    //                xmlstring = xmlstring + "<Error>This mobile number is already associated with an existing GTBank Account.</Error>";
    //                xmlstring = xmlstring + "</Response>";
    //                return xmlstring;

    //            }
    //        }

    //        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

    //        //open connetion
    //        if (conn.State != ConnectionState.Open)
    //        {
    //            conn.Open();
    //        }

    //        comm = new SqlCommand("InsertIRefer", conn);
    //        comm.CommandType = CommandType.StoredProcedure;
    //        comm.Parameters.AddWithValue("@bracode", braCode);
    //        comm.Parameters.AddWithValue("@cusnum", cusnum);
    //        comm.Parameters.AddWithValue("@referred_name", Referred_name);
    //        comm.Parameters.AddWithValue("@referred_mobileno", Referred_mobileno);
    //        comm.Parameters.AddWithValue("@referred_email", Referred_name);
    //        comm.Parameters.AddWithValue("@channel", Channel);
    //        comm.Parameters.AddWithValue("@initiated_by", initiator);
    //        comm.Parameters.AddWithValue("@refereeNUBAN", nubannumber);

    //        adpt = new SqlDataAdapter(comm);
    //        ds = new DataSet();

    //        adpt.Fill(ds);

    //        xmlstring = "<Response>";

    //        if (ds.Tables[0].Rows.Count > 0)
    //        {
    //            xmlstring = xmlstring + "<CODE>1000</CODE>";
    //            xmlstring = xmlstring + "<REFCODE>" + ds.Tables[0].Rows[0]["Ref_code"].ToString() + "</REFCODE>";
    //        }
    //        else
    //        {
    //            xmlstring = xmlstring + "<CODE>1001</CODE>";
    //            xmlstring = xmlstring + "<Error>" + "0" + "</Error>";
    //        }

    //        xmlstring = xmlstring + "</Response>";

    //        //Send email to customer and referree
    //        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"].ToString()));
    //        oraconn.Open();
    //        OracleCommand cmd = null;
    //        OracleDataReader reader;
    //        String emailstr = "";
    //        string name = string.Empty;
    //        String query_str = "SELECT email,get_name2(" + braCode + "," + cusnum + ",0,0,0) name  " + " FROM address where bra_code=" + braCode.ToString() + " and cus_num=" + cusnum.ToString();
    //        cmd = new OracleCommand(query_str, oraconn);
    //        reader = cmd.ExecuteReader();
    //        if (reader.HasRows)
    //        {
    //            reader.Read();
    //            emailstr = reader["email"].ToString();
    //            name = reader["name"].ToString();
    //            reader.Close();
    //            reader = null;
    //        }

    //        if (oraconn.State != ConnectionState.Closed) oraconn.Close();





    //        string reffererEmail = "";
    //        reffererEmail = reffererEmail + "Dear " + name + Environment.NewLine + Environment.NewLine;
    //        reffererEmail = reffererEmail + "Thank you for participating in the GTBank i-refer scheme." + Environment.NewLine;
    //        reffererEmail = reffererEmail + "With the GTBank i-refer scheme, you can share our world- class banking experience with your friends, families and associates. You also receive a cash reward into your account for every successful referral you make." + Environment.NewLine;
    //        reffererEmail = reffererEmail + "There is no limit to the number of people you can refer to the GTBank i-refer scheme." + Environment.NewLine;
    //        reffererEmail = reffererEmail + "Your unique code for referral under the GTBank i-refer scheme is " + ds.Tables[0].Rows[0]["Ref_code"].ToString() + Environment.NewLine;
    //        reffererEmail = reffererEmail + "Kindly note that your GTBank account would be credited with your cash reward once your referee commences full operation of the account." + Environment.NewLine;
    //        reffererEmail = reffererEmail + "For further enquiries, please call GTConnect; our fully interactive 24 hours self-service Contact Centre, on 0700-GTCONNECT (0700-482666328), 01-4480000, 0802-9002900 or 0803-9003900." + Environment.NewLine;


    //        string refferedEmail = "";

    //        refferedEmail = refferedEmail + "Dear " + Referred_name + Environment.NewLine + Environment.NewLine;
    //        refferedEmail = refferedEmail + "INVITATION TO OPEN A GTBANK ACCOUNT " + Environment.NewLine;
    //        refferedEmail = refferedEmail + "You have been referred by " + name + " to open a GTBank account.  " + Environment.NewLine;
    //        refferedEmail = refferedEmail + "At GTBank, there is �Something for Everyone� with our range of products and services to cater for all your financial needs. With our variety of individual accounts such as Smart Kids Save (SKS) account, GTTarget account, GTSave account and Seniors account, we ensure that all your individual needs are met. Our range of corporate accounts such as GTMax and GTBusiness account also guarantees the success of your business and corporate objectives. " + Environment.NewLine;
    //        refferedEmail = refferedEmail + "You can explore our wide range of products and services by visiting www.gtbank.com.  At your convenience, you can also visit any of our branches nationwide to open a GTBank account or by visiting https://ao.gtbank.com/aowe/start.aspx  " + Environment.NewLine;
    //        refferedEmail = refferedEmail + "Kindly provide the unique referral code " + ds.Tables[0].Rows[0]["Ref_code"].ToString() + " during your account opening application. " + Environment.NewLine;
    //        refferedEmail = refferedEmail + "For further information on any of our products or services, you can visit the nearest GTBank branch or our website www.gtbank.com. You can also call GTConnect; our fully interactive 24 hours self-service Contact Centre, on 0700-GTCONNECT (0700-482666328), 01-4480000, 0802-9002900 or 0803-9003900. " + Environment.NewLine;



    //        String mailfrom = ConfigurationManager.AppSettings["SenderEmail"].ToString();
    //        String mailsubject = "INVITATION TO OPEN A GTBANK ACCOUNT";
    //        // String mailmessagerefered = "Hello, \n\nPlease note that you have been referred by your friend. \n\n Thank you.";
    //        Email email = new Email();
    //        //  String ret_val = email.SendEmail(mailfrom, Referred_email, mailsubject, refferedEmail, emailstr.Replace(";", ",").Split(',')[0]);
    //        //  String ret_val2 = email.SendEmail(mailfrom, emailstr, mailsubject,reffererEmail , emailstr.Replace(";", ",").Split(',')[0]);


    //        oraconn = null;
    //        cmd = null;

    //    }
    //    catch (Exception ex)
    //    {
    //        xmlstring = "<Response>";
    //        xmlstring = xmlstring + "<CODE>1001</CODE>";
    //        xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
    //        xmlstring = xmlstring + "</Response>";
    //    }

    //    return xmlstring;
    //}

    public String ValidateAdminUsrOffSiteDesktop(String id, String pswd, int appid, string ipAddress)
    {
        String result = null;
        String adserver = ConfigurationManager.AppSettings["ADServer"].ToString();

        adserver = "LDAP://" + adserver;
        DirectoryEntry Entry = new DirectoryEntry(adserver, id, pswd);
        DirectorySearcher Searcher = new DirectorySearcher(Entry);
        SearchResult result1;

        try
        {
            Searcher.Filter = ("(anr=" + id + ")");
            result1 = Searcher.FindOne();

            if (result1 == null)
            {
                //result = ValidateAdminUsr(id, pswd, appid, ipAddress);
                xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Invalid Login Details!</Error>";
                xmlstring = xmlstring + "</Response>";
                result = xmlstring;
            }
            else
            {
                InsertAppLoginDetails(id, appid, DateTime.Now, ipAddress);
                xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<Error>Successful</Error>";
                xmlstring = xmlstring + "</Response>";
                result = xmlstring;
            }
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + "Could not retrieve user details: " + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
            result = xmlstring;
        }

        return result;
    }

    public string SaveBeneficiary(string userId, string beneficiaryAccountName, string beneAccountNumber, string benBank, string transtype)
    {
        //Save Beneficiary
        string connection = ConfigurationManager.AppSettings["e_oneConnString"];
        Sql s = new Sql();
        SqlParameter[] param = new SqlParameter[]
                                    {
                                        new SqlParameter("@User_Id",userId),
                                        new SqlParameter("@BeneName", beneficiaryAccountName), 
                                        new SqlParameter("@BenAccount", beneAccountNumber),
                                        new SqlParameter("@BeneBankCode", benBank),
                                        new SqlParameter("@PreRegistered ", "0"),
                                        new SqlParameter("@TransType ", transtype),
                                    };


        string res = s.ExecuteSqlScalar("Log_IbankBeneficiary", connection, true, param);
        return res;
    }

    public String ValidateAdminUsr(String id, String pswd, int appid, string ipAddress)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataRow dr, dr_app, dr_tokenflag;
        String xmlrep = null;
        String xmlschema = null;

        try
        {
            using (conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
            {
                //open connetion
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                comm = new SqlCommand("AuthenticateAdminUser", conn);
                comm.Parameters.AddWithValue("@UserID", id);
                comm.Parameters.AddWithValue("@userPassword", pswd);
                comm.Parameters.AddWithValue("@ApplicationID", appid);

                comm.CommandType = CommandType.StoredProcedure;
                adpt = new SqlDataAdapter(comm);
                ds = new DataSet();

                adpt.Fill(ds);
            }

            ds.DataSetName = "RESPONSE";

            xmlrep = ds.GetXml();
            xmlschema = ds.GetXmlSchema();
            xmlstring = "<Response>";
            DateTime dtTimeLoggedIn = DateTime.Now;

            if (ds.Tables[0].Rows.Count > 0)
            {
                ds.Tables[0].TableName = "USER";
                ds.Tables[1].TableName = "ROLE";
                ds.Tables[2].TableName = "MENUS";
                ds.Tables[3].TableName = "ACTIONS";
                //ds.Tables[7].TableName = "Approle";

                dr = ds.Tables[0].Rows[0];
                dr_app = ds.Tables[4].Rows[0];
                //dr_approle = ds.Tables[7].Rows[0];

                //if (Convert.ToInt32(dr["PWD"]) != 1)
                //{
                //    xmlstring = xmlstring + "<CODE>1001</CODE>";
                //    xmlstring = xmlstring + "<Error>" + "INVALID USERNAME OR PASSWORD" + "</Error>";
                //}
                //else if (dr["confirmed"].ToString() != "1")
                //{
                //    xmlstring = xmlstring + "<CODE>1003</CODE>";
                //    xmlstring = xmlstring + "<Error>" + "USER NOT CONFIRMED" + "</Error>";
                //}
                //else if (dr_app["Active"].ToString() != "1")
                //{
                //    xmlstring = xmlstring + "<CODE>1002</CODE>";
                //    xmlstring = xmlstring + "<Error>" + "APPLICATION IS TEMPORARILY NOT AVAILABLE" + "</Error>";
                //}
                if (ds.Tables[7] == null || ds.Tables[7].Rows.Count <= 0)
                {
                    xmlstring = xmlstring + "<CODE>1003</CODE>";
                    xmlstring = xmlstring + "<Error>" + "APPLICATION IS TEMPORARILY NOT AVAILABLE" + "</Error>";
                }
                else
                {

                    if (dr_app["Active"].ToString() != "1")
                    {
                        xmlstring = xmlstring + "<CODE>1002</CODE>";
                        xmlstring = xmlstring + "<Error>" + "APPLICATION IS TEMPORARILY NOT AVAILABLE" + "</Error>";
                    }
                    else
                    {
                        xmlstring = xmlstring + "<CODE>1000</CODE>";
                        dr_tokenflag = ds.Tables[5].Rows[0];

                        //GET USER
                        xmlstring = xmlstring + "<USER>";
                        xmlstring = xmlstring + "<ID>" + dr["BASIS_ID"] + "</ID>";
                        xmlstring = xmlstring + "<NAME>" + dr["User_name"] + "</NAME>";
                        xmlstring = xmlstring + "<BRANCH>" + dr["branch_code"] + "</BRANCH>";
                        xmlstring = xmlstring + "<EMAIL>" + dr["email"] + "</EMAIL>";
                        //xmlstring = xmlstring + "<PWDEXPIRE>" + dr["Expiry"].ToString() + "</PWDEXPIRE>";
                        xmlstring = xmlstring + "<PWDEXPIRE>0</PWDEXPIRE>";
                        xmlstring = xmlstring + "<DOMAINID>" + dr["User_id"].ToString() + "</DOMAINID>";
                        xmlstring = xmlstring + "<USETOKEN>" + dr_tokenflag["flag"].ToString() + "</USETOKEN>";
                        //GET TOKEN ID
                        if (dr["TokenId"] != DBNull.Value)
                            xmlstring = xmlstring + "<TOKENID>" + dr["TokenId"].ToString() + "</TOKENID>";
                        else
                            xmlstring = xmlstring + "<TOKENID>" + "0" + "</TOKENID>";
                        if (ds.Tables[6] != null && ds.Tables[6].Rows.Count > 0)
                        {
                            DataRow dwRow = ds.Tables[6].Rows[0];
                            DateTime dtLastLoginDate = new DateTime();
                            String strResponse = string.Empty;
                            dtLastLoginDate = dwRow[0] == DBNull.Value ? dtLastLoginDate : Convert.ToDateTime(dwRow[0]);
                            if (dtLastLoginDate.Date != DateTime.MinValue)
                            {
                                strResponse = String.Format("{0} at {1}", dtLastLoginDate.Date.ToString("dd-MMM-yyyy"), dtLastLoginDate.ToString("h:mm:ss tt"));
                            }

                            xmlstring = xmlstring + "<LASTLOGINDATE>" + strResponse + "</LASTLOGINDATE>";
                        }
                        xmlstring = xmlstring + "</USER>";
                        //GET ROLE
                        xmlstring = xmlstring + "<ROLE>";
                        dr = ds.Tables[1].Rows[0];
                        xmlstring = xmlstring + "<RID>" + dr["ROLE_ID"] + "</RID>";
                        xmlstring = xmlstring + "<RNAME>" + dr["ROLE_DESC"] + "</RNAME>";
                        xmlstring = xmlstring + "</ROLE>";

                        //GET MENUS
                        xmlstring = xmlstring + "<MENUS>";
                        foreach (DataRow dr1 in ds.Tables[2].Rows)
                        {
                            xmlstring = xmlstring + "<MENU>";
                            xmlstring = xmlstring + "<MID>" + dr1["MENU_ID"] + "</MID>";
                            xmlstring = xmlstring + "<MCATEGORY>" + dr1["MENU_CATEGORY"] + "</MCATEGORY>";
                            xmlstring = xmlstring + "<MCAPTION>" + dr1["MENU_CAPTION"] + "</MCAPTION>";
                            xmlstring = xmlstring + "<MURL>" + dr1["RESOURCE"] + "</MURL>";
                            xmlstring = xmlstring + "<MOFFSITEID>" + dr1["OffSiteMenuId"] + "</MOFFSITEID>";
                            bool isVisible = dr1["IsVisible"] == DBNull.Value ? true : Convert.ToBoolean(dr1["IsVisible"]);
                            xmlstring = xmlstring + "<ISVISIBLE>" + isVisible.ToString() + "</ISVISIBLE>";
                            xmlstring = xmlstring + "</MENU>";
                        }
                        xmlstring = xmlstring + "</MENUS>";

                        //GET ACTIONS
                        xmlstring = xmlstring + "<ACTIONS>";
                        foreach (DataRow dr1 in ds.Tables[3].Rows)
                        {
                            xmlstring = xmlstring + "<ACTION>";
                            xmlstring = xmlstring + "<ACTIONCODE>" + dr1["ACTION_CODE"] + "</ACTIONCODE>";
                            xmlstring = xmlstring + "<ACTIONDESC>" + dr1["ACTION_DESC"] + "</ACTIONDESC>";
                            xmlstring = xmlstring + "</ACTION>";
                        }
                        xmlstring = xmlstring + "</ACTIONS>";
                        InsertAppLoginDetails(id, appid, dtTimeLoggedIn, ipAddress);
                    }
                }
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "INVALID USERNAME OR PASSWORD, OR ACCESS DENIED" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + "Could not retrieve user details: " + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
            ErrHandler.WriteError("Error validating Admin User: " + ex.Message);
        }

        return xmlstring;
        //return xmlrep;
    }

    public string InitiateIRefer(int braCode, int cusnum, string Referred_name, string Referred_mobileno, string Referred_email, string Channel, string initiator, string nubannumber)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        string accountexist = string.Empty;
        string accountreffred = string.Empty;
        try
        {

            accountexist = getLinkedAccountGENSDB(Referred_mobileno);
            if (!string.IsNullOrEmpty(accountexist)) // this mobile number is associated with an account cannot continue
            {
                xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1090</CODE>";
                xmlstring = xmlstring + "<Error>Mobile Number is already associated with an existing GTBank account</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;

            }

            accountreffred = GetRefferedAccount(Referred_mobileno);

            if (!string.IsNullOrEmpty(accountreffred)) // this mobile number is associated with an account cannot continue
            {
                xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1090</CODE>";
                xmlstring = xmlstring + "<Error>This mobile number is already associated with an existing GTBank Account.</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;

            }

            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("InsertIRefer", conn);
            comm.CommandType = CommandType.StoredProcedure;
            comm.Parameters.AddWithValue("@bracode", braCode);
            comm.Parameters.AddWithValue("@cusnum", cusnum);
            comm.Parameters.AddWithValue("@referred_name", Referred_name);
            comm.Parameters.AddWithValue("@referred_mobileno", Referred_mobileno);
            comm.Parameters.AddWithValue("@referred_email", Referred_email);
            comm.Parameters.AddWithValue("@channel", Channel);
            comm.Parameters.AddWithValue("@initiated_by", initiator);
            comm.Parameters.AddWithValue("@refereeNUBAN", nubannumber);

            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);

            xmlstring = "<Response>";

            if (ds.Tables[0].Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<REFCODE>" + ds.Tables[0].Rows[0]["Ref_code"].ToString() + "</REFCODE>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "0" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";

            //Send email to customer and referree
            OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"].ToString()));
            oraconn.Open();
            OracleCommand cmd = null;
            OracleDataReader reader;
            String emailstr = "";
            string name = string.Empty;
            String query_str = "SELECT email,get_name2(" + braCode + "," + cusnum + ",0,0,0) name  " + " FROM address where bra_code=" + braCode.ToString() + " and cus_num=" + cusnum.ToString();
            cmd = new OracleCommand(query_str, oraconn);
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                emailstr = reader["email"].ToString();
                name = reader["name"].ToString();
                reader.Close();
                reader = null;
            }

            if (oraconn.State != ConnectionState.Closed) oraconn.Close();





            string reffererEmail = "";
            reffererEmail = reffererEmail + "Dear " + name + Environment.NewLine + Environment.NewLine;
            reffererEmail = reffererEmail + "Thank you for participating in the GTBank i-refer scheme." + Environment.NewLine;
            reffererEmail = reffererEmail + "With the GTBank i-refer scheme, you can share our world- class banking experience with your friends, families and associates. You also receive a cash reward into your account for every successful referral you make." + Environment.NewLine;
            reffererEmail = reffererEmail + "There is no limit to the number of people you can refer to the GTBank i-refer scheme." + Environment.NewLine;
            reffererEmail = reffererEmail + "Your unique code for referral under the GTBank i-refer scheme is " + ds.Tables[0].Rows[0]["Ref_code"].ToString() + Environment.NewLine;
            reffererEmail = reffererEmail + "Kindly note that your GTBank account would be credited with your cash reward once your referee commences full operation of the account." + Environment.NewLine;
            reffererEmail = reffererEmail + "For further enquiries, please call GTConnect; our fully interactive 24 hours self-service Contact Centre, on 0700-GTCONNECT (0700-482666328), 01-4480000, 0802-9002900 or 0803-9003900." + Environment.NewLine;


            string refferedEmail = "";

            refferedEmail = refferedEmail + "Dear " + Referred_name + Environment.NewLine + Environment.NewLine;
            refferedEmail = refferedEmail + "INVITATION TO OPEN A GTBANK ACCOUNT " + Environment.NewLine;
            refferedEmail = refferedEmail + "You have been referred by " + name + " to open a GTBank account.  " + Environment.NewLine;
            refferedEmail = refferedEmail + "At GTBank, there is �Something for Everyone� with our range of products and services to cater for all your financial needs. With our variety of individual accounts such as Smart Kids Save (SKS) account, GTTarget account, GTSave account and Seniors account, we ensure that all your individual needs are met. Our range of corporate accounts such as GTMax and GTBusiness account also guarantees the success of your business and corporate objectives. " + Environment.NewLine;
            refferedEmail = refferedEmail + "You can explore our wide range of products and services by visiting www.gtbank.com.  At your convenience, you can also visit any of our branches nationwide to open a GTBank account or by visiting https://ao.gtbank.com/aowe/start.aspx  " + Environment.NewLine;
            refferedEmail = refferedEmail + "Kindly provide the unique referral code " + ds.Tables[0].Rows[0]["Ref_code"].ToString() + " during your account opening application. " + Environment.NewLine;
            refferedEmail = refferedEmail + "For further information on any of our products or services, you can visit the nearest GTBank branch or our website www.gtbank.com. You can also call GTConnect; our fully interactive 24 hours self-service Contact Centre, on 0700-GTCONNECT (0700-482666328), 01-4480000, 0802-9002900 or 0803-9003900. " + Environment.NewLine;



            String mailfrom = ConfigurationManager.AppSettings["SenderEmail"].ToString();
            String mailsubject = "INVITATION TO OPEN A GTBANK ACCOUNT";
            // String mailmessagerefered = "Hello, \n\nPlease note that you have been referred by your friend. \n\n Thank you.";
            Email email = new Email();
            //  String ret_val = email.SendEmail(mailfrom, Referred_email, mailsubject, refferedEmail, emailstr.Replace(";", ",").Split(',')[0]);
            //  String ret_val2 = email.SendEmail(mailfrom, emailstr, mailsubject,reffererEmail , emailstr.Replace(";", ",").Split(',')[0]);


            oraconn = null;
            cmd = null;

        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String TransferCal(String Acct_fro, String Acct_to, Double Amount, int expl_code, String Remarks)
    {
        String t_from, t_to, Req_code, ResultStr;
        Char[] charsep = { '+' };
        Double T_amt;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        Boolean chk_bal = false;

        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = checkAccountFormat(Acct_fro.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to debit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            chk_bal = checkAccountFormat(Acct_to.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to credit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            tempstr = Acct_to.Split(delim);

            t_to = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');
            tempstr = Acct_fro.Split(delim);
            t_from = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');

            Amount = Math.Round(Amount, 2);

            T_amt = Amount;

            Req_code = "32";

            ResultStr = this.PostToBasis(t_from, t_to, T_amt, expl_code, Remarks, Req_code);

            if (ResultStr.CompareTo("@ERR7@") == 0 || ResultStr.CompareTo("@ERR19@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCESS</MESSAGE>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + "Basis Reponse = " + ResultStr + ". " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1002</CODE>";
                xmlstring = xmlstring + "<ERROR> " + "Basis Reponse = " + ResultStr + ". " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else if (ResultStr.CompareTo("@ERR23@") == 0 || ResultStr.CompareTo("@ERR24@") == 0)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR> " + "Basis Reponse = " + ResultStr + ". " + ErrorMsg(ResultStr) + "</ERROR>";
            }
            else
            {
                //get basis return error
                xmlstring = xmlstring + "<CODE>1004</CODE>";
                xmlstring = xmlstring + "<ERROR> " + "Basis Reponse = " + ResultStr + ". " + ErrorMsg(ResultStr) + "</ERROR>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            ErrHandler.Log("Eone|TransferCal", Remarks, ex.Message);
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<ERROR>" + ex.Message + "</ERROR>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public string SendMT940_Frequency(string Cust_id, DateTime StartDate, DateTime EndDate)  //frequency flag: 0 = Range, 1 = Daily, 2 = Weekly, 3 = Monthly, 4 = Yearly
    {
        LogHandler log = new LogHandler();
        String sentemail = string.Empty;
        int frequency_flag = 0;
        String Day = DateTime.Now.ToString("dd-MM-yy", CultureInfo.CreateSpecificCulture("en-GB"));
        String Today = DateTime.Now.ToString("yyyy-MM-dd", CultureInfo.CreateSpecificCulture("en-GB"));
        string filePath = ConfigurationManager.AppSettings["workarea"].ToString() + "\\ftpfiles\\" + Day;
        SqlConnection conn;
        SqlCommand comm;
        DataTable ds_cust, ds, ds_resend;
        SqlDataAdapter adpt;
        ds_resend = null;
        DataRow dr_app;
        String sqlstr_cust = null, sqlstr = null;
        String[] str_files = null;
        int array_count = 0;
        int StmtNo = 0;
        int oldStmtNo = 0;
        int resendcount = 0;
        string output = "";
        string[] filearray = null;
        DateTime bankdate = DateTime.Now;
        String freqdesc = String.Empty;
        String FTP_IND = "0";   //"0" = No FTP, "1" = one or more files to be FTP
        String customerid_resend;
        DateTime dt_start, dt_end;
        String dt_start_str, dt_end_str;

        log.WriteLog("About to begin generation of MT940 for Customer ID: " + Cust_id, "MT940_RangeLog");
        //Get Maximun number of split files
        int max_split_files = Convert.ToInt32(ConfigurationManager.AppSettings["max_split_files"]);

        //get customers info
        conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MT940_Conn"].ToString());
        //open connetion
        if (conn.State != ConnectionState.Open)
        {
            conn.Open();
        }

        if (bankdate.DayOfWeek == DayOfWeek.Saturday)
            bankdate = bankdate.AddDays(2.0);
        else if (bankdate.DayOfWeek == DayOfWeek.Sunday)
            bankdate = bankdate.AddDays(1.0);


        //Get Config Settings
        customerid_resend = Cust_id;
        dt_start_str = StartDate.ToString("ddMMyyyy");// ConfigurationManager.AppSettings["start_date"].ToString();
        dt_end_str = EndDate.ToString("ddMMyyyy");// ConfigurationManager.AppSettings["end_date"].ToString();

        dt_start = DateTime.ParseExact(dt_start_str, "ddMMyyyy", CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces);
        dt_end = DateTime.ParseExact(dt_end_str, "ddMMyyyy", CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces);

        sqlstr_cust = "select * from customers where id = " + customerid_resend;

        comm = new SqlCommand(sqlstr_cust, conn);
        comm.CommandType = CommandType.Text;
        adpt = new SqlDataAdapter(comm);
        ds_cust = new DataTable();
        adpt.Fill(ds_cust);

        if (ds_cust.Rows.Count > 0)
        {
            foreach (DataRow dr_cust in ds_cust.Rows)
            {
                if (dr_cust["active"].ToString() == "1")
                {
                    if (dr_cust["FTP_File"].ToString() == "1")
                        FTP_IND = "1";

                    array_count = 0;
                    sqlstr = "select * from account where customerid = " + dr_cust["id"].ToString();    // +" and convert(date,Date_Last_Sent) <> '" + Today + "'";
                    comm = new SqlCommand(sqlstr, conn);
                    comm.CommandType = CommandType.Text;
                    adpt = new SqlDataAdapter(comm);
                    ds = new DataTable();
                    adpt.Fill(ds);


                    str_files = new string[max_split_files];
                    Generator gn = null;
                    foreach (DataRow dr in ds.Rows)
                    {
                        //Resend first if Resend table contains rows
                        StmtNo = Convert.ToInt32(dr["StmtNo"]);

                        StmtNo = StmtNo + 1;
                        gn = new Generator(dr_cust, dr, dt_start, dt_end);

                        log.WriteLog("Generating BASIS transxn for Customer ID: " + Cust_id, "MT940_RangeLog");

                        gn.GetBasisTransactions(dr_cust, dr);

                        log.WriteLog("Generating MT940 format for transxn for Customer ID: " + Cust_id, "MT940_RangeLog");

                        output = gn.Generate940(dr_cust, dr, StmtNo);
                        filearray = output.Split(',');
                        foreach (string str in filearray)
                        {
                            if (array_count <= max_split_files)
                            {
                                str_files[array_count] = str;
                                array_count = array_count + 1;
                            }
                        }

                        log.WriteLog("End of File Generation for MT940 format for Customer ID: " + Cust_id, "MT940_RangeLog");
                        if (gn != null)
                            gn.UpdateStatementNo(Convert.ToInt32(dr["AccountID"]), StmtNo, Convert.ToDecimal(dr["last_balance"]));
                    }

                    //Send Mail to recipients for the customer
                    int file_exists = 0;
                    foreach (String str_temp in str_files)
                    {
                        if (str_temp != null)
                        {
                            file_exists = 1;
                            break;
                        }
                    }
                    if (file_exists > 0)
                    {
                        Email email = new Email();
                        String sub_mess;
                        String main_mess;

                        byte[] EmailInBytes = null;

                        log.WriteLog("Converting output file to bytes Customer ID: " + Cust_id, "MT940_RangeLog");
                        if (output != "")
                        {
                            try
                            {
                                FileInfo file = new FileInfo(output);

                                FileStream fs = new FileStream(output, FileMode.Open, FileAccess.Read);

                                BinaryReader br = new BinaryReader(fs);

                                EmailInBytes = br.ReadBytes((int)fs.Length);

                                br.Close();

                                fs.Close();

                                log.WriteLog("End of Converting output file to bytes Customer ID: " + Cust_id, "MT940_RangeLog");
                            }
                            catch (Exception ex)
                            {
                                ErrHandler.WriteError("Error converting MT940 file to Byte: " + ex.Message);
                            }

                        }

                        string fileName = Path.GetFileName(output);
                        sub_mess = "MT940 Confirmation";
                        main_mess = "<br>" + "Good day,";

                        main_mess = main_mess + "<br>" + "<br>" + "Please find attached copies of your MT940 swift message as requested.";
                        main_mess = main_mess + "<br>" + "<br>" + "Regards";
                        main_mess = main_mess + "<br>" + "<br>" + "GTBank MT940 System";

                        log.WriteLog("Sending Email to customer with attachment for Customer ID: " + Cust_id, "MT940_RangeLog");
                        string emailSentResp = email.SendEmail_Attachment("mt940Statement@gtbank.com", dr_cust["email"].ToString(), sub_mess, main_mess, "", EmailInBytes, "text/html", fileName);
                        log.WriteLog("End of Sending Email to customer with attachment for Customer ID: " + Cust_id + "; the response is: " + emailSentResp, "MT940_RangeLog");
                    }
                }

            }
        }

        conn.Close();
        conn = null;
        return sentemail;
    }

    public string SalaryAdvanceRequest(string accountnumber, double Amount, string medium)
    {
        string response = string.Empty;

        try
        {
            //  double wuchargeAmount = Convert.ToDouble(ConfigurationManager.AppSettings["sadvchargeAmount"]);
            if (accountnumber.Contains("/"))
            {
                BASIS basis = new BASIS();
                string nuban = basis.ConvertToNuban(accountnumber);

                string[] acctsplit = accountnumber.Split('/');
                string bra_code = acctsplit[0].ToString();
                string cus_num = acctsplit[1].ToString();
                string userid = bra_code + cus_num + "01";

                UInt64 insertresult = LogSalaryAdvanceRequest(userid, accountnumber, nuban, "", medium, Amount);

                if (insertresult > 0)
                {

                    double eligibleSalaryAdvanceSalary = 0;
                    double minimumSalaryAdvanceAmount = Convert.ToDouble(ConfigurationManager.AppSettings["MinimumSalaryAdvanceAmount"]);
                    double maximumSalaryAdvanceAmount = Convert.ToDouble(ConfigurationManager.AppSettings["MaximumSalaryAdvanceAmount"]);
                    string[] acctnumberdetails = accountnumber.Split('/');
                    string acctnumber = accountnumber;





                    //string currentsalaryadvancestatus = basis.GetSalaryRunningAdvanceStatus(acctnumberdetails[0], acctnumberdetails[1], acctnumberdetails[2], acctnumberdetails[3], acctnumberdetails[4]);


                    //if (currentsalaryadvancestatus.Trim().Equals("1"))
                    //{
                    //    string respcode = "1007";
                    //    string respmessage = "Dear customer, you have a salary advance running on this account you cannot request for a new one.";
                    //    UpdateSalaryAdvanceRequest(insertresult, respmessage + "-" + insertresult, respcode);

                    //    xmlstring = "";
                    //    xmlstring = xmlstring + "<Response>";
                    //    xmlstring = xmlstring + "<CODE>" + respcode + "</CODE>";
                    //    xmlstring = xmlstring + "<Message>" + respmessage + "</Message>";
                    //    xmlstring = xmlstring + "</Response>";
                    //    return xmlstring;

                    //}

                    ErrHandler.WriteError("About to check EXADATA if customer " + accountnumber + " is eligible for Auto processing :", "SalaryAdvanceRequest");
                    eligibleSalaryAdvanceSalary = basis.GetSalaryAdvanceEligibilityStatus(acctnumberdetails[0], acctnumberdetails[1]);

                    ErrHandler.WriteError("EXADATA returned salary amount :" + eligibleSalaryAdvanceSalary + " for customer " + accountnumber, "SalaryAdvanceRequest");
                    //customer might be eligible for auto credit


                    if ((eligibleSalaryAdvanceSalary > 0))
                    {


                        double RequestAmount = Amount;

                        if (((RequestAmount >= minimumSalaryAdvanceAmount) & (RequestAmount <= maximumSalaryAdvanceAmount) & (RequestAmount <= (0.5 * eligibleSalaryAdvanceSalary))))
                        {
                            //The customer has come this far then its okay to credit automatically
                            //  Dim maturitydate As String = DateTime.Now.AddDays(saldavdetailsAutoCredit.LoanTenor).ToString("dd/MM/yyyy", CultureInfo.CreateSpecificCulture("en-GB"))
                            string maturitydate = DateTime.Now.AddDays(30).ToString("MM/dd/yyyy", CultureInfo.CreateSpecificCulture("en-GB"));
                            // use 30 days for auto credit
                            ErrHandler.WriteError("About to check call BASSIS to autocredit salary advance : for customer " + accountnumber);
                            string result = basis.ProcessSalaryAdvanceAutoCredit(acctnumber, RequestAmount, eligibleSalaryAdvanceSalary, maturitydate);

                            ErrHandler.WriteError("BASIS returned processing value  :" + result + " for customer " + accountnumber);

                            if ((result.Equals("0")))
                            {

                                string chargeaccount = acctnumberdetails[0] + ConfigurationManager.AppSettings["SalaryCommissionAccount"];
                                double chargerate = Convert.ToDouble(ConfigurationManager.AppSettings["SalaryCommissionRate"]);
                                double commissionAmount = (chargerate / 100) * RequestAmount;
                                double vatAmount = (5 / 100) * commissionAmount;

                                string[] Acct_To_Credit = chargeaccount.Split('/');
                                string credt_acct = Acct_To_Credit[0].ToString().PadLeft(4, '0') + Acct_To_Credit[1].ToString().PadLeft(7, '0') + Acct_To_Credit[2].ToString().PadLeft(3, '0') + Acct_To_Credit[3].ToString().PadLeft(4, '0') + Acct_To_Credit[4].ToString().PadLeft(3, '0');

                                string[] Acct_To_Debit = acctnumber.Split('/');
                                //  string debit_acct = Acct_To_Debit(0).ToString.PadLeft(4, "0") + Acct_To_Debit(1).ToString.PadLeft(7, "0") + Acct_To_Debit(2).ToString.PadLeft(3, "0") + Acct_To_Debit(3).ToString.PadLeft(4, "0") + Acct_To_Debit(4).ToString.PadLeft(3, "0");
                                string debit_acct = Acct_To_Debit[0].ToString().PadLeft(4, '0') + Acct_To_Debit[1].ToString().PadLeft(7, '0') + Acct_To_Debit[2].ToString().PadLeft(3, '0') + Acct_To_Debit[3].ToString().PadLeft(4, '0') + Acct_To_Debit[4].ToString().PadLeft(3, '0');



                                string VATAcct_To = Acct_To_Debit[0].ToString().PadLeft(4, '0') + "10".PadLeft(7, '0') + "1".PadLeft(3, '0') + "4522" + "0".PadLeft(3, '0');

                                string mResponseComm = PostToBasis(debit_acct, credt_acct, commissionAmount, 605, medium + " Salary Advance Commission", "32");

                                ErrHandler.WriteError("SADV commision response : " + mResponseComm, "SalaryAdvanceRequest");
                                string mResponseVAT = PostToBasis(debit_acct, VATAcct_To, vatAmount, 157, medium + " Salary Advance VAT", "32");
                                ErrHandler.WriteError("SADV VAT response : " + mResponseVAT, "SalaryAdvanceRequest");


                                UpdateSalaryAdvanceRequest(insertresult, "AUTO CREDITED", "1000");
                                xmlstring = "";
                                xmlstring = xmlstring + "<Response>";
                                xmlstring = xmlstring + "<CODE>1000</CODE>";
                                xmlstring = xmlstring + "<Message>Your Salary Advance Request has been succesfully processed and credited into your account " + nuban + "</Message>";
                                xmlstring = xmlstring + "</Response>";
                                return xmlstring;


                            }


                            else
                            {


                                string respcode = "1003";
                                string respmessage = "An Error Occured processing your request, please try again";
                                UpdateSalaryAdvanceRequest(insertresult, respmessage + "-" + result, respcode);

                                xmlstring = "";
                                xmlstring = xmlstring + "<Response>";
                                xmlstring = xmlstring + "<CODE>" + respcode + "</CODE>";
                                xmlstring = xmlstring + "<Message>" + respmessage + "</Message>";
                                xmlstring = xmlstring + "</Response>";
                                return xmlstring;


                            }


                        }
                        else if (RequestAmount < minimumSalaryAdvanceAmount)
                        {
                            string respcode = "1004";
                            string respmessage = "The request Amount is too small, minimum amount is : " + minimumSalaryAdvanceAmount.ToString();
                            UpdateSalaryAdvanceRequest(insertresult, respmessage, respcode);

                            xmlstring = "";
                            xmlstring = xmlstring + "<Response>";
                            xmlstring = xmlstring + "<CODE>" + respcode + "</CODE>";
                            xmlstring = xmlstring + "<Message>" + respmessage + "</Message>";
                            xmlstring = xmlstring + "</Response>";
                            return xmlstring;



                        }
                        else if (RequestAmount > maximumSalaryAdvanceAmount)
                        {
                            string respcode = "1005";
                            string respmessage = "The request Amount is too high maximum, maximum amount is : " + maximumSalaryAdvanceAmount.ToString();
                            UpdateSalaryAdvanceRequest(insertresult, respmessage, respcode);

                            xmlstring = "";
                            xmlstring = xmlstring + "<Response>";
                            xmlstring = xmlstring + "<CODE>" + respcode + "</CODE>";
                            xmlstring = xmlstring + "<Message>" + respmessage + "</Message>";
                            xmlstring = xmlstring + "</Response>";
                            return xmlstring;



                        }
                        else if (RequestAmount > (0.5 * eligibleSalaryAdvanceSalary))
                        {
                            string respcode = "1006";
                            string respmessage = "The request amount is higher than 50% of your average salary";
                            UpdateSalaryAdvanceRequest(insertresult, respmessage, respcode);

                            xmlstring = "";
                            xmlstring = xmlstring + "<Response>";
                            xmlstring = xmlstring + "<CODE>" + respcode + "</CODE>";
                            xmlstring = xmlstring + "<Message>" + respmessage + "</Message>";
                            xmlstring = xmlstring + "</Response>";
                            return xmlstring;

                        }
                        else
                        {
                            string respcode = "1002";
                            string respmessage = "Dear customer you are not eligible for automated salary advance, kindly initiate your request from Internet banking or any branch closest to you";
                            UpdateSalaryAdvanceRequest(insertresult, respmessage, respcode);

                            xmlstring = "";
                            xmlstring = xmlstring + "<Response>";
                            xmlstring = xmlstring + "<CODE>" + respcode + "</CODE>";
                            xmlstring = xmlstring + "<Message>" + respmessage + "</Message>";
                            xmlstring = xmlstring + "</Response>";
                            return xmlstring;


                        }



                    }
                    else
                    {


                        string respcode = "1001";
                        string respmessage = "Dear customer you are not eligible for automated salary advance, kindly initiate your request from Internet banking or any branch closest to you";
                        UpdateSalaryAdvanceRequest(insertresult, respmessage, respcode);

                        xmlstring = "";
                        xmlstring = xmlstring + "<Response>";
                        xmlstring = xmlstring + "<CODE>" + respcode + "</CODE>";
                        xmlstring = xmlstring + "<Message>" + respmessage + "</Message>";
                        xmlstring = xmlstring + "</Response>";
                        return xmlstring;


                    }

                }
                else
                {

                    xmlstring = "";
                    xmlstring = xmlstring + "<Response>";
                    xmlstring = xmlstring + "<CODE>4000</CODE>";
                    xmlstring = xmlstring + "<Message>An Error occurred initiating your request please try again</Message>";
                    xmlstring = xmlstring + "</Response>";
                    //     ErrHandler.WriteError("Response for " + XMLString + " is : : " + xmlstring, "SalaryAdvanceRequest");
                    return xmlstring;

                }
            }
            else
            {


                xmlstring = "";
                xmlstring = xmlstring + "<Response>";
                xmlstring = xmlstring + "<CODE>3002</CODE>";
                xmlstring = xmlstring + "<Message>Invalid Account number format</Message>";
                xmlstring = xmlstring + "</Response>";

                return xmlstring;


            }

        }




        catch (Exception ex)
        {
            ErrHandler.WriteError("An error occured : " + ex.Message, "SalaryAdvanceRequest");

            xmlstring = "";
            xmlstring = xmlstring + "<Response>";
            xmlstring = xmlstring + "<CODE>3000</CODE>";
            xmlstring = xmlstring + "<Message>An Internal error occured please try again.</Message>";
            xmlstring = xmlstring + "</Response>";
            return xmlstring;
        }

    }

    public UInt64 LogSalaryAdvanceRequest(string CustomerID, string AccountNumber, string Nuban, string AuthCode, string MobileNumber, double LoanAmount)
    {

        //     @CustomerID nvarchar(20),
        //@AccountNumber nvarchar(50),
        //@Nuban nvarchar(15),
        //@AuthCode nvarchar(50),
        //@MobileNumber nvarchar(20),
        //@LoanAmount decimal(18, 2),
        //@Medium nvarchar(10) = 'USSD'



        SqlCommand cmdSQLselect = new SqlCommand();

        SqlConnection e_OneConn = new SqlConnection(ConfigurationManager.AppSettings["purchaseConnString"].ToString());


        SqlParameter PmCustomerID = new SqlParameter("@CustomerID", CustomerID);
        SqlParameter PmAccountNumber = new SqlParameter("@AccountNumber", AccountNumber);
        SqlParameter PmNuban = new SqlParameter("@Nuban", Nuban);
        SqlParameter PmAuthCode = new SqlParameter("@AuthCode", AuthCode);
        SqlParameter PmMobileNumber = new SqlParameter("@MobileNumber", MobileNumber);
        SqlParameter PmLoanAmount = new SqlParameter("@LoanAmount", LoanAmount);
        SqlParameter PmMedium = new SqlParameter("@Medium", "USSD");


        try
        {
            // Add Parameter to command Object
            cmdSQLselect.Parameters.Add(PmCustomerID);
            cmdSQLselect.Parameters.Add(PmAccountNumber);
            cmdSQLselect.Parameters.Add(PmNuban);
            cmdSQLselect.Parameters.Add(PmAuthCode);
            cmdSQLselect.Parameters.Add(PmMobileNumber);
            cmdSQLselect.Parameters.Add(PmLoanAmount);
            cmdSQLselect.Parameters.Add(PmMedium);


            if (e_OneConn.State == ConnectionState.Closed)
            {
                e_OneConn.Open();
            }
            cmdSQLselect.Connection = e_OneConn;
            cmdSQLselect.CommandText = "usp_SalaryAdvanceRequestInsert";
            cmdSQLselect.CommandType = CommandType.StoredProcedure;
            return Convert.ToUInt64(cmdSQLselect.ExecuteScalar());
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("User ID : " + MobileNumber + " Has an error on salary advance" + ex.Message, "SalaryAdvanceRequest");

            return 0;
        }
        finally
        {
            if (e_OneConn.State == ConnectionState.Open)
            {
                e_OneConn.Close();
                cmdSQLselect.Dispose();
            }
        }
    }

    public bool UpdateSalaryAdvanceRequest(UInt64 RequestID, string ResponseMessage, string ResponseCode)
    {

        SqlConnection e_OneConn = new SqlConnection(ConfigurationManager.AppSettings["purchaseConnString"].ToString());
        SqlCommand cmdSQLselect = new SqlCommand();
        SqlParameter PmRequestID = new SqlParameter("@RequestID", RequestID);

        SqlParameter PmResponseMessage = new SqlParameter("@ResponseMessage", ResponseMessage);
        SqlParameter PmResponseCode = new SqlParameter("@ResponseCode", ResponseCode);



        try
        {
            // Add Parameter to command Object
            PmRequestID.SqlDbType = SqlDbType.Int;
            cmdSQLselect.Parameters.Add(PmRequestID);
            cmdSQLselect.Parameters.Add(PmResponseMessage);
            cmdSQLselect.Parameters.Add(PmResponseCode);

            if (e_OneConn.State == ConnectionState.Closed)
            {
                e_OneConn.Open();
            }
            cmdSQLselect.Connection = e_OneConn;
            cmdSQLselect.CommandText = "usp_SalaryAdvanceRequestUpdate";
            cmdSQLselect.CommandType = CommandType.StoredProcedure;
            cmdSQLselect.ExecuteNonQuery();
            return true;
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message, "SalaryAdvanceRequest");
            return false;


        }
        finally
        {
            if (e_OneConn.State == ConnectionState.Open)
            {
                e_OneConn.Close();
                cmdSQLselect.Dispose();
            }
        }
    }

    internal int Insert_Account(Int64 pUser_id, int pCusNo, int pBraCode, int pledCode, int pSubAcctCode, string pAccountFullName, string preason, string creator, string channel, string docAlp)
    {
        int result = 0;

        using (SqlConnection sqlconn = new SqlConnection(ConfigurationManager.AppSettings["e_oneConnString"]))
        {
            using (SqlCommand sqlcomm = new SqlCommand("proc_Insert_Account", sqlconn))
            {
                sqlcomm.CommandType = CommandType.StoredProcedure;
                try
                {
                    if (sqlconn.State == ConnectionState.Closed)
                    {
                        sqlconn.Open();
                    }
                    sqlcomm.Parameters.AddWithValue("@user_id", pUser_id);
                    sqlcomm.Parameters.AddWithValue("@customerNo", pCusNo);
                    sqlcomm.Parameters.AddWithValue("@BraCode", pBraCode);
                    sqlcomm.Parameters.AddWithValue("@LedCode", pledCode);
                    sqlcomm.Parameters.AddWithValue("@subAcctCode", pSubAcctCode);
                    sqlcomm.Parameters.AddWithValue("@AccountFullName", pAccountFullName);
                    sqlcomm.Parameters.AddWithValue("@reason", preason);
                    sqlcomm.Parameters.AddWithValue("@Channel", channel);
                    sqlcomm.Parameters.AddWithValue("@Docalp", docAlp);
                    sqlcomm.Parameters.AddWithValue("@Createdby", creator);

                    result = Convert.ToInt32(sqlcomm.ExecuteNonQuery());

                }
                catch (Exception ex)
                {
                    ErrHandler.WriteError("Error when Inserting new subaccount ==> " + ex.Message);
                }
                finally
                {
                    sqlconn.Close();
                }
                return result;
            }
        }
    }

    public string AvailRevolvingCredit(int bra_code, int cus_num, int cur_code, int led_code, int sub_acct_code, int tell_id, double rate, double bal_lim, string mat_date, string channel, string docAlp, string transUniqIndenf)
    {
        string result1 = string.Empty;
        string result2 = string.Empty;
        long result3 = 1;
        string ipAddress = string.Empty;
        string customerid = bra_code.ToString() + cus_num.ToString();
        DateTime matDate;

        if (!string.IsNullOrEmpty(mat_date))
        {
            matDate = Convert.ToDateTime(mat_date);
        }
        else matDate = DateTime.MinValue;

        ipAddress = Dns.GetHostByName(Dns.GetHostName()).AddressList[0].ToString() + "|" + System.Net.Dns.GetHostName();

        using (OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
        {
            OracleTransaction transaction;
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            transaction = oraconn.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                xmlstring = "<Response>";
                OracleCommand oracomm = oraconn.CreateCommand();
                oracomm.CommandType = CommandType.StoredProcedure;
                oracomm.CommandTimeout = 60;

                //Start a local transaction and assign transaction object for a pending local transaction                
                oracomm.Transaction = transaction;
                oracomm.CommandText = "EONEPKG1.gtb_bal_lim_blk";

                oracomm.Parameters.Add("inp_bra", OracleType.Int32, 15).Value = bra_code;
                oracomm.Parameters.Add("inp_cus", OracleType.Int32, 15).Value = cus_num;
                oracomm.Parameters.Add("inp_cur", OracleType.Int32, 15).Value = cur_code;
                oracomm.Parameters.Add("inp_led", OracleType.Int32, 15).Value = led_code;
                oracomm.Parameters.Add("inp_sub", OracleType.Int32, 15).Value = sub_acct_code;
                oracomm.Parameters.Add("inp_tell_id", OracleType.Int32, 15).Value = tell_id;
                oracomm.Parameters.Add("inp_bal_lim", OracleType.Double, 20).Value = bal_lim;
                oracomm.Parameters.Add("inp_lim_mat_date", OracleType.DateTime, 15).Value = matDate;
                oracomm.Parameters.Add("return_status", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

                oracomm.ExecuteNonQuery();
                result1 = oracomm.Parameters["return_status"].Value.ToString();
                oracomm.Parameters.Clear();

                if (result1.Trim().CompareTo("0") == 0)
                {
                    try
                    {
                        //OracleCommand oracomm = oraconn.CreateCommand();
                        //oracomm.CommandType = CommandType.StoredProcedure;
                        // oracomm.CommandTimeout = 60;

                        //Start a local transaction and assign transaction object for a pending local transaction                
                        //oracomm.Transaction = transaction;
                        oracomm.CommandText = "EONEPKG1.gtb_acct_rate";

                        oracomm.Parameters.Add("inp_bra", OracleType.Int32, 15).Value = bra_code;
                        oracomm.Parameters.Add("inp_cus", OracleType.Int32, 15).Value = cus_num;
                        oracomm.Parameters.Add("inp_cur", OracleType.Int32, 15).Value = cur_code;
                        oracomm.Parameters.Add("inp_led", OracleType.Int32, 15).Value = led_code;
                        oracomm.Parameters.Add("inp_sub", OracleType.Int32, 15).Value = sub_acct_code;
                        oracomm.Parameters.Add("inp_tell_id", OracleType.Int32, 15).Value = tell_id;
                        oracomm.Parameters.Add("inp_rate", OracleType.Double, 20).Value = rate;
                        oracomm.Parameters.Add("return_status", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

                        oracomm.ExecuteNonQuery();
                        result2 = oracomm.Parameters["return_status"].Value.ToString();
                        if (result2.Trim().CompareTo("0") == 0)
                        {

                            transaction.Commit();
                            ErrHandler.WriteError("Commit operation successful for: " + customerid + "," + bal_lim.ToString() + ", - Revolving Credit , " + result1 + "," + result2 + "," + transUniqIndenf);
                            xmlstring = xmlstring + "<CODE>1000</CODE>";
                            xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                            xmlstring = xmlstring + "</Response>";
                            //ReportingLogs reportLog = new ReportingLogs();
                            PostingToBasis_Logs(result1, result3, result3, docAlp, bal_lim, transUniqIndenf, customerid, result2, ipAddress, "IB");

                            return xmlstring;
                        }
                        else
                        {
                            transaction.Rollback();
                            ErrHandler.WriteError(result2 + " || Rolled back transaction for: " + customerid + "," + bal_lim.ToString() + ", - Revolving Credit , " + result1 + "," + result2 + "," + transUniqIndenf);
                            xmlstring = xmlstring + "<CODE>1001</CODE>";
                            xmlstring = xmlstring + "<MESSAGE>" + result2 + "</MESSAGE>";
                            xmlstring = xmlstring + "</Response>";
                            return xmlstring;
                        }

                        //return result3.ToString();
                    }

                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        ErrHandler.WriteError(ex.Message + " || return_status threw error. " + customerid + " || Rolled back transaction for: " + customerid + "," + bal_lim.ToString() + ", - Revolving Credit , " + result2 + "," + result3 + "," + transUniqIndenf);
                        //return "@ERR-75@";
                        xmlstring = xmlstring + "<CODE>1004</CODE>";
                        xmlstring = xmlstring + "<MESSAGE>" + ex.Message + "</MESSAGE>";
                        xmlstring = xmlstring + "</Response>";
                        return xmlstring;
                    }

                    //return result1;
                }
                else
                {
                    transaction.Rollback();
                    ErrHandler.WriteError(result1 + " || Rolled back transaction for: " + customerid + "," + bal_lim.ToString() + ", - Revolving Credit , " + result2 + "," + result3 + "," + transUniqIndenf);
                    //return result1;
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<MESSAGE>" + result1 + "</MESSAGE>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                ErrHandler.WriteError(ex.Message + "|| Rolled back transaction: " + customerid + "," + bal_lim.ToString() + ", - Revolving Credit , " + result2 + "," + result3 + "," + transUniqIndenf);
                xmlstring = xmlstring + "<CODE>1004</CODE>";
                xmlstring = xmlstring + "<MESSAGE>" + ex.Message + "</MESSAGE>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }
            finally
            {
                oraconn.Close();
            }
        }
    }

    public void PostingToBasis_Logs(string channel, long out_tra_seq1, long inp_tra_seq1, string inp_doc_alp, double amount, string appTransUniqIndenf, string debitAcct, string creditAcct, string ipAddress, string compName)
    {
        SqlCommand sqlSelect = new SqlCommand();
        //SqlDataReader sqlreader;
        SqlConnection TranSeq = new SqlConnection(ConfigurationManager.AppSettings["REPORTING_LOG"].ToString());
        try
        {
            if (TranSeq.State == ConnectionState.Closed)
            {
                TranSeq.Open();
            }

            sqlSelect.CommandText = "PostingToBasis_Logs";
            sqlSelect.CommandType = CommandType.StoredProcedure;
            sqlSelect.Connection = TranSeq;
            sqlSelect.CommandTimeout = 120;
            sqlSelect.Parameters.AddWithValue("@out_tra_seq1", out_tra_seq1);
            sqlSelect.Parameters.AddWithValue("@inp_tra_seq1", inp_tra_seq1);
            sqlSelect.Parameters.AddWithValue("@inp_doc_alp", inp_doc_alp);
            sqlSelect.Parameters.AddWithValue("@amount", amount);
            sqlSelect.Parameters.AddWithValue("@uniqIdentifier", appTransUniqIndenf);
            sqlSelect.Parameters.AddWithValue("@debitAcct", debitAcct);
            sqlSelect.Parameters.AddWithValue("@creditAcct", creditAcct);
            sqlSelect.Parameters.AddWithValue("@ipAddress", ipAddress);
            sqlSelect.Parameters.AddWithValue("@computerName", compName);

            int res = sqlSelect.ExecuteNonQuery();
            if (res < 1)
                ErrHandler.WriteError("Unable to transaction insert into Transfer_OrigtTraSeq.  || (channel, out_tra_seq1, inp_tra_seq1,  amount, appTransUniqIndenf) = (" + channel + "," + out_tra_seq1 + "," + inp_doc_alp + "," + amount + "," + appTransUniqIndenf + ")");

        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + "|| (channel, out_tra_seq1, inp_tra_seq1, amount, appTransUniqIndenf) = (" + channel + "," + out_tra_seq1 + "," + inp_doc_alp + "," + amount + "," + appTransUniqIndenf + ")");
        }
        finally
        {
            if (TranSeq.State == ConnectionState.Open)
            {
                TranSeq.Close();
            }
        }
    }

    public DataSet GetBillPaymentAgregatorByID(int id)
    {
        DataSet dtAgreegator = new DataSet();

        SqlDataAdapter dtadapt = new SqlDataAdapter();
        try
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["e_oneConnStringGT"].ToString()))
            {
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                SqlCommand comm = new SqlCommand("SelectAgreegatorByID", conn);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@ID", id);

                dtadapt.SelectCommand = comm;
                dtadapt.Fill(dtAgreegator);

                //result = Convert.ToInt64(comm.ExecuteScalar());
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message);
            return null;
        }



        return dtAgreegator;

    }

    public ObjectResponse AccountupdateviaPM(string accountNo, string requesttype, string DOB, string Occupation, string marital, string address, string channel, string docIDs, string gender)
    {
        ObjectResponse resp = new ObjectResponse();
        String acct_result = String.Empty;

        try
        {
            BASIS callBasis = new BASIS();
            string customerName = string.Empty;

            string[] arrayAccountNo = accountNo.Split('/');
            string[] requesttype1 = requesttype.Split(',');

            if (arrayAccountNo.GetLength(0) != 5)
            {
                resp.code = 1001;
                resp.message = "Invalid Account Number: " + accountNo;
                ErrHandler.WriteError(resp + accountNo);
                return resp;
            }

            OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
            string query_str = "select cus_sho_name from address where bra_code=" + Convert.ToInt32(arrayAccountNo[0]) + " and cus_num=" + Convert.ToInt32(arrayAccountNo[1]) + " and cur_code=0 and led_code=0 and sub_acct_code=0";

            oraconn.Open();
            OracleCommand cmd = new OracleCommand(query_str, oraconn);
            OracleDataReader reader;

            // execute the function
            reader = cmd.ExecuteReader();
            if (reader.HasRows == true)
            {
                reader.Read();
                customerName = reader["cus_sho_name"].ToString();
            }
            else
            {
                resp.code = 1002;
                resp.message = "Invalid Customer Name: " + accountNo;
                ErrHandler.WriteError(resp + accountNo);
                return resp;
            }

            reader.Close();
            reader = null;
            cmd = null;
            oraconn.Close();

            string loginSessionID = PM.login1();

            if (!string.IsNullOrEmpty(loginSessionID))
            {
                NameValueCollection nameValues = new NameValueCollection();

                nameValues.Add("DOB", DOB);
                nameValues.Add("Occupation", Occupation);
                nameValues.Add("customerName", customerName);
                nameValues.Add("marital", marital);
                nameValues.Add("address", address);
                nameValues.Add("accountNo", accountNo);
                nameValues.Add("channel", channel);
                nameValues.Add("DocumentIDs", docIDs);
                nameValues.Add("gender", gender);
                nameValues.Add("requesttype", requesttype);

                ArrayList al = new ArrayList((object[])ConvertNameValueCollectionIntoArrayList(nameValues));
                ParameterValue[] Params = ConvertNameValueCollectionIntoParams(al);
                string caseid = PM.newCase1(loginSessionID, Params);

                if (!string.IsNullOrEmpty(caseid))
                {
                    string[] caseidARR = caseid.Split('-');

                    string caseidNo = string.Empty;

                    if (caseidARR.GetLength(0) > 1)
                    {
                        caseidNo = caseidARR[1];
                        ErrHandler.WriteError(resp + accountNo + "--" + caseid);
                    }
                    else
                    {
                        resp.code = 1003;
                        resp.message = "Invalid case number, accountNo: " + accountNo;
                        ErrHandler.WriteError(resp + accountNo);
                        return resp;
                    }

                    string pmRoutCasResp = string.Empty;
                    pmRoutCasResp = PM.routeCase1(loginSessionID, caseidNo, 1);

                    if (!string.IsNullOrEmpty(pmRoutCasResp))
                    {
                        resp.code = 1000;
                        resp.message = "Case route successfully, accountNo: " + accountNo + "--" + caseid;
                        ErrHandler.WriteError(resp + accountNo);
                        return resp;
                    }
                    else
                    {
                        resp.code = 1004;
                        resp.message = "Case cannot be route, accountNo: " + accountNo;
                        ErrHandler.WriteError(resp + accountNo);
                        return resp;
                    }
                }
                else
                {
                    resp.code = 1005;
                    resp.message = "Invalid caseID, accountNo: " + accountNo;
                    ErrHandler.WriteError(resp + accountNo);
                    return resp;
                }
            }
            else
            {
                resp.code = 1006;
                resp.message = "Invalid login session, accountNo: " + accountNo;
                ErrHandler.WriteError(resp + accountNo);
                return resp;
            }
        }
        catch (Exception ex)
        {
            resp.code = 1010;
            resp.message = "System error, accountNo: " + accountNo + " | " + ex.Message;
            ErrHandler.WriteError(accountNo + ex.Message);
            return resp;
        }
    }

    public String InitiateAccountUpdateRequest2(string RequestType, string FirstName, string LastName, string IDCard, string AddressLine1, string AddressLine2, string EmailAddress, string MobileNumber,
                                                  string AccountNumber, string UserID, string update_status, string MaritalStatus, string Occupation, string Gender, string DOB, string update_by)
    {
        SqlConnection conn = null;
        SqlCommand comm;
        int count = 0;
        UInt64 res = 0;
        try
        {
            xmlstring = "<Response>";
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }


            comm = new SqlCommand("usp_AccountUpdateRequestInsert2", conn);
            comm.Parameters.AddWithValue("@RequestType", RequestType);
            comm.Parameters.AddWithValue("@FirstName", FirstName);
            comm.Parameters.AddWithValue("@LastName", LastName);
            comm.Parameters.AddWithValue("@IDCard", IDCard);
            comm.Parameters.AddWithValue("@AddressLine1", AddressLine1);
            comm.Parameters.AddWithValue("@AddressLine2", AddressLine2);
            comm.Parameters.AddWithValue("@EmailAddress", EmailAddress);
            comm.Parameters.AddWithValue("@MobileNumber", MobileNumber);
            comm.Parameters.AddWithValue("@AccountNumber", AccountNumber);
            comm.Parameters.AddWithValue("@UserID", UserID);
            comm.Parameters.AddWithValue("@update_status", update_status);
            comm.Parameters.AddWithValue("@MaritalStatus", MaritalStatus);
            comm.Parameters.AddWithValue("@Occupation", Occupation);
            comm.Parameters.AddWithValue("@Gender", Gender);
            comm.Parameters.AddWithValue("@DOB", DOB);
            comm.Parameters.AddWithValue("@update_by", update_by);


            comm.CommandType = CommandType.StoredProcedure;
            //   res = Convert.ToUInt64( comm.ExecuteScalar());

            SqlDataAdapter adpt = new SqlDataAdapter(comm);
            DataTable ds = new DataTable();

            adpt.Fill(ds);


            if (ds.Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                //xmlstring = xmlstring + "<REFCODE>" + ds.Rows[0]["Ref_code"].ToString() + "</REFCODE>";
                xmlstring = xmlstring + "<REFCODE>" + ds.Rows[0][0].ToString() + "</REFCODE>";
                xmlstring = xmlstring + "</Response>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Could not insert new record</Error>";
                xmlstring = xmlstring + "</Response>";
            }
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        comm = null;
        conn.Close();
        conn = null;
        return xmlstring;

    }


    public String TransferFunds_Cal(String Acct_fro, String Acct_to, Double Amount, String type, String channel, int Expl_code, String Remarks, int origtbrabracode, string docAlp, int supervisorID, int tellerID, string transUniqIndenf, string bankCode, string docNum, string inp_Period)
    {
        String t_from, t_to, Req_code, ResultStr;
        Char[] charsep = { '+' };
        Double T_amt;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        Boolean chk_bal = false;
        String Remarks1 = null;
        BASIS basis = new BASIS();

        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = checkAccountFormat(Acct_fro.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to debit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            chk_bal = checkAccountFormat(Acct_to.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account to credit is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            tempstr = Acct_to.Split(delim);

            string[] temp1 = Acct_fro.Split(delim);

            //if (docAlp != "GTCN" || docAlp != "CLPS")
            //{

            //    if (tempstr[2] != "1" && (temp1[1] != tempstr[1]))
            //    {

            //        xmlstring = xmlstring + "<CODE>1010</CODE>";
            //        xmlstring = xmlstring + "<ERROR>FX transfer not allowed</ERROR>";
            //        xmlstring = xmlstring + "</Response>";
            //        return xmlstring;
            //    }
            //}

            t_to = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');
            tempstr = Acct_fro.Split(delim);
            t_from = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');

            Amount = Math.Round(Amount, 2);

            T_amt = Amount;

            Req_code = "32";

            if (type == "OWN")
            {
                //Expl_code = 100;
                Remarks1 = channel + " - OWN Account Transfer from " + Acct_fro + " to " + Acct_to;
            }
            else if (type == "PRE")
            {
                //Expl_code = 102;
                Remarks1 = channel + " - PRE-REGISTERED Account Transfer from " + Acct_fro + " to " + Acct_to;
            }
            else if (type == "ANY")
            {
                //Expl_code = 102;
                Remarks1 = channel + " - ANY Account Transfer from " + Acct_fro + " to " + Acct_to;
            }
            else
            {
                //Expl_code = 102;
                Remarks1 = Remarks;
            }

            if (Remarks1.Length > 165)
            {
                Remarks1 = Remarks1.Substring(0, 165);
                //accountNo = callBasis.NubanToOldAcct(accountNo);
            }

            //BASIS callBasis = new BASIS();

            //Remarks1 = Remarks1 + " REF:" + callBasis.ConvertToNuban(Acct_fro) + transUniqIndenf.PadRight(15, '0');

            ResultStr = this.PostToBasis_Cal(t_from, t_to, T_amt, Expl_code, Remarks1, Req_code, supervisorID, tellerID, origtbrabracode, transUniqIndenf, channel, docAlp, Acct_fro, Acct_to, bankCode, docNum, inp_Period);

            if (ResultStr.CompareTo("@ERR7@") == 0 || ResultStr.CompareTo("@ERR19@") == 0)
            {
                //log output
                if (type == "OWN" || type == "PRE" || type == "ANY")
                {
                    LogTransfer(Acct_fro.Replace("/", "").Substring(0, 9), Acct_fro, Acct_to, Convert.ToDecimal(T_amt), channel, Remarks1);
                }

                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + basis.BasisError(ResultStr) + "</ERROR>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception exG1)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<ERROR>" + exG1.Message + "</ERROR>";
            xmlstring = xmlstring + "</Response>";

            ErrHandler.CalypsoPostLog("exG1 ~ " + exG1.Message);
        }

        return xmlstring;
    }

    public string PostToBasis_Cal(string Acct_from, string Acct_to, double Tra_amt, int Expl_code, string Remark, string Req_code, int supervisorID, int tellerID, int origtbraCode, string transUniqIndenf, string channel, string docAlp, string debitACC, string creditACC, string bankCode, string docNum, string inp_Period)
    {
        string result1 = string.Empty;
        long result2 = 0;
        long result3 = 0;
        string[] tempstrDebitAcc;
        string[] tempstrCreditAcc;

        tempstrDebitAcc = debitACC.Split('/');
        tempstrCreditAcc = creditACC.Split('/');

        if (Acct_from.Trim() == Acct_to.Trim())
        {
            ErrHandler.CalypsoPostLog("Acct_from = Acct_to for: " + Acct_from + "||" + Acct_to + "||" + Tra_amt.ToString() + "||" + origtbraCode + "||" + result2 + "||" + transUniqIndenf);
            return "@ERR-74@";
        }

        if (Tra_amt <= 0.0)
        {
            ErrHandler.CalypsoPostLog("Tra_amt <= 0.0 for: " + Acct_from + "||" + Acct_to + "||" + Tra_amt.ToString() + "||" + origtbraCode + "||" + result2 + "||" + transUniqIndenf);
            return "@ERR-74@";
        }

        using (OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
        {
            OracleTransaction transaction;
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            transaction = oraconn.BeginTransaction(IsolationLevel.ReadCommitted);
            try
            {
                OracleCommand oracomm = oraconn.CreateCommand();
                oracomm.CommandType = CommandType.StoredProcedure;
                oracomm.CommandTimeout = 45;

                //Start a local transaction and assign transaction object for a pending local transaction                
                oracomm.Transaction = transaction;
                oracomm.CommandText = "EONEPKG.GTBPBSC0_FULL";

                oracomm.Parameters.Add("INP_ACCT_FROM", OracleType.VarChar, 21).Value = Acct_from;
                oracomm.Parameters.Add("INP_ACCT_TO", OracleType.VarChar, 21).Value = Acct_to;
                oracomm.Parameters.Add("INP_TRA_AMT", OracleType.Double, 20).Value = Tra_amt;
                oracomm.Parameters.Add("INP_EXPL_CODE", OracleType.Int32, 15).Value = Expl_code;
                oracomm.Parameters.Add("INP_REMARKS", OracleType.VarChar, 200).Value = Remark;
                oracomm.Parameters.Add("inp_rqst_code", OracleType.VarChar, 15).Value = Req_code;
                oracomm.Parameters.Add("INP_MAN_APP1", OracleType.Int32, 15).Value = supervisorID;
                oracomm.Parameters.Add("inp_tell_id", OracleType.Int32, 15).Value = tellerID;
                oracomm.Parameters.Add("INP_DOC_ALP", OracleType.VarChar, 200).Value = docAlp;//CALY

                oracomm.Parameters.Add("inp_period", OracleType.Int32, 15).Value = inp_Period;
                oracomm.Parameters.Add("inp_bnk_code", OracleType.Int32, 15).Value = bankCode;
                oracomm.Parameters.Add("inp_doc_num", OracleType.Int32, 15).Value = docNum;

                oracomm.Parameters.Add("out_tra_seq1", OracleType.Int32, 15).Direction = ParameterDirection.Output;
                oracomm.Parameters.Add("inp_tra_seq1", OracleType.Int32, 15).Direction = ParameterDirection.Output;
                oracomm.Parameters.Add("INP_ORIGT_BRA_CODE", OracleType.Int32, 15).Value = origtbraCode;//999
                oracomm.Parameters.Add("out_return_status", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                oracomm.ExecuteNonQuery();
                result1 = oracomm.Parameters["OUT_RETURN_STATUS"].Value.ToString();

                if (result1.Trim().CompareTo("@ERR7@") == 0 || result1.Trim().CompareTo("@ERR19@") == 0)
                {
                    try
                    {
                        result2 = Convert.ToInt64(oracomm.Parameters["out_tra_seq1"].Value.ToString()); //Originating Transaction Sequence
                        result3 = Convert.ToInt64(oracomm.Parameters["inp_tra_seq1"].Value.ToString()); //Originating Transaction Sequence

                        if (result2 <= 0 || result3 <= 0)
                        {
                            transaction.Rollback();
                            ErrHandler.CalypsoPostLog(result1 + " returned from basis but sequence is zero for transaction" + " || Rolled back transaction for: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);
                            return "@ERR-74@";
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        ErrHandler.CalypsoPostLog(ex.Message + " || out_tra_seq1 or inp_tra_seq1 threw error. " + result1 + " || Rolled back transaction for: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);
                        return "@ERR-74@";
                    }

                    transaction.Commit();
                    ErrHandler.CalypsoPostLog("Commit operation successful for: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);

                    return result1;
                }
                else
                {
                    transaction.Rollback();
                    ErrHandler.CalypsoPostLog(result1 + " || Rolled back transaction for: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);
                    return result1;
                }
            }
            catch (Exception exG2)
            {
                transaction.Rollback();
                ErrHandler.CalypsoPostLog(exG2.Message + "|| Rolled back transaction: " + Acct_from + "," + Acct_to + "," + Tra_amt.ToString() + "," + origtbraCode + "," + result2 + "," + result3 + "," + transUniqIndenf);
                result1 = exG2.Message;
                return result1;
            }
            finally
            {
                oraconn.Close();
            }
        }
    }

    public ObjectATMHotlist ATM_HotlistCard(string phone, string pin, string terminalId)
    {
        string reqTime = DateTime.Now.ToString("yyyy-MMM-dd hh:mm:ss.fff tt");
        string fullAccount = string.Empty;
        BASIS basis = new BASIS();
        ObjectATMHotlist objResp = new ObjectATMHotlist();
        DataTable tableAcc = new DataTable();
        string braCode = string.Empty;
        string cusNum = string.Empty;
        string curCode = string.Empty;
        string ledCode = string.Empty;
        string subAcct = string.Empty;
        DataSet setCusDetail = new DataSet();
        Encrypt enc = new Encrypt();
        string classMeth = "Eone|ATM_HotlistCard";

        string panOne = string.Empty;
        string panLastFour = string.Empty;
        string seqNo = string.Empty;
        string expiry = string.Empty;
        string cardId = string.Empty;
        string cardidd_value = string.Empty;
        string cardHolderName = string.Empty;
        bool cardGotten = false;
        string processInfo = string.Empty;
        string iddV = string.Empty;
        string panEncr = string.Empty;
        int hotListResp = 0;
        string pPAN = string.Empty;
        long customerID = 0;
        int responseCode = 41;
        string uniqueCode = string.Empty;
        string tableName = string.Empty;
        string hotlist_BankCard = string.Empty;
        int count = 0;

        try
        {
            tableAcc = basis.GetAccountNo_UsingPhoneNo(phone);
            if (tableAcc == null)
            {
                objResp.code = 9991;
                objResp.message = "Cannot validate customer details, please try again.";
                return objResp;
            }

            if (tableAcc.Rows.Count <= 0)
            {
                objResp.code = 9991;
                objResp.message = "Cannot retrieve customer details, please try again.";
                return objResp;
            }

            foreach (DataRow dtItem in tableAcc.Rows)
            {
                braCode = dtItem["BranchCode"].ToString();
                cusNum = dtItem["CustomerNo"].ToString();
                customerID = Convert.ToInt64((braCode + cusNum));

                setCusDetail = GetCustomerDetail_ATMHotList(braCode, cusNum);
                DataTable tableMerge = new DataTable();

                foreach (DataTable mItem in setCusDetail.Tables)
                {
                    tableMerge.Merge(mItem);
                }

                foreach (DataRow item in tableMerge.Rows)
                {
                    panEncr = item["pan1"].ToString();
                    panOne = enc.Decrypt_TrpDes(panEncr);
                    string hotlistedBefore = item["hotlisted_by"].ToString();

                    if (!string.IsNullOrEmpty(hotlistedBefore))
                    {
                        objResp.code = 1012;
                        objResp.message = "Card has already been hotlisted(from bankCard). hotlisted_by = " + hotlistedBefore;
                        return objResp;
                    }

                    try
                    {
                        panLastFour = panOne.Substring(panOne.Length - 4, 4);
                    }
                    catch (Exception)
                    {
                    }

                    if (panLastFour == pin)
                    {
                        seqNo = item["seqNo"].ToString();
                        expiry = item["expiry"].ToString();
                        cardId = item["card_Id"].ToString();
                        iddV = item["cardidd_value"].ToString();
                        cardidd_value = enc.Decrypt_TrpDes(iddV);
                        cardHolderName = item["cardholder_name"].ToString();
                        tableName = item["tableName"].ToString();
                        cardGotten = true;

                        break;
                    }

                    count++;
                }

                if (cardGotten == true)
                {
                    processInfo = "panEncr=" + panEncr + "|seqNo=" + seqNo + "|expiry=" + expiry + "|cardId=" + cardId + "|iddV=" + iddV + "|cardHolderName=" + cardHolderName + "|cardGotten=" + cardGotten.ToString() + "|tableName=" + tableName;
                    ErrHandler.Log(classMeth, phone, processInfo);
                    break;
                }
            }

            if (cardGotten == false && count > 0)
            {
                objResp.code = 1013;
                objResp.message = "There is no valid card tied to the details provided, please try again.";
                return objResp;
            }

            if (cardGotten == false)
            {
                objResp.code = 1002;
                objResp.message = "There is no valid card tied to the details provided, please try again.";
                return objResp;
            }

            pPAN = cardidd_value.Substring(0, 6) + panOne;
            hotListResp = HotlistCard(pPAN, customerID, expiry.Substring(2, 2) + expiry.Substring(0, 2), seqNo, responseCode);

            if (hotListResp == 5)//Fep: hotlist succesful
            {
                hotlist_BankCard = Hotlist_UpdateBankCard(tableName, responseCode, panEncr, expiry, seqNo, braCode, cusNum, phone);

                if (hotlist_BankCard == "1")
                {
                    objResp.code = 1000;
                    objResp.message = "FEB = 5 and BankCard = " + hotlist_BankCard;
                    return objResp;
                }
                else
                {
                    objResp.code = 1000;
                    objResp.message = "FEB = 5 and bankCard = " + hotlist_BankCard;
                    return objResp;
                }
            }
            else if (hotListResp == 4)//Fep: Inactive
            {
                objResp.code = 1010;
                objResp.message = "FEB = 4, Inactive card";
                return objResp;
            }
            else if (hotListResp == 6)//Fep: Alreadey Hotlisted
            {
                objResp.code = 1011;
                objResp.message = "FEB = 6, Alreadey Hotlisted";
                return objResp;
            }
            else if (hotListResp == 7)//Fep: Error Hotlisting
            {
                objResp.code = 1012;
                objResp.message = "FEB = 7, Error Hotlisting";
                return objResp;
            }
        }
        catch (Exception exG)
        {
            ErrHandler.Log(classMeth, phone, exG.Message + Environment.NewLine + exG.StackTrace);
            objResp.code = 9999;
            objResp.message = exG.Message.Replace("'", "");
            return objResp;
        }
        finally
        {
            bool insertResult = this.Insert_ATMHotlist(customerID, phone, reqTime, DateTime.Now.ToString("yyyy-MMM-dd hh:mm:ss.fff tt"), terminalId, objResp.code, objResp.message, panEncr, iddV, cardId, seqNo, expiry, cardHolderName, tableName);
            ErrHandler.Log(classMeth + "|finally", phone, "insertResult = " + insertResult);
        }

        return objResp;
    }

    public DataSet GetCustomerDetail_ATMHotList(string braCode, string cusNum)
    {
        string classMeth = "Eone|GetCustomerDetail_ATMHotList";
        DataSet dtSet = new DataSet();
        string tDay = DateTime.Now.AddYears(-4).Date.ToString("yyyy-MM-dd");

        using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BankcardConnString"].ToString()))
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "GetCardDetails_ATMHotlist";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = conn;
            cmd.CommandTimeout = 20;
            cmd.Parameters.AddWithValue("@braCode", braCode);
            cmd.Parameters.AddWithValue("@cusNum", cusNum);
            cmd.Parameters.AddWithValue("@pExp", tDay);

            SqlDataAdapter adpt = null;

            try
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                adpt = new SqlDataAdapter(cmd);
                adpt.Fill(dtSet);
                return dtSet;
            }
            catch (Exception ex)
            {
                ErrHandler.Log(classMeth, braCode + cusNum + "01", ex.Message);
                return dtSet;
            }
            finally
            {
                if (conn.State != ConnectionState.Closed)
                    conn.Close();
            }
        }

    }

    public bool Insert_ATMHotlist(long customerId, string phoneNo, string requestTime, string responseTime, string terminalId, Int32 responseCode, string respMessage,
        string pan1, string cardIdd_Value, string cardId, string seqNo, string expiry, string customerName, string tableName)
    {
        string classMethod = "Eone|Insert_ATMHotlist";

        try
        {
            using (SqlConnection conn1 = new SqlConnection(ConfigurationManager.AppSettings["ATMSERVICE_CONN"]))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "INSERT_ATMHotlist";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn1;
                cmd.CommandTimeout = 30;
                cmd.Parameters.AddWithValue("@customerId", customerId);
                cmd.Parameters.AddWithValue("@phoneNo", phoneNo);
                cmd.Parameters.AddWithValue("@requestTime", requestTime);
                cmd.Parameters.AddWithValue("@responseTime", responseTime);
                cmd.Parameters.AddWithValue("@terminalId", terminalId);
                cmd.Parameters.AddWithValue("@responseCode", responseCode);
                cmd.Parameters.AddWithValue("@respMessage", respMessage);
                cmd.Parameters.AddWithValue("@pan1", pan1);
                cmd.Parameters.AddWithValue("@cardIdd_Value", cardIdd_Value);
                cmd.Parameters.AddWithValue("@cardId", cardId);
                cmd.Parameters.AddWithValue("@seqNo", seqNo);
                cmd.Parameters.AddWithValue("@expiry", expiry);
                cmd.Parameters.AddWithValue("@customerName", customerName);
                cmd.Parameters.AddWithValue("@tableName", tableName);

                try
                {
                    if (conn1.State == ConnectionState.Closed)
                    {
                        conn1.Open();
                    }

                    try
                    {
                        int exeRes = cmd.ExecuteNonQuery();

                        if (exeRes == 1)
                        {
                            return true;
                        }
                    }
                    catch (SqlException ex)
                    {
                        ErrHandler.Log(classMethod + "|ex1", phoneNo, ex.Message);
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    ErrHandler.Log(classMethod + "|ex2", phoneNo, ex.Message);
                    return false;
                }
                finally
                {
                    if (conn1.State != ConnectionState.Closed)
                        conn1.Close();
                }
            }
        }
        catch (Exception ex)
        {
            ErrHandler.Log(classMethod + "|ex3", phoneNo, ex.Message);
            return false;
        }

        return false;
    }

    public string Hotlist_UpdateBankCard(string table, Int32 pResponseCode, string pan1, string expiry, string seqNo, string branchCode, string customerNo, string phone)
    {
        string resp = string.Empty;
        string classMeth = "Eone|Hotlist_UpdateBankCard";

        try
        {
            string Sql = "Update " + table + " set CardStatusID = " + pResponseCode + "," + " Hotlisted_By = " + branchCode + customerNo + "," + " Date_Hotlisted=getdate() " +
            " where  pan1 = '" + pan1 + "'" + " and Expiry = '" + expiry + "' and Seqno = " + seqNo + " and Branch_Code = " + branchCode + " and customer_no = " + customerNo;

            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BankcardConnString"].ToString()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandTimeout = 20;

                cmd.CommandText = Sql;
                cmd.CommandType = CommandType.Text;
                resp = cmd.ExecuteNonQuery().ToString();

                conn.Close();
            }
        }
        catch (Exception ex)
        {
            ErrHandler.Log(classMeth, phone, ex.Message + Environment.NewLine + ex.StackTrace);
            resp = ex.Message;
        }

        return resp;
    }

    // method to calculate Eligibity Amount for Max Advance Customers
    public string MaxAdvanceEligibityDetails(double intrate, string tenor, double monthSalAmount, double debitServiceRatio, string channel)
    {
        try
        {
            string bal = string.Empty;
            int tenorValue;
            double tenor1;
            string position = string.Empty;
            string position2 = string.Empty;
            double interestfactor1;
            double expInterestfactor;

            string response = string.Empty;

            //channelExist = ValidateListofValues(ConfigurationManager.AppSettings["FXCHANNEL"], 1, channel);

            if (!(int.TryParse(tenor, out tenorValue)))
            {
                return "<Response><CODE>1001</CODE><ERROR>Invalid Tenor. Tenor must be a valid number in months</ERROR></Response>";
            }

            //if (intrate <= 0 || intrate > 100)
            //{
            //    return "<Response><CODE>1001</CODE><ERROR>Interest Rate must be between 0 and 100. It is recorded in percentage</ERROR></Response>";
            //}
            //if (debitServiceRatio <= 0 || debitServiceRatio > 100)
            //{
            //    return "<Response><CODE>1001</CODE><ERROR>Debit Service Ratio Rate must be between 0 and 100. It is recorded in percentage</ERROR></Response>";
            //}




            try
            {
                // calculate interest factor
                interestfactor1 = (intrate / 12) / 100;
                double interestfactor = Math.Round(interestfactor1, 4);

                // calculate exponential value
                tenor1 = Convert.ToDouble(tenor);
                double eValue = 1 + interestfactor1;
                expInterestfactor = Math.Pow(eValue, tenor1);
                double dValue = 1 / expInterestfactor;
                double cValue = 1 - dValue;
                double repaymentFactor1 = cValue / interestfactor1;
                double repaymentFactor = Math.Round(repaymentFactor1, 4);

                double maxAllowedRepayment1 = (debitServiceRatio * monthSalAmount) / 100;
                double maxAllowedRepayment = Math.Round(maxAllowedRepayment1, 4);

                double maxLoanAmt1 = maxAllowedRepayment1 * repaymentFactor1;
                double maxLoanAmt = Math.Round(maxLoanAmt1, 4);
                return "<Response><CODE>1000</CODE><MAXALLOWEDREPAYMENT>" + maxAllowedRepayment + "</MAXALLOWEDREPAYMENT><MAXLOANAMT>" + maxLoanAmt + "</MAXLOANAMT><INTFACTOR>" + interestfactor + "</INTFACTOR><REPAYFACTOR>" + repaymentFactor + "</REPAYFACTOR></Response>";
            }
            catch (Exception ex)
            {
                return "<Response><CODE>1002</CODE><ERROR>An error occurred." + ex.Message.Replace("'", "") + "</ERROR><POSITION>" + position + "</POSITION></Response>";
            }

        }
        catch (Exception ex)
        {
            return "<Response><CODE>1002</CODE><ERROR>An error occurred." + ex.Message.Replace("'", "") + "</ERROR><POSITION></POSITION></Response>";
        }
    }

    public string APRandRepaymentAmountForMaxAdvance(double intrate, string tenor, double managementfee, double commitmentfee, double insurancerate, double loanAmt, string channel)
    {
        try
        {
            string bal = string.Empty;
            int tenorValue;
            double tenor1;


            string response = string.Empty;

            //channelExist = ValidateListofValues(ConfigurationManager.AppSettings["FXCHANNEL"], 1, channel);

            if (!(int.TryParse(tenor, out tenorValue)))
            {
                return "<Response><CODE>1001</CODE><ERROR>Invalid Tenor. Tenor must be a valid number in months</ERROR></Response>";
            }
            //if (intrate <= 0 || intrate > 100)
            //{
            //    return "<Response><CODE>1001</CODE><ERROR>Interest Rate must be between 0 and 100. It is recorded in percentage</ERROR></Response>";
            //}
            //if (insurancerate <= 0 || insurancerate > 100)
            //{
            //    return "<Response><CODE>1001</CODE><ERROR>Insurance Rate must be between 0 and 100. It is recorded in percentage</ERROR></Response>";
            //}


            try
            {
                // calculate interest factor
                //interestfactor1 = (intrate / 12) / 100;
                //double interestfactor = Math.Round(interestfactor1, 4);
                tenor1 = Convert.ToDouble(tenor);
                double tenorYears = ((Convert.ToDouble(tenor)) / 12);
                double committmentfee1 = commitmentfee / tenorYears;
                double insurancerate1 = insurancerate / tenorYears;

                double APR = committmentfee1 + managementfee + insurancerate1 + intrate;

                // calculate repayment value
                double monthrate = (intrate / 12) / 100;
                double monthrate1 = Math.Round(monthrate, 4);
                //double num = monthrate1 * (monthrate1 + 1);
                double numerator = monthrate * Math.Pow((monthrate + 1), tenor1);
                double den = (monthrate + 1);
                double denominate = Math.Pow(den, tenor1);
                double denominator = denominate - 1;
                double repayment = numerator / denominator * loanAmt;
                double repaymentAmount = Math.Round(repayment, 2);

                return "<Response><CODE>1000</CODE><APR>" + APR + "</APR><REPAYMENTAMT>" + repaymentAmount + "</REPAYMENTAMT></Response>";
            }
            catch (Exception ex)
            {
                return "<Response><CODE>1002</CODE><ERROR>An error occurred." + ex.Message.Replace("'", "") + "</ERROR></Response>";
            }

        }
        catch (Exception ex)
        {
            return "<Response><CODE>1002</CODE><ERROR>An error occurred." + ex.Message.Replace("'", "") + "</ERROR></Response>";
        }
    }

    public DataTable getexchangerate()
    {
        SqlConnection conn;
        SqlCommand comm;
        DataTable ds = new DataTable();
        SqlDataAdapter adpt;

        try
        {
            conn = new SqlConnection(ConfigurationManager.AppSettings["CnnRealtime"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            string query = "gtb_get_currency_rates";
            comm = new SqlCommand(query, conn);
            //comm.Parameters.AddWithValue("@customer_id", bra_code + cus_num);
            comm.CommandType = CommandType.StoredProcedure;

            adpt = new SqlDataAdapter(comm);
            ds.TableName = "Exchangerate";
            adpt.Fill(ds);


        }
        catch (Exception ex)
        {
            ds.TableName = "Exchangerate";
        }

        return ds;
    }

}
