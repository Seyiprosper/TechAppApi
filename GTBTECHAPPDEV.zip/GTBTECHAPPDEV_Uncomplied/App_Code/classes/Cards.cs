﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using EncryptionLib;
using System.Configuration;
using System.Data.OracleClient;

/// <summary>
/// Summary description for Cards
/// </summary>
public class Cards
{
    ErrHandler ErrWriter = new ErrHandler();

	public Cards()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    //(string pPAN, string pSeqNo, string pExpiry, string pAccountID, string pAccountType, string pCurrencyCode, string RequestBy, string pCardVal2, string pUniqueID, string pLinkType, string pTBPostFix)

    public string PAN { get; set; }
    public string SeqNo { get; set; }
    public string Expiry { get; set; }
    public string AccountID { get; set; }
    public string AccountType { get; set; }
    public string CurrencyCode { get; set; }
    public string RequestBy { get; set; }
    public string CardVal { get; set; }
    public string UniqueID { get; set; }
    public string LinkType { get; set; }
    public string TBPostFix { get; set; }


    //public int LinkingUnlinkCard(string pPAN, string pSeqNo, string pExpiry, string pAccountID, string pAccountType, string pCurrencyCode, string RequestBy, string pCardVal2, string pUniqueID, string pLinkType, string pTBPostFix)
    //{
    //  var ConPostcard = new SqlConnection(ConfigurationManager.AppSettings["CnnPostcard"]);

    //    var _Encrypt = new Encrypt();
    //    int functionReturnValue = 0;
    //    //exec GTB_Acct_Linking2 '6277870120907205737','004','1007','209072057301000200','20','556','1234'
    //    SqlCommand sqlSelect = new SqlCommand();
    //    Random RandomNo = new Random();
    //    SqlParameter pmPAN = new SqlParameter("@Pan", (pPAN + _Encrypt.Decrypt_TrpDes(pCardVal2)).Trim());
    //    SqlParameter pmExpiry = new SqlParameter("@expiry_date", pExpiry.Substring(2,2) + pExpiry.Substring(0,2));
    //    SqlParameter pmSeqNo = new SqlParameter("@seq_nr", pSeqNo.PadLeft(3, '0'));
    //    SqlParameter pmAccountID = new SqlParameter("@AccountID", pAccountID);
    //    SqlParameter pmAccountType = new SqlParameter("@AccountType", pAccountType);
    //    SqlParameter pmCurrencyCode = new SqlParameter("@CurrencyCode", pCurrencyCode);
    //    SqlParameter pmUpdatedBy = new SqlParameter("@UserID", RequestBy);
    //    SqlParameter pmCuustID = new SqlParameter("@CUstID", pUniqueID);
    //    string errStr = null;
    //    int mResponse = 0;
    //    string Sql = "";
    //    try
    //    {
    //        sqlSelect.Parameters.Add(pmPAN);
    //        sqlSelect.Parameters.Add(pmExpiry);
    //        sqlSelect.Parameters.Add(pmSeqNo);
    //        sqlSelect.Parameters.Add(pmAccountID);
    //        sqlSelect.Parameters.Add(pmAccountType);
    //        sqlSelect.Parameters.Add(pmCurrencyCode);
    //        sqlSelect.Parameters.Add(pmUpdatedBy);
    //        sqlSelect.Parameters.Add(pmCuustID);
    //        if (ConPostcard.State == ConnectionState.Closed)
    //        {
    //            ConPostcard.Open();
    //        }
    //        sqlSelect.Connection = ConPostcard;
    //        if (pLinkType == "1")
    //        {
    //            if (pTBPostFix.Equals("_MasterCard", StringComparison.OrdinalIgnoreCase))
    //            {
    //                sqlSelect.CommandText = "GTB_Acct_Linking";
    //            }
    //            else if  (pTBPostFix.Equals("_MasterCardTempCard", StringComparison.OrdinalIgnoreCase))  
    //            {
    //                sqlSelect.CommandText = "GTB_Acct_Linking_TempCard";
    //            }
    //            else if  (pTBPostFix.Equals("_UtilityCard", StringComparison.OrdinalIgnoreCase))    
    //            {
    //                sqlSelect.CommandText = "GTB_Acct_Linking_UtilityCard";
    //            }
    //            else if (pTBPostFix.Equals("_VirtualCard", StringComparison.OrdinalIgnoreCase))
    //            {
    //                sqlSelect.CommandText = "GTB_Acct_Linking_VirtualCard";
    //            }
    //        }
    //        else if (pLinkType == "3")
    //        {
    //            if  (pTBPostFix.Equals("_MasterCard", StringComparison.OrdinalIgnoreCase))     
    //            {
    //                sqlSelect.CommandText = "GTB_Acct_UnLinking";
    //            }
    //            else if  (pTBPostFix.Equals("_MasterCardTempCard", StringComparison.OrdinalIgnoreCase))   
    //            {
    //                sqlSelect.CommandText = "GTB_Acct_UnLinking_TempCard";
    //            }
    //            else if  (pTBPostFix.Equals("_UtilityCard", StringComparison.OrdinalIgnoreCase))     
    //            {
    //                sqlSelect.CommandText = "GTB_Acct_UnLinking_UtilityCard";
    //            }
    //            else if (pTBPostFix.Equals("_VirtualCard", StringComparison.OrdinalIgnoreCase))
    //            {
    //                sqlSelect.CommandText = "GTB_Acct_Linking_VirtualCard";
    //            }
    //        }
    //        sqlSelect.CommandType = CommandType.StoredProcedure;
    //        mResponse = Convert.ToInt16(sqlSelect.ExecuteScalar());
    //        functionReturnValue = mResponse;
    //    }
    //    catch (Exception ex)
    //    {
    //        errStr = ex.Message + "Stack trace" + ex.StackTrace;
    //        ErrHandler.WriteError(errStr);
    //        functionReturnValue = -100;
          
    //    }
    //    finally
    //    {
    //        if (ConPostcard.State == ConnectionState.Open)
    //        {
    //            ConPostcard.Close();
    //        }
    //    }
    //    return functionReturnValue;
    //}

    public string CreateUtility(int braCode, int cusNum)
    {

        int Result = 1;
        int subAcct = 1;

        using (OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
        {
            using (OracleCommand oracomm = new OracleCommand("EONEPKG.GTBCIR30", oraconn))
            {
                oracomm.CommandType = CommandType.StoredProcedure;
                try
                {
                    if (oraconn.State == ConnectionState.Closed)
                    {
                        oraconn.Open();
                    }
                    oracomm.Parameters.Add("INP_BRA_CODE", OracleType.Number, 15).Value = braCode;
                    oracomm.Parameters.Add("INP_CUS_NUM", OracleType.Number, 15).Value = cusNum;
                    oracomm.Parameters.Add("INP_CUR_CODE", OracleType.Number, 15).Value = 1;
                    oracomm.Parameters.Add("INP_LED_CODE", OracleType.Number, 15).Value = 5011;
                    oracomm.Parameters.Add("INP_TELL_ID", OracleType.Number, 15).Value = 9005;
                    oracomm.Parameters.Add("OUT_SUB_ACCT_CODE", OracleType.Number, 15).Direction = ParameterDirection.Output;
                    oracomm.Parameters.Add("OERR_FLAG", OracleType.Number, 15).Direction = ParameterDirection.Output;

                    oracomm.ExecuteNonQuery();

                    subAcct = Convert.ToInt32(oracomm.Parameters["OUT_SUB_ACCT_CODE"].Value.ToString());
                    Result = Convert.ToInt32(oracomm.Parameters["OERR_FLAG"].Value.ToString());

                }
                catch (Exception ex)
                {
                    ErrHandler.WriteError("Error Message" + ex.Message + " Error Source: " + ex.Source + " Stack Trace " + ex.StackTrace);

                }
                finally
                {
                    oraconn.Close();
                }
                return Result.ToString() + ":" + subAcct.ToString();
            }
        }
    }

    //public DataTable CardTransactions(string whereClause, SqlWebParameter[] sqlParam)
    //{
    //    DataTable result = new DataTable("Tranx");
    //    string Result = string.Empty;
    //    SqlConnection oraconn = new SqlConnection(ConfigurationManager.AppSettings["CnnOffice"]);
    //    string selectQuery = "select * from tranx_details_CRM ";
    //    string fullQuery = selectQuery + whereClause;
    //    SqlCommand comm = new SqlCommand(fullQuery, oraconn);
    //    comm.CommandType = CommandType.Text;
    //    try
    //    {
    //        if (oraconn.State == ConnectionState.Closed)
    //        {
    //            oraconn.Open();
    //        }
    //        foreach (var item in sqlParam)
    //        {
    //            comm.Parameters.Add(new SqlParameter(item.ParameterName, item.Value));
    //        }

    //        SqlDataReader reader = comm.ExecuteReader();
    //        result.Load(reader);

    //        return result;

    //    }
    //    catch (Exception ex)
    //    {
    //        ErrHandler.WriteError(string.Format("Error getting card transactions with message ==> {0} and stack trace ==> {1}", ex.Message, ex.StackTrace));

    //    }
    //    finally
    //    {
    //        oraconn.Close();
    //    }

    //    return result;
    //}

    public int LinkingUnlinkCard(string pPAN, string pSeqNo, string pExpiry, string pAccountID, string pAccountType, string pCurrencyCode, string RequestBy, string pCardVal2, string pUniqueID, string pLinkType, string pTBPostFix)
    {
        var ConPostcard = new SqlConnection(ConfigurationManager.AppSettings["CnnPostcard"]);

        var _Encrypt = new Encrypt();
        int functionReturnValue = 0;
        //exec GTB_Acct_Linking2 '6277870120907205737','004','1007','209072057301000200','20','556','1234'
        SqlCommand sqlSelect = new SqlCommand();
        Random RandomNo = new Random();
        SqlParameter pmPAN = new SqlParameter("@Pan", (pPAN + _Encrypt.Decrypt_TrpDes(pCardVal2)).Trim());
        SqlParameter pmExpiry = new SqlParameter("@expiry_date", pExpiry.Substring(2, 2) + pExpiry.Substring(0, 2));
        SqlParameter pmSeqNo = new SqlParameter("@seq_nr", pSeqNo.PadLeft(3, '0'));
        SqlParameter pmAccountID = new SqlParameter("@AccountID", pAccountID);
        SqlParameter pmAccountType = new SqlParameter("@AccountType", pAccountType);
        SqlParameter pmCurrencyCode = new SqlParameter("@CurrencyCode", pCurrencyCode);
        SqlParameter pmUpdatedBy = new SqlParameter("@UserID", RequestBy);
        SqlParameter pmCuustID = new SqlParameter("@CUstID", pUniqueID);
        string errStr = null;
        int mResponse = 0;
        string Sql = "";
        try
        {
            sqlSelect.Parameters.Add(pmPAN);
            sqlSelect.Parameters.Add(pmExpiry);
            sqlSelect.Parameters.Add(pmSeqNo);
            sqlSelect.Parameters.Add(pmAccountID);
            sqlSelect.Parameters.Add(pmAccountType);
            sqlSelect.Parameters.Add(pmCurrencyCode);
            sqlSelect.Parameters.Add(pmUpdatedBy);
            if (!pTBPostFix.Equals("_MasterCard", StringComparison.OrdinalIgnoreCase))
            {
                sqlSelect.Parameters.Add(pmCuustID);
            }

            if (ConPostcard.State == ConnectionState.Closed)
            {
                ConPostcard.Open();
            }
            sqlSelect.Connection = ConPostcard;
            if (pLinkType == "1")
            {
                if (pTBPostFix.Equals("_MasterCard", StringComparison.OrdinalIgnoreCase))
                {
                    sqlSelect.CommandText = "GTB_Acct_Linking";
                }
                else if (pTBPostFix.Equals("_MasterCardTempCard", StringComparison.OrdinalIgnoreCase))
                {
                    sqlSelect.CommandText = "GTB_Acct_Linking_TempCard";
                }
                else if (pTBPostFix.Equals("_UtilityCard", StringComparison.OrdinalIgnoreCase))
                {
                    sqlSelect.CommandText = "GTB_Acct_Linking_UtilityCard";
                }
                else if (pTBPostFix.Equals("_VirtualCard", StringComparison.OrdinalIgnoreCase))
                {
                    sqlSelect.CommandText = "GTB_Acct_Linking_VirtualCard";
                }
            }
            else if (pLinkType == "3")
            {
                if (pTBPostFix.Equals("_MasterCard", StringComparison.OrdinalIgnoreCase))
                {
                    sqlSelect.CommandText = "GTB_Acct_UnLinking";
                }
                else if (pTBPostFix.Equals("_MasterCardTempCard", StringComparison.OrdinalIgnoreCase))
                {
                    sqlSelect.CommandText = "GTB_Acct_UnLinking_TempCard";
                }
                else if (pTBPostFix.Equals("_UtilityCard", StringComparison.OrdinalIgnoreCase))
                {
                    sqlSelect.CommandText = "GTB_Acct_UnLinking_UtilityCard";
                }
                else if (pTBPostFix.Equals("_VirtualCard", StringComparison.OrdinalIgnoreCase))
                {
                    sqlSelect.CommandText = "GTB_Acct_Linking_VirtualCard";
                }
            }
            sqlSelect.CommandType = CommandType.StoredProcedure;
            mResponse = Convert.ToInt16(sqlSelect.ExecuteScalar());
            functionReturnValue = mResponse;
        }
        catch (Exception ex)
        {
            errStr = ex.Message + "Stack trace" + ex.StackTrace;
            ErrHandler.WriteError(errStr);
            functionReturnValue = -100;

        }
        finally
        {
            if (ConPostcard.State == ConnectionState.Open)
            {
                ConPostcard.Close();
            }
        }
        return functionReturnValue;
    }

    public DataSet CardTransactions(string bracode, string cus_num, string cur_code, string led_code, string sub_acct, string pan, DateTime begin, DateTime end, string status)
    {
        //DataTable result = new DataTable("Tranx");
        DataSet result = new DataSet();
        //string Result = string.Empty;
        SqlDataAdapter adpt;
        SqlConnection oraconn = new SqlConnection(ConfigurationManager.AppSettings["CnnOffice"]);

        SqlCommand sqlSelect = new SqlCommand();
        SqlParameter pmBRACODE = new SqlParameter("@bra_code", bracode);
        SqlParameter pmCUSNUM = new SqlParameter("@cus_num", cus_num);
        SqlParameter pmCurcode = new SqlParameter("@cur_code", cur_code);
        SqlParameter pmLedcode = new SqlParameter("@led_code", led_code);
        SqlParameter pmSubacct = new SqlParameter("@sub_acct_code", sub_acct);
        SqlParameter pmPAN = new SqlParameter("@Pan", pan);
        SqlParameter pmBEGIN = new SqlParameter("@begin", begin);
        SqlParameter pmEND = new SqlParameter("@end", end);
        SqlParameter pmSTATUS = new SqlParameter("@status", status);

        try
        {
            sqlSelect.Parameters.Add(pmBRACODE);
            sqlSelect.Parameters.Add(pmCUSNUM);
            sqlSelect.Parameters.Add(pmCurcode);
            sqlSelect.Parameters.Add(pmLedcode);
            sqlSelect.Parameters.Add(pmSubacct);
            if (pan != "")
            {
                sqlSelect.Parameters.Add(pmPAN);
            }
            sqlSelect.Parameters.Add(pmBEGIN);
            sqlSelect.Parameters.Add(pmEND);
            sqlSelect.Parameters.Add(pmSTATUS);

            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            sqlSelect.Connection = oraconn;

            sqlSelect.CommandText = "gtb_trx_details_proc";
            sqlSelect.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(sqlSelect);
            adpt.Fill(result);

        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(string.Format("Error getting card transactions with message ==> {0} and stack trace ==> {1}", ex.Message, ex.StackTrace));

        }
        finally
        {
            oraconn.Close();
        }

        return result;
    }

}