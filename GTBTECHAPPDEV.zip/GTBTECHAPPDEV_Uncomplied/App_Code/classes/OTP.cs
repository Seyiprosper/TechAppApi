﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data.OracleClient;
using System.IO;
using System.Text;
using System.Net.Mail;
using System.Net.Mime;
using APPDEVDLL;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;
using Microsoft.VisualBasic;
using System.Security.Cryptography;

/// <summary>
/// Summary description for OTP
/// </summary>
public class OTP
{
	public OTP ()
	{
        
	}

    BASIS callBasis = new BASIS();
    Eone eone = new Eone();

    public string GenerateOTP(int braCode, int cusNum, string channel, int otpLength, string transID, string terminalID)
    {
        string response = string.Empty;
        string otp_key = string.Empty;
        string[] arrayAcct;

        try
        {
            int channelValid = 0;
            string chan = ConfigurationManager.AppSettings["OTPCHANNEL"];
            string[] channelArr = chan.Split(',');

            foreach (string arr in channelArr)
            {
                if (arr.ToUpper().Trim() == channel.ToUpper().Trim())
                {
                    channelValid = 1;
                    break;
                }
            }

            if (channelValid != 1)
            {
                ErrHandler.WriteError("Invalid channel, kindly check web config, OTPCHANNEL");
                return response;
            }

            string firstRan = "1";
            string secondRan = "9";
            int lim = otpLength - 3;

            Random ran = new Random();
            for (int i = 1; i < lim; i++)
            {
                firstRan += "0";
                secondRan += "9";
            }

            int _intRan = ran.Next(Convert.ToInt32(firstRan), Convert.ToInt32(secondRan));
            string otpCode = DateTime.Now.Millisecond.ToString().PadRight(3, '7') + _intRan.ToString();
            string _strMsg = "Please use the OTP code: " + Convert.ToInt64(otpCode.Trim()).ToString() + " to complete your transaction. OTP code expires after 10 minutes.";
            string _strSendSMS = string.Empty;
            string userID = string.Empty;
            userID = braCode.ToString() + cusNum.ToString() + "01" ;

            _strSendSMS = SendOTPSMS(braCode, cusNum, _strMsg);
            if (_strSendSMS.Split(',').GetLength(0) == 2)
            {
                ErrHandler.WriteError("Successfully sent OTP(GenerateOTP) via SMS to USERID = " + userID);
                otp_key = System.Guid.NewGuid().ToString("N");
                string otp_encrypt = EncryptPIN(Convert.ToInt64(otpCode.Trim()).ToString(), otp_key);
                string[] _strArray;
                _strArray = _strSendSMS.Trim().Split(',');
                if (InsertOTPTransCode(Convert.ToInt64(userID), otp_encrypt, _strArray.GetValue(1).ToString(), otp_key, channel, transID, terminalID))
                {
                    ErrHandler.WriteError("Successfully inserted OTP(GenerateOTP) Code to Eone db for USERID = " + userID + " || " + _strSendSMS);
                    return "Sent";
                }
                else
                {
                    ErrHandler.WriteError("Unable to Insert OTP(GenerateOTP) to E-one table for USERID = " + userID);
                    return "OTP not successful";
                }
            }
            else
            {
                ErrHandler.WriteError("(GenerateOTP)Unable to send SMS for USERID = " + userID + ". Response = " + _strSendSMS);
                return "OTP not successful";
            }

        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message);
        }

        return response;
    }

    public string ValidateOTP(int braCode, int cusNum, string _strOTP, string transID, string terminalID)
    {
        string response = string.Empty, oldAcct = string.Empty, ret_val = string.Empty; //, otp_key;
        string[] arrayAcct;

        try
        {
            string userID = braCode.ToString() + cusNum.ToString() + "01";

            if (braCode.ToString().Length != 3 || cusNum.ToString().Length < 6)
            {
                ErrHandler.WriteError(" Invalid bracode or cusnum for USERID = " + userID); 
                return "Invalid account";
            }

            if (_strOTP.Trim().Length < 6)
            {
                return "Invalid OTP";
            }

            ret_val = VerifyTransCodeOPT(Convert.ToInt64(userID), Convert.ToInt64(_strOTP), transID, terminalID);

            if (ret_val.Trim().CompareTo("SUCCESS") == 0)
            {
                ErrHandler.WriteError("Successfully validated SMS(GenerateOTP) OTP for USERID = " + userID);
                if (UpdateOTPTransCode(Convert.ToInt64(userID), Convert.ToInt64(_strOTP), transID, terminalID))
                {
                    return "Validated";
                }
                else
                {
                    ErrHandler.WriteError("Successfully validated SMS(GenerateOTP) OTP for USERID = " + userID + " . However we could not update db");
                    return "OTP validation not Successful";
                }
            }
            else
            {
                ErrHandler.WriteError("Unable to validate  or SMS OTP for USERID = " + userID);
                return "OTP validation not Successful";
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message);
            return "OTP validation not Successful";
        }
    }

    public bool InsertOTPTransCode(long userid, string otpCode, string mobileNo, string otp_key, string medium, string transID, string terminalID)
    {
        using (SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["OTPCONSTRING"]))
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "proc_InsertOTPSMSCode_ATM";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = conn;
            cmd.CommandTimeout = 120;
            cmd.Parameters.AddWithValue("@User_ID", userid);
            cmd.Parameters.AddWithValue("@OTP_No", otpCode);
            cmd.Parameters.AddWithValue("@MobileNo", mobileNo);
            cmd.Parameters.AddWithValue("@OTP_Key", otp_key);
            cmd.Parameters.AddWithValue("@Medium", medium);
            cmd.Parameters.AddWithValue("@TransID", transID);
            cmd.Parameters.AddWithValue("@TerminalID", terminalID);

            try
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                if (cmd.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                ErrHandler.WriteError(ex.Message + " SMSOTP table on Eone");
                return false;
            }
            finally
            {
                conn.Close();
            }
        }
    }

    public string SendOTPSMS(int braCode, int cusNum, string message)
    {
        string SMS_result = string.Empty;
        DataTable dtMobile = new DataTable();
        string MobileNum = string.Empty;
        string userID = braCode.ToString() + cusNum.ToString() + "01";

        using (OracleConnection conn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
        {
            OracleDataAdapter oraAdapter = new OracleDataAdapter("Select Mob_num,Tel_num From Address Where bra_code=" + braCode + " and cus_num=" + cusNum, conn);

            try
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }

                oraAdapter.Fill(dtMobile);
                if (dtMobile.Rows.Count > 0)
                {
                    ErrHandler.WriteError("Successfully retrieved customer mobile number from BASIS, userid = " + userID);
                    MobileNum = dtMobile.Rows[0]["Mob_Num"].ToString().Trim().Replace("-", "") != string.Empty
                    ? dtMobile.Rows[0]["Mob_Num"].ToString().Trim().Replace("-", "") : dtMobile.Rows[0]["Tel_Num"].ToString().Trim().Replace("-", "");
                }
                else
                {
                    ErrHandler.WriteError("Unable to retrieve customer mobile number from BASIS, userid = " + userID);
                    return "";
                }

                SMS_result = eone.SendSMS(message, MobileNum);

                if (SMS_result.Split(',').GetLength(0) == 2)
                {
                    ErrHandler.WriteError("SEND_OTP_RESPONSE for userid = " + userID + " is " + SMS_result);
                    return SMS_result;
                }
                else
                {
                    ErrHandler.WriteError("SEND_OTP_RESPONSE for userid = " + userID + " is " + SMS_result);
                    return "";
                }

            }
            catch (Exception ex)
            {
                ErrHandler.WriteError(ex.Message + " || BASIS, userid = " + userID);
                return "";
            }
        }
    }

    public string EncryptPIN(string plainMessage, string key)
    {
        TripleDESCryptoServiceProvider des = new TripleDESCryptoServiceProvider();
        des.IV = new byte[8];
        PasswordDeriveBytes pdb = new PasswordDeriveBytes(key, new byte[0]);
        des.Key = pdb.CryptDeriveKey("RC2", "MD5", 128, new byte[8]);
        MemoryStream ms = new MemoryStream(plainMessage.Length * 2);
        CryptoStream encStream = new CryptoStream(ms, des.CreateEncryptor(),
        CryptoStreamMode.Write);
        byte[] plainBytes = Encoding.UTF8.GetBytes(plainMessage);
        encStream.Write(plainBytes, 0, plainBytes.Length);
        encStream.FlushFinalBlock();
        byte[] encryptedBytes = new byte[ms.Length];
        ms.Position = 0;
        ms.Read(encryptedBytes, 0, (int)ms.Length);
        encStream.Close();
        return Convert.ToBase64String(encryptedBytes);
    }

    public string DecryptPIN(string encryptedBase64, string key)
    {

        TripleDESCryptoServiceProvider des = new TripleDESCryptoServiceProvider();
        des.IV = new byte[8];
        PasswordDeriveBytes pdb = new PasswordDeriveBytes(key, new byte[0]);
        des.Key = pdb.CryptDeriveKey("RC2", "MD5", 128, new byte[8]);
        byte[] encryptedBytes = Convert.FromBase64String(encryptedBase64);
        MemoryStream ms = new MemoryStream(encryptedBase64.Length);
        CryptoStream decStream = new CryptoStream(ms, des.CreateDecryptor(),
        CryptoStreamMode.Write);
        decStream.Write(encryptedBytes, 0, encryptedBytes.Length);
        decStream.FlushFinalBlock();
        byte[] plainBytes = new byte[ms.Length];
        ms.Position = 0;
        ms.Read(plainBytes, 0, (int)ms.Length);
        decStream.Close();
        return Encoding.UTF8.GetString(plainBytes);
    }

    public string VerifyTransCodeOPT(long user_id, long otpCode, string transID, string terminalID)
    {
        string result = string.Empty;
        string xmlstring = string.Empty, otp_encrypt = string.Empty;
        SqlDataReader reader;
        SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["OTPCONSTRING"].ToString());
        SqlCommand comm = new SqlCommand("proc_SelectOTPSMSCode_ATM", conn);
        comm.Parameters.AddWithValue("@User_ID", user_id);
        //comm.Parameters.AddWithValue("@TransID", transID);
        comm.Parameters.AddWithValue("@TerminalID", terminalID);
        comm.CommandType = CommandType.StoredProcedure;
        //open connetion
        if (conn.State != ConnectionState.Open)
        {
            conn.Open();
        }
        try
        {
            reader = comm.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                otp_encrypt = EncryptPIN(otpCode.ToString(), reader.GetString(0));
                if (reader.GetString(1).Trim().CompareTo(otp_encrypt) == 0)
                {
                    result = "SUCCESS";

                    if (reader.GetString(2).Trim().CompareTo(transID) == 0)
                    {
                        result = "SUCCESS";

                        if (reader.GetString(3).Trim().CompareTo(terminalID) == 0)
                        {
                            result = "SUCCESS";
                        }
                        else
                        {
                            result = "FAILED";
                        }
                    }
                    else
                    {
                        result = "FAILED";
                    }
                }
                else
                {
                    result = "FAILED";
                }
            }
            else
            {
                result = "FAILED";
            }
            reader.Close();
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + " Eone SMSOTP table");
        }
        finally
        {
            conn.Dispose();
        }
        return result;
    }

    public bool UpdateOTPTransCode(long userid, long otpCode, string transID, string terminalID)
    {
        using (SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["OTPCONSTRING"]))
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "proc_UpdateOTPSMSCode_ATM";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = conn;
            cmd.CommandTimeout = 120;
            cmd.Parameters.AddWithValue("@User_ID", userid);
            //cmd.Parameters.AddWithValue("@TransID", transID);
            cmd.Parameters.AddWithValue("@TerminalID", terminalID);

            try
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
                if (cmd.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                ErrHandler.WriteError(ex.Message + " Eone SMSOTP table");
                return false;
            }
            finally
            {
                conn.Close();
            }
        }
    }

}