﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Data.OracleClient;
using System.Configuration;


/// <summary>
/// Summary description for Dispense
/// </summary>
public class Dispense
{
	public Dispense()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public String InternationalDispense(string bra_code, string cusnum, string cusname, string email, string phoneno, string curcode, string ledcode, string subacctcode, decimal trans_amt, string transdate,
    int channel, int cardtype, string pan, string stan, string mercht, int trans_type, decimal billamt, System.DateTime datelogged, int orig_bracode, int currency,
    int resolution, System.DateTime resolution_date, string tick)
    {
        string response;
        string returnvalue = string.Empty;
        SqlConnection dispErr = new SqlConnection(ConfigurationManager.AppSettings["Dispenseconn"]);
        SqlCommand cmd = new SqlCommand("usp_InternationalDisputeLogInsert", dispErr);
       
        try
        {
            if (dispErr.State == ConnectionState.Closed)
            {
                dispErr.Open();
            }
            cmd.Connection = dispErr;
            cmd.CommandText = "usp_InternationalDisputeLogInsert";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@BranchCode", bra_code);
            cmd.Parameters.AddWithValue("@CustomerNumber", cusnum);
            cmd.Parameters.AddWithValue("@CustomerName", cusname);
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@PhoneNo", phoneno);
            cmd.Parameters.AddWithValue("@CurrencyCode", curcode);
            cmd.Parameters.AddWithValue("@LedgerCode", ledcode);
            cmd.Parameters.AddWithValue("@SubAccountCode", subacctcode);
            cmd.Parameters.AddWithValue("@TransactionAmount", trans_amt);
            cmd.Parameters.AddWithValue("@TransactionDate", transdate);
            cmd.Parameters.AddWithValue("@Channel", channel);
            cmd.Parameters.AddWithValue("@CardType", cardtype);
            cmd.Parameters.AddWithValue("@PAN", pan);
            cmd.Parameters.AddWithValue("@STAN", stan);
            cmd.Parameters.AddWithValue("@Merchant", mercht);
            //'@TransactionType
            cmd.Parameters.AddWithValue("@TransactionType", trans_type);
            cmd.Parameters.AddWithValue("@BillingAmount", trans_amt);
            cmd.Parameters.AddWithValue("@DateLogged", datelogged);
            cmd.Parameters.AddWithValue("@originatingBraCode", orig_bracode);
            cmd.Parameters.AddWithValue("@Currency", currency);
            cmd.Parameters.AddWithValue("@Resolution", resolution);
            cmd.Parameters.AddWithValue("@ResolutionDate", resolution_date);
            cmd.Parameters.AddWithValue("@loggedBy", cusname);
            cmd.Parameters.AddWithValue("@tick", tick);
            //  cmd.CommandText = "usp_InternationalDisputeLogInsert"
            returnvalue = cmd.ExecuteScalar().ToString();//.ExecuteNonQuery();
            //'.ExecuteScalar()
            if (!string.IsNullOrEmpty(returnvalue))
            {
                response = "<RESPONSE><CODE>1000</CODE><MESSAGE>" + returnvalue.ToString() + "</MESSAGE></RESPONSE>";

            }
            else
            {
                response = "<RESPONSE><CODE>1001</CODE><ERROR>" + returnvalue.ToString() + "</ERROR></RESPONSE>";
            }

        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
            response = "<RESPONSE><CODE>1001</CODE><ERROR>" + ex.Message.ToString() + "</ERROR></RESPONSE>";
          //  MessageAlert(ex.Message);

        }
        finally
        {
            dispErr.Close();
        }


        return response;
    }


    public String InternationalDispenseError(string bra_code, string cusnum, string cusname, string email, string phoneno, string curcode, string ledcode, string subacctcode, decimal trans_amt, string transdate,
   int channel, int cardtype, string pan, string stan, string mercht, int trans_type, int billamt, System.DateTime datelogged, int orig_bracode, int currency,
   int resolution, System.DateTime resolution_date, string tick, string ComplaintType, string GoodsDescription, string MerchantAttempt, string MerchantResolution)
    {
        string response = "";
        string returnvalue = "";
        SqlConnection dispErr = new SqlConnection(ConfigurationManager.AppSettings["Dispenseconn"]);
        SqlCommand cmd = new SqlCommand("usp_InternationalDisputeLogInsert", dispErr);

        try
        {
            if (dispErr.State == ConnectionState.Closed)
            {
                dispErr.Open();
            }
            cmd.Connection = dispErr;
            cmd.CommandText = "usp_InternationalDisputeLogInsert";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@BranchCode", bra_code);
            cmd.Parameters.AddWithValue("@CustomerNumber", cusnum);
            cmd.Parameters.AddWithValue("@CustomerName", cusname);
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@PhoneNo", phoneno);
            cmd.Parameters.AddWithValue("@CurrencyCode", curcode);
            cmd.Parameters.AddWithValue("@LedgerCode", ledcode);
            cmd.Parameters.AddWithValue("@SubAccountCode", subacctcode);
            cmd.Parameters.AddWithValue("@TransactionAmount", trans_amt);
            cmd.Parameters.AddWithValue("@TransactionDate", transdate);
            cmd.Parameters.AddWithValue("@Channel", channel);
            cmd.Parameters.AddWithValue("@CardType", cardtype);
            cmd.Parameters.AddWithValue("@PAN", pan);
            cmd.Parameters.AddWithValue("@STAN", stan);
            cmd.Parameters.AddWithValue("@Merchant", mercht);
            //'@TransactionType
            cmd.Parameters.AddWithValue("@TransactionType", trans_type);
            cmd.Parameters.AddWithValue("@BillingAmount", trans_amt);
            cmd.Parameters.AddWithValue("@DateLogged", datelogged);
            cmd.Parameters.AddWithValue("@originatingBraCode", orig_bracode);
            cmd.Parameters.AddWithValue("@Currency", currency);
            cmd.Parameters.AddWithValue("@Resolution", resolution);
            cmd.Parameters.AddWithValue("@ResolutionDate", resolution_date);
            cmd.Parameters.AddWithValue("@loggedBy", cusname);
            cmd.Parameters.AddWithValue("@tick", tick);
            cmd.Parameters.AddWithValue("@ComplaintType", ComplaintType);
            cmd.Parameters.AddWithValue("@GoodsDescription", GoodsDescription);
            cmd.Parameters.AddWithValue("@MerchantAttempt", MerchantAttempt);
            cmd.Parameters.AddWithValue("@MerchantResolution", MerchantResolution);
            //  cmd.CommandText = "usp_InternationalDisputeLogInsert"
            returnvalue = cmd.ExecuteNonQuery().ToString();
            if (!string.IsNullOrEmpty(returnvalue))
            {
                response = "<RESPONSE><CODE>1000</CODE><MESSAGE>" + returnvalue.ToString() + "</MESSAGE></RESPONSE>";

            }
            else
            {
                response = "<RESPONSE><CODE>1001</CODE><ERROR>" + returnvalue.ToString() + "</ERROR></RESPONSE>";
            }

        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
            response = "<RESPONSE><CODE>1001</CODE><ERROR>" + ex.Message.ToString() + "</ERROR></RESPONSE>";
            //  MessageAlert(ex.Message);

        }
        finally
        {
            dispErr.Close();
        }


        return response;
    }
    //


    public  String InsertMobileMoney(string bra_code, string cusnum, string curcode, string ledcode, string subacctcode, decimal trans_amt, decimal amt_disp, decimal amt_due, string transdate, string stan,
    string userid, int platform, string bank, string status, string errtype, string pan, string mercht, string settled, System.DateTime datelogged, string acctname,
    string smart_card_no, string phoneno, string network, string atmlocate, string atmbranch, string cusname, string benphone, string benacctno, string refid, int orig_bracode,
    string uptick, string transdetail)
    {

        string response = string.Empty;
        string returnvalue = string.Empty;
        SqlConnection dispErr = new SqlConnection(ConfigurationManager.AppSettings["Dispenseconn"]);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandType = CommandType.StoredProcedure;

        try
        {
            if (dispErr.State == ConnectionState.Closed)
            {
                dispErr.Open();
            }
            //ErrorType
            cmd.Connection = dispErr;
            cmd.CommandText = "usp_MobileMoneyInsert";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@BranchCode", bra_code);
            cmd.Parameters.AddWithValue("@CustomerNumber", cusnum);
            cmd.Parameters.AddWithValue("@CurrencyCode", curcode);
            cmd.Parameters.AddWithValue("@LedgerCode", ledcode);
            cmd.Parameters.AddWithValue("@SubAccountCode", subacctcode);
            cmd.Parameters.AddWithValue("@CustomerName", cusname);
            cmd.Parameters.AddWithValue("@statuscheck", "0");
            cmd.Parameters.AddWithValue("@PhoneNo", phoneno);
            cmd.Parameters.AddWithValue("@Bank", bank);
            cmd.Parameters.AddWithValue("@platformid", platform);
            cmd.Parameters.AddWithValue("@TransactionAmount", trans_amt);
            cmd.Parameters.AddWithValue("@TransactionDate", transdate);
            cmd.Parameters.AddWithValue("@Referenceid", refid);
            cmd.Parameters.AddWithValue("@settled", settled);
            cmd.Parameters.AddWithValue("@errortype", errtype);
            cmd.Parameters.AddWithValue("@TransactionDetail", transdetail);
            cmd.Parameters.AddWithValue("@LoggedBy", userid);
            cmd.Parameters.AddWithValue("@DateLogged", datelogged);
            cmd.Parameters.AddWithValue("@origbracode", orig_bracode);
            cmd.Parameters.AddWithValue("@Status", status);
          //  cmd.Parameters.AddWithValue("@tick", uptick);
            returnvalue = cmd.ExecuteScalar().ToString();//.ExecuteNonQuery();
            //'.ExecuteScalar()
            if (!string.IsNullOrEmpty(returnvalue))
            {
                response = "<RESPONSE><CODE>1000</CODE><MESSAGE>" + returnvalue.ToString() + "</MESSAGE></RESPONSE>";

            }
            else
            {
                response = "<RESPONSE><CODE>1001</CODE><ERROR>" + returnvalue.ToString() + "</ERROR></RESPONSE>";
            }

        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
            response = "<RESPONSE><CODE>1001</CODE><ERROR>" + ex.Message.ToString() + "</ERROR></RESPONSE>";

        } 
        finally
        {
            dispErr.Close();
        }


        return response;

    }
  
    
    public  bool checkIntdispenselog(string bracode, string cusnum, string curcode, string ledcode, string subaccount, decimal amount, string trandate, string stan)
    {
        bool result = false;

        string query = "select * from InternationalDisputeLog where bra_code = '" + bracode + "' and cus_num = '" + cusnum + "' and cur_code = '" + curcode + "' and led_code ='" + ledcode + "' and sub_acct_code = '" + subaccount + "'   and TransactionAmount = '" + amount + "' and TransactionDate = '" + trandate + "' and STAN = '" + stan + "' ";
        //"
        SqlCommand sqlcomm = new SqlCommand();
        SqlDataReader sqlreader = default(SqlDataReader);
        SqlConnection sqlconnection = new SqlConnection(ConfigurationManager.AppSettings["Dispenseconn"]);
        sqlcomm.CommandText = query;
        sqlcomm.CommandType = CommandType.Text;
        sqlcomm.Connection = sqlconnection;

        try
        {
            sqlconnection.Open();
            sqlreader = sqlcomm.ExecuteReader();

            if (!sqlreader.HasRows)
            {
                return false;
            }
        }
        catch (SqlException ex)
        {
            string msg = "Exist Already";
            msg += ex.Message;
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
            //throw new Exception(msg);
            return false;
        }
        finally
        {
            sqlconnection.Close();
        }
        return true;
    }
    public  bool checkifexist(string bracode, string cusnum, string curcode, string ledcode, string subaccount, decimal amount, string trandate, string stan)
    {

        string query = "select * from DispenseErrorLog where BranchCode = '" + bracode + "' and CustomerNumber = '" + cusnum + "' and CurrencyCode = '" + curcode + "' and LedgerCode ='" + ledcode + "' and SubAccountCode = '" + subaccount + "'   and TransactionAmount = '" + amount + "' and TransactionDate = '" + trandate + "' and STAN = '" + stan + "' and Status = 'Logged'";
        //"
        SqlCommand sqlcomm = new SqlCommand();
        SqlDataReader sqlreader = default(SqlDataReader);
        SqlConnection sqlconnection = new SqlConnection(ConfigurationManager.AppSettings["Dispenseconn"]);
        sqlcomm.CommandText = query;
        sqlcomm.CommandType = CommandType.Text;
        sqlcomm.Connection = sqlconnection;

        try
        {
            sqlconnection.Open();
            sqlreader = sqlcomm.ExecuteReader();

            if (!sqlreader.HasRows)
            {
                return false;
            }
        }
        catch (SqlException ex)
        {
            string msg = "Exist Already";
            msg += ex.Message;
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
            //throw new Exception(msg);
            return false;
        }
        finally
        {
            sqlconnection.Close();
        }
        return true;
    }

    public  int checkPlatformID(string bank)
    {
        int result = default(int);

        bank.Replace("'", "''");
        string query = "select PlatformID from BankPlatform where BankName  like '%" + bank + "%'";
        Int16 count = 0;

        SqlConnection dispErr = new SqlConnection(ConfigurationManager.AppSettings["Dispenseconn"]);
        //'  Dim cmdSQLselect As New SqlClient.SqlCommand
        SqlDataReader drSQLselect = default(SqlDataReader);


        try
        {

            using (SqlCommand cmdSQLselect = new SqlCommand(query, dispErr))
            {
                if (dispErr.State == ConnectionState.Closed)
                {
                    dispErr.Open();
                }

                //' Dim dr1 As OracleDataReader = cmd1.ExecuteReader()
                drSQLselect = cmdSQLselect.ExecuteReader();
                while (drSQLselect.Read())
                {
                    result = Convert.ToInt32(drSQLselect["PlatFormID"]);
                }
            }


        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message);
           // WebMsgBox.Show(ex.Message);
        }
        finally
        {
            dispErr.Close();

        }


        return result;
    }

    

        
public  String InsertDispenseRecord(string bra_code, string cusnum, string curcode, string ledcode, string subacctcode, decimal trans_amt, decimal amt_disp, decimal amt_due, string transdate, string stan,
string userid, int platform, string bank, string status, string errtype, string pan, string mercht, string settled, System.DateTime datelogged, string acctname,
string smart_card_no, string phoneno, string network, string atmlocate, string atmbranch, string cusname, string benphone, string benacctno, string refid, int orig_bracode,
string uptick)
{

    string response = string.Empty;
	string returnvalue = "";
    SqlConnection dispErr = new SqlConnection(ConfigurationManager.AppSettings["Dispenseconn"]);
	SqlCommand cmd = new SqlCommand("new_DispenseLogInsert", dispErr);
	cmd.CommandType = CommandType.StoredProcedure;

	try {
		if (dispErr.State == ConnectionState.Closed)
        {
			dispErr.Open();
		}
		//ErrorType
		cmd.Parameters.AddWithValue("@BranchCode", bra_code);
		cmd.Parameters.AddWithValue("@CustomerNumber", cusnum);
		cmd.Parameters.AddWithValue("@CurrencyCode", curcode);
		cmd.Parameters.AddWithValue("@LedgerCode", ledcode);
		cmd.Parameters.AddWithValue("@SubAccountCode", subacctcode);
		cmd.Parameters.AddWithValue("@TransactionAmount", trans_amt);
		cmd.Parameters.AddWithValue("@AmountDispensed", amt_disp);
		cmd.Parameters.AddWithValue("@AmountDue", amt_due);
		cmd.Parameters.AddWithValue("@TransactionDate", transdate);
		cmd.Parameters.AddWithValue("@Stan", stan);
		cmd.Parameters.AddWithValue("@Userid", userid);
		cmd.Parameters.AddWithValue("@Platform", platform);
		cmd.Parameters.AddWithValue("@Bank", bank);
		cmd.Parameters.AddWithValue("@Status", status);
		cmd.Parameters.AddWithValue("@Errortype", errtype);
		cmd.Parameters.AddWithValue("@Pan", pan);
		cmd.Parameters.AddWithValue("@Merchant", mercht);
		cmd.Parameters.AddWithValue("@Settled", settled);
		cmd.Parameters.AddWithValue("@DateLogged", datelogged);
		cmd.Parameters.AddWithValue("@Accountname", acctname);
		cmd.Parameters.AddWithValue("@Smartcardno", smart_card_no);
		cmd.Parameters.AddWithValue("@PhoneNo", phoneno);
		cmd.Parameters.AddWithValue("@Network", network);
		cmd.Parameters.AddWithValue("@GTBATMLocation", atmlocate);
		cmd.Parameters.AddWithValue("@ATMBranchCode", atmbranch);
		cmd.Parameters.AddWithValue("@Customername", cusname);
		cmd.Parameters.AddWithValue("@BeneficiaryPhoneNo", benphone);
		cmd.Parameters.AddWithValue("@BeneficiaryAccountNo", benacctno);
		cmd.Parameters.AddWithValue("@ReferenceID", refid);
		cmd.Parameters.AddWithValue("@Originatingbracode", orig_bracode);
		cmd.Parameters.AddWithValue("@ticks", uptick);		
		cmd.CommandText = "new_DispenseLogInsert";

		returnvalue = cmd.ExecuteScalar().ToString();//.ExecuteNonQuery();
		//'.ExecuteScalar()
        if (!string.IsNullOrEmpty(returnvalue))
        {
            response = "<RESPONSE><CODE>1000</CODE><MESSAGE>" + returnvalue.ToString() + "</MESSAGE></RESPONSE>";

        }
        else
        {
            response = "<RESPONSE><CODE>1001</CODE><ERROR>" + returnvalue.ToString() + "</ERROR></RESPONSE>";
        }

	} 
    catch (Exception ex) 
    {
        ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
        response = "<RESPONSE><CODE>1001</CODE><ERROR>" + ex.Message.ToString() + "</ERROR></RESPONSE>";

	} 
    finally
    {
		dispErr.Close();
	}


    return response;
}


}