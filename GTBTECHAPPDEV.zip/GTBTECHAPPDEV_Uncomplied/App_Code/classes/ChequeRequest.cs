﻿using System;
using System.Linq;
using System.Web;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.OracleClient;


/// <summary>
/// Summary description for ChequeRequest
/// </summary>
public class ChequeRequest
{
	public ChequeRequest()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    SqlConnection ConSql = new SqlConnection(ConfigurationManager.AppSettings["CnnCard"].ToString());
    SqlConnection ConEone = new SqlConnection(ConfigurationManager.AppSettings["CnnStrSQLReadWrite"].ToString());

    OracleConnection OraConn = new OracleConnection(ConfigurationManager.AppSettings["ConnectStrHoBank"].ToString());

    private string mNuban;
    private string mAccountName;
    private int mSerialStart;
    private int mSerialStop;
    private string mChequeBookType;
    private int mRequestBranch;
    private int mPickUpBranchCode;
    private int mRequestBy;
    private double mAmountCharged;
    private string mChequeLeaves;
    private string mRequestorName;
    private string mAccountNumber;
    private int mChequeRequestID;
    private string mPacks;
    private string mTrackId;
    public string TrackId
    {
        get { return mTrackId; }
        set { mTrackId = value; }
    }

    public string Packs
    {
        get { return mPacks; }
        set { mPacks = value; }
    }

    public string AccountNumber
    {
        get { return mAccountNumber; }
        set { mAccountNumber = value; }
    }

    public string RequestorName
    {
        get { return mRequestorName; }
        set { mRequestorName = value; }
    }

    public string ChequeLeaves
    {
        get { return mChequeLeaves; }
        set { mChequeLeaves = value; }
    }

    public int RequestBranch
    {
        get { return mRequestBranch; }
        set { mRequestBranch = value; }
    }

    public double AmountCharged
    {
        get { return mAmountCharged; }
        set { mAmountCharged = value; }
    }

    public int PickUpBranchCode
    {
        get { return mPickUpBranchCode; }
        set { mPickUpBranchCode = value; }
    }

    public int RequestBy
    {
        get { return mRequestBy; }
        set { mRequestBy = value; }
    }

    public string ChequeBookType
    {
        get { return mChequeBookType; }
        set { mChequeBookType = value; }
    }

    public int SerialStop
    {
        get { return mSerialStop; }
        set { mSerialStop = value; }
    }

    public int SerialStart
    {
        get { return mSerialStart; }
        set { mSerialStart = value; }
    }

    public string AccountName
    {
        get { return mAccountName; }
        set { mAccountName = value; }
    }

    public int ChequeRequestID
    {
        get { return mChequeRequestID; }
        set { mChequeRequestID = value; }
    }

    public string Nuban
    {
        get { return mNuban; }
        set { mNuban = value; }
    }
    /// <summary>
    /// This method retrieves the Request ID From the databse
    /// </summary>
    /// <param name="mailType"></param>
    /// <returns></returns>
    /// <remarks></remarks>
    public void GetLastChequeRequestID()
    {
        SqlDataReader drSelect = default(SqlDataReader);
        SqlCommand cmdSelect = new SqlCommand();
        try
        {
            if (ConSql.State == ConnectionState.Closed)
            {
                ConSql.Open();
            }
            cmdSelect.Connection = ConSql;
            cmdSelect.CommandText = "select isnull(max(RequestID), 0) RequestID from chequeBook";
            cmdSelect.CommandType = CommandType.Text;
            drSelect = cmdSelect.ExecuteReader();
            if (drSelect.HasRows == true)
            {
                drSelect.Read();
                // GetLastChequeRequestID = drSelect("RequestID")
                ChequeRequestID = Convert.ToInt32(drSelect["RequestID"]);
            }

        }
        catch (Exception ex)
        {
            ChequeRequestID = 0;
        }
        finally
        {
            if (ConSql.State == ConnectionState.Open)
            {
                ConSql.Close();
            }
        }
    }
    public bool AddChequebookRequest()
    {
        int functionReturnValue = 0;
        SqlCommand cmdInsert = new SqlCommand();
        //Dim pmBranchCode As New SqlParameter("@BranchCode", BranchCode)
        //Dim pmCustomerNo As New SqlParameter("@CustomerNo", CustomerNo)
        SqlParameter pmPickUpBranchCode = new SqlParameter("@PickUpBranchCode", PickUpBranchCode);
        SqlParameter pmAccountNumber = new SqlParameter("@AccountNumber", mAccountNumber);
        SqlParameter pmChequeBookType = new SqlParameter("@ChequeBookType", mChequeBookType);

        SqlParameter pmChequeLeaves = new SqlParameter("@ChequeLeaves", mChequeLeaves);
        SqlParameter pmAccountName = new SqlParameter("@AccountName", mAccountName);
        SqlParameter pmSerialStart = new SqlParameter("@SerialStart", mSerialStart);
        SqlParameter pmSerialStop = new SqlParameter("@SerialStop", mSerialStop);
        SqlParameter pmNuban = new SqlParameter("@NUBAN", mNuban);
        // Dim pmRequestorName As New SqlParameter("@RequestedBy", RequestorName)
        SqlParameter pmUserid = new SqlParameter("@UserID", RequestBy);
        // Dim pmCardHolderName As New SqlParameter("@ChequeBookType", mChequeBookType)

        // Dim pmStatus As New SqlParameter("@Status", Status)
        SqlParameter pmAmountCharged = new SqlParameter("@AmountCharged", AmountCharged);
        SqlParameter pmRequestBranch = new SqlParameter("@RequestBranch", mRequestBranch);
        SqlParameter pmChannel = new SqlParameter("@Channel", "Ibank");
        SqlParameter pmPacks = new SqlParameter("@Packs", mPacks);
        SqlParameter pmRequestID = new SqlParameter("@RequestID", mChequeRequestID);
        SqlParameter pmTrackId = new SqlParameter("@mTrackId", mTrackId);

        // @Packs int,
        //@RequestID int
        // @Channel
        try
        {
            if (ConSql.State == ConnectionState.Closed)
            {
                ConSql.Open();
            }
            //cmdInsert.Parameters.Add(pmBranchCode)
            //cmdInsert.Parameters.Add(pmCustomerNo) 
            cmdInsert.Parameters.Add(pmPickUpBranchCode);
            //dim pmRequestDate as SqlParameter ("@RequestDate", mRequestDate) 
            // cmdInsert.Parameters.Add(pmStatus)
            cmdInsert.Parameters.Add(pmAccountNumber);
            cmdInsert.Parameters.Add(pmUserid);
            cmdInsert.Parameters.Add(pmAccountName);
            cmdInsert.Parameters.Add(pmAmountCharged);
            cmdInsert.Parameters.Add(pmChequeBookType);
            cmdInsert.Parameters.Add(pmChequeLeaves);
            cmdInsert.Parameters.Add(pmSerialStart);
            cmdInsert.Parameters.Add(pmSerialStop);
            cmdInsert.Parameters.Add(pmNuban);
            // cmdInsert.Parameters.Add(pmRequestorName)
            cmdInsert.Parameters.Add(pmRequestBranch);
            cmdInsert.Parameters.Add(pmChannel);
            cmdInsert.Parameters.Add(pmPacks);
            cmdInsert.Parameters.Add(pmRequestID);
            cmdInsert.Parameters.Add(pmTrackId);

            // cmdInsert.Par ()
            cmdInsert.Connection = ConSql;
            cmdInsert.CommandText = "usp_ChequebookRequestInsert";
            cmdInsert.CommandType = CommandType.StoredProcedure;

            functionReturnValue = cmdInsert.ExecuteNonQuery();
            //cmdInsert.Parameters("@ReturnCardID").Value

        }
        catch (Exception ex)
        {
            functionReturnValue = 0;
        }
        finally
        {
            if (ConSql.State == ConnectionState.Open)
            {
                ConSql.Close();
            }
        }

        if (functionReturnValue == 1)
            return true;
        else if (functionReturnValue == 0)
            return false;
        else
            return false;

    }

    public bool PendingRequestExist(string pNuban)
    {
        bool functionReturnValue = false;
        SqlDataReader drSelect = default(SqlDataReader);
        SqlCommand cmdSelect = new SqlCommand();
        try
        {
            if (ConSql.State == ConnectionState.Closed)
            {
                ConSql.Open();
            }
            cmdSelect.Connection = ConSql;
            cmdSelect.CommandText = "select * from chequebook where ChequeBookStatus=81 and NUBAN = '" + pNuban + "'";
            cmdSelect.CommandType = CommandType.Text;
            drSelect = cmdSelect.ExecuteReader();
            if (drSelect.HasRows == true)
            {
                functionReturnValue = true;
            }
            else
            {
                functionReturnValue = false;
            }


        }
        catch (Exception ex)
        {
            functionReturnValue = false;
        }
        finally
        {
            if (ConSql.State == ConnectionState.Open)
            {
                ConSql.Close();
            }
        }
        return functionReturnValue;
    }


    public bool CustomerIsValidForDebit(int BranchCode, int CustomerNo)
    {
        bool functionReturnValue = false;
        OracleDataReader oraSelect = default(OracleDataReader);
        OracleCommand cmdSelect = new OracleCommand();
        try
        {
            if (OraConn.State == ConnectionState.Closed)
            {
                OraConn.Open();
            }
            cmdSelect.Connection = OraConn;
            cmdSelect.CommandText = "select type_of_dep from customer c " + "inner join text_tab t on c.type_of_dep = t.tab_ent " + "where bra_code = " + BranchCode.ToString() + " and cus_num = " + CustomerNo.ToString() + " and t.tab_id = 559" + "group by type_of_dep ";
            // select * from chequebook where ChequeBookStatus=1 and NUBAN = '" & pNuban & "'"
            cmdSelect.CommandType = CommandType.Text;
            oraSelect = cmdSelect.ExecuteReader();
            if (oraSelect.HasRows == true)
            {
                functionReturnValue = false;
            }
            else
            {
                functionReturnValue = true;
            }


        }
        catch (Exception ex)
        {
            functionReturnValue = true;
        }
        finally
        {
            if (OraConn.State == ConnectionState.Open)
            {
                OraConn.Close();
            }
        }
        return functionReturnValue;
    }

    public bool UnclollectedChequeExist(string pNuban)
    {
        bool functionReturnValue = false;
        SqlDataReader drSelect = default(SqlDataReader);
        SqlCommand cmdSelect = new SqlCommand();
        try
        {
            if (ConSql.State == ConnectionState.Closed)
            {
                ConSql.Open();
            }
            cmdSelect.Connection = ConSql;
            cmdSelect.CommandText = "select * from chequebook where ChequeBookStatus=7 and NUBAN = '" + pNuban + "'";
            cmdSelect.CommandType = CommandType.Text;
            drSelect = cmdSelect.ExecuteReader();
            if (drSelect.HasRows == true)
            {
                functionReturnValue = true;
            }
            else
            {
                functionReturnValue = false;
            }


        }
        catch (Exception ex)
        {
            functionReturnValue = false;
        }
        finally
        {
            if (ConSql.State == ConnectionState.Open)
            {
                ConSql.Close();
            }
        }
        return functionReturnValue;
    }


    bool InsertProxyCollectibles(string userID, string acctNumber, string userName, string collectibleType, string pickUpBranch, string nameOfThirdParty,
      string meansOfID, int serialStart, int serialEnd, int noOfLeaves)
    {
        bool functionReturnValue = false;
        Int64 result = 0;
        using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BankcardConnString"].ToString()))
        {
            //SELECT FIRST INTO THE TABLE       
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            using (SqlCommand sqlComm = new SqlCommand("usp_ProxyCollectiblesInsert", conn))
            {
                //sqlComm.Parameters.Clear();
                sqlComm.CommandType = CommandType.StoredProcedure;
                sqlComm.Parameters.AddWithValue("@UserID", userID);
                sqlComm.Parameters.AddWithValue("@AccountNumber", acctNumber);
                sqlComm.Parameters.AddWithValue("@UserName", userName);
                sqlComm.Parameters.AddWithValue("@CollectibleType", collectibleType);
                sqlComm.Parameters.AddWithValue("@PickUpBranch", pickUpBranch);
                sqlComm.Parameters.AddWithValue("@NameOfThirdParty", nameOfThirdParty);
                sqlComm.Parameters.AddWithValue("@MeansOfId", meansOfID);
                sqlComm.Parameters.AddWithValue("@SerialStart", serialStart);
                sqlComm.Parameters.AddWithValue("@SerialEnd", serialEnd);
                sqlComm.Parameters.AddWithValue("@NoOfLeaves", serialEnd);

                result = Convert.ToInt64(sqlComm.ExecuteScalar());
            }
        }

        if (result == 1)
            functionReturnValue = true;
        else if (result == 0)
            functionReturnValue = false;
        else
            functionReturnValue = false;

        return functionReturnValue;
    }

    public Int64 saveChequeThirdPartyPickup(string userID, string acctNumber, string requestID, string pickUpBranch, string nameOfThirdParty, string meansOfID)
    {
        Int64 result = 0;
        DataTable dtTable = new DataTable();
        string userName = string.Empty;
        int serialStart = 0; int serialEnd = 0; int noOfLeaves = 0;
        string fullUserID = userID;
        if (userID.Length == 9)
        {
            userID = userID.Substring(0, 8);
        }
        else if (userID.Length > 9)
        {
            userID = userID.Substring(0, 9);
        }
        using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["BankcardConnString"].ToString()))
        {
            //SELECT FIRST INTO THE TABLE       
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }

            using (SqlCommand sqlComm = new SqlCommand("ChequeBookAvailableforPickUP", conn))
            {
                sqlComm.Parameters.Clear();
                sqlComm.CommandType = CommandType.StoredProcedure;
                sqlComm.Parameters.AddWithValue("@userid", userID);
                SqlDataAdapter adp = new SqlDataAdapter(sqlComm);
                adp.Fill(dtTable);
            }
        }

        if (dtTable != null && dtTable.Rows.Count > 0)
        {
            DataRow[] dwRow = dtTable.Select("RequestID = " + requestID);
            if (dwRow.Any())
            {
                DataTable dtRequest = dwRow.CopyToDataTable();
                userName = dtRequest.Rows[0]["AccountName"].ToString();
                noOfLeaves = Convert.ToInt32(dtRequest.Rows[0]["ChequeLeaves"]);
                serialStart = Convert.ToInt32(dtRequest.Rows[0]["SerialStart"]);
                serialEnd = Convert.ToInt32(dtRequest.Rows[0]["SerialStop"]);

                InsertProxyCollectibles(fullUserID, acctNumber, userName, "CHEQUE", pickUpBranch, nameOfThirdParty, meansOfID, serialStart, serialEnd, noOfLeaves);
            }
        }
        else
        {
            ErrHandler.WriteError("No Cheque Book available for pick-up");
        }

        return result;
    }

}