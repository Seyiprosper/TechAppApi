﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data.OracleClient;
using System.IO;
using System.Text;
using System.Globalization;
using GTBSecure;
using System.Net.Mail;
using System.Net.Mime;
using APPDEVDLL;
using System.Xml;
using System.Xml.XPath;
using Microsoft.VisualBasic;
using System.Collections;
using System.Collections.Generic;
//using Renci.SshNet;
using System.Linq;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Diagnostics;
using System.Text.RegularExpressions;


public class AlterChannelIbankReg
{
    string NUBAN = string.Empty;
    string PAN_last4 = string.Empty;
    string braCod = string.Empty;
    string cusNum = string.Empty;
    string mobileNo = string.Empty;
    string channelUpper = string.Empty;
    string atmTransid = string.Empty;
    string atmTerminalID = string.Empty;

    public AlterChannelIbankReg(string NUBAN_, string PAN_last4_, string TelNo, string channel)
    {
        NUBAN = NUBAN_;
        PAN_last4 = PAN_last4_;
        mobileNo = TelNo;
        channelUpper = channel.ToUpper().Trim();

        if (channelUpper == "ATM")
        {
            atmTransid = PAN_last4_;
            atmTerminalID = TelNo;
            PAN_last4 = string.Empty;
        }
    }

    XmlDocument document = default(XmlDocument);
    XPathNavigator navigator = default(XPathNavigator);
    XPathNodeIterator snodes = default(XPathNodeIterator);
    SqlConnection conBankCar = new SqlConnection(ConfigurationManager.ConnectionStrings["BankcardConnString"].ToString());
    SqlConnection conEone = new SqlConnection(ConfigurationManager.AppSettings["e_oneConnString"].ToString());
    SqlDataReader reader;
    BASIS callBasis = new BASIS();
    Eone eone = new Eone();
    Service twig = new Service();
    Email mail = new Email();

    public string Ibank_Regist()
    {
        string fullAcctNum = string.Empty;
        string fullAccNo = string.Empty;
        string[] fullAc;
        DataTable PANfromDB;
        string decryptPAN = string.Empty;
        string last4PAN = string.Empty;
        string phoneEmail = string.Empty;
        string phoneStatus = string.Empty;
        string phoneNo = string.Empty;
        string phoneNo1 = string.Empty;
        int phoneSucceed = 0;
        string userID = string.Empty;
        string userName = string.Empty;
        int confirmed = 0;
        string _strMsg = string.Empty;
        string passWord = string.Empty;
        string encrPIN = string.Empty;
        string em = string.Empty;
        string email = string.Empty;
        int emailSucceed = 0;
        int phoneMatch = 0;
        string logerr = string.Empty;
        string[] ph_split = { ",", "/", ":", ";" };
        string[] phoneNo2;
        int year = DateTime.Today.Year;
        int month = DateTime.Today.Month;
        int day = DateTime.Today.Day;
        int mm, yyyy, dd;
        twig.Url = ConfigurationManager.AppSettings["TwigWebUrl"];
        long loginCount = 0;

        try
        {
            if (channelUpper.Trim() != "ATM")
            {
                fullAcctNum = callBasis.NubanToOldAcct(NUBAN);
                fullAccNo = XmlReader(fullAcctNum);

                if (NUBAN.Length != 10 || PAN_last4.Length != 4)
                {
                    ErrHandler.WriteError("IBANKONBOARDING || Input error. || UserID: " + userID);
                    return "<Response><CODE>1001</CODE><Error>Input error.</Error></Response>";
                }
            }
            else
            {
                fullAccNo = NUBAN;
            }


            if (fullAccNo.Length > 15)
            {
                fullAc = fullAccNo.Split('/');
                braCod = fullAc[0];
                cusNum = fullAc[1];

                if (braCod.Length != 3 || cusNum.Length < 6)
                {
                    ErrHandler.WriteError("IBANKONBOARDING || Acount number cannot be validated. || UserID: " + userID);
                    return "<Response><CODE>1001</CODE><Error>Acount number cannot be validated.</Error></Response>";
                }
            }
            else
            {
                ErrHandler.WriteError("IBANKONBOARDING || Acount number cannot be validated. || UserID: " + userID);
                return "<Response><CODE>1001</CODE><Error>Acount number cannot be validated.</Error></Response>";
            }

            userID = braCod + cusNum + "01";

            if (channelUpper.Trim() != "ATM")
            {
                PANfromDB = getPANLast_();
                EncryptionLib.Encrypt enc = new EncryptionLib.Encrypt();

                foreach (DataRow row in PANfromDB.Rows)
                {
                    string PANDB = row[0].ToString();
                    try
                    {
                        mm = Convert.ToInt16(row[1].ToString().Substring(0, 2));
                        yyyy = Convert.ToInt16("20" + row[1].ToString().Substring(2, 2));

                        if (month == 2)
                        {
                            if (DateTime.IsLeapYear(year))
                            {
                                dd = 29;
                            }
                            else
                                dd = 28;
                        }
                        else if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)
                            dd = 31;
                        else
                            dd = 30;

                        if (yyyy > year)
                        {
                            decryptPAN = enc.Decrypt_TrpDes(PANDB);
                            last4PAN = decryptPAN.Substring(decryptPAN.Length - 4);
                            if (last4PAN == PAN_last4)
                            {
                                confirmed = 1;
                                break;
                            }
                        }

                        if (yyyy == year)
                        {
                            if (mm > month)
                            {
                                decryptPAN = enc.Decrypt_TrpDes(PANDB);
                                last4PAN = decryptPAN.Substring(decryptPAN.Length - 4);
                                if (last4PAN == PAN_last4)
                                {
                                    confirmed = 1;
                                    break;
                                }
                            }

                            if (mm == month)
                            {
                                if (dd > day)
                                {
                                    decryptPAN = enc.Decrypt_TrpDes(PANDB);
                                    last4PAN = decryptPAN.Substring(decryptPAN.Length - 4);
                                    if (last4PAN == PAN_last4)
                                    {
                                        confirmed = 1;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrHandler.WriteError(ex.Message + " || IBANKONBOARDING || UserID: " + userID);
                    }
                }
            }
            else
            {
                confirmed = 1;
            }

            if (confirmed != 1)
            {
                ErrHandler.WriteError("IBANKONBOARDING || PAN does not exist. UserID: " + userID);
                return "<Response><CODE>1001</CODE><Error>PAN does not exist.</Error></Response>";
            }

            string querEone_UserID = "select User_Name from Users where User_Id = '" + userID + "'";
            userName = checkUserID(querEone_UserID);

            using (SqlConnection conn1 = new SqlConnection(ConfigurationManager.AppSettings["e_oneConnString"]))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "CheckIBankLog";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn1;
                cmd.CommandTimeout = 60;
                cmd.Parameters.AddWithValue("@userID", userID);

                try
                {
                    if (conn1.State == ConnectionState.Closed)
                    {
                        conn1.Open();
                    }

                    try
                    {
                        reader = cmd.ExecuteReader();
                        if (reader.HasRows)
                        {
                            reader.Read();
                            loginCount = Convert.ToInt64(reader["loginCount"]);
                        }
                    }
                    catch (SqlException ex)
                    {
                        ErrHandler.WriteError(ex.Message + " || " + ex.StackTrace);
                    }
                }
                catch (Exception ex)
                {
                    ErrHandler.WriteError(ex.Message + ex.StackTrace + ex.ToString() + ex.Data);
                }
                finally
                {
                    if (conn1.State != ConnectionState.Closed)
                        conn1.Close();
                }
            }

            if (loginCount > 0)
            {
                ErrHandler.WriteError("IBANKONBOARDING || Record exist on IBLogins. UserID: " + userID);
                return "<Response><CODE>1002</CODE><Error>User already has login details.</Error></Response>";
            }

            if (string.IsNullOrEmpty(userName))
            {
                ErrHandler.WriteError("IBANKONBOARDING || User has not been profiled. UserID: " + userID);
                return "<Response><CODE>1001</CODE><Error>User has not been profiled.</Error></Response>";
            }

            Random rdom = new Random();
            passWord = rdom.Next(100, 999) + (DateTime.Now.Millisecond).ToString().PadLeft(3, '8');
            encrPIN = GTBSecure.Secure.EncryptString(passWord);

            _strMsg = "Your login credentials for GTBank Internet Banking are UserID: " + userID + " and Password = " + passWord + ". Kindly reset your password on first time login";

            string querrPhoneandEmail = "Select Mob_num, Tel_num, email From Address Where bra_code= '" + braCod + "' and cus_num = '" + cusNum + "'";
            phoneEmail = GetPhoneNoandEmail(querrPhoneandEmail);
            phoneStatus = phoneEmail.Split('~')[0].ToString() + "/" + phoneEmail.Split('~')[1].ToString();
            phoneNo2 = phoneStatus.Split(ph_split, StringSplitOptions.RemoveEmptyEntries);

            if (channelUpper.Trim() != "ATM")
            {
                if (phoneStatus.Length > 7)
                {
                    foreach (string item in phoneNo2)
                    {
                        if (item == mobileNo)
                        {
                            phoneMatch = 1;
                            break;
                        }
                    }
                }
            }
            else
            {
                if (phoneEmail.Split('~')[0].ToString().Length > 7 || phoneEmail.Split('~')[1].ToString().Length > 7)
                {
                    phoneMatch = 1;
                }
            }

            if (phoneMatch != 1)
            {
                ErrHandler.WriteError("IBANKONBOARDING || Phone number does not match or Mob_num/Tel_num does not exist. UserID: " + userID);
                return "<Response><CODE>1001</CODE><Error>Phone number does not match or Mob_num/Tel_num does not exist.</Error></Response>";
            }

            string PINUpdateResult = twig.Update_User_Pin(userID, encrPIN);
            if (PINUpdateResult != "0")
            {
                ErrHandler.WriteError("IBANKONBOARDING || PIN cannot be reset. UserID: " + userID);
                return "<Response><CODE>1001</CODE><Error>PIN cannot be reset.</Error></Response>";
            }

            //phoneNo = phoneNo2[0].Trim();

            //if (phoneNo2.Length > 1)
            //{
            //    phoneNo1 = phoneStatus.Split(ph_split, StringSplitOptions.RemoveEmptyEntries)[1].Trim();
            //}

            string smsRespon;
            string[] smsResponse = null;
            //string smsRespon1;
            if (channelUpper.Trim() != "ATM")
            {
                smsRespon = eone.SendSMS(_strMsg, mobileNo);
                smsResponse = smsRespon.Trim().Split(',');
            }
            else
            {
                mobileNo = phoneEmail.Split('~')[0].ToString();
                smsRespon = eone.SendSMS(_strMsg, mobileNo);
                smsResponse = smsRespon.Trim().Split(',');


                if (smsResponse.Length != 2)
                {
                    mobileNo = phoneEmail.Split('~')[1].ToString();
                    smsRespon = eone.SendSMS(_strMsg, mobileNo);
                    smsResponse = smsRespon.Trim().Split(',');
                }
            }


            //if (smsResponse.Length != 2)
            //{
            //    smsRespon1 = eone.SendSMS(_strMsg, phoneNo1);
            //    smsResponse = smsRespon1.Trim().Split(',');
            //    if (smsResponse.Length == 2)
            //        phoneNo = phoneNo1;
            //}

            if (smsResponse.Length == 2)
            {
                phoneSucceed = 1;
            }

            logerr = "NUBAN = " + NUBAN + "%%%UserID = " + userID + "%%%PAN = " + PAN_last4 + "%%%TelNO = " + mobileNo + "%%% Channel = " + channelUpper + "%%% smsRespon = " + smsRespon;

            //em = phoneEmail.Split('~')[2].Trim();

            //if (string.IsNullOrEmpty(em) || em.Length < 5)
            //{
            //    email = "NA";
            //}

            //else
            //    email = em;

            //try
            //{
            //    if (em.Length > 4)
            //    {
            //        string[] emailSeparators = { ",", "!", "?", ";", ":", " ", "/", "%", "#", "$", "^", "&", "*", "=", "\\" };
            //        String[] email_Str;
            //        email_Str = email.Split(emailSeparators, StringSplitOptions.RemoveEmptyEntries);
            //        int no_Email = email_Str.Length;

            //        if (no_Email == 1)
            //        {
            //            string EmailResponse = mail.SendEmail("intops@gtbank.com", email_Str[0], "Internet Banking Login Credential", _strMsg);
            //            if (EmailResponse == "Succeed")
            //            {
            //                emailSucceed = 1;
            //                ErrHandler.WriteError("Login credential successfully sent to UserID: " + userID);
            //            }
            //        }

            //        if (no_Email > 1)
            //        {
            //            string EmailResponse = mail.SendEmail("intops@gtbank.com", email_Str[0], "Internet Banking Login Credential", _strMsg);
            //            string EmailResponse1 = mail.SendEmail("intops@gtbank.com", email_Str[1], "Internet Banking Login Credential", _strMsg);
            //            if (EmailResponse == "Succeed" || EmailResponse1 == "Succeed")
            //            {
            //                emailSucceed = 1;
            //                ErrHandler.WriteError("Login credential successfully sent to UserID: " + userID);
            //            }
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    ErrHandler.WriteError(ex.ToString());
            //    return "<Response><CODE>1001</CODE><Error>Unknown Error</Error></Response>";
            //}

            if (phoneSucceed != 1 /*&& emailSucceed != 1*/)
            {
                ErrHandler.WriteError("IBANKONBOARDING || Login credentials could not be sent to customer.. UserID: " + userID);
                return "<Response><CODE>1001</CODE><Error>Login credentials could not be sent to customer.</Error></Response>";
            }
            else
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["e_oneConnString"]))
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "proc_InsertIBankOnboarding";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = conn;
                    cmd.CommandTimeout = 120;
                    cmd.Parameters.AddWithValue("@NUBAN", NUBAN);
                    cmd.Parameters.AddWithValue("@userID", userID);
                    cmd.Parameters.AddWithValue("@last4digit_PAN", PAN_last4);
                    cmd.Parameters.AddWithValue("@telNO", mobileNo);
                    cmd.Parameters.AddWithValue("@channel", channelUpper);
                    cmd.Parameters.AddWithValue("@ATMTransID", atmTransid);
                    cmd.Parameters.AddWithValue("@ATMTerminalID", atmTerminalID);

                    try
                    {
                        if (conn.State == ConnectionState.Closed)
                        {
                            conn.Open();
                        }
                        if (cmd.ExecuteNonQuery() > 0)
                        {

                        }
                        else
                        {
                            ErrHandler.WriteError(logerr);
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrHandler.WriteError(ex + logerr);
                    }
                    finally
                    {
                        if (conn.State != ConnectionState.Closed)
                            conn.Close();
                    }
                }

                return "<Response><CODE>1000</CODE>Succeed</Response>";
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.ToString());
            return "<Response><CODE>1001</CODE><Error>Unknown Error</Error></Response>";
        }
    }

    public string XmlReader(string xml)
    {
        document = new XmlDocument();
        document.LoadXml(xml);
        navigator = document.CreateNavigator();
        snodes = navigator.Select("/Response/CODE");
        snodes.MoveNext();
        string code = snodes.Current.Value;
        string result = "00";

        if (code == "1000")
        {
            snodes = navigator.Select("/Response/MESSAGE");
            snodes.MoveNext();
            return result = snodes.Current.Value;
        }
        else
        {
            return result;
        }
    }

    public DataTable getPANLast_()
    {
        DataTable encryptPANlast4 = new DataTable();
        //EncryptionLib.Encrypt enc = new EncryptionLib.Encrypt();
        //string encPAN = enc.Encrypt_TrpDes(pan.Substring(6, 10));

        string conn = ConfigurationManager.ConnectionStrings["BankcardConnString"].ToString();
        SqlConnection sqlconn = new SqlConnection(conn);
        SqlCommand cmd = new SqlCommand();
        //SqlDataAdapter adpt = new SqlDataAdapter(cmd);
        cmd.Parameters.Add("@braCode", SqlDbType.VarChar);
        cmd.Parameters.Add("@cusNum", SqlDbType.VarChar);
        cmd.Parameters["@braCode"].Value = braCod;
        cmd.Parameters["@cusNum"].Value = cusNum;
        cmd.CommandText = "proc_GetlastfourPAN";
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = sqlconn;
        cmd.CommandTimeout = 120;

        try
        {
            if (sqlconn.State == ConnectionState.Closed)
            {
                sqlconn.Open();
            }
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                encryptPANlast4.Load(dr);
            }
            dr.Close();
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + " BankCard db");
        }
        finally
        {
            sqlconn.Close();
        }
        return encryptPANlast4;
    }

    public string checkUserID(string query)
    {
        string User_Name = string.Empty;
        try
        {
            SqlCommand comm1 = new SqlCommand(query, conEone);
            if (conEone.State != ConnectionState.Open)
            {
                conEone.Open();
            }

            try
            {
                reader = comm1.ExecuteReader();

                if (reader.HasRows)
                {
                    reader.Read();

                    User_Name = reader["User_Name"].ToString();
                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                ErrHandler.WriteError(ex.Message + " Eone db");

            }
            finally
            {
                if (conEone.State != ConnectionState.Closed)
                {
                    conEone.Close();
                }
            }

        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message);
        }

        return User_Name;

    }

    public string GetPhoneNoandEmail(string query)
    {
        string result = null;
        OracleConnection OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

        using (OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
        {
            using (OracleCommand OraSelect = new OracleCommand())
            {
                //Dim OraDrSelect As OracleDataReader
                try
                {
                    if (OraConn.State == ConnectionState.Closed)
                    {
                        OraConn.Open();
                    }
                    OraSelect.Connection = OraConn;

                    OraSelect.CommandText = query;
                    OraSelect.CommandType = CommandType.Text;
                    using (OracleDataReader OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (OraDrSelect.HasRows == true)
                        {
                            OraDrSelect.Read();
                            result = OraDrSelect["Mob_num"].ToString();
                            string result1 = OraDrSelect["Tel_num"].ToString();
                            string mail = OraDrSelect["email"].ToString();
                            OraConn.Close();
                            return result + "~" + result1 + "~" + mail;
                        }
                        else
                        {
                            OraConn.Close();
                            return "-2";
                        }
                    }
                }
                catch (Exception ex)
                {
                    ErrHandler.WriteError(ex.ToString());
                    OraConn.Close();
                    return "-1";
                }
                finally
                {
                    if (OraConn.State != ConnectionState.Closed)
                        OraConn.Close();
                }
            }
        }

    }
}