using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data.OracleClient;
using System.Data;
using System.Configuration;
using System.IO;
//using FTPSolution;
using System.Globalization;
using System.Text.RegularExpressions;

namespace MT940Generator
{
    class Generator
    {
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        OracleDataReader dr;
        Decimal open_bal;
        DataTable dt_trans, dt_cust;
        DateTime startDate, endDate, openbaldate, closebaldate;
        DateTime rep_date;
        String param1, param2, param3, param4, param5;
        Decimal openingBalance, closingBalance;
        Decimal s60F, s60M, s62M, s62F;
        String Day = DateTime.Now.ToString("dd-MM-yy", CultureInfo.CreateSpecificCulture("en-GB"));

        public Generator()
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"].ToString()));
        }

        public Generator(DataRow cust_det, String acctno)
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"].ToString()));
            GetAcctDetails(cust_det["AccountNumber"].ToString());
        }

        public Generator(DataRow customer_detail, DataRow cust_det, DateTime startdate)
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"].ToString()));
            rep_date = startdate;

            startDate = rep_date.AddDays(-1.0);

            //startDate = new DateTime(2012, 2, 1);

            //Check if date falls on a weekend
            if (startDate.DayOfWeek == DayOfWeek.Saturday && customer_detail["send_weekend"].ToString() == "0")
                startDate = startDate.AddDays(-1.0);
            else if (startDate.DayOfWeek == DayOfWeek.Sunday && customer_detail["send_weekend"].ToString() == "0")
                startDate = startDate.AddDays(-2.0);

            endDate = startDate;

            //endDate = startDate.AddDays(28.0);
            GetAcctDetails(cust_det["AccountNumber"].ToString());
        }

        public Generator(DataRow customer_detail, DataRow cust_det, DateTime startdate, DateTime enddate)
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"].ToString()));
            rep_date = startdate;

            //if(freq_flag == 1)  //1 = Daily
            //{
            //    startDate = rep_date.AddDays(-1.0);

            //    //Check if date falls on a weekend
            //    if (startDate.DayOfWeek == DayOfWeek.Saturday && customer_detail["send_weekend"].ToString() == "0")
            //        startDate = startDate.AddDays(-1.0);
            //    else if (startDate.DayOfWeek == DayOfWeek.Sunday && customer_detail["send_weekend"].ToString() == "0")
            //        startDate = startDate.AddDays(-2.0);

            //    endDate = startDate;
            //}
            //else if (freq_flag == 3)  //3 = Monthly
            //{
            //    startDate = FirstDayOfPreviousMonthFromDateTime(startdate);
            //    endDate = LastDayOfMonthFromDateTime(startdate);
            //}
            //else
            //{
                //startDate = rep_date.AddDays(-1.0);

                startDate = rep_date;

                ////Check if date falls on a weekend
                //if (startDate.DayOfWeek == DayOfWeek.Saturday && customer_detail["send_weekend"].ToString() == "0")
                //    startDate = startDate.AddDays(-1.0);
                //else if (startDate.DayOfWeek == DayOfWeek.Sunday && customer_detail["send_weekend"].ToString() == "0")
                //    startDate = startDate.AddDays(-2.0);

                endDate = enddate;
            //}

            GetAcctDetails(cust_det["AccountNumber"].ToString());
        }

        private void GetAcctDetails(String Acctno)
        {
            char[] delim = new char[] { '/' };
            String[] tempstr;
            tempstr = Acctno.Split(delim);
            param1 = tempstr[0];
            param2 = tempstr[1];
            param3 = tempstr[2];
            param4 = tempstr[3];
            param5 = tempstr[4];
        }

        public void GetBasisTransactions(DataRow datrow, DataRow datacctrow)
        {
            String sqlstr1, sqlstr2, sqlstr3;
            String paramstr = "";
            //DateTime qry_date;
            //startDate = "15082011";
            //endDate = "15082011";

            //qry_date = startDate.AddDays(-2.0);

            openbaldate = startDate.AddDays(-1.0);
            closebaldate = startDate;

            //Get Openeing Balance from BAsis  //this wont work if the last transaction for the day is has can_rea_code <> 0

            if (datrow["id"].ToString() == "22")
            {
                openingBalance = Convert.ToDecimal(datacctrow["last_balance"]);
            }
            else
            {
                //sqlstr1 = "SELECT NVL(crnt_bal,0) openingBalance FROM transact WHERE bra_code = " + param1 + " AND cus_num = " + param2 + " AND cur_code = " + param3 + " AND led_code = " + param4 + " AND sub_acct_code = " + param5 + " AND tra_date = (SELECT max(tra_date) FROM transact" + " WHERE bra_code = " + param1 + " AND cus_num = " + param2 + " AND cur_code = " + param3 + " AND led_code = " + param4 + " AND sub_acct_code = " + param5 + " AND tra_date < TO_DATE('" + startDate.ToString("ddMMyyyy") + "','ddMMyyyy') AND can_rea_code = 0) ";
                //sqlstr1 = sqlstr1 + " AND tra_seq1 = (SELECT max(tra_seq1) FROM transact" + " WHERE bra_code = " + param1 + " AND cus_num = " + param2 + " AND cur_code = " + param3 + " AND led_code = " + param4 + " AND sub_acct_code = " + param5;
                //sqlstr1 = sqlstr1 + " AND tra_date = (SELECT max(tra_date) FROM transact" + " WHERE bra_code = " + param1 + " AND cus_num = " + param2 + " AND cur_code = " + param3 + " AND led_code = " + param4 + " AND sub_acct_code = " + param5 + " AND tra_date < TO_DATE('" + startDate.ToString("ddMMyyyy") + "','ddMMyyyy') AND can_rea_code = 0 )) ";
                //sqlstr1 = sqlstr1 + " AND tra_seq2 = (SELECT max(tra_seq2) FROM transact" + " WHERE bra_code = " + param1 + " AND cus_num = " + param2 + " AND cur_code = " + param3 + " AND led_code = " + param4 + " AND sub_acct_code = " + param5;
                //sqlstr1 = sqlstr1 + " AND tra_date = (SELECT max(tra_date) FROM transact" + " WHERE bra_code = " + param1 + " AND cus_num = " + param2 + " AND cur_code = " + param3 + " AND led_code = " + param4 + " AND sub_acct_code = " + param5 + " AND tra_date < TO_DATE('" + startDate.ToString("ddMMyyyy") + "','ddMMyyyy') AND can_rea_code = 0 ) ";
                //sqlstr1 = sqlstr1 + " AND tra_seq1 = (SELECT max(tra_seq1) FROM transact" + " WHERE bra_code = " + param1 + " AND cus_num = " + param2 + " AND cur_code = " + param3 + " AND led_code = " + param4 + " AND sub_acct_code = " + param5;
                //sqlstr1 = sqlstr1 + " AND tra_date = (SELECT max(tra_date) FROM transact" + " WHERE bra_code = " + param1 + " AND cus_num = " + param2 + " AND cur_code = " + param3 + " AND led_code = " + param4 + " AND sub_acct_code = " + param5 + " AND tra_date < TO_DATE('" + startDate.ToString("ddMMyyyy") + "','ddMMyyyy')) AND can_rea_code = 0 )) ";
                paramstr = param1 + "," + param2 + "," + param3 + "," + param4 + "," + param5 + ",'" + openbaldate.ToString("ddMMMyyyy") + "'";
                sqlstr1 = "SELECT getopnbal6(" + paramstr + ") as openingBalance from dual";


                if (oraconn.State != ConnectionState.Open)
                    oraconn.Open();

                cmd = new OracleCommand(sqlstr1, oraconn);
                ora_adpt = new OracleDataAdapter(cmd);
                dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                    if (dr.Read())
                        openingBalance = Convert.ToDecimal(dr["openingBalance"]);
                    else
                        openingBalance = 0M;
                }
                else
                    openingBalance = 0M;
            }

            
            //Get Transactions
            if (datrow["id"].ToString() == "22")
            {
                sqlstr2 = "SELECT T.TRA_DATE, T.TRA_SEQ1, T.TRA_SEQ2, T.BRA_CODE, ";
                sqlstr2 = sqlstr2 + "T.TRA_AMT, T.DEB_CRE_IND, T.EXPL_CODE, X.DES_ENG, T.VAL_DATE, ";
                sqlstr2 = sqlstr2 + "T.CAN_REA_CODE, T.DOC_ALP, T.DOC_NUM, T.REMARKS,";
                sqlstr2 = sqlstr2 + "T.CUS_NUM, T.CUR_CODE, T.LED_CODE, T.SUB_ACCT_CODE, ";
                sqlstr2 = sqlstr2 + "T.ORIGT_BRA_CODE, T.DOC_ALP, T.BANK_CODE, A.CHE_DIG FROM transact T, ACCOUNT A, TEXT_TAB X ";
                sqlstr2 = sqlstr2 + "WHERE ((A.BRA_CODE = T.BRA_CODE) AND (A.CUS_NUM = T.CUS_NUM) AND ";
                sqlstr2 = sqlstr2 + "(A.CUR_CODE = T.CUR_CODE) AND (A.LED_CODE = T.LED_CODE) AND ";
                sqlstr2 = sqlstr2 + "(A.SUB_ACCT_CODE = T.SUB_ACCT_CODE) AND ";
                sqlstr2 = sqlstr2 + "(T.CAN_REA_CODE = 0)";
                sqlstr2 = sqlstr2 + " AND ( (T.VAL_DATE = TO_DATE('" + startDate.ToString("ddMMyyyy") + "','ddMMyyyy')) OR (T.TRA_DATE = TO_DATE('" + startDate.ToString("ddMMyyyy") + "','ddMMyyyy') AND T.VAL_DATE < TO_DATE('" + startDate.ToString("ddMMyyyy") + "','ddMMyyyy')) )";
                sqlstr2 = sqlstr2 + " AND (T.BRA_CODE = " + param1 + ") ";
                sqlstr2 = sqlstr2 + "AND (T.CUS_NUM = " + param2 + ") AND (T.CUR_CODE = " + param3 + ") AND (T.LED_CODE = " + param4 + ") AND (T.SUB_ACCT_CODE = " + param5 + ") ";
                sqlstr2 = sqlstr2 + "AND (X.TAB_ID = 60) AND (X.TAB_ENT = T.EXPL_CODE))";
            }
            else
            {
                sqlstr2 = "SELECT T.TRA_DATE, T.TRA_SEQ1, T.TRA_SEQ2, T.BRA_CODE, ";
                sqlstr2 = sqlstr2 + "T.TRA_AMT, T.DEB_CRE_IND, T.EXPL_CODE, X.DES_ENG, T.VAL_DATE, ";
                sqlstr2 = sqlstr2 + "T.CAN_REA_CODE, T.DOC_ALP, T.DOC_NUM, T.REMARKS,";
                sqlstr2 = sqlstr2 + "T.CUS_NUM, T.CUR_CODE, T.LED_CODE, T.SUB_ACCT_CODE, ";
                sqlstr2 = sqlstr2 + "T.ORIGT_BRA_CODE, T.BANK_CODE, A.CHE_DIG FROM transact T, ACCOUNT A, TEXT_TAB X ";
                sqlstr2 = sqlstr2 + "WHERE ((A.BRA_CODE = T.BRA_CODE) AND (A.CUS_NUM = T.CUS_NUM) AND ";
                sqlstr2 = sqlstr2 + "(A.CUR_CODE = T.CUR_CODE) AND (A.LED_CODE = T.LED_CODE) AND ";
                sqlstr2 = sqlstr2 + "(A.SUB_ACCT_CODE = T.SUB_ACCT_CODE) AND ";
                sqlstr2 = sqlstr2 + "(T.CAN_REA_CODE = 0) AND (T.TRA_DATE BETWEEN TO_DATE('" + startDate.ToString("ddMMyyyy") + "','ddMMyyyy') AND TO_DATE('" + endDate.ToString("ddMMyyyy") + "','ddMMyyyy')) AND (T.BRA_CODE = " + param1 + ") ";
                sqlstr2 = sqlstr2 + "AND (T.CUS_NUM = " + param2 + ") AND (T.CUR_CODE = " + param3 + ") AND (T.LED_CODE = " + param4 + ") AND (T.SUB_ACCT_CODE = " + param5 + ") ";
                sqlstr2 = sqlstr2 + "AND (X.TAB_ID = 60) AND (X.TAB_ENT = T.EXPL_CODE))";
            }


            cmd = new OracleCommand(sqlstr2, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            dt_trans = new DataTable();
            ora_adpt.Fill(dt_trans);

            oraconn.Close();
        }

        public void GetBasisTransactions_Monthly(DataRow datrow, DataRow datacctrow)
        {
            String sqlstr1, sqlstr2, sqlstr3;
            String paramstr = "";
            
            openbaldate = startDate.AddDays(-1.0);
            closebaldate = startDate;

            //Get Openeing Balance from BAsis  //this wont work if the last transaction for the day is has can_rea_code <> 0

            if (datrow["id"].ToString() == "22")
            {
                openingBalance = Convert.ToDecimal(datacctrow["last_balance"]);
            }
            else
            {
                //sqlstr1 = "SELECT NVL(crnt_bal,0) openingBalance FROM transact WHERE bra_code = " + param1 + " AND cus_num = " + param2 + " AND cur_code = " + param3 + " AND led_code = " + param4 + " AND sub_acct_code = " + param5 + " AND tra_date = (SELECT max(tra_date) FROM transact" + " WHERE bra_code = " + param1 + " AND cus_num = " + param2 + " AND cur_code = " + param3 + " AND led_code = " + param4 + " AND sub_acct_code = " + param5 + " AND tra_date < TO_DATE('" + startDate.ToString("ddMMyyyy") + "','ddMMyyyy') AND can_rea_code = 0) ";
                //sqlstr1 = sqlstr1 + " AND tra_seq1 = (SELECT max(tra_seq1) FROM transact" + " WHERE bra_code = " + param1 + " AND cus_num = " + param2 + " AND cur_code = " + param3 + " AND led_code = " + param4 + " AND sub_acct_code = " + param5;
                //sqlstr1 = sqlstr1 + " AND tra_date = (SELECT max(tra_date) FROM transact" + " WHERE bra_code = " + param1 + " AND cus_num = " + param2 + " AND cur_code = " + param3 + " AND led_code = " + param4 + " AND sub_acct_code = " + param5 + " AND tra_date < TO_DATE('" + startDate.ToString("ddMMyyyy") + "','ddMMyyyy') AND can_rea_code = 0 )) ";
                //sqlstr1 = sqlstr1 + " AND tra_seq2 = (SELECT max(tra_seq2) FROM transact" + " WHERE bra_code = " + param1 + " AND cus_num = " + param2 + " AND cur_code = " + param3 + " AND led_code = " + param4 + " AND sub_acct_code = " + param5;
                //sqlstr1 = sqlstr1 + " AND tra_date = (SELECT max(tra_date) FROM transact" + " WHERE bra_code = " + param1 + " AND cus_num = " + param2 + " AND cur_code = " + param3 + " AND led_code = " + param4 + " AND sub_acct_code = " + param5 + " AND tra_date < TO_DATE('" + startDate.ToString("ddMMyyyy") + "','ddMMyyyy') AND can_rea_code = 0 ) ";
                //sqlstr1 = sqlstr1 + " AND tra_seq1 = (SELECT max(tra_seq1) FROM transact" + " WHERE bra_code = " + param1 + " AND cus_num = " + param2 + " AND cur_code = " + param3 + " AND led_code = " + param4 + " AND sub_acct_code = " + param5;
                //sqlstr1 = sqlstr1 + " AND tra_date = (SELECT max(tra_date) FROM transact" + " WHERE bra_code = " + param1 + " AND cus_num = " + param2 + " AND cur_code = " + param3 + " AND led_code = " + param4 + " AND sub_acct_code = " + param5 + " AND tra_date < TO_DATE('" + startDate.ToString("ddMMyyyy") + "','ddMMyyyy')) AND can_rea_code = 0 )) ";
                paramstr = param1 + "," + param2 + "," + param3 + "," + param4 + "," + param5 + ",'" + openbaldate.ToString("ddMMMyyyy") + "'";
                sqlstr1 = "SELECT getopnbal6(" + paramstr + ") as openingBalance from dual";


                if (oraconn.State != ConnectionState.Open)
                    oraconn.Open();

                cmd = new OracleCommand(sqlstr1, oraconn);
                ora_adpt = new OracleDataAdapter(cmd);
                dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                    if (dr.Read())
                        openingBalance = Convert.ToDecimal(dr["openingBalance"]);
                    else
                        openingBalance = 0M;
                }
                else
                    openingBalance = 0M;
            }


            //Get Transactions
            if (datrow["id"].ToString() == "22")
            {
                sqlstr2 = "SELECT T.TRA_DATE, T.TRA_SEQ1, T.TRA_SEQ2, T.BRA_CODE, ";
                sqlstr2 = sqlstr2 + "T.TRA_AMT, T.DEB_CRE_IND, T.EXPL_CODE, X.DES_ENG, T.VAL_DATE, ";
                sqlstr2 = sqlstr2 + "T.CAN_REA_CODE, T.DOC_ALP, T.DOC_NUM, T.REMARKS,";
                sqlstr2 = sqlstr2 + "T.CUS_NUM, T.CUR_CODE, T.LED_CODE, T.SUB_ACCT_CODE, ";
                sqlstr2 = sqlstr2 + "T.ORIGT_BRA_CODE, T.DOC_ALP, T.BANK_CODE, A.CHE_DIG FROM transact T, ACCOUNT A, TEXT_TAB X ";
                sqlstr2 = sqlstr2 + "WHERE ((A.BRA_CODE = T.BRA_CODE) AND (A.CUS_NUM = T.CUS_NUM) AND ";
                sqlstr2 = sqlstr2 + "(A.CUR_CODE = T.CUR_CODE) AND (A.LED_CODE = T.LED_CODE) AND ";
                sqlstr2 = sqlstr2 + "(A.SUB_ACCT_CODE = T.SUB_ACCT_CODE) AND ";
                sqlstr2 = sqlstr2 + "(T.CAN_REA_CODE = 0)";
                sqlstr2 = sqlstr2 + " AND ( (T.VAL_DATE = TO_DATE('" + startDate.ToString("ddMMyyyy") + "','ddMMyyyy')) OR (T.TRA_DATE = TO_DATE('" + startDate.ToString("ddMMyyyy") + "','ddMMyyyy') AND T.VAL_DATE < TO_DATE('" + startDate.ToString("ddMMyyyy") + "','ddMMyyyy')) )";
                sqlstr2 = sqlstr2 + " AND (T.BRA_CODE = " + param1 + ") ";
                sqlstr2 = sqlstr2 + "AND (T.CUS_NUM = " + param2 + ") AND (T.CUR_CODE = " + param3 + ") AND (T.LED_CODE = " + param4 + ") AND (T.SUB_ACCT_CODE = " + param5 + ") ";
                sqlstr2 = sqlstr2 + "AND (X.TAB_ID = 60) AND (X.TAB_ENT = T.EXPL_CODE))";
            }
            else
            {
                sqlstr2 = "SELECT T.TRA_DATE, T.TRA_SEQ1, T.TRA_SEQ2, T.BRA_CODE, ";
                sqlstr2 = sqlstr2 + "T.TRA_AMT, T.DEB_CRE_IND, T.EXPL_CODE, X.DES_ENG, T.VAL_DATE, ";
                sqlstr2 = sqlstr2 + "T.CAN_REA_CODE, T.DOC_ALP, T.DOC_NUM, T.REMARKS,";
                sqlstr2 = sqlstr2 + "T.CUS_NUM, T.CUR_CODE, T.LED_CODE, T.SUB_ACCT_CODE, ";
                sqlstr2 = sqlstr2 + "T.ORIGT_BRA_CODE, T.BANK_CODE, A.CHE_DIG FROM transact T, ACCOUNT A, TEXT_TAB X ";
                sqlstr2 = sqlstr2 + "WHERE ((A.BRA_CODE = T.BRA_CODE) AND (A.CUS_NUM = T.CUS_NUM) AND ";
                sqlstr2 = sqlstr2 + "(A.CUR_CODE = T.CUR_CODE) AND (A.LED_CODE = T.LED_CODE) AND ";
                sqlstr2 = sqlstr2 + "(A.SUB_ACCT_CODE = T.SUB_ACCT_CODE) AND ";
                sqlstr2 = sqlstr2 + "(T.CAN_REA_CODE = 0) AND (T.TRA_DATE BETWEEN TO_DATE('" + startDate.ToString("ddMMyyyy") + "','ddMMyyyy') AND TO_DATE('" + endDate.ToString("ddMMyyyy") + "','ddMMyyyy')) AND (T.BRA_CODE = " + param1 + ") ";
                sqlstr2 = sqlstr2 + "AND (T.CUS_NUM = " + param2 + ") AND (T.CUR_CODE = " + param3 + ") AND (T.LED_CODE = " + param4 + ") AND (T.SUB_ACCT_CODE = " + param5 + ") ";
                sqlstr2 = sqlstr2 + "AND (X.TAB_ID = 60) AND (X.TAB_ENT = T.EXPL_CODE))";
            }


            cmd = new OracleCommand(sqlstr2, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            dt_trans = new DataTable();
            ora_adpt.Fill(dt_trans);

            oraconn.Close();
        }


        private string formatremarks(string remarks)
        {
            string finalremark = string.Empty;
            string specialcharacter = ConfigurationManager.AppSettings["specialcharacters"];
            string[] specialcharacters = null;
            char symbol;
            specialcharacters = specialcharacter.Split(',');
            finalremark = remarks;
            foreach (string character in specialcharacters)
            {
                
                symbol = Convert.ToChar(character);
                finalremark = finalremark.Replace(symbol, ' ');
                
            }

            return finalremark;

        }


        public String Generate940(DataRow dr_cust, DataRow cust_det, int stmtNo)
        {
            string path = ConfigurationManager.AppSettings["workarea"] + "\\ftpfiles\\" + Day;
            String fileName, fileName1, filePath = "";
            String AcctName = cust_det["AccountName"].ToString();
            String k = "12";
            String strTmp;
            String strDest_Code = cust_det["des_CODE"].ToString();
            String datestr;
            String sapcode="";
            //int stmtNo = Convert.ToInt32(cust_det["StmtNo"]) + 1;
            String newlinestr = "\r\n";
            String Curr = cust_det["Cur_code"].ToString();
            String DebCre;
            String strCur_code = cust_det["Cur_code"].ToString();
            String strAmt;
            String strAmt1;
            String UseNUBAN = cust_det["UseNUBAN"].ToString();
            String NUBAN = cust_det["NUBAN"].ToString();
            string availablebal = "";
            String TraAmnt, CustRef, BankRef="0", Remarks;
            String strt61="", strt86="", strt62F="", strt64="";
            String mValDate = null, mTraDate = null;
            String Cr_Dr_Ind;
            String Trans_Type;
            String narr_GAPS = null, narr_ref = null;
            Char[] charsep = { ' ' };
            String[] tempstr;
            Decimal runningBalance = 0M;
            Decimal output = 0M;
            int transactions = dt_trans.Rows.Count;
            int trans = Convert.ToInt16(ConfigurationManager.AppSettings["trans"]);

            //Get Maximun number of split files
            int max_split_files = Convert.ToInt32(ConfigurationManager.AppSettings["max_split_files"]);

            output = transactions / trans;
            string filepath1 = "";
            int filenumber = 0;
            Int32 sum = 0;
			String[] amount;
            string naira = string.Empty;
            string kobo = string.Empty;

            if (transactions > trans)
            {
                filenumber = Convert.ToInt16(Math.Round(output));
                sum = filenumber * trans;
                if ((transactions - sum) > 0)
                {
                    filenumber = filenumber + 1;
                }
            }

            if (transactions > trans && dr_cust["split_file"].ToString() == "1" && filenumber <= max_split_files)
            {
                filenumber = Convert.ToInt16(Math.Round(output));
                sum = filenumber * trans;
                if ((transactions - sum) > 0)
                {
                    filenumber = filenumber + 1;
                }

                int location = 0;
                int p = 0;

                //Create content
                runningBalance = openingBalance;

                for (int i = 1; i <= filenumber; i++)
                {

                    StreamWriter sw;


                    //Create the file
                    filePath = ConfigurationManager.AppSettings["workarea"].ToString();
                    if (cust_det["customerid"].ToString() == "1") //Guiness
                        fileName = AcctName + "XX" + k + "XX" + rep_date.ToString("ddMMMyyyy");
                    else if (cust_det["customerid"].ToString() == "2" || cust_det["customerid"].ToString() == "25") //Total
                        fileName = cust_det["filename"].ToString();
                    else
                        fileName = AcctName + "_" + rep_date.ToString("ddMMMyyyy");

                    try
                    {
                        filePath = filePath + fileName + "_" + i + cust_det["ext_code"].ToString();
                        if ((filepath1.Equals("")))
                        {
                            filepath1 = filePath;
                        }
                        else
                        {
                            filepath1 = filepath1 + "," + filePath;
                        }



                        //filepath1 = filePath + "," + filePath + fileName + "_" + i + ".msg";



                        sw = new StreamWriter(filePath);


                        if (cust_det["customerid"].ToString() == "19" || cust_det["customerid"].ToString() == "37" || cust_det["customerid"].ToString() == "38") //Dangote
                        {
                            strTmp = "{";
                        }
                        else
                        {
                            strTmp = "{1:F01GTBINGLAAXXX0000000000}{2:I940" + strDest_Code + "}{4:";
                        }


                        if (cust_det["customerid"].ToString() == "19" || cust_det["customerid"].ToString() == "37" || cust_det["customerid"].ToString() == "38") // Dangote
                        {
                            strTmp = strTmp + newlinestr + ":20:ST" + rep_date.ToString("yyMMdd") + "CYC/" + stmtNo.ToString().PadLeft(6, '0');
                        }
                        else if (cust_det["customerid"].ToString() == "22" || cust_det["customerid"].ToString() == "42") // NBL
                        {
                            strTmp = strTmp + newlinestr + ":20:" + rep_date.AddDays(-1.0).ToString("yyMMdd");
                        }
                        else
                        {
                            strTmp = strTmp + newlinestr + ":20:" + rep_date.ToString("yyyyMMdd") + rep_date.ToString("MM") + stmtNo.ToString().PadLeft(6, '0');
                        }


                        if (UseNUBAN == "1")
                            strTmp = strTmp + newlinestr + ":25:" + NUBAN;

                        else
                        {

                            if (cust_det["customerid"].ToString() == "4")   //Lufthansa
                                strTmp = strTmp + newlinestr + ":25:" + param1.PadLeft(4, '0') + "/" + param2.PadLeft(7, '0') + param3.PadLeft(3, '0') + param4.PadLeft(4, '0') + param5.PadLeft(3, '0');
                            else
                                strTmp = strTmp + newlinestr + ":25:" + param1 + param2 + param3 + param4 + param5;
                        }

                        if (cust_det["customerid"].ToString() == "22" || cust_det["customerid"].ToString() == "42")
                            strTmp = strTmp + newlinestr + ":28C:" + stmtNo.ToString().PadLeft(6, '0');
                        else
                            strTmp = strTmp + newlinestr + ":28C:" + stmtNo.ToString() + "/" + i.ToString() + "";

                        if (i == 1)
                        {
                            strAmt = Convert.ToDecimal(Math.Abs(openingBalance)).ToString().Replace(".", ",");
                            //strAmt = (strAmt.Contains(",")) ? strAmt : strAmt + ",00";
							strAmt = (strAmt.Contains(",")) ? strAmt : strAmt + ",00";
                            amount = strAmt.Split(',');
                            naira = amount[0];
                            kobo = amount[1];
                            if (kobo.Length > 2)
                            {
                                kobo = kobo.Substring(0, 2);
                            }
                            strAmt = naira + ',' + kobo;
                            DebCre = (openingBalance >= 0) ? "C" : "D";
                            strTmp = strTmp + newlinestr + ":60F:" + DebCre + startDate.ToString("yyMMdd") + strCur_code + strAmt;

                           
                        }
                        else
                        {
                            strAmt = Convert.ToDecimal(Math.Abs(runningBalance)).ToString().Replace(".", ",");
                            //strAmt = (strAmt.Contains(",")) ? strAmt : strAmt + ",00";
							strAmt = (strAmt.Contains(",")) ? strAmt : strAmt + ",00";
                            amount = strAmt.Split(',');
                            naira = amount[0];
                            kobo = amount[1];
                            if (kobo.Length > 2)
                            {
                                kobo = kobo.Substring(0, 2);
                            }
                            strAmt = naira + ',' + kobo;
                            DebCre = (openingBalance >= 0) ? "C" : "D";
                            strTmp = strTmp + newlinestr + ":60M:" + DebCre + startDate.ToString("yyMMdd") + strCur_code + strAmt;
                        }

                        //Loop thro the transactions
                        //foreach (DataRow dr in dt_trans.Rows)
                        for (p = location; p < location + trans; p++)
                        {
                            if (transactions > p)
                            {
                                DataRow dr = dt_trans.Rows[p];
                                mValDate = Convert.ToDateTime(dr["Val_Date"]).ToString("yyMMdd");
                                mTraDate = Convert.ToDateTime(dr["Tra_Date"]).ToString("MMdd");
                                Remarks = dr["REMARKS"].ToString().PadRight(100, ' ');
                                Cr_Dr_Ind = (dr["DEB_CRE_IND"].ToString() == "1") ? "D" : "C";
                                TraAmnt = Convert.ToDecimal(dr["TRA_AMT"]).ToString().Replace(".", ",");
                                TraAmnt = (TraAmnt.Contains(",")) ? TraAmnt : TraAmnt + ",00";

                                if (cust_det["customerid"].ToString() == "22") //nbl
                                {
                                    //Get SAP Code
                                    Trans_Type = GetTransType2(dr);
                                    DataRow dr_ref = GetReferences(Trans_Type, dr);

                                    BankRef = Trans_Type + "NONREF" + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();   //dr[("DOC_NUM")

                                    strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + dr_ref["bank_ref"].ToString();
                                    strt86 = ":86:" + dr_ref["trans_ref"].ToString();
                                }
                                else if (cust_det["customerid"].ToString() == "2" || cust_det["customerid"].ToString() == "25") //Total
                                {
                                    String[] temp_rem_array = null;
                                    String temp_rem = String.Empty;
                                    String gaps_transid = String.Empty;
                                    String gaps_reference = String.Empty;
                                    String gaps_ben_name = String.Empty;
                                    String total_remarks = String.Empty;

                                    Trans_Type = "N" + GetTransType(dr["DES_ENG"].ToString());

                                    //Get GAPS transaction id 
                                    if (dr["remarks"].ToString().Contains("via GAPS"))
                                    {
                                        temp_rem_array = dr["remarks"].ToString().Split(' ');
                                        gaps_transid = temp_rem_array[3];
                                        if (gaps_transid != "")
                                        {
                                            gaps_ben_name = GetGAPSBeneficiaryName(gaps_transid);
                                        }
                                        else
                                        {
                                            gaps_ben_name = dr["remarks"].ToString().Substring(dr["remarks"].ToString().IndexOf(" TO "));
                                            gaps_ben_name = gaps_ben_name.Replace(" TO ", "");
                                        }

                                        gaps_reference = temp_rem_array[2];

                                        BankRef = Trans_Type + gaps_reference + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();
                                        total_remarks = gaps_reference + "//" + " " + " via GAPS TRF IFO " + " " + gaps_ben_name;
                                    }
                                    else if (dr["remarks"].ToString().Contains("trGP"))
                                    {
                                        gaps_ben_name = dr["remarks"].ToString().Substring(44, 20);
                                        total_remarks = dr["remarks"].ToString().Substring(dr["remarks"].ToString().IndexOf("trGP"));
                                        gaps_reference = total_remarks.Split(' ')[1];

                                        BankRef = Trans_Type + gaps_reference + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();
                                        total_remarks = gaps_reference + "//" + " NEFT TRF IFO " + gaps_ben_name;
                                    }
                                    else
                                    {
                                        BankRef = Trans_Type + "NONREF" + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();
                                        total_remarks = formatremarks(Remarks.Trim().Replace("@", ""));
                                    }

                                    strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;
                                    strt86 = ":86:" + total_remarks;
                                }
                                else if (cust_det["customerid"].ToString() == "86") //Etisalat
                                {
                                    Trans_Type = "N" + GetTransType(dr["DES_ENG"].ToString());


                                    if (Trans_Type == "NTRF" && dr["EXPL_CODE"].ToString() == "102" && Cr_Dr_Ind == "C" && Remarks.Substring(0, 8).ToUpper() == "VIA GAPS")
                                    {
                                        if (cust_det["customerid"].ToString() == "1 ")  //Guiness
                                            Trans_Type = "NCOL";
                                        else
                                            Trans_Type = "NTRF";

                                        tempstr = Remarks.Split(charsep, StringSplitOptions.RemoveEmptyEntries);
                                        narr_GAPS = Remarks.Substring(0, 8).ToUpper();
                                        //narr_ref = Remarks.Substring(9, 11);
                                        narr_ref = tempstr[2];

                                        BankRef = Trans_Type + "NONREF" + "//" + narr_ref;   //Reference


                                        strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;
                                        //strt86 = ":86:" + Remarks.Substring(20, 29);
                                        strt86 = ":86:" + tempstr[3];
                                    }
                                    else if (Trans_Type == "NCHK" && Cr_Dr_Ind == "C")
                                    {
                                        BankRef = Trans_Type + "NONREF" + "//" + dr["DOC_NUM"].ToString();  //Reference
                                        strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;
                                        strt86 = ":86:" + dr["DOC_ALP"].ToString() + dr["DOC_NUM"].ToString();
                                    }
                                    else
                                    {
                                        BankRef = Trans_Type + "NONREF" + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();   //dr[("DOC_NUM")
                                        strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;
                                        //strt86 = ":86:" + dr["Doc_Num"].ToString() + " " + Remarks.Trim().Replace("@", "");
                                        strt86 = ":86:" + dr["Doc_Num"].ToString() + " " + formatremarks(Remarks.Trim().Replace("@", ""));
                                    }
                                }                                   
                                
                                else if (cust_det["customerid"].ToString() == "42") //FIRS
                            {
                                String[] temp_rem_array = null;
                                String temp_rem = String.Empty;
                                String gaps_transid = String.Empty;
                                String gaps_reference = String.Empty;
                                String gaps_ben_name = String.Empty;
                                String total_remarks = String.Empty;
                                String PayDocNum = String.Empty;
                                String BenCode = String.Empty;
                                String BenName = String.Empty;
                                String totalref = String.Empty;
                                DataTable gaptable = new DataTable();
                                string nipref = string.Empty;

                                Trans_Type = "N" + GetTransType(dr["DES_ENG"].ToString());

                                //Get GAPS transaction id 
                                if (dr["remarks"].ToString().Contains("via GAPS"))
                                {
                                    temp_rem_array = dr["remarks"].ToString().Split(' ');
                                    gaps_transid = temp_rem_array[3];
                                    totalref = temp_rem_array[3];
                                    if (gaps_transid != "")
                                    {
                                        gaptable = GetGAPSBeneficiaryDetails(gaps_transid);
                                        // gaps_ben_name = GetGAPSBeneficiaryName(gaps_transid);

                                        if(gaptable.Rows.Count > 0)
                                        {
                                            PayDocNum = gaptable.Rows[0]["Reference"].ToString();
                                            BenCode = gaptable.Rows[0]["VendorCode"].ToString();
                                            BenName = gaptable.Rows[0]["VendorName"].ToString();
                                            Remarks = gaptable.Rows[0]["Remarks"].ToString();
                                            BenCode = "IR" + BenCode;

                                           totalref = BenCode + " " + BenName + " " + PayDocNum + " " + Remarks;
                                            

                                        }
                                    }
                                    else
                                    {
                                        gaps_ben_name = dr["remarks"].ToString().Substring(dr["remarks"].ToString().IndexOf(" TO "));
                                        gaps_ben_name = gaps_ben_name.Replace(" TO ", "");
                                        BenName = gaps_ben_name;
                                    }

                                    gaps_reference = temp_rem_array[2];

                                    BankRef = Trans_Type + gaps_reference + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();
                                    total_remarks = gaps_reference + "//" + " " + " via GAPS TRF IFO " + " " + BenName;

                                 
                                    ////strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;
                                    //////strt86 = ":86:" + Remarks.Substring(20, 29);
                                    ////strt86 = ":86:" + totalref;
                                }
                                else if (dr["remarks"].ToString().Contains("trGP"))
                                {
                                      tempstr = Remarks.Split(charsep, StringSplitOptions.RemoveEmptyEntries);
                                    gaps_transid = tempstr[tempstr.Length - 1].ToString();

                                    if (gaps_transid != "")
                                    {
                                        gaptable = GetGAPSBeneficiaryDetails(gaps_transid);
                                        if(gaptable.Rows.Count > 0)
                                        {
                                            PayDocNum = gaptable.Rows[0]["Reference"].ToString();
                                            BenCode = gaptable.Rows[0]["VendorCode"].ToString();
                                            BenName = gaptable.Rows[0]["VendorName"].ToString();
                                            Remarks = gaptable.Rows[0]["Remarks"].ToString();
                                            BenCode = "IR" + BenCode;

                                            totalref = BenCode + " " + BenName + " " + PayDocNum + " " + Remarks;
                                        }

                                            
                                    }
                                    BenName  = dr["remarks"].ToString().Substring(44, 20);
                                    total_remarks = dr["remarks"].ToString().Substring(dr["remarks"].ToString().IndexOf("trGP"));
                                    totalref = total_remarks;
                                    gaps_reference = total_remarks.Split(' ')[1];

                                    BankRef = Trans_Type + gaps_reference + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();
                                    //total_remarks = gaps_reference + "//" + " NEFT TRF IFO " + gaps_ben_name;
                                }
                                else if(dr["expl_code"].ToString().Equals("640") || dr["expl_code"].ToString().Equals("643"))
                                {
                                    nipref = dr["remarks"].ToString().Substring(0, 30);
                                     if (nipref != "")
                                     {
                                        gaptable = GetNIPDetails(nipref);
                                          if(gaptable.Rows.Count > 0)
                                        {
                                            
                                            BenName = gaptable.Rows[0]["BenName"].ToString();
                                              Remarks = gaptable.Rows[0]["Remark"].ToString();
                                            

                                            totalref = BenCode + " " + BenName + " " + PayDocNum + " " + Remarks;
                                        }
                                         
                                     }


                                }
                                else
                                {
                                    BankRef = Trans_Type + "NONREF" + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();
                                    total_remarks = formatremarks(Remarks.Trim().Replace("@", ""));
                                    totalref = total_remarks;
                                }

                                strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;
                                strt86 = ":86:" + totalref;
                            }
                                else
                                {
                                    Trans_Type = "N" + GetTransType(dr["DES_ENG"].ToString());


                                    if (Trans_Type == "NTRF" && dr["EXPL_CODE"].ToString() == "102" && Cr_Dr_Ind == "C" && Remarks.Substring(0, 8).ToUpper() == "VIA GAPS")
                                    {
                                        if (cust_det["customerid"].ToString() == "1 ")  //Guiness
                                            Trans_Type = "NCOL";
                                        else
                                            Trans_Type = "NTRF";

                                        tempstr = Remarks.Split(charsep, StringSplitOptions.RemoveEmptyEntries);
                                        narr_GAPS = Remarks.Substring(0, 8).ToUpper();
                                        //narr_ref = Remarks.Substring(9, 11);
                                        narr_ref = tempstr[2];
                                        //BankRef = Trans_Type + "NONREF" + "//" + Remarks.Substring(9, 11);   //Reference
                                        BankRef = Trans_Type + "NONREF" + "//" + narr_ref;   //Reference
                                        strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;
                                        //strt86 = ":86:" + Remarks.Substring(20, 29);
                                        strt86 = ":86:" + tempstr[3];
                                    }
                                    else if (Trans_Type == "NCHK" && Cr_Dr_Ind == "C")
                                    {
                                        BankRef = Trans_Type + "NONREF" + "//" + dr["DOC_NUM"].ToString();  //Reference
                                        strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;
                                        strt86 = ":86:" + dr["DOC_ALP"].ToString() + dr["DOC_NUM"].ToString();
                                    }
                                    else
                                    {
                                        BankRef = Trans_Type + "NONREF" + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();   //dr[("DOC_NUM")
                                        strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;
                                        //strt86 = ":86:" + dr["Doc_Num"].ToString() + " " + Remarks.Trim().Replace("@", "");
                                        strt86 = ":86:" + dr["Doc_Num"].ToString() + " " + formatremarks(Remarks.Trim().Replace("@", ""));
                                    }

                                }

                                if (strt86.Length > 69)
                                    strt86 = strt86.Substring(0, 65);

                                if (Cr_Dr_Ind == "D")
                                    runningBalance = runningBalance - Convert.ToDecimal(dr["TRA_AMT"]);
                                else
                                    runningBalance = runningBalance + Convert.ToDecimal(dr["TRA_AMT"]);

                                strTmp = strTmp + newlinestr + strt61;
                                strTmp = strTmp + newlinestr + strt86;

                            }
                        }

                        strAmt = Convert.ToString(Math.Abs(runningBalance)).Replace(".", ",");
                        //strAmt = (strAmt.Contains(",")) ? strAmt : strAmt + ",00";
						strAmt = (strAmt.Contains(",")) ? strAmt : strAmt + ",00";
                            amount = strAmt.Split(',');
                            naira = amount[0];
                            kobo = amount[1];
                            if (kobo.Length > 2)
                            {
                                kobo = kobo.Substring(0, 2);
                            }
                            strAmt = naira + ',' + kobo;
						
						
						
                        strt62F = (runningBalance >= 0) ? "C" : "D";
                        strt62F = strt62F + endDate.ToString("yyMMdd") + strCur_code + strAmt;

                        if (i < filenumber)
                        {
                            strTmp = strTmp + newlinestr + ":62M:" + strt62F;
                           
                        }
                        else
                        {
                            strTmp = strTmp + newlinestr + ":62F:" + strt62F;
                        }

                        if (cust_det["customerid"].ToString() == "19" || cust_det["customerid"].ToString() == "37" || cust_det["customerid"].ToString() == "38") //Dangote
                        {
                            strTmp = strTmp + newlinestr + ":64:" + strt62F;
                            strTmp = strTmp + newlinestr + "-}";

                        }
                        else
                        {
                            strTmp = strTmp + newlinestr + ":86:GUARANTY TRUST BANK PLC";
                            strTmp = strTmp + newlinestr + "-}";
                            
                        }
                        sw.Write(strTmp);
                        sw.Flush();

                        sw.Close();
                        sw = null;

                        //FTP file to the swift server
                        //if (dr_cust["FTP_File"].ToString() == "1")
                        //{
                        //    FTP_File(filePath);
                        //}

                        if (dr_cust["FTP_File"].ToString() == "1")
                        {
                            //FTP_File(filePath);
                            string filenamext = Path.GetFileName(filePath);
                            //path = 
                            string path1 = path + "\\" + filenamext;

                            if (!(Directory.Exists(path)))
                            {
                                Directory.CreateDirectory(path);
                                File.Copy(filePath, path1);
                            }
                            else
                            {
                                File.Copy(filePath, path1);

                            }



                        }
                    }
                    catch (Exception ex)
                    {
                        filePath = "0";
                    }

                    location = location + trans;

                }

                cust_det["last_balance"] = runningBalance;

                return filepath1;


            }
            else
            {
                StreamWriter sw;


                //Create the file
                filePath = ConfigurationManager.AppSettings["workarea"].ToString();
                if (cust_det["customerid"].ToString() == "1")
                    fileName = AcctName + "XX" + k + "XX" + rep_date.ToString("ddMMMyyyy");
                else if (cust_det["customerid"].ToString() == "2" || cust_det["customerid"].ToString() == "25")
                    fileName = cust_det["filename"].ToString();
                else
                    fileName = AcctName + "_" + rep_date.ToString("ddMMMyyyy");

                try
                {
                    filePath = filePath + fileName + cust_det["ext_code"].ToString();

                    sw = new StreamWriter(filePath);

                    //Create content
                    runningBalance = openingBalance;

                    if (cust_det["customerid"].ToString() == "19" || cust_det["customerid"].ToString() == "37" || cust_det["customerid"].ToString() == "38") //Dangote
                    {
                        strTmp = "{";
                        
                    }
                    else
                    {
                        strTmp = "{1:F01GTBINGLAAXXX0000000000}{2:I940" + strDest_Code + "}{4:";
                    }

                    if (cust_det["customerid"].ToString() == "19" || cust_det["customerid"].ToString() == "37" || cust_det["customerid"].ToString() == "38") //Dangote
                    {
                        strTmp = strTmp + newlinestr + ":20:ST" + rep_date.ToString("yyMMdd") + "CYC/" + stmtNo.ToString().PadLeft(6, '0');
                    }
                    else if (cust_det["customerid"].ToString() == "22" || cust_det["customerid"].ToString() == "42") // NBL
                    {
                        strTmp = strTmp + newlinestr + ":20:" + rep_date.AddDays(-1.0).ToString("yyMMdd");
                    }
                    else
                    {
                        strTmp = strTmp + newlinestr + ":20:" + rep_date.ToString("yyyyMMdd") + rep_date.ToString("MM") + stmtNo.ToString().PadLeft(6, '0');
                    }


                    if (UseNUBAN == "1")
                        strTmp = strTmp + newlinestr + ":25:" + NUBAN;

                    else
                    {

                        if (cust_det["customerid"].ToString() == "4")   //Lufthansa
                            strTmp = strTmp + newlinestr + ":25:" + param1.PadLeft(4, '0') + "/" + param2.PadLeft(7, '0') + param3.PadLeft(3, '0') + param4.PadLeft(4, '0') + param5.PadLeft(3, '0');
                        else
                            strTmp = strTmp + newlinestr + ":25:" + param1 + param2 + param3 + param4 + param5;
                    }

                    if (cust_det["customerid"].ToString() == "22" || cust_det["customerid"].ToString() == "42") //NBL
                        strTmp = strTmp + newlinestr + ":28C:" + stmtNo.ToString().PadLeft(6, '0');
                    else
                        strTmp = strTmp + newlinestr + ":28C:" + stmtNo.ToString() + "/1";

                    //if(cust_det["customerid"].ToString() == "1")
                    //    strTmp = strTmp + newlinestr + ":28C:" + stmtNo.ToString() + "/1";
                    //else if (cust_det["customerid"].ToString() == "2")
                    //    strTmp = strTmp + newlinestr + ":28:" + stmtNo.ToString() + "/1";

                    strAmt = Convert.ToDecimal(Math.Abs(openingBalance)).ToString().Replace(".", ",");
                    

                    strAmt = (strAmt.Contains(",")) ? strAmt : strAmt + ",00";
                    amount = strAmt.Split(',');
                    naira = amount[0];
                    kobo = amount[1];
                    if (kobo.Length > 2)
                    {
                        kobo = kobo.Substring(0, 2);
                    }
                    strAmt = naira + ',' + kobo;


                    DebCre = (openingBalance > 0) ? "C" : "D";

                    strTmp = strTmp + newlinestr + ":60F:" + DebCre + startDate.ToString("yyMMdd") + strCur_code + strAmt;

                    //Loop thro the transactions
                    int counter = 0;
                    try
                    {
                        foreach (DataRow dr in dt_trans.Rows)
                        {
                            mValDate = Convert.ToDateTime(dr["Val_Date"]).ToString("yyMMdd");
                            mTraDate = Convert.ToDateTime(dr["Tra_Date"]).ToString("MMdd");
                            Remarks = dr["REMARKS"].ToString().PadRight(100, ' ');
                            Cr_Dr_Ind = (dr["DEB_CRE_IND"].ToString() == "1") ? "D" : "C";
                            TraAmnt = Convert.ToDecimal(dr["TRA_AMT"]).ToString().Replace(".", ",");
                            TraAmnt = (TraAmnt.Contains(",")) ? TraAmnt : TraAmnt + ",00";

                            if (cust_det["customerid"].ToString() == "22") //NBL
                            {
                                //Get SAP Code
                                Trans_Type = GetTransType2(dr);
                                DataRow dr_ref = GetReferences(Trans_Type, dr);
                                counter = counter + 1;

                                if (counter > 112)
                                {
                                    counter = counter;
                                }
                                //BankRef = Trans_Type + "NONREF" + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();   //dr[("DOC_NUM")

                                strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + dr_ref["bank_ref"].ToString();
                                strt86 = ":86:" + dr_ref["trans_ref"].ToString();
                            }
                            else if (cust_det["customerid"].ToString() == "2" || cust_det["customerid"].ToString() == "25") //Total
                            {
                                String[] temp_rem_array = null;
                                String temp_rem = String.Empty;
                                String gaps_transid = String.Empty;
                                String gaps_reference = String.Empty;
                                String gaps_ben_name = String.Empty;
                                String total_remarks = String.Empty;

                                Trans_Type = "N" + GetTransType(dr["DES_ENG"].ToString());

                                //Get GAPS transaction id 
                                if (dr["remarks"].ToString().Contains("via GAPS"))
                                {
                                    temp_rem_array = dr["remarks"].ToString().Split(' ');
                                    gaps_transid = temp_rem_array[3];
                                    if (gaps_transid != "")
                                    {
                                        gaps_ben_name = GetGAPSBeneficiaryName(gaps_transid);
                                    }
                                    else
                                    {
                                        gaps_ben_name = dr["remarks"].ToString().Substring(dr["remarks"].ToString().IndexOf(" TO "));
                                        gaps_ben_name = gaps_ben_name.Replace(" TO ", "");
                                    }

                                    gaps_reference = temp_rem_array[2];

                                    BankRef = Trans_Type + gaps_reference + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();
                                    total_remarks = gaps_reference + "//" + " " + " via GAPS TRF IFO " + " " + gaps_ben_name;
                                }
                                else if (dr["remarks"].ToString().Contains("trGP"))
                                {
                                    gaps_ben_name = dr["remarks"].ToString().Substring(44, 20);
                                    total_remarks = dr["remarks"].ToString().Substring(dr["remarks"].ToString().IndexOf("trGP"));
                                    gaps_reference = total_remarks.Split(' ')[1];

                                    BankRef = Trans_Type + gaps_reference + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();
                                    total_remarks = gaps_reference + "//" + " NEFT TRF IFO " + gaps_ben_name;
                                }
                                else
                                {
                                    BankRef = Trans_Type + "NONREF" + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();
                                    total_remarks = formatremarks(Remarks.Trim().Replace("@", ""));
                                }

                                strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;
                                strt86 = ":86:" + total_remarks;
                            }
                            else if (cust_det["customerid"].ToString() == "86") //Etisalat
                            {
                                Trans_Type = "N" + GetTransType(dr["DES_ENG"].ToString());
                                string[] spli_remarks = Remarks.Split('/');
                                String etisalat_ref = "";
                                if ((spli_remarks.Length == 3) && (spli_remarks[2].Trim().Length >=10))
                                {
                                    etisalat_ref = spli_remarks[2].Trim().Substring(0, 10);
                                }
                                else
                                {
                                    etisalat_ref = "";
                                }
                                // String spattern = 

                                if (Trans_Type == "NTRF" && dr["EXPL_CODE"].ToString() == "102" && Cr_Dr_Ind == "C" && Remarks.Substring(0, 8).ToUpper() == "VIA GAPS")
                                {
                                    if (cust_det["customerid"].ToString() == "1 ")  //Guiness
                                        Trans_Type = "NCOL";
                                    else
                                        Trans_Type = "NTRF";

                                    tempstr = Remarks.Split(charsep, StringSplitOptions.RemoveEmptyEntries);
                                    narr_GAPS = Remarks.Substring(0, 8).ToUpper();
                                    //narr_ref = Remarks.Substring(9, 11);
                                    // narr_ref = tempstr[2];

                                    narr_ref = etisalat_ref;

                                    BankRef = Trans_Type + "NONREF" + "//" + narr_ref;   //Reference


                                    strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;
                                    //strt86 = ":86:" + Remarks.Substring(20, 29);
                                    strt86 = ":86:" + tempstr[3];
                                }
                                else if (Trans_Type == "NCHK" && Cr_Dr_Ind == "C")
                                {
                                    //BankRef = Trans_Type + "NONREF" + "//" + dr["DOC_NUM"].ToString();  //Reference
                                    BankRef = Trans_Type + "NONREF" + "//" + etisalat_ref;  //Reference

                                    strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;


                                    strt86 = ":86:" + dr["DOC_ALP"].ToString() + dr["DOC_NUM"].ToString();
                                }
                                else
                                {
                                    //BankRef = Trans_Type + "NONREF" + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();   //dr[("DOC_NUM")
                                    BankRef = Trans_Type + "NONREF" + "//" + etisalat_ref;   //dr[("DOC_NUM")

                                    strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;


                                    //strt86 = ":86:" + dr["Doc_Num"].ToString() + " " + Remarks.Trim().Replace("@", "");
                                    strt86 = ":86:" + dr["Doc_Num"].ToString() + " " + formatremarks(Remarks.Trim().Replace("@", ""));
                                }
                            }
                            else if (cust_det["customerid"].ToString() == "42") //FIRS
                            {
                                String[] temp_rem_array = null;
                                String temp_rem = String.Empty;
                                String gaps_transid = String.Empty;
                                String gaps_reference = String.Empty;
                                String gaps_ben_name = String.Empty;
                                String total_remarks = String.Empty;
                                String PayDocNum = String.Empty;
                                String BenCode = String.Empty;
                                String BenName = String.Empty;
                                String totalref = String.Empty;
                                DataTable gaptable = new DataTable();
                                string nipref = string.Empty;

                                Trans_Type = "N" + GetTransType(dr["DES_ENG"].ToString());

                                //Get GAPS transaction id 
                                if (dr["remarks"].ToString().Contains("via GAPS"))
                                {
                                    temp_rem_array = dr["remarks"].ToString().Split(' ');
                                    gaps_transid = temp_rem_array[3];
                                    totalref = temp_rem_array[3];
                                    if (gaps_transid != "")
                                    {
                                        gaptable = GetGAPSBeneficiaryDetails(gaps_transid);
                                        // gaps_ben_name = GetGAPSBeneficiaryName(gaps_transid);

                                        if(gaptable.Rows.Count > 0)
                                        {
                                            PayDocNum = gaptable.Rows[0]["Reference"].ToString();
                                            BenCode = gaptable.Rows[0]["VendorCode"].ToString();
                                            BenName = gaptable.Rows[0]["VendorName"].ToString();
                                            Remarks = gaptable.Rows[0]["Remarks"].ToString();
                                            BenCode = "IR" + BenCode;

                                           totalref = BenCode + " " + BenName + " " + PayDocNum + " " + Remarks;
                                            

                                        }
                                    }
                                    else
                                    {
                                        gaps_ben_name = dr["remarks"].ToString().Substring(dr["remarks"].ToString().IndexOf(" TO "));
                                        gaps_ben_name = gaps_ben_name.Replace(" TO ", "");
                                        BenName = gaps_ben_name;
                                    }

                                    gaps_reference = temp_rem_array[2];

                                    BankRef = Trans_Type + gaps_reference + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();
                                    total_remarks = gaps_reference + "//" + " " + " via GAPS TRF IFO " + " " + BenName;

                                 
                                    ////strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;
                                    //////strt86 = ":86:" + Remarks.Substring(20, 29);
                                    ////strt86 = ":86:" + totalref;
                                }
                                else if (dr["remarks"].ToString().Contains("trGP"))
                                {
                                      tempstr = Remarks.Split(charsep, StringSplitOptions.RemoveEmptyEntries);
                                    gaps_transid = tempstr[tempstr.Length - 1].ToString();

                                    if (gaps_transid != "")
                                    {
                                        gaptable = GetGAPSBeneficiaryDetails(gaps_transid);
                                        if(gaptable.Rows.Count > 0)
                                        {
                                            PayDocNum = gaptable.Rows[0]["Reference"].ToString();
                                            BenCode = gaptable.Rows[0]["VendorCode"].ToString();
                                            BenName = gaptable.Rows[0]["VendorName"].ToString();
                                            Remarks = gaptable.Rows[0]["Remarks"].ToString();
                                            BenCode = "IR" + BenCode;

                                            totalref = BenCode + " " + BenName + " " + PayDocNum + " " + Remarks;
                                        }

                                            
                                    }
                                    BenName  = dr["remarks"].ToString().Substring(44, 20);
                                    total_remarks = dr["remarks"].ToString().Substring(dr["remarks"].ToString().IndexOf("trGP"));
                                    totalref = total_remarks;
                                    gaps_reference = total_remarks.Split(' ')[1];

                                    BankRef = Trans_Type + gaps_reference + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();
                                    //total_remarks = gaps_reference + "//" + " NEFT TRF IFO " + gaps_ben_name;
                                }
                                else if(dr["expl_code"].ToString().Equals("640") || dr["expl_code"].ToString().Equals("643"))
                                {
                                    nipref = dr["remarks"].ToString().Substring(0, 30);
                                     if (nipref != "")
                                     {
                                        gaptable = GetNIPDetails(nipref);
                                          if(gaptable.Rows.Count > 0)
                                        {
                                            
                                            BenName = gaptable.Rows[0]["BenName"].ToString();
                                              Remarks = gaptable.Rows[0]["Remark"].ToString();
                                            

                                            totalref = BenCode + " " + BenName + " " + PayDocNum + " " + Remarks;
                                        }
                                         
                                     }


                                }
                                else
                                {
                                    BankRef = Trans_Type + "NONREF" + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();
                                    total_remarks = formatremarks(Remarks.Trim().Replace("@", ""));
                                    totalref = total_remarks;
                                }

                                strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;
                                strt86 = ":86:" + totalref;
                            }                            
                            else
                            {
                                Trans_Type = "N" + GetTransType(dr["DES_ENG"].ToString());

                                if (Trans_Type == "NTRF" && dr["EXPL_CODE"].ToString() == "102" && Cr_Dr_Ind == "C" && Remarks.Substring(0, 8).ToUpper() == "VIA GAPS")
                                {
                                    if (cust_det["customerid"].ToString() == "1") //Guiness
                                        Trans_Type = "NCOL";
                                    else
                                        Trans_Type = "NTRF";

                                    //Remarks = "Via GAPS R2300083881 GTB_166934_R2300083881 transfer from Taiwo to Guiness Plc";
                                    tempstr = Remarks.Split(charsep, StringSplitOptions.RemoveEmptyEntries);
                                    narr_GAPS = Remarks.Substring(0, 8).ToUpper();
                                    //narr_ref = Remarks.Substring(9, 11);
                                    narr_ref = tempstr[2];
                                    //BankRef = Trans_Type + "NONREF" + "//" + Remarks.Substring(9, 11);   //Reference
                                    BankRef = Trans_Type + "NONREF" + "//" + narr_ref;   //Reference
                                    strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;
                                    //strt86 = ":86:" + Remarks.Substring(20, 29);
                                    strt86 = ":86:" + tempstr[3];
                                }
                                else if (Trans_Type == "NCHK" && Cr_Dr_Ind == "C")
                                {
                                    BankRef = Trans_Type + "NONREF" + "//" + dr["DOC_NUM"].ToString();  //Reference
                                    strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;
                                    strt86 = ":86:" + dr["DOC_ALP"].ToString() + dr["DOC_NUM"].ToString();
                                }
                                else
                                {
                                    BankRef = Trans_Type + "NONREF" + "//" + dr["TRA_SEQ1"].ToString() + dr["TRA_SEQ2"].ToString();   //dr[("DOC_NUM")
                                    strt61 = ":61:" + mValDate + mTraDate + Cr_Dr_Ind + "N" + TraAmnt + BankRef;
                                    strt86 = ":86:" + dr["Doc_Num"].ToString() + " " + formatremarks(Remarks.Trim().Replace("@", ""));
                                }
                            }

                            if (strt86.Length > 69)
                                strt86 = strt86.Substring(0, 65);

                            if (Cr_Dr_Ind == "D")
                                runningBalance = runningBalance - Convert.ToDecimal(dr["TRA_AMT"]);
                            else
                                runningBalance = runningBalance + Convert.ToDecimal(dr["TRA_AMT"]);

                            strTmp = strTmp + newlinestr + strt61;
                            strTmp = strTmp + newlinestr + strt86;

                        }
                    }
                    catch (Exception ex)
                    {

                    }

                    strAmt = Convert.ToString(Math.Abs(runningBalance)).Replace(".", ",");
                    strAmt = (strAmt.Contains(",")) ? strAmt : strAmt + ",00";

                    
                    amount = strAmt.Split(',');
                    naira = amount[0];
                    kobo = amount[1];
                    if (kobo.Length > 2)
                    {
                        kobo = kobo.Substring(0, 2);
                    }
                    strAmt = naira + ',' + kobo;

                    strt62F = (runningBalance >= 0) ? "C" : "D";
                    //strt62F = strt62F + mValDate + strCur_code + strAmt;
                    strt62F = strt62F + endDate.ToString("yyMMdd") + strCur_code + strAmt;

                    strTmp = strTmp + newlinestr + ":62F:" + strt62F;
                    if (cust_det["customerid"].ToString() == "19" || cust_det["customerid"].ToString() == "37" || cust_det["customerid"].ToString() == "38")
                    {
                        strTmp = strTmp + newlinestr + ":64:" + strt62F;
                        strTmp = strTmp + newlinestr + "-}";
                        
                    }
                    else
                    {
                        strTmp = strTmp + newlinestr + ":86:GUARANTY TRUST BANK PLC";
                        strTmp = strTmp + newlinestr + "-}";  

                    }
                    sw.Write(strTmp);
                    sw.Flush();

                    sw.Close();
                    sw = null;

                    //FTP file to the swift server
                    //if (dr_cust["FTP_File"].ToString() == "1")
                    //{
                    //    if (dr_cust["split_file"].ToString() != "1")
                    //    FTP_File(filePath);
                    //}
                    if (dr_cust["FTP_File"].ToString() == "1")
                    {
                        //FTP_File(filePath);
                        string filenamext = Path.GetFileName(filePath);
                        //path = 
                        string path1 = path + "\\" + filenamext;

                        if (!(Directory.Exists(path)))
                        {
                            Directory.CreateDirectory(path);
                            File.Copy(filePath, path1);
                        }
                        else
                        {
                            File.Copy(filePath, path1);

                        }



                    }
                }
                catch (Exception ex)
                {
                    filePath = "0";
                }


                cust_det["last_balance"] = runningBalance;

            }


            if (!(filepath1.Equals("")))
            {
                return filepath1;
            }
            else
            {
                return filePath;
            }

        }


        private DataTable GetGAPSBeneficiaryDetails(string gaps_transid)
        {
            DataTable dst = new DataTable();
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["GAPSConnstrRead"].ToString()))
            {
                SqlCommand comm = new SqlCommand("dbo.proc_getMT940BeneDetails", conn);
                SqlDataAdapter adapter = new SqlDataAdapter(comm);

                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@transid", Convert.ToInt64(gaps_transid));

                try
                {
                    //open connetion
                    if (conn.State != ConnectionState.Open)
                    {
                        conn.Open();
                    }
                    adapter.Fill(dst);
                    adapter.Dispose();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return dst = null;
                }
                conn.Close();
            }

            if (dst.Rows.Count > 0)
            {
                return dst;//.Rows[0]["vendorname"].ToString();
            }
            else
            {
                return dst = null;
            }
        }


        private DataTable GetNIPDetails(string gaps_transid)
        {
            DataTable dst = new DataTable();
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["eone"].ToString()))
            {
                SqlCommand comm = new SqlCommand("dbo.proc_SelectNIPTrans_MT940", conn);
                SqlDataAdapter adapter = new SqlDataAdapter(comm);

                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@transid", Convert.ToInt64(gaps_transid));

                try
                {
                    //open connetion
                    if (conn.State != ConnectionState.Open)
                    {
                        conn.Open();
                    }
                    adapter.Fill(dst);
                    adapter.Dispose();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return dst = null;
                }
                conn.Close();
            }

            if (dst.Rows.Count > 0)
            {
                return dst;//.Rows[0]["vendorname"].ToString();
            }
            else
            {
                return dst = null;
            }
        }




        private string GetGAPSBeneficiaryName(string gaps_transid)
        {
            DataTable dst = new DataTable();
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["GAPSConnstrRead"].ToString()))
            {
                SqlCommand comm = new SqlCommand("dbo.proc_getMT940BeneName", conn);
                SqlDataAdapter adapter = new SqlDataAdapter(comm);

                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@transid", Convert.ToInt64(gaps_transid));

                try
                {
                    //open connetion
                    if (conn.State != ConnectionState.Open)
                    {
                        conn.Open();
                    }
                    adapter.Fill(dst);
                    adapter.Dispose();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return "0";
                }
                conn.Close();
            }

            if (dst.Rows.Count > 0)
                return dst.Rows[0]["vendorname"].ToString();
            else
                return "0";
        }

        private DataRow GetReferences(string Trans_Type, DataRow p)
        {
            String tempstr = "";
            String SAPCode = "", SAPCode1 = "", Remarks="";
            String newlinestr = "\r\n";
            String loopstr = null;
            DataTable dt_ref = new DataTable();
            
            DataColumn dc_ref = new DataColumn("bank_ref", typeof(String));
            dt_ref.Columns.Add(dc_ref);
            dc_ref = new DataColumn("trans_ref", typeof(String));
            dt_ref.Columns.Add(dc_ref);
            dc_ref = new DataColumn("sap_code", typeof(String));
            dt_ref.Columns.Add(dc_ref);
            dc_ref = new DataColumn("remarks", typeof(String));
            dt_ref.Columns.Add(dc_ref);

            DataRow dr_ref = dt_ref.NewRow();
            String Rem = p["REMARKS"].ToString().Trim();
            int length = Rem.Length;

            if (Rem == "" || Rem.Length < 7)
            {
                SAPCode = "1111111";
                SAPCode1 = SAPCode;
            }
            else
            {
                //if (Rem.IndexOf("NG") >= 0)
                //{
                //    Remarks = " " + Rem;
                //    if (Rem.IndexOf("NG") >= 0)
                //    {
                //        if (p["DEB_CRE_IND"].ToString() == "1")
                //        {
                //            SAPCode = "NG" + Remarks.Substring(Rem.IndexOf(" NG") + 3, 4);
                //            SAPCode1 = SAPCode;
                //        }
                //        else
                //        {
                //            String tempstr_rem = "";
                //            if (Rem.Contains(" NG") == true)
                //            {
                //                tempstr_rem = Remarks.Substring(Rem.IndexOf(" NG"));
                //                if (tempstr_rem.Length >= 6)
                //                {
                //                    SAPCode = "CNG" + Remarks.Substring(Rem.IndexOf(" NG") + 3, 4);
                //                    SAPCode1 = SAPCode.Substring(SAPCode.Length - 6, 6);
                //                }
                //                else
                //                {
                //                    SAPCode = "1111111";
                //                    SAPCode1 = SAPCode;
                //                }
                //            }
                //            else
                //            {
                //                SAPCode = "1111111";
                //                SAPCode1 = SAPCode;
                //            }
                //        }

                //        if (SAPCode.Substring(0, 2) == "NG" && SAPCode.Replace(" ", "").Length < 6)
                //        {
                //            tempstr = Remarks.Substring(Remarks.IndexOf(" NG") + 3, 5);
                //            SAPCode = "NG" + tempstr.Replace(" ", "");
                //            SAPCode1 = "NG " + SAPCode.Substring(SAPCode.Length - 4, 4);
                //        }

                //        if (SAPCode.Substring(0, 3) == "CNG" && SAPCode.Replace(" ", "").Length < 7)
                //        {
                //            tempstr = Remarks.Substring(Remarks.IndexOf(" NG") + 3, 5);
                //            SAPCode = "CNG" + tempstr.Replace(" ", "");
                //            SAPCode1 = "NG " + SAPCode.Substring(SAPCode.Length - 4, 4);
                //        }
                //    }
                //    else
                //    {
                //        if (Remarks.IndexOf("CNG") != 0)
                //        {
                //            tempstr = Remarks.Substring(Remarks.IndexOf("CNG") + 3, 4);
                //            SAPCode = "CNG" + tempstr;
                //            SAPCode1 = SAPCode;
                //        }
                //    }

                //}

                DataTable dt;
                CultureInfo provider = CultureInfo.InvariantCulture;
                Int64 res;
                Int32 codelength = 7;
                Boolean seencode = false;
                String nbl_custid = ConfigurationManager.AppSettings["NBPLC_CUSTOMERID"].ToString();
                for (int i = 0; i < Rem.Length - (codelength-1); i++)
                {
                    if (Int64.TryParse(Rem.Substring(i, 7), NumberStyles.None, provider, out res) == true)
                    {                        
                        //Check if sapcode exists in the database
                        dt = NBL_GetCustomerDetails(Rem.Substring(i, 7), Convert.ToInt32(nbl_custid));
                        if (dt.Rows.Count > 0)
                        {
                            seencode = true;
                            SAPCode = Rem.Substring(i, 7);
                            break;
                        }
                        else
                        {
                            SAPCode = "";
                            continue;
                        }
                    }
                }

                if (seencode == false)
                    SAPCode = "1111111";

                SAPCode1 = SAPCode;
            }
            
            if(p["REMARKS"] != null)
            
                Remarks = p["REMARKS"].ToString().Replace(SAPCode1, "");
            else
                Remarks = "";

            dr_ref["sap_code"] = SAPCode1;
            dr_ref["remarks"] = Remarks;

            switch(Trans_Type)
            {
                case "NTRF":
                    if(p["Deb_cre_Ind"].ToString() == "2")
                    {
                        if(p["REMARKS"] == null || Rem.Length == 0)
                        {
                            dr_ref["bank_ref"] = Trans_Type + "//" + p["DES_ENG"].ToString() + "";
                            dr_ref["trans_ref"] = SAPCode + "/TRF " + p["TRA_SEQ1"].ToString() + p["TRA_SEQ2"].ToString();
                        }
                        else
                        {
                            dr_ref["bank_ref"] = Trans_Type + "//" + Remarks + "";
                            dr_ref["trans_ref"] = SAPCode + "/" + p["TRA_SEQ1"].ToString() + p["TRA_SEQ2"].ToString();
                        }
                    }
                    else
                    {
                        String tempstr2 = "";
                        switch(p["EXPL_CODE"].ToString())
                        {
                            case "102":
                                //dr_ref["bank_ref"] = Trans_Type + "//" + Remarks.Substring(Rem.IndexOf("to") + 4, length - (Rem.IndexOf("to") + 3)); //+newlinestr;
                                dr_ref["bank_ref"] = Trans_Type + "//" + Remarks; //+newlinestr;
                                if (Rem.Substring(0, 8) == "via GAPS")
                                {

                                    dr_ref["trans_ref"] = Rem.Substring(9, Remarks.IndexOf(" from") - 11) + "/TRF " + p["TRA_SEQ1"].ToString() + p["TRA_SEQ2"].ToString();
                                    
                                }
                                else
                                {
                                    if (Rem.Length < 18)
                                    {
                                        tempstr = Rem;
                                    }
                                    else
                                    {
                                        tempstr = Rem.Substring(0, 18);
                                    }
                                    
                                    dr_ref["trans_ref"] = tempstr.Substring(tempstr.Length-10, 10) + "/TRF " + p["TRA_SEQ1"].ToString() + p["TRA_SEQ2"].ToString();
                                }
                                break;
                            case "2081":
                                //dr_ref["bank_ref"] = Trans_Type + "//" + Remarks.Substring(Rem.IndexOf("to") + 4, length - (Rem.IndexOf("to") + 3)); //+newlinestr;
                                dr_ref["bank_ref"] = Trans_Type + "//" + Remarks; //+newlinestr;
                                if (Rem.Substring(0, 8) == "via GAPS") //Transfer to GTB accounts
                                {
                                    string[] remarray = Rem.Split(' ');


                                    dr_ref["trans_ref"] = remarray[2].ToString() + "/TRF " + p["TRA_SEQ1"].ToString() + p["TRA_SEQ2"].ToString();

                                }
                                else    //Transfer to other banks - NEFT
                                {
                                    //tempstr = Rem.Substring(0, 18);
                                    tempstr = Rem.Substring(Rem.IndexOf("trGP") + 5, 14) ;
                                    //dr_ref["trans_ref"] = tempstr.Substring(tempstr.Length-10, 10) + "/TRF " + p["TRA_SEQ1"].ToString() + p["TRA_SEQ2"].ToString();
                                    dr_ref["trans_ref"] = tempstr + "/TRF " + p["TRA_SEQ1"].ToString() + p["TRA_SEQ2"].ToString();
                                }
                                break;
                            case "640":
                                int length1 = 0;
                                
                                length1 = Rem.Substring(0, 64).Length;
                                dr_ref["bank_ref"] = Trans_Type + "//" + Rem.Substring(0, 64).Substring(length1 - 20, 20) + "";

                                if(Rem.IndexOf("trGP") > 0)
                                {
                                    dr_ref["trans_ref"] = Rem + "/TRF " + p["TRA_SEQ1"].ToString() + p["TRA_SEQ2"].ToString();
                                }
                                else
                                {
                                    dr_ref["trans_ref"] = Rem + "/TRF " + p["TRA_SEQ1"].ToString() + p["TRA_SEQ2"].ToString();
                                }
                                break;
                        
                            default:
                                if(p["REMARKS"] == null || Rem.Length == 0)
                                {
                                    dr_ref["bank_ref"] = Trans_Type + "//" + p["DES_ENG"].ToString() + "";
                                    dr_ref["trans_ref"] = SAPCode + "/TRF " + p["TRA_SEQ1"].ToString() + p["TRA_SEQ2"].ToString();
                                }
                                else
                                {
                                    dr_ref["bank_ref"] = Trans_Type + "//" + Remarks + "";
                                    dr_ref["trans_ref"] = SAPCode + "/" + p["TRA_SEQ1"].ToString() + p["TRA_SEQ2"].ToString();
                                }
                                break;
                        }
                    }
                    break;
                case "NCMS":
                    dr_ref["bank_ref"] = Trans_Type + "//" + p["TRA_SEQ1"].ToString() + p["TRA_SEQ2"].ToString() + "";
                    dr_ref["trans_ref"] = Remarks;
                    break;
                case "NCHK":
                    dr_ref["bank_ref"] = Trans_Type + "//" + Remarks + "";
                    dr_ref["trans_ref"] = SAPCode + "/" + p["Doc_Alp"].ToString() + "-" + p["DOC_NUM"].ToString();
                    break;
                case "NMSC":
                    dr_ref["bank_ref"] = Trans_Type + "//" + p["DES_ENG"].ToString() + " " + Remarks + "";
                    dr_ref["trans_ref"] = SAPCode + "/" + p["TRA_SEQ1"].ToString() + p["TRA_SEQ2"].ToString();
                    break;
                case "NINT":
                    if(p["Deb_cre_ind"].ToString() == "C")
                    {
                        dr_ref["bank_ref"] = Trans_Type + "//INTEREST" + "";
                        dr_ref["trans_ref"] = "INTEREST RECEIVED " + p["VAL_DATE"].ToString();
                    }
                    else
                    {
                        dr_ref["bank_ref"] = Trans_Type + "//INTEREST" + "";
                        dr_ref["trans_ref"] = "INTEREST PAID " + p["VAL_DATE"].ToString();
                    }
                    break;
                case "NCHG":
                    SqlConnection sqlconn = new SqlConnection(ConfigurationManager.ConnectionStrings["TradeTrackerConnstr"].ToString());
                    SqlCommand sqlcomm = null;
                    SqlDataAdapter sqladpt = null;
                    DataTable dt = null;
                    String explcode = p["EXPL_CODE"].ToString();
                    String LCNO=String.Empty, BCREF=String.Empty;
                    String MFNO = String.Empty;
                    String year_str = "";
                    String reftype = String.Empty;
                    int refnum = 0;
                    String sqlstr2 = "", narration1 = "";

                    if (explcode == "70" || explcode == "88" || explcode == "89" || explcode == "90" || explcode == "91" || explcode == "93" || explcode == "95" || explcode == "96" || explcode == "98" || explcode == "348" || explcode == "350" || explcode == "395" || explcode == "446" || explcode == "525" || explcode == "526" || explcode == "530" || explcode == "534" || explcode == "651" || explcode == "650" || explcode == "1271" || explcode == "1278" || explcode == "1279" || explcode == "1274" || explcode == "1325" || explcode == "1326" || explcode == "1329" || explcode == "1419" || explcode == "2159")   //Trade related transactions
                    {
                        //Add MF Number of form m for formM/LC related transactions
                        if (explcode == "1271" || explcode == "1278" || explcode == "1279")    //LC Charges
                        {
                            year_str = p["DOC_NUM"].ToString().Substring(0, 2);
                            refnum = Convert.ToInt32(p["DOC_NUM"].ToString().Substring(2));

                            LCNO = p["BRA_CODE"].ToString() + "/21/" + year_str + "/" + refnum.ToString().PadLeft(4, '0');

                            sqlconn.Open();
                            sqlstr2 = "select * from form_m where ba_no in (select ba_no from lc where substring(lc_number,1," + LCNO.Length.ToString() + ") = '" + LCNO + "')";
                            sqlcomm = new SqlCommand(sqlstr2, sqlconn);
                            dt = new DataTable();
                            sqladpt = new SqlDataAdapter(sqlcomm);
                            sqladpt.Fill(dt);
                            sqlconn.Close();

                            if (dt.Rows.Count > 0)
                            {
                                MFNO = dt.Rows[0]["form_m_no"].ToString();
                            }
                            else
                                MFNO = "";

                            if (explcode == "1271")
                                narration1 = "SWIFT COMMISSION - IMPORT LC";
                            else if (explcode == "1278")
                                narration1 = "VAT AMOUNT - IMPORT LC";
                            else if (explcode == "1279")
                                narration1 = "COMMISSION - IMPORT LC";

                            dr_ref["bank_ref"] = "NTRF" + "//" + MFNO + " " + narration1 + " " + Remarks;
                            dr_ref["trans_ref"] = "BANK CHARGES " + p["VAL_DATE"].ToString();
                        }
                        else if (explcode == "1325" || explcode == "1326" || explcode == "1329")    //BC Charges
                        {
                            year_str = p["DOC_NUM"].ToString().Substring(0, 2);
                            refnum = Convert.ToInt32(p["DOC_NUM"].ToString().Substring(2));

                            BCREF = p["BRA_CODE"].ToString() + "/71/" + year_str + "/" + refnum.ToString().PadLeft(4, '0');

                            sqlstr2 = "select * from b c_table where bra_code = " + p["bra_code"].ToString() + " and cus_num=" + p["cus_num"].ToString() + " and ref_type=71 and ref_year=" + year_str + " and ref_num=" + refnum.ToString();
                            cmd = new OracleCommand(sqlstr2, oraconn);
                            ora_adpt = new OracleDataAdapter(cmd);
                            dt_trans = new DataTable();
                            ora_adpt.Fill(dt_trans);

                            oraconn.Close();

                            if (dt_trans.Rows.Count > 0)
                            {
                                MFNO = dt_trans.Rows[0]["pymnt_inst1"].ToString();
                                MFNO = MFNO.Split('/')[0].ToString();
                                dt_trans.Rows.Clear();
                            }
                            else
                                MFNO = "";

                            if (explcode == "1325")
                                narration1 = "";
                            else if (explcode == "1326")
                                narration1 = "";
                            else if (explcode == "1329")
                                narration1 = "";

                            dr_ref["bank_ref"] = "NTRF" + "//" + MFNO + " " + narration1 + " " + Remarks;
                            dr_ref["trans_ref"] = "BANK CHARGES " + p["VAL_DATE"].ToString();
                        }
                        else if (explcode == "88" || explcode == "89")    //Oversea charges
                        {
                            //Extract the LC/BC rference
                            String[] temp_array = Rem.Substring(Rem.IndexOf("IRO") + 4).Split('/');
                            if (temp_array.GetLength(0) == 4)
                            {
                                reftype = temp_array[1];
                                if (reftype == "21")   //LC
                                {
                                    LCNO = temp_array[0] + "/" + temp_array[1] + "/" + temp_array[2] + "/" + temp_array[3];
                                    sqlconn.Open();
                                    sqlstr2 = "select * from form_m where ba_no in (select ba_no from lc where substring(lc_number,1," + LCNO.Length.ToString() + ") = '" + LCNO + "')";
                                    sqlcomm = new SqlCommand(sqlstr2, sqlconn);
                                    dt = new DataTable();
                                    sqladpt = new SqlDataAdapter(sqlcomm);
                                    sqladpt.Fill(dt);

                                    if (dt.Rows.Count > 0)
                                    {
                                        MFNO = dt.Rows[0]["form_m_no"].ToString();
                                    }
                                    else
                                        MFNO = "";

                                    narration1 = "";

                                    dr_ref["bank_ref"] = "NTRF" + "//" + MFNO + " " + narration1 + " " + Remarks;
                                    dr_ref["trans_ref"] = "BANK CHARGES " + p["VAL_DATE"].ToString();
                                }
                                else if (reftype == "71")    //BC
                                {
                                    LCNO = temp_array[0] + "/" + temp_array[1] + "/" + temp_array[2] + "/" + temp_array[3];
                                    sqlstr2 = "select * from b c_table where bra_code = " + p["bra_code"].ToString() + " and cus_num=" + p["cus_num"].ToString() + " and ref_type=71 and ref_year=" + temp_array[2] + " and ref_num=" + temp_array[3];
                                    cmd = new OracleCommand(sqlstr2, oraconn);
                                    ora_adpt = new OracleDataAdapter(cmd);
                                    dt_trans = new DataTable();
                                    ora_adpt.Fill(dt_trans);

                                    oraconn.Close();

                                    if (dt_trans.Rows.Count > 0)
                                    {
                                        MFNO = dt_trans.Rows[0]["pymnt_inst1"].ToString();
                                        MFNO = MFNO.Split('/')[0].ToString();
                                        dt_trans.Rows.Clear();
                                    }
                                    else
                                        MFNO = "";

                                    narration1 = "";

                                    dr_ref["bank_ref"] = "NTRF" + "//" + MFNO + " " + narration1 + " " + Remarks;
                                    dr_ref["trans_ref"] = "BANK CHARGES " + p["VAL_DATE"].ToString();
                                }
                            }

                        }
                        else
                        {
                            dr_ref["bank_ref"] = "NTRF" + "//CHARGES - " + Remarks + "";
                            dr_ref["trans_ref"] = "BANK CHARGES " + p["VAL_DATE"].ToString();
                        }
                    }
                    else
                    {
                        dr_ref["bank_ref"] = Trans_Type + "//CHARGES - " + Remarks + "";
                        dr_ref["trans_ref"] = "BANK CHARGES " + p["VAL_DATE"].ToString();
                    }
                    break;
                case "NCOM":
                    dr_ref["bank_ref"] = Trans_Type + "//COMMISSIONS" + "";
                    dr_ref["trans_ref"] = "COMMISSIONS " + p["VAL_DATE"].ToString();
                    break;
                case "NBNK":
                    dr_ref["bank_ref"] = Trans_Type + "//BANK FEES" + "";
                    dr_ref["trans_ref"] = "BANK FEES " + p["VAL_DATE"].ToString();
                    break;
                case "NRTI":
                    dr_ref["bank_ref"] = Trans_Type + "//" + Remarks + "";
                    dr_ref["trans_ref"] = "3511111" + "/" + p["Doc_Alp"].ToString() + " " + p["DOC_NUM"].ToString();
                    break;
 
            }            
            dt_ref.Rows.Add(dr_ref);
            
            return dt_ref.Rows[0];
        }

        public DataTable NBL_GetCustomerDetails(String customercode, int customerid)
        {
            DataTable dst = new DataTable();
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GTCollectionConnstr"].ToString()))
            {
                SqlCommand comm = new SqlCommand("dbo.NBL_getCustomerDetailsByCode", conn);
                SqlDataAdapter adapter = new SqlDataAdapter(comm);

                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@customercode", customercode);
                comm.Parameters.AddWithValue("@customerid", customerid);

                try
                {
                    //open connetion
                    if (conn.State != ConnectionState.Open)
                    {
                        conn.Open();
                    }
                    adapter.Fill(dst);
                    adapter.Dispose();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return dst;
                }
                conn.Close();
            }

            return dst;
        }

        protected decimal getbal()
        {
            decimal balance = 0;
            decimal runningBalance = openingBalance;
            foreach (DataRow dr in dt_trans.Rows)
            {
                //mValDate = Convert.ToDateTime(dr["Val_Date"]).ToString("yyMMdd");
                //mTraDate = Convert.ToDateTime(dr["Tra_Date"]).ToString("MMdd");
                //Remarks = dr["REMARKS"].ToString().PadRight(100, ' ');
                string Cr_Dr_Ind = (dr["DEB_CRE_IND"].ToString() == "1") ? "D" : "C";
                String TraAmnt = Convert.ToDecimal(dr["TRA_AMT"]).ToString().Replace(".", ",");
                TraAmnt = (TraAmnt.Contains(",")) ? TraAmnt : TraAmnt + ",00";

                if (Cr_Dr_Ind == "D")
                    runningBalance = runningBalance - Convert.ToDecimal(dr["TRA_AMT"]);
                else
                    runningBalance = runningBalance + Convert.ToDecimal(dr["TRA_AMT"]);

            }
            balance = runningBalance;

            return balance;
        }



        //private void FTP_File(String filepath)
        //{
        //    String serverip = ConfigurationManager.AppSettings["FTPServerIP"].ToString();
        //    String FTP_User = ConfigurationManager.AppSettings["FTPUserName"].ToString();
        //    String FTP_Pswd = ConfigurationManager.AppSettings["FTPPassword"].ToString();
        //    String FTP_Port = ConfigurationManager.AppSettings["FTPPort"].ToString();
        //    String FTP_Folder = ConfigurationManager.AppSettings["FTPFolder"].ToString();

        //    clsFTP ftpcls = new clsFTP(serverip, FTP_Folder, FTP_User, FTP_Pswd, Convert.ToInt32(FTP_Port));
        //    ftpcls.UploadFile(filepath);
        //    ftpcls.CloseConnection();
        //    ftpcls = null;
        //    GC.Collect();
        //}

        public void UpdateStatementNo(int ID, int newno, Decimal last_balance)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MT940_Conn"].ToString());
            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            String sqlstr = "update account set StmtNo = " + newno.ToString() + ", last_balance = " + last_balance.ToString() + ", Date_Last_Sent = getdate() where AccountID = " + ID.ToString();
            SqlCommand comm = new SqlCommand(sqlstr, conn);
            comm.CommandType = CommandType.Text;
            int res = comm.ExecuteNonQuery();
            conn.Close();
        }

        private string GetTransType(string p)
        {
            String resp;

            switch(p)
            {
                case "CHEQUE BOOK ISSUE CHARGES":   
                    resp = "CHG";
                    break;
                case "COT":   
                    resp = "CHG";
                    break;
                case "ISSUED DRAFT CHARGE":   
                    resp = "CHG";
                    break;
                case "NIBSS HANDLING CHARGE":   
                    resp = "CHG";
                    break;
                case "ONLINE STATEMENT CHARGE":   
                    resp = "CHG";
                    break;
                case "OVERSEAS BANK CHARGES":   
                    resp = "CHG";
                    break;
                case "STOP PAYMT CHARGE":   
                    resp = "CHG";
                    break;
                case "SWIFT/TELEX CHARGE":   
                    resp = "CHG";
                    break;
                case "ACCEPTED DRAFTS":   
                    resp = "CHK";
                    break;
                case "BANK DRAFT":   
                    resp = "CHK";
                    break;
                case "BANKERS CHEQUE":   
                    resp = "CHK";
                    break;
                case "CHECK DEPOSIT - TRANSIT":   
                    resp = "CHK";
                    break;
                case "CHEQUE DEPOSIT":   
                    resp = "CHK";
                    break;
                case "SETTLE BANKERS CHEQUES":   
                    resp = "CHG";
                    break;
                case "VALUE ADDED TAX":
                    resp = "CHG";
                    break;
                case "TRANSFER FROM A/C TO A/C COMMISSION":
                    resp = "CHG";
                    break;
                case "CASH DEPOSIT":   
                    resp = "CLR";
                    break;
                case "CASH WITHDRAWAL":   
                    resp = "CLR";
                    break;
                case "CLEARING DEPOSIT":   
                    resp = "CLR";
                    break;
                case "CLEARING DEPOSIT - DEBIT ACCOUNT":   
                    resp = "CLR";
                    break;
                case "CLEARING WITHDRAWAL":   
                    resp = "CLR";
                    break;
                case "ATM WITHDRAWAL COMMISSION":   
                    resp = "COM";
                    break;
                case "COMMISSION":   
                    resp = "COM";
                    break;
                case "DRAFT COMMISSION":   
                    resp = "COM";
                    break;
                case "LC COMMISSION":   
                    resp = "COM";
                    break;
                case "FX PURCHASE (SPOT)":   
                    resp = "FEX";
                    break;
                case "FX SALE (SPOT)":   
                    resp = "FEX";
                    break;
                case "INTEREST CAPITALISED":   
                    resp = "INT";
                    break;
                case "INTEREST ON MATURED INVESTMENT":   
                    resp = "INT";
                    break;
                case "MISC.":   
                    resp = "MSC";
                    break;
                case "RETURN BY LETTER":   
                    resp = "RTI";
                    break;
                case "RETURNED CHEQUE":   
                    resp = "RTI";
                    break;
                case "WITHHOLDING TAX":   
                    resp = "TAX";
                    break;
                case "COMM.TRANSFER TO REL.ACCT.":   
                    resp = "TRF";
                    break;
                case "FUND TRANSFER - OWN ACCOUNTS":   
                    resp = "TRF";
                    break;
                case "INTEREST TRANSFER":   
                    resp = "TRF";
                    break;
                case "INTERNAL TRANSFER(DIFF A/CS)":   
                    resp = "TRF";
                    break;
                case "ISSUED TRANSFERS FOR BANKS":   
                    resp = "TRF";
                    break;
                case "OWN ACCOUNT TRANSFER":   
                    resp = "TRF";
                    break;
                case "TELEGRAPHIC TRANSFER":   
                    resp = "TRF";
                    break;
                case "TRANSFER BETWEEN CUSTOMERS":   
                    resp = "TRF";
                    break;
                case "TRANSFER LG TO PAID LG":   
                    resp = "TRF";
                    break;
                case "CIFTS OUTFLOW":
                    resp = "TRF";
                    break;
                default:
                    resp = "DIR";
                    break;
            }  

            return resp;
        }

        private string GetTransType2(DataRow p)
        {
            String resp = "";

            if (p["Deb_Cre_Ind"].ToString() == "2")
            {
                if (Convert.ToInt64(p["DOC_NUM"]) != 0 && p["DOC_ALP"].ToString().Length >= 3)
                    resp = "NCHK";
                else
                {
                    if (p["DES_ENG"].ToString() == "INTEREST CAPITALISED")
                        resp = "NINT";
                    else
                    {
                        switch (p["EXPL_CODE"].ToString())
                        {
                            case "100":
                                resp = "NCMS";
                                break;
                            case "124":
                                resp = "NTRF";
                                break;
                            case "102":
                                resp = "NTRF";
                                p["Doc_Alp"] = "GTB";
                                break;
                            case "147":
                                resp = "NTRF";
                                break;
                            case "640":
                                resp = "NTRF";
                                break;
                            case "214":
                                if (p["remarks"].ToString().Contains("A/C") || p["remarks"].ToString().Contains("MAIN") || p["remarks"].ToString().Contains("ACCT") || p["remarks"].ToString().Contains("110") || p["remarks"].ToString().Contains("130221"))
                                    resp = "NCMS";
                                else
                                {
                                    resp = "NTRF";
                                    p["Doc_Alp"] = "GTB";
                                }
                                break;
                            default:
                                resp = "NMSC";
                                break;
                        }
                    }
                }
            }
            else if (p["Deb_Cre_Ind"].ToString() == "1")
            {
                int len = p["DES_ENG"].ToString().Length;
                String explcode = p["EXPL_CODE"].ToString();

                if (Convert.ToInt32(p["EXPL_CODE"]) == 933 || p["DES_ENG"].ToString() == "RETURNED CHEQUE")
                    resp = "NCHK";
                else if (explcode == "88" || explcode == "1271" || explcode == "1278" || explcode == "1279" || explcode == "1325" || explcode == "1326" || explcode == "1329")
                {
                    resp = "NCHG";
                }
                else
                {
                    if (p["DES_ENG"].ToString() == "MISC.")
                        resp = "NMSC";
                    else if ((p["DES_ENG"].ToString().Substring(len - 7, 7) == "CHARGES" || p["DES_ENG"].ToString().Substring(len - 6, 6) == "CHARGE" || p["DES_ENG"].ToString().Substring(len - 10, 10) == "COMMISSION" || p["DES_ENG"].ToString().Substring(len - 4, 4) == "COMM") && (p["DES_ENG"].ToString() != "LC COMMISSION"))
                        resp = "NCHG";
                    else
                    {
                        switch (p["DES_ENG"].ToString())
                        {
                            case "LC COMMISSION":
                                resp = "NCOM";
                                break;
                            case "VAT":
                                resp = "NCHG";
                                break;
                            case "VALUE ADDED TAX":
                                resp = "NCHG";
                                break;
                            case "COT":
                                resp = "NCHG";
                                break;
                            case "INTEREST CAPITALISED":
                                resp = "NINT";
                                break;
                            case "COMM. INVISIBLE TRF.":
                                resp = "NFAC";
                                break;
                            default:
                                switch (p["EXPL_CODE"].ToString())
                                {
                                    case "60":
                                        resp = "NMSC";
                                        break;
                                    case "100":
                                        resp = "NCMS";
                                        break;
                                    case "214":
                                        if (p["remarks"].ToString().Contains("A/C") || p["remarks"].ToString().Contains("MAIN") || p["remarks"].ToString().Contains("ACCT") || p["remarks"].ToString().Contains("110") || p["remarks"].ToString().Contains("130221/110 "))
                                            resp = "NCMS";
                                        else
                                        {
                                            resp = "NTRF";
                                            p["Doc_Alp"] = "GTB";
                                        }
                                        break;
                                    default:
                                        resp = "NTRF";
                                        break;
                                }
                                break;
                        }
                    }
                }
            }

            if(resp == "NCHK" || resp == "NRTI")
            {
                switch(Convert.ToInt16(p["BANK_CODE"]))
                {
                    case 57:
                        p["Doc_Alp"] = "ZIB";
                        break;
                    case 33:
                        p["Doc_Alp"] = "UBA";
                        break;
                    case 215:
                        p["Doc_Alp"] = "UBP";
                        break;
                    case 32:
                        p["Doc_Alp"] = "UBN";
                        break;
                    case 44:
                        p["Doc_Alp"] = "ABP";
                        break;
                    case 56:
                        p["Doc_Alp"] = "OIB";
                        break;
                    case 69:
                        p["Doc_Alp"] = "ICB";
                        break;
                    case 11:
                        p["Doc_Alp"] = "FBN";
                        break;
                    case 58:
                        p["Doc_Alp"] = "GTB";
                        break;
                    case 63:
                        p["Doc_Alp"] = "DBP";
                        break;
                    case 85:
                        p["Doc_Alp"] = "FBB";
                        break;
                    case 35:
                        p["Doc_Alp"] = "WBP";
                        break;
                    case 40:
                        p["Doc_Alp"] = "ETB";
                        break;
                    case 216:
                        p["Doc_Alp"] = "SIB";
                        break;
                    case 23:
                        p["Doc_Alp"] = "CIT";
                        break;
                    //case 33:
                    //    p["Doc_Alp"] = "SCB";
                    //    break;
                    case 68:
                        p["Doc_Alp"] = "STB";
                        break;
                    case 70:
                        p["Doc_Alp"] = "FBP";
                        break;
                    case 214:
                        p["Doc_Alp"] = "FCM";
                        break;
                    case 82:
                        p["Doc_Alp"] = "PHB";
                        break;
                    case 76:
                        p["Doc_Alp"] = "SKY";
                        break;
                    case 14:
                        p["Doc_Alp"] = "AFR";
                        break;
                    case 84:
                        p["Doc_Alp"] = "SPR";
                        break;
                }
            }

            return resp;
        }

        public DateTime FirstDayOfPreviousMonthFromDateTime(DateTime dateTime)
        {

            string isincurrentmonth = checkifisincurrentmonth();// ConfigurationManager.AppSettings["IsInCurrentMonth"].ToString();



            if (isincurrentmonth.Equals("0")) //sending for last month in a new month
            {

                if (dateTime.Month == 1)
                {

                    return new DateTime(dateTime.Year - 1, 12, 1);

                }

                else
                {

                    return new DateTime(dateTime.Year, dateTime.Month - 1, 1);

                }

            }

            else if (isincurrentmonth.Equals("1")) //sending for this month in this month
            {

                if (dateTime.Month == 1)
                {

                    return new DateTime(dateTime.Year, 1, 1);

                }

                else
                {

                    return new DateTime(dateTime.Year, dateTime.Month, 1);

                }

            }

            else
            {

                return DateTime.Now;



            }





        }



        public DateTime LastDayOfMonthFromDateTime(DateTime dateTime)
        {

            string isincurrentmonth = checkifisincurrentmonth();// ConfigurationManager.AppSettings["IsInCurrentMonth"].ToString();



            if (isincurrentmonth.Equals("0")) //sending for last month in a new month
            {

                if (dateTime.Month == 1)
                {

                    DateTime firstDayOfTheMonth = new DateTime(dateTime.Year - 1, 12, 1);

                    return firstDayOfTheMonth.AddMonths(1).AddDays(-1);

                }

                else
                {

                    DateTime firstDayOfTheMonth = new DateTime(dateTime.Year, dateTime.Month - 1, 1);

                    return firstDayOfTheMonth.AddMonths(1).AddDays(-1);

                }

            }

            else if (isincurrentmonth.Equals("1")) //sending for this month in this month
            {

                if (dateTime.Month == 1)
                {

                    DateTime firstDayOfTheMonth = new DateTime(dateTime.Year, 1, 1);

                    return firstDayOfTheMonth.AddMonths(1).AddDays(-1);

                }

                else
                {

                    DateTime firstDayOfTheMonth = new DateTime(dateTime.Year, dateTime.Month, 1);

                    return firstDayOfTheMonth.AddMonths(1).AddDays(-1);

                }

            }

            else
            {
                return DateTime.Now;

            }

        }

        private string checkifisincurrentmonth() // this is to determine the month on BASIS
        {

            string response = string.Empty;

            int date = DateTime.Now.Day;

            if (date <= 31) // if the date is less than day 15 we are sending for previous month
            {

                response = "0";



            }

            else
            {

                response = "1";

            }



            return response;

        }
    }
}
