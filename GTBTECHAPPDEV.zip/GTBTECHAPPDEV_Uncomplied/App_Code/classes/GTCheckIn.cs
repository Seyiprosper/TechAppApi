﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.OracleClient;
using System.Globalization;
using System.Web;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.XPath;

public class GTCheckIn
{
    string xmlstring = "<Response>";
    string sqlconn = ConfigurationManager.AppSettings["e_oneConnString"];
    SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["e_oneConnString"].ToString());
    SqlDataReader reader;
    Email sEmail = new Email();
    XmlDocument document = default(XmlDocument);
    XPathNavigator navigator = default(XPathNavigator);
    XPathNodeIterator snodes = default(XPathNodeIterator);

    public GTCheckIn()
    {

    }

    public string BookAppointment(string userId, string cusName, string acctNum, string transType, int branchCode, DateTime appointmentDate, string phoneNo, string eMail, string timeSlot, string Medium, string Additional_Request)
    {
        try
        {
            if (string.IsNullOrEmpty(userId))
            {
                userId = "";
            }

            if (string.IsNullOrEmpty(cusName))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Customer name cannot be null.</Error>";
                return xmlstring + "</Response>";
            }

            if (string.IsNullOrEmpty(acctNum))
            {
                acctNum = "";
            }

            if (string.IsNullOrEmpty(transType))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Transaction type cannot be null.</Error>";
                return xmlstring + "</Response>";
            }

            if (string.IsNullOrEmpty(eMail))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Email cannot be null.</Error>";
                return xmlstring + "</Response>";
            }

            //if (!ValidateEmail(eMail))
            //{
            //    xmlstring = xmlstring + "<CODE>1001</CODE>";
            //    xmlstring = xmlstring + "<Error>Email address is not valid.</Error>";
            //    return xmlstring + "</Response>";
            //}

            if (string.IsNullOrEmpty(phoneNo))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Phone number cannot be null.</Error>";
                return xmlstring + "</Response>";
            }

            if (string.IsNullOrEmpty(branchCode.ToString()) || branchCode.ToString().Length != 3)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Branch code should be three digits.</Error>";
                return xmlstring + "</Response>";
            }

            if (string.IsNullOrEmpty(timeSlot))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Time slot cannot be null.</Error>";
                return xmlstring + "</Response>";
            }

            if (string.IsNullOrEmpty(Medium))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Medium cannot be null.</Error>";
                return xmlstring + "</Response>";
            }

            //if (string.IsNullOrEmpty(appointmentDate))
            //{
            //    xmlstring = xmlstring + "<Error>Appointment date cannot be null.</Error>";
            //    return xmlstring + "</Response>";
            //}

            SqlConnection Conn = new SqlConnection();
            SqlCommand Command = default(SqlCommand);

            string userid = null;
            string cusname;
            string acctnum = null;
            string transtype;
            string email;
            string phoneno;
            int branchcode;
            int timeslot;
            string appointmentdate;
            string refno;
            int status;
            string StartTime = null;
            string StopTime = null;



            Conn.ConnectionString = ConfigurationManager.ConnectionStrings["e_oneConnString"].ConnectionString;

            appointmentdate = appointmentDate.ToLongDateString().ToString();

            userid = userId;
            cusname = cusName.Replace(",", "");
            acctnum = acctNum;
            transtype = transType;
            email = eMail;
            phoneno = phoneNo;
            branchcode = branchCode;
            timeslot = Convert.ToInt32(timeSlot);
            refno = branchcode + appointmentDate.DayOfYear.ToString().PadRight(3,'0') + RefNO();
            status = 1;

            if (Conn.State != ConnectionState.Open)
            {
                Conn.Open();
            }

            string SQL = string.Empty;

            Command = new SqlCommand();
            Command.Connection = Conn;
            Command.CommandType = CommandType.StoredProcedure;
            Command.CommandText = "new_InsertAppointment";
            Command.Parameters.AddWithValue("@userid", userid);
            Command.Parameters.AddWithValue("@cusname", cusname);
            Command.Parameters.AddWithValue("@acctnum", acctnum);
            Command.Parameters.AddWithValue("@transtype", transtype);
            Command.Parameters.AddWithValue("@email", email);
            Command.Parameters.AddWithValue("@phoneno", phoneno);
            Command.Parameters.AddWithValue("@branchcode", branchcode);
            Command.Parameters.AddWithValue("@timeslot", timeslot);
            Command.Parameters.AddWithValue("@appointmentdate", appointmentDate);
            Command.Parameters.AddWithValue("@refno", refno);
            Command.Parameters.AddWithValue("@status", status);
            Command.Parameters.AddWithValue("@Medium", Medium); //Additional_Request
            Command.Parameters.AddWithValue("@Additional_Request", Additional_Request);

            SQL = Command.ExecuteScalar().ToString();
            Conn.Close();
            char[] delim = new char[] { '/' };
            string relM = RM_ID(branchCode);
            string[] Rm_DivHead = relM.Split(delim);
            string RM = Rm_DivHead[0];
            string Div_Head = Rm_DivHead[1];
            string RMEmail = Rm_DivHead[2];
            string DivHeadEmail = Rm_DivHead[3];

            string getTime = "Select StartTime, StopTime FROM AvailableTime Where SN = " + timeSlot;
            SqlCommand comm = new SqlCommand(getTime, conn);
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            try
            {
                reader = comm.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    StartTime = reader["StartTime"].ToString();
                    StopTime = reader["StopTime"].ToString();
                }
            }
            catch (Exception)
            {

            }

            string[] emailSeparators = { ",", "!", "?", ";", ":", " ", "/", "%", "#", "$", "^", "&", "*", "=", "\\" };
            String[] email_Str;
            email_Str = email.Split(emailSeparators, StringSplitOptions.RemoveEmptyEntries);
            int no_Email = email_Str.Length;

            Eone eone = new Eone();
            string branchNameXML = eone.GetBranchInfo(branchcode.ToString());
            string branchName = XmlReader(branchNameXML);
            if (branchName == "0")
                branchName = "";

            string msgString = ("Dear " + cusname + ("," + (Environment.NewLine + Environment.NewLine)));
            //msgString = (msgString + ("GTBANK APPOINTMENT BOOKING" + (Environment.NewLine + Environment.NewLine)));
            msgString = (msgString + ("Please be informed that your appointment has been booked. The appointment would hold with " + RM + "(" + RMEmail + ") at our GTBank " + branchName + " branch on " + appointmentdate + " by " + StartTime + ("." + (Environment.NewLine + Environment.NewLine))));
            msgString = (msgString + ("If you did not make this request, please call GTConnect; our fully interactive 24 hours self-service Contact Centre, " + ("on 0700-GTCONNECT (0700-482666328), 01-4480000, 0802-9002900 or 0803-9003900 or send an email to e-fraudteam@gtbank.com immediately. "
                        + (Environment.NewLine
                        + (Environment.NewLine + ("Thank you for banking with us."
                        + (Environment.NewLine)))))));

            try
            {
                if (no_Email == 1)
                {
                    sEmail.SendEmail("intops@gtbank.com", email_Str[0], "GTBANK APPOINTMENT BOOKING", msgString);
                }

                if (no_Email == 2)
                {
                    sEmail.SendEmail("intops@gtbank.com", email_Str[0], "GTBANK APPOINTMENT BOOKING", msgString);
                    sEmail.SendEmail("intops@gtbank.com", email_Str[1], "GTBANK APPOINTMENT BOOKING", msgString);
                }

                sEmail.SendEmail("intops@gtbank.com", RMEmail, "GTBANK APPOINTMENT BOOKING", msgString, DivHeadEmail);
            }
            catch (Exception)
            {
                
            }

            return xmlstring + "<CODE>1000</CODE><RM>" + RM + "</RM>" + "<MESSAGE>" + " Successfully logged with reference ID: " + refno + "</MESSAGE>" + "</Response>";
        }


        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + ex + "</Response>";
        }

        return xmlstring + "</Response>";
    }

    public string RM_ID(int braCode)
    {
        string RM = null;
        string Div_Head = null;
        string RM_Email = null;
        string DivHead_Email = null;
        SqlDataReader rdr;
        SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["e_oneConnString"].ToString());
        string queryRM = "select RM, Div_Head, RM_EmailAddress, DivHead_EmailAddress from Branches where Branch_Code = " + braCode;
        SqlCommand comm1 = new SqlCommand(queryRM, conn);
        if (conn.State == ConnectionState.Closed)
        {
            conn.Open();
        }
        try
        {
            //SqlDataReader rdr = comm1.ExecuteReader();
            rdr = comm1.ExecuteReader();
            if (rdr.HasRows)
            {
                rdr.Read();
                RM = rdr["RM"].ToString();
                Div_Head = rdr["Div_Head"].ToString();
                RM_Email = rdr["RM_EmailAddress"].ToString();
                DivHead_Email = rdr["DivHead_EmailAddress"].ToString();
                return RM + "/" + Div_Head + "/" + RM_Email + "/" + DivHead_Email;
            }
            else
                return RM + "/" + Div_Head + "/" + RM_Email + "/" + DivHead_Email;
        }
        catch
        {
            return RM + "/" + Div_Head + "/" + RM_Email + "/" + DivHead_Email;
        }

        finally
        {
            if (conn.State == ConnectionState.Open)
                conn.Close();
        }
    }

    public string RefNO()
    {
        Random rdom = new Random();
        int b = rdom.Next(100, 999);
        int c = rdom.Next(1000, 9999);
        int d = rdom.Next(10000, 99999);

        return b.ToString() + c.ToString() + d.ToString() + DateTime.Now.Millisecond.ToString().PadRight (3,'0');
    }

    public string CancelAppointment(string userID, string refNO)
    {
        string cusname = null;
        string branchCode = null;
        string appointmentdate = null;
        string time = null;
        string email = null;

        try
        {
            if (string.IsNullOrEmpty(userID))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>UserID cannot be null.</Error>";
                return xmlstring;
            }

            if (string.IsNullOrEmpty(refNO))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Reference number cannot be null.</Error>";
                return xmlstring;
            }

            string User_ID = null;
            string refno = null;
            int status;

            SqlConnection Conn = new SqlConnection();
            SqlCommand Command = default(SqlCommand);

            User_ID = userID;
            refno = refNO;
            status = 3;

            Conn.ConnectionString = ConfigurationManager.ConnectionStrings["e_oneConnString"].ConnectionString;

            if (Conn.State != ConnectionState.Open)
            {
                Conn.Open();
            }

            string SQL = string.Empty;

            Command = new SqlCommand();
            Command.Connection = Conn;
            Command.CommandType = CommandType.StoredProcedure;
            Command.CommandText = "proc_CancelAppointmentTrans";
            Command.Parameters.AddWithValue("@User_ID ", User_ID);
            Command.Parameters.AddWithValue("@refno", refno);
            Command.Parameters.AddWithValue("@status ", status);

            SQL = Command.ExecuteNonQuery().ToString();
            Conn.Close();

            string querGetData = "select CustomerName, Branch, EmailAddress, SlotDate, TimeID from AppointmentTrans where userID = '" + userID + "' and ReferenceNo = '" + refno + "'";
            SqlCommand comm1 = new SqlCommand(querGetData, conn);
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            try
            {
                reader = comm1.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    cusname = reader["CustomerName"].ToString().Replace("," , "");
                    branchCode = reader["Branch"].ToString();
                    email = reader["EmailAddress"].ToString();
                    DateTime xxx = Convert.ToDateTime(reader["SlotDate"].ToString());
                    appointmentdate = xxx.ToLongDateString().ToString();
                    time = reader["TimeID"].ToString();
                    conn.Close();
                }
                else
                {
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                conn.Close();
                xmlstring = xmlstring + ex;
            }

            char[] delim = new char[] { '/' };
            string relM = RM_ID(Convert.ToInt32(branchCode));
            string[] Rm_DivHead = relM.Split(delim);
            string RM = Rm_DivHead[0];
            string Div_Head = Rm_DivHead[1];
            string RMEmail = Rm_DivHead[2];
            string DivHeadEmail = Rm_DivHead[3];

            string[] emailSeparators = { ",", "!", "?", ";", ":", " ", "/", "%", "#", "$", "^", "&", "*", "=", "\\" };
            String[] email_Str;
            email_Str = email.Split(emailSeparators, StringSplitOptions.RemoveEmptyEntries);
            int no_Email = email_Str.Length;


            string msgString = ("Dear " + cusname + ("," + (Environment.NewLine + Environment.NewLine)));
            //msgString = (msgString + ("GTBANK APPOINTMENT BOOKING" + (Environment.NewLine + Environment.NewLine)));
            msgString = (msgString + ("Please be informed that your appointment has been cancelled" + ("." + (Environment.NewLine + Environment.NewLine))));
            msgString = (msgString + ("If you did not make this request, please call GTConnect; our fully interactive 24 hours self-service Contact Centre, " + ("on 0700-GTCONNECT (0700-482666328), 01-4480000, 0802-9002900 or 0803-9003900 or send an email to e-fraudteam@gtbank.com immediately. "
                        + (Environment.NewLine
                        + (Environment.NewLine + ("Thank you for banking with us."
                        + (Environment.NewLine)))))));

            try
            {
                if (no_Email == 1)
                {
                    sEmail.SendEmail("intops@gtbank.com", email_Str[0], "GTBANK APPOINTMENT BOOKING", msgString);
                }

                if (no_Email == 2)
                {
                    sEmail.SendEmail("intops@gtbank.com", email_Str[0], "GTBANK APPOINTMENT BOOKING", msgString);
                    sEmail.SendEmail("intops@gtbank.com", email_Str[1], "GTBANK APPOINTMENT BOOKING", msgString);
                }

                sEmail.SendEmail("intops@gtbank.com", RMEmail, "GTBANK APPOINTMENT BOOKING", msgString, DivHeadEmail);
            }
            catch (Exception)
            {
                
            }

            return xmlstring + "<CODE>1000</CODE>" + "<MESSAGE>" + "Appointment has been canceled successfully." + "</MESSAGE>" + "</Response>";
        }

        catch (Exception ex)
        {
            xmlstring = xmlstring + ex;
        }

        return xmlstring + "</Response>";
    }

    public string RejectAppointment(string userID, string refNo, string rejectedBy, string rejectedReason)
    {
        try
        {
            if (string.IsNullOrEmpty(userID))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>UserID cannot be null.</Error>";
                return xmlstring;
            }

            if (string.IsNullOrEmpty(refNo))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Reference ID cannot be null.</Error>";
                return xmlstring;
            }

            if (string.IsNullOrEmpty(rejectedBy))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Kindly provide your name.</Error>";
                return xmlstring;
            }

            if (string.IsNullOrEmpty(rejectedReason))
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Please provide reason for rejection.</Error>";
                return xmlstring;
            }

            string User_ID = null;
            int status;
            string rejectedby = null;
            string rejectionreason = null;
            string refno = null;

            SqlConnection Conn = new SqlConnection();
            SqlCommand Command = default(SqlCommand);

            User_ID = userID;
            status = 4;
            rejectedby = rejectedBy;
            rejectionreason = rejectedReason;
            refno = refNo;

            Conn.ConnectionString = ConfigurationManager.ConnectionStrings["e_oneConnString"].ConnectionString;

            if (Conn.State != ConnectionState.Open)
            {
                Conn.Open();
            }

            string SQL = string.Empty;

            Command = new SqlCommand();
            Command.Connection = Conn;
            Command.CommandType = CommandType.StoredProcedure;
            Command.CommandText = "proc_RejectAppointmentTrans";
            Command.Parameters.AddWithValue("@User_ID ", User_ID);
            Command.Parameters.AddWithValue("@refno ", refno);
            Command.Parameters.AddWithValue("@status", status);
            Command.Parameters.AddWithValue("@rejectedby", rejectedby);
            Command.Parameters.AddWithValue("@rejectionreason ", rejectionreason);

            SQL = Command.ExecuteNonQuery().ToString();
            Conn.Close();

            //string emailMessage = "You have scheduled a meeting with GTBank on " + appointmentdate + "with reference number " + refno;
            //sEmail.SendEmail("intops@gtbank.com", email, "GTCheck-In Appointment", emailMessage);

            return xmlstring + "<CODE>1000</CODE>" + "<MESSAGE>" + "Appointment has been rejected successfully." + "</MESSAGE>" + "</Response>";
        }

        catch (Exception ex)
        {
            xmlstring = xmlstring + ex;
        }

        return xmlstring + "</Response>";
    }

    //public bool ValidateEmail(string strEmail)
    //{
    //    Regex rgxEmail = new Regex(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +@"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +@".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
    //    return rgxEmail.IsMatch(strEmail);
    //}

    public bool ValidateEmail(string emailAddress)
    {
        try
        {
            string TextToValidate = emailAddress.Trim().Replace("_", "").Replace("-", "");
            Regex expression = new Regex("^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$");

            // test email address with expression
            if (expression.IsMatch(TextToValidate))
            {
                // is valid email address
                return true;
            }
            else
            {
                // is not valid email address
                return false;
            }
        }
        catch (Exception generatedExceptionName)
        {
            throw generatedExceptionName;
        }
    }

    public DataTable Holidays()
    {
        DateTime dt = DateTime.Now;
        string query = "select from_date from holiday where year =" + dt.Year;
        OracleConnection OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        DataTable holiday = new DataTable();
        holiday.TableName = "Holidays";

        using (OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
        {
            using (OracleCommand OraSelect = new OracleCommand())
            {
                //Dim OraDrSelect As OracleDataReader

                try
                {
                    if (OraConn.State == ConnectionState.Closed)
                    {
                        OraConn.Open();
                    }
                    OraSelect.Connection = OraConn;

                    OraSelect.CommandText = query;
                    OraSelect.CommandType = CommandType.Text;
                    using (OracleDataReader OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (OraDrSelect.HasRows == true)
                        {
                            OraDrSelect.Read();
                            holiday.Load(OraDrSelect);

                            OraConn.Open();
                        }
                    }
                }
                catch (OracleException ex)
                {
                    ErrHandler.WriteError(ex.ToString());
                    return holiday;
                }
                finally
                {
                    if (OraConn.State != ConnectionState.Closed)
                    {
                        OraConn.Close();
                    }
                }
            }
        }
        return holiday;
    }

    public string GetEmail(string query)
    {
        string result = null;
        OracleConnection OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

        using (OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
        {
            using (OracleCommand OraSelect = new OracleCommand())
            {
                //Dim OraDrSelect As OracleDataReader

                try
                {
                    if (OraConn.State == ConnectionState.Closed)
                    {
                        OraConn.Open();
                    }
                    OraSelect.Connection = OraConn;

                    OraSelect.CommandText = query;
                    OraSelect.CommandType = CommandType.Text;
                    using (OracleDataReader OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (OraDrSelect.HasRows == true)
                        {
                            OraDrSelect.Read();
                            result = OraDrSelect["email"].ToString();
                            OraConn.Close();
                            return result;
                        }
                        else
                        {
                            OraConn.Close();
                            return "-2";
                        }
                    }

                    OraConn.Close();
                }
                catch (Exception ex)
                {
                    OraConn.Close();
                    return "-1";
                }
                finally
                {

                }
            }
        }
    }

    public string XmlReader(string xml)
    {
        document = new XmlDocument();
        document.LoadXml(xml);
        navigator = document.CreateNavigator();
        snodes = navigator.Select("/Response/BRANCH_NAME");
        snodes.MoveNext();
        string code = snodes.Current.Value;
        string result = "0";

        if (code.Length > 3)
        {
            return result = code;
        }
        else
        {
            return result;
        }
    }
}