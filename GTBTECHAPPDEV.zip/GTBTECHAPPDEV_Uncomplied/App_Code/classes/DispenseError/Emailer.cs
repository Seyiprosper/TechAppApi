﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Text;
using System.Net.Mail;
using System.Net.Mime;
using System.IO;
using System.Text.RegularExpressions;
using System.Configuration;


public class Emailer
{
    public static string SendMessage2(string subject, string messageBody, string fromAddress, string toAddress, string ccAddress, string bccAddress)
    {
        try
        {
            MailMessage message = new MailMessage();
            SmtpClient client = new SmtpClient();

            //Set the sender's address
            message.From = new MailAddress(fromAddress);

            //Allow multiple "To" addresses to be separated by a semi-colon
            if ((toAddress.Trim().Length > 1))
            {
                foreach (string addr in toAddress.Split(','))
                {
                    if (!string.IsNullOrEmpty(addr))
                    {
                        message.To.Add(new MailAddress(addr));
                    }
                }
            }

            //Allow multiple "Cc" addresses to be separated by a semi-colon
            if ((ccAddress.Trim().Length > 1))
            {
                foreach (string addr in ccAddress.Split(','))
                {
                    if (!string.IsNullOrEmpty(addr))
                    {
                        message.CC.Add(new MailAddress(addr));
                    }
                }
            }

            if ((bccAddress.Trim().Length > 1))
            {
                foreach (string addr in bccAddress.Split(','))
                {
                    if (!string.IsNullOrEmpty(addr))
                    {
                        message.Bcc.Add(new MailAddress(addr));
                    }
                }
            }

            //Set the subject and message body text
            message.Subject = subject;
            message.Body = messageBody;

            //TODO: *** Modify for your SMTP server ***
            //Set the SMTP server to be used to send the message
            client.Host = ConfigurationManager.AppSettings["SmtpServer"];

            //Send the e-mail message
            client.Send(message);
            return "";
            //Return ("Message sent to: " & toAddress & " and copied: " & ccAddress & "  at ") + DateTime.Now.ToString() & "."
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message);
            return ex.Message.ToString();
        }
    }

    public static bool ValidateEmailAddress(string emailAddress)
    {
        try
        {
            string TextToValidate = emailAddress.Trim().Replace("_", "").Replace("-", "");
            Regex expression = new Regex("^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$");

            // test email address with expression
            if (expression.IsMatch(TextToValidate))
            {
                // is valid email address
                return true;
            }
            else
            {
                // is not valid email address
                return false;
            }
        }
        catch (Exception generatedExceptionName)
        {
            throw generatedExceptionName;
        }
    }

    public static MemoryStream GetImage(string Imagepath__1)
    {
        String StartUpPath = Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName);
        String imagepath__2 = Imagepath__1;
        // String imagepath = StartUpPath + "\\HtmlFiles\\animated_ad.gif";
        FileStream fs = File.OpenRead(imagepath__2);
        byte[] data = new byte[fs.Length];
        fs.Read(data, 0, data.Length);

        // MemoryStream ms = new MemoryStream(data);
        // Bitmap bmp = new Bitmap(ms);

        return new System.IO.MemoryStream(data);
    }

    public static bool SendIntroHtmlMessage(string sendTo, string sendFrom, string sendSubject, string Message__1, string attachmentpath)
    {
        // return true;
        ErrHandler err = new ErrHandler();
        string message2 = Message__1;

        try
        {

            System.Net.Mail.AlternateView htmlView = System.Net.Mail.AlternateView.CreateAlternateViewFromString(Message__1, null, "text/html");

            // @"\Webtips Emailer\ <admin@webtips.co.in>"
            MailMessage message__2 = new MailMessage();
            message__2.Subject = sendSubject;
            message__2.From = new MailAddress("GTBank Card Services<" + sendFrom + ">");

            if (sendTo.Trim().Length > 0)
            {
                foreach (string addr in sendTo.Replace(",", ";").Split(';'))
                {
                    //MailAddress cc = new MailAddress(copyTo);}
                    if (!string.IsNullOrEmpty(addr))
                    {
                        if (ValidateEmailAddress(addr.Trim()))
                        {
                            message__2.To.Add(new MailAddress(addr.Trim()));
                        }
                    }
                }
            }
            if (!string.IsNullOrEmpty(attachmentpath))
            {
                Attachment attached = new Attachment(attachmentpath, MediaTypeNames.Application.Octet);
                attached.Name = Path.GetFileName(attachmentpath);
                message__2.Attachments.Add(attached);
            }


            System.Net.Mail.LinkedResource gtbimage = new System.Net.Mail.LinkedResource(GetImage("C:\\MonthlyStmtResources" + "\\Images\\logo_g.gif"), "image/gif");
            gtbimage.ContentId = "gtblogo";
            htmlView.LinkedResources.Add(gtbimage);


            System.Net.Mail.LinkedResource statementadvert = new System.Net.Mail.LinkedResource(GetImage("C:\\MonthlyStmtResources" + "\\Images\\StatementAdvert.PNG"), "image/png");
            statementadvert.ContentId = "advert";
            htmlView.LinkedResources.Add(statementadvert);
            message__2.AlternateViews.Add(htmlView);

            // create smtp client at mail server location
            SmtpClient client = new SmtpClient(ConfigurationManager.AppSettings["SmtpServer"].ToString());
            // add credentials
            client.UseDefaultCredentials = false;

            // send message
            client.Send(message__2);

            message__2.Attachments.Clear();
            return true;
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Error Sending Email For customer with Email " + sendTo + " : " + ex.Message);
            return false;
        }
    }

    public static bool SendMessageWithAttachment(string subject, string messageBody, string fromAddress, string toAddress, string ccAddress, string bccAddress, string attachment)
    {
        try
        {
            MailMessage message = new MailMessage();
            SmtpClient client = new SmtpClient();

            //Set the sender's address
            message.From = new MailAddress(fromAddress);

            //Allow multiple "To" addresses to be separated by a semi-colon
            if ((toAddress.Trim().Length > 1))
            {
                foreach (string addr in toAddress.Split(','))
                {
                    if (!string.IsNullOrEmpty(addr))
                    {
                        message.To.Add(new MailAddress(addr));
                    }
                }
            }

            //Allow multiple "Cc" addresses to be separated by a semi-colon
            if ((ccAddress.Trim().Length > 1))
            {
                foreach (string addr in ccAddress.Split(','))
                {
                    if (!string.IsNullOrEmpty(addr))
                    {
                        message.CC.Add(new MailAddress(addr));
                    }
                }
            }

            if ((bccAddress.Trim().Length > 1))
            {
                foreach (string addr in bccAddress.Split(','))
                {
                    if (!string.IsNullOrEmpty(addr))
                    {
                        message.Bcc.Add(new MailAddress(addr));
                    }
                }
            }

            if (!string.IsNullOrEmpty(attachment))
            {
                message.Attachments.Add(new System.Net.Mail.Attachment(attachment));
            }

            //Set the subject and message body text
            message.Subject = subject;
            message.Body = messageBody;
            message.IsBodyHtml = true;
            //TODO: *** Modify for your SMTP server ***
            //Set the SMTP server to be used to send the message
            client.Host = ConfigurationManager.AppSettings["SmtpServer"];

            //Send the e-mail message
            client.Send(message);
            return true;
            //Return ("Message sent to: " & toAddress & " and copied: " & ccAddress & "  at ") + DateTime.Now.ToString() & "."
        }
        catch (Exception ex)
        {
            return false;
        }
    }

    //Public Shared Function SendMessage(ByVal sendTo As String, ByVal copyTo As String, ByVal sendFrom As String, ByVal sendSubject As String, ByVal mailMessage As String) As String
    //    Dim StartUpPath As [String] = Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName)
    //    Try
    //        ' validate the email address
    //        Dim bTest As Boolean = ValidateEmailAddress(sendTo)

    //        ' if the email address is bad, return message
    //        If bTest = False Then
    //            Return "Invalid recipient email address: " + sendTo
    //        End If

    //        ' create the email message
    //        Dim message As New MailMessage(sendFrom, sendTo, sendSubject, SendMessage)
    //        Dim cc As New MailAddress(copyTo)
    //        message.CC.Add(cc)
    //        ' create smtp client at mail server location
    //        Dim client As New SmtpClient(ConfigurationManager.AppSettings("EmailServer").ToString())
    //        ' add credentials
    //        client.UseDefaultCredentials = False

    //        ' send message
    //        client.Send(message)

    //        Return "Message sent to " + sendTo + " at " + DateTime.Now.ToString() + "."
    //    Catch ex As Exception
    //        Return ex.Message.ToString()
    //    End Try
    //End Function
}


