﻿
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.SessionState;


public class Error_Log : System.Web.HttpApplication
{
    public void AppLogWrite(string Msg, bool Err_write)
    {
        EventLog applog = new EventLog();
        //Dim EventLogName As String = "Internet Banking"
        try
        {
            //  If (Not applog.SourceExists(EventLogName)) Then
            // applog.CreateEventSource(EventLogName, EventLogName)
            // End If
            applog.Source = "Application";

            if (Err_write)
            {
                applog.WriteEntry(Msg, EventLogEntryType.Error);
            }
            else
            {
                applog.WriteEntry(Msg, EventLogEntryType.Information);
            }

        }
        catch (Exception ex)
        {
        }
    }
}



