﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.OracleClient;
using System.Globalization;
using System.Web;

public class DispenseError
{
    OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
    ErrHandler err = new ErrHandler();
    SendSMS smssender = new SendSMS();
    private String xmlstring = null;
    private ReturnValue rt = new ReturnValue();
    Emailer emailer = new Emailer();
    string sqlconn = ConfigurationManager.AppSettings["Dispenseconn"];
    
    public DispenseError()
    {

    }

    public String SubmitSingle(int branchCode, int origbraCode, int cusNum, int curCode, int ledCode, int subacctCode, decimal tranAmount, decimal amtDispensed, string PAN1, string STAN1, string bankNam, string transacDate, string merchant, string tellerID, string smartCardNo, string phoneNo, string network, string declineReason, string errorType, string GTBATMLocation, string ATMBranchCode, string benePhoneNo, string beneAcctNo, string refID, string ticks)
    {
        //string cusName = "";
        xmlstring = "<Response>";

        try
        {
            if (oraconn.State != ConnectionState.Open)
            {
                oraconn.Open();
            }
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<ERROR>Cannot connect to basis.</ERROR>";
            xmlstring = xmlstring + "<ConfigurationErrorsException>" + ex + "</ConfigurationErrorsException>" + "</Response>";
            return xmlstring + "</Response>";
        }

        try
        {
            if (branchCode.ToString().Length != 3)
            {
                xmlstring = xmlstring + "<ERROR>Branch Code must be 3 characters.</ERROR>";
                return xmlstring + "</Response>";
            }

            else if (origbraCode.ToString().Length != 3)
            {
                xmlstring = xmlstring + "<ERROR>Originating branch Code must be 3 characters.</ERROR>";
                return xmlstring + "</Response>";
            }

            else if (cusNum.ToString().Length != 6)
            {
                xmlstring = xmlstring + "<ERROR>Customer number must be 6 characters.</ERROR>";
                return xmlstring + "</Response>";
            }

            else if (curCode.ToString() == null)
            {
                xmlstring = xmlstring + "<ERROR>Currency Code cannot be null.</ERROR>";
                return xmlstring + "</Response>";
            }

            else if (ledCode.ToString() == null)
            {
                xmlstring = xmlstring + "<ERROR>Ledger Code cannot be null.</ERROR>";
                return xmlstring + "</Response>";
            }

            else if (subacctCode.ToString() == null)
            {
                xmlstring = xmlstring + "<ERROR>Sub Account Code cannot be null.</ERROR>";
                return xmlstring + "</Response>";
            }

            else if (tranAmount.ToString() == null)
            {
                xmlstring = xmlstring + "<ERROR>Transaction amount cannot be null.</ERROR>";
                return xmlstring + "</Response>";
            }

            else if (amtDispensed.ToString() == null)
            {
                xmlstring = xmlstring + "<ERROR>Input amount dispensed to the customer.</ERROR>";
                return xmlstring + "</Response>";
            }

            else if (PAN1.Length < 4)
            {
                xmlstring = xmlstring + "<ERROR>PAN should be four characters.</ERROR>";
                return xmlstring + "</Response>";
            }

            else if (STAN1.Length != 6)
            {
                xmlstring = xmlstring + "<ERROR>STAN must be 6 characters.</ERROR>";
                return xmlstring + "</Response>";
            }

            else if (transacDate.Length < 9)
            {
                xmlstring = xmlstring + "<ERROR>Transaction date cannot be less than 9 characters 'DDMMMYYYY'.</ERROR>";
                return xmlstring + "</Response>";
            }

            else if (tellerID == null)
            {
                xmlstring = xmlstring + "<ERROR>Please provide userID.</ERROR>";
                return xmlstring + "</Response>";
            }

            else if (string.IsNullOrEmpty(merchant))
            {
                merchant = "";
            }

            if (string.IsNullOrEmpty(smartCardNo))
            {
                smartCardNo = "";
            }

            if (string.IsNullOrEmpty(phoneNo))
            {
                phoneNo = "";
            }

            if (string.IsNullOrEmpty(network))
            {
                network = "";
            }

            if (string.IsNullOrEmpty(declineReason))
            {
                declineReason = "";
            }

            if (string.IsNullOrEmpty(errorType))
            {
                errorType = "";
            }

            if (string.IsNullOrEmpty(GTBATMLocation))
            {
                GTBATMLocation = "";
            }

            if (string.IsNullOrEmpty(ATMBranchCode))
            {
                ATMBranchCode = "";
            }

            if (string.IsNullOrEmpty(benePhoneNo))
            {
                benePhoneNo= "";
            }

            if (string.IsNullOrEmpty(beneAcctNo))
            {
                beneAcctNo = "";
            }

            if (string.IsNullOrEmpty(refID))
            {
                refID = "";
            }

            if (string.IsNullOrEmpty(ticks))
            {
                ticks = "";
            }

            string email = null;
            SqlConnection Conn = new SqlConnection();
            SqlCommand Command = default(SqlCommand);
            string BranchCode = branchCode.ToString();
            string CustomerNumber = cusNum.ToString();
            string CurrencyCode = curCode.ToString();
            string LedgerCode = ledCode.ToString();
            string SubAccountCode = subacctCode.ToString();
            decimal Amount = default(decimal);
            decimal Dispensedamt = default(decimal);
            decimal AmtDue = tranAmount - amtDispensed;
            string STAN = null;
            string PAN = null;
            string Merchant = null;
            string UserID = null;
            string SmartCardNo = null;
            string MobileNumber = null;
            string Network = null;
            string DeclineReason = null;
            string emailmessage = null;
            string txt = null;
            string acct_name = null;
            string BankName = null;
            string CusName = null;

            string bankDate2 = DateTime.Now.Date.ToString("dd-MMM-yyyy", CultureInfo.CreateSpecificCulture("en-GB"));
            Conn.ConnectionString = ConfigurationManager.ConnectionStrings["DispenseConn"].ConnectionString;
            //string TranDate = Strings.Format(Convert.ToDateTime(transacDate.SelectedDateString), "yyyy-MM-dd");  string TranDate = String.Format("DD-MMM-YYYY", transacDate).ToString().Replace("-", "");

            DateTime date = DateTime.Parse(transacDate);
            string TranDate = date.ToString("yyyy-MM-dd");

            BranchCode = branchCode.ToString();
            CustomerNumber = cusNum.ToString();
            CurrencyCode = curCode.ToString();
            LedgerCode = ledCode.ToString();
            SubAccountCode = subacctCode.ToString();
            Amount = tranAmount;
            Dispensedamt = amtDispensed;
            AmtDue = tranAmount - amtDispensed;
            STAN = STAN1;
            PAN = PAN1;
            Merchant = merchant;
            UserID = tellerID;
            SmartCardNo = smartCardNo;
            MobileNumber = phoneNo;
            Network = network;
            DeclineReason = declineReason;
            
            BankName = bankNam;
            CusName = getname(BranchCode, CustomerNumber, CurrencyCode, LedgerCode, SubAccountCode);

            if (CheckErrorOccured(BranchCode, CustomerNumber, LedgerCode, CurrencyCode, SubAccountCode, STAN, TranDate, Amount, PAN))
            {
                if (CheckErrorReversed(BranchCode, CustomerNumber, LedgerCode, CurrencyCode, SubAccountCode, STAN, TranDate, AmtDue))
                {
                    xmlstring = xmlstring + "Dispense error already reversed." + "</Response>";
                    return xmlstring + "</Response>";
                }
            }
            else
            {
                xmlstring = xmlstring + "No dispense error occurred on this account on this day." + "</Response>";
                return xmlstring + "</Response>";
            }

            string PlatformID = null;
            string query = "";
            query = "select PlatformID from dbo.BankPlatform where BankName = '" + BankName + "'";
            Conn.Open();
            SqlCommand CommCheck1 = new SqlCommand(query, Conn);
            SqlDataReader drCheck1 = CommCheck1.ExecuteReader();
            drCheck1.Read();

            PlatformID = drCheck1.GetValue(0).ToString();

            drCheck1.Close();
            Conn.Close();

            string CheckSQL = null;
            CheckSQL = "select count(*) from DispenseErrorLog where BranchCode='" + BranchCode + "' and CustomerNumber='" + CustomerNumber + "' and CurrencyCode='" + CurrencyCode + "' and LedgerCode='" + LedgerCode + "' and SubAccountCode='" + SubAccountCode + "' and STAN='" + STAN + "' and PAN='" + PAN + "' and TransactionAmount='" + Amount + "'";
            int check = 0;
            SqlDataReader drCheck = default(SqlDataReader);
            SqlCommand CommCheck = default(SqlCommand);

            Conn.Open();
            CommCheck = new SqlCommand(CheckSQL, Conn);
            drCheck = CommCheck.ExecuteReader();
            drCheck.Read();

            check = Convert.ToInt32(drCheck.GetValue(0));
            drCheck.Close();
            Conn.Close();

            if (check != 0)
            {
                xmlstring = xmlstring + "This dispense error has already been logged before." + "</Response>";
                return xmlstring + "</Response>";
            }

            else if (check == 0)
            {
                string CheckSQL1 = null;
                CheckSQL1 = "select count(*) from DispenseErrorLog where BranchCode='" + BranchCode + "' and CustomerNumber='" + CustomerNumber + "' and CurrencyCode='" + CurrencyCode + "' and LedgerCode='" + LedgerCode + "' and SubAccountCode='" + SubAccountCode + "' and PAN='" + PAN + "' and TransactionAmount='" + Amount + "' and TransactionDate = '" + TranDate + "'";
                int check1 = 0;
                SqlDataReader drCheck3 = default(SqlDataReader);
                SqlCommand CommCheck3 = default(SqlCommand);

                Conn.Open();
                CommCheck3 = new SqlCommand(CheckSQL1, Conn);
                drCheck3 = CommCheck3.ExecuteReader();
                drCheck3.Read();

                check1 = Convert.ToInt32(drCheck3.GetValue(0));
                drCheck3.Close();
                Conn.Close();

                if (check1 != 0)
                {
                    xmlstring = xmlstring + "A dispense error with this amount has been logged before, please check the box displayed below to confirm relog." + "</Response>";
                    return xmlstring + "</Response>";
                }

                else
                {
                    string SQL = string.Empty;

                    if (Conn.State != ConnectionState.Open)
                    {
                        Conn.Open();
                    }

                    Command = new SqlCommand();
                    Command.Connection = Conn;
                    Command.CommandType = CommandType.StoredProcedure;
                    Command.CommandText = "new_DispenseLogInsert";
                    Command.Parameters.AddWithValue("@BranchCode", BranchCode);
                    Command.Parameters.AddWithValue("@CustomerNumber", CustomerNumber);
                    Command.Parameters.AddWithValue("@CurrencyCode", CurrencyCode);
                    Command.Parameters.AddWithValue("@LedgerCode", LedgerCode);
                    Command.Parameters.AddWithValue("@SubAccountCode", SubAccountCode);
                    Command.Parameters.AddWithValue("@TransactionAmount", Amount);
                    Command.Parameters.AddWithValue("@AmountDispensed", Dispensedamt);
                    Command.Parameters.AddWithValue("@AmountDue", AmtDue);
                    Command.Parameters.AddWithValue("@TransactionDate", TranDate);
                    Command.Parameters.AddWithValue("@Status", "Logged");
                    Command.Parameters.AddWithValue("@Stan", STAN);
                    Command.Parameters.AddWithValue("@Bank", BankName);
                    Command.Parameters.AddWithValue("@Platform", PlatformID);
                    Command.Parameters.AddWithValue("@Pan", PAN);
                    Command.Parameters.AddWithValue("@Merchant", Merchant);
                    Command.Parameters.AddWithValue("@Settled", "0");
                    Command.Parameters.AddWithValue("@DateLogged", DateTime.Now);
                    Command.Parameters.AddWithValue("@Userid", UserID);
                    Command.Parameters.AddWithValue("@Accountname", CusName);
                    Command.Parameters.AddWithValue("@Smartcardno", SmartCardNo);
                    Command.Parameters.AddWithValue("@PhoneNo", MobileNumber);
                    Command.Parameters.AddWithValue("@Network", Network);
                    Command.Parameters.AddWithValue("@Customername", CusName);
                    Command.Parameters.AddWithValue("@Originatingbracode", origbraCode);
                    Command.Parameters.AddWithValue("@Declinereason", DeclineReason);
                    Command.Parameters.AddWithValue("@Insertmultiple", 1);
                    Command.Parameters.AddWithValue("@Errortype", errorType); 
                    Command.Parameters.AddWithValue("@GTBATMLocation", GTBATMLocation);
                    Command.Parameters.AddWithValue("@ATMBranchCode", ATMBranchCode);
                    Command.Parameters.AddWithValue("@BeneficiaryPhoneNo", benePhoneNo);
                    Command.Parameters.AddWithValue("@BeneficiaryAccountNo", beneAcctNo);
                    Command.Parameters.AddWithValue("@ReferenceID", refID);
                    Command.Parameters.AddWithValue("@ticks", ticks);

                    SQL = Command.ExecuteScalar().ToString();
                    Conn.Close();

                    emailmessage = string.Empty;
                    txt = string.Empty;
                    acct_name = string.Empty;
                    email = string.Empty;
                    emailmessage = "Your POS ATM or Web dispense error request with STAN " + STAN + " and amount " + AmtDue + " has been logged by GTBank. Your Tracking Id is " + SQL + " Please expect further updates.";

                    //txt = System.IO.File.ReadAllText(("~\\HtmlFiles\\Statement.html"));
                    txt = txt.Replace("{EVENTDATE}", bankDate2);
                    acct_name = CusName;
                    txt = txt.Replace("{CUSNAME}", acct_name);
                    txt = txt.Replace("{msg}", emailmessage);
                    email = getbasisemail(BranchCode, CustomerNumber);

                    if (!(string.IsNullOrEmpty(email)))
                    {
                        Emailer.SendIntroHtmlMessage(email, "CardServices@gtbank.com", "Dispense Error Request Status", txt, "");
                    }

                    xmlstring = xmlstring + "Details submitted successfully with tracking ID: ";
                    return xmlstring + SQL + " and refID" + refID +"</Response>";
                }
            }
        }

        catch (Exception ex)
        {
            ex.ToString();
            xmlstring = xmlstring + ex;
            //xmlstring = xmlstring + "</Response>";
            oraconn.Close();
        }

        return xmlstring + "</Response>";
    }

    public bool CheckErrorOccured(string bracode, string cusnum, string ledcode, string curcode, string subacctcode, string STAN, string tradate1, decimal traamt, string PAN)
    {
        xmlstring = "<Response>";
        OracleDataReader dr = default(OracleDataReader);
        string tradate = tradate1; //String.Format("DD-MMM-YYYY", tradate1).ToString().Replace("-", "");
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

        //OracleConnection oraconn = new OracleConnection(ConfigurationManager.ConnectionStrings["BasisConn"].ConnectionString);

        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }

            string querystring = string.Empty;
            querystring = " select set_date as tra_date, remarks, tra_amt, substr(STAN, -6) as doc_num from pend_tra p where p.expl_code in (465, 466, 467, 468, 470, 449, 489) and p.SET_DATE = '" + tradate1 + "' ";
            querystring = querystring + " and p.BRA_CODE = '" + bracode + "' and p.CUS_NUM = '" + cusnum + "' and p.CUR_CODE  = '" + curcode + "' ";
            querystring = querystring + "and p.LED_CODE = '" + ledcode + "' and p.SUB_ACCT_CODE = '" + subacctcode + "'  and ";
            querystring = querystring + "substr(p.CARD_NUM, -4) = '" + PAN + "' and substr(p.stan, -6) = '" + STAN + "' and p.tra_amt = '" + traamt + "' UNION  select tra_date, remarks, tra_amt, substr(doc_num, -6) as doc_num from ";
            querystring = querystring + " transact t where t.expl_code in (465, 466, 467, 468, 470, 449, 489) and t.TRA_DATE = '" + tradate1 + "' ";
            querystring = querystring + " and t.BRA_CODE = '" + bracode + "' and t.CUS_NUM = '" + cusnum + "' and t.CUR_CODE  = '" + curcode + "' ";
            querystring = querystring + "and t.LED_CODE = '" + ledcode + "' and t.SUB_ACCT_CODE = '" + subacctcode + "' and substr(t.doc_num, -6) = '" + STAN + "' and t.tra_amt = '" + traamt + "'";

            OracleCommand oracomm = new OracleCommand(querystring, oraconn);
            dr = oracomm.ExecuteReader();

            if ((dr.Read()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        catch (Exception ex)
        {
            return false;
        }

        finally
        {
            oraconn.Close();
            oraconn = null;
        }
    }

    public bool CheckErrorReversed(string bracode, string cusnum, string ledcode, string curcode, string subacctcode, string stan, string tradate1, decimal traamt)
    {
        xmlstring = "<Response>";
        OracleDataReader dr = default(OracleDataReader);
        string tradate = tradate1; //String.Format("DD-MMM-YYYY", tradate1).ToString().Replace("-", "");    
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
       
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }

            string querystring = string.Empty;
            querystring = "select * from pend_tra where bra_code = '" + bracode + "' and cus_num = '" + cusnum + "' and led_code = '" + ledcode + "'and sub_acct_code = '" + subacctcode + "' and set_date >='" + tradate + "' and doc_num='" + "9999" + stan + " ' and deb_cre_ind  = 2";
            OracleCommand oracomm = new OracleCommand(querystring, oraconn);
            dr = oracomm.ExecuteReader();

            if ((dr.Read()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception ex)
        {
            return false;
        }
        finally
        {
            oraconn.Close();
        }
    }

    protected string getbasisemail(string bracode, string cusnum)
    {
        string email = "";
        string connstr1 = null;
        connstr1 = GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]);
        //OracleConnection OraConn__1 = new OracleConnection[oraconn];
        OracleCommand OraSelect = new OracleCommand();
        OracleDataReader OraDrSelect = null;

        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }

            OraSelect.Connection = oraconn;

            string a = "select email from address where bra_code = '" + bracode + "'  and cus_num =" + cusnum + " and led_code = 0 and cur_code = 0 and  sub_acct_code =0";
            // Dim a As String = "select distinct a.cus_sho_name,MOB_NUM||' / '||TEL_NUM_2 phone_num,substr(c.acct_mgr,1,3) as acct_off_PCcode, d.t_email,navailbal(" & param & ") avail_bal   from address   a,customer b, acct_inf c, team d,account e  where  a.bra_code =" & txtBraCode.Text & " and a.cus_num = " & txtCusNum.Text & " and a.cur_code = 0 and c.led_code = " & led_code & " and a.bra_code = b.bra_code and a.cus_num = b.cus_num and b.bra_code = c.bra_code and c.bra_code = e.bra_code and c.cus_num = e.cus_num and b.cus_num = c.cus_num and d.team_no = substr(c.acct_mgr,1,3)"
            OraSelect.CommandText = a;
            //"select a.cus_sho_name,a.Name_line1,a.add_line1||' '||a.add_line2 as Perm_address, b.BIR_DATE,MOB_NUM||' / '||TEL_NUM_2 phone_num,EMAIL , b.SOC_SEC_NUM,c.acct_mgr   from address   a,customer b, acct_inf c where a.bra_code = " & txtBraCode.Text & " and a.cus_num = " & txtCusNum.Text & " and a.bra_code = b.bra_code and a.cus_num = b.cus_num and b.bra_code = c.bra_code and b.cus_num = c.cus_num"
            OraSelect.CommandType = CommandType.Text;
            OraDrSelect = OraSelect.ExecuteReader();

            if (OraDrSelect.Read() == true)
            {
                email = OraDrSelect["email"].ToString();
                return email;
            }
            else
            {
                return email;
            }
        }

        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message);
        }
        return email;
    }

    protected string getname(string bracode, string cusnum, string curcode, string ledcode, string subacctcode)
    {
        string email = "";

        String connstr1 = default(String);
        connstr1 = GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]);
        //OracleConnection OraConn__1 = new OracleConnection(oraconn);

        OracleCommand OraSelect = new OracleCommand();
        OracleDataReader OraDrSelect = null;

        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }

            OraSelect.Connection = oraconn;
            string a = "select get_name2(" + bracode.Trim() + " ," + cusnum.Trim() + " ," + curcode.Trim() + "," + ledcode.Trim() + ", " + subacctcode.Trim() + ") cus_sho_name from dual";
            // Dim a As String = "select distinct a.cus_sho_name,MOB_NUM||' / '||TEL_NUM_2 phone_num,substr(c.acct_mgr,1,3) as acct_off_PCcode, d.t_email,navailbal(" & param & ") avail_bal   from address   a,customer b, acct_inf c, team d,account e  where  a.bra_code =" & txtBraCode.Text & " and a.cus_num = " & txtCusNum.Text & " and a.cur_code = 0 and c.led_code = " & led_code & " and a.bra_code = b.bra_code and a.cus_num = b.cus_num and b.bra_code = c.bra_code and c.bra_code = e.bra_code and c.cus_num = e.cus_num and b.cus_num = c.cus_num and d.team_no = substr(c.acct_mgr,1,3)"
            OraSelect.CommandText = a;
            //"select a.cus_sho_name,a.Name_line1,a.add_line1||' '||a.add_line2 as Perm_address, b.BIR_DATE,MOB_NUM||' / '||TEL_NUM_2 phone_num,EMAIL , b.SOC_SEC_NUM,c.acct_mgr   from address   a,customer b, acct_inf c where a.bra_code = " & txtBraCode.Text & " and a.cus_num = " & txtCusNum.Text & " and a.bra_code = b.bra_code and a.cus_num = b.cus_num and b.bra_code = c.bra_code and b.cus_num = c.cus_num"
            OraSelect.CommandType = CommandType.Text;
            OraDrSelect = OraSelect.ExecuteReader();
            if (OraDrSelect.Read() == true)
            {
                email = OraDrSelect["cus_sho_name"].ToString();
                return email;
            }
            else
            {
                return email;
            }
        }
        catch (Exception ex)
        {

            ErrHandler.WriteError(ex.Message + "occured at" + DateTime.Now);
        }
        return email;
    }

    protected void msg(string msg)
    {
        //Response.Write("<Script language='javascript'>window.alert('" + msg + "');</script>");
    }

    protected void clearscreen()
     {
         //txtAmtDue.Text = "";
         //txtAccountName.Value = "";
         //txtCurCode.Value = "";
         //txtCustomerName.Value = "";
         //txtLedCode.SelectedValue = "";
         //txtMerchant.Value = "";
         //txtMobNum.Value = "";
         //txtNetwork.Value = "";
         //txtPAN.Value = "";
         //txtSmartCardNo.Value = "";
         //txtSTAN.Value = "";
         //txtSubAcctCode.Value = "";
         //txtTranAmount.Value = "";
         //txtAmtDispensed.Text = "";
         //CheckBox1.Checked = false;
         //Butsubmit1.Visible = false;
         //Label21.Visible = false;
         //CheckBox1.Visible = false;
     }

    protected string GetCustomer(string branchcode, string customerNum)
    {
        OracleConnection BConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        BConn.Open();

        //OracleConnection BConn = new OracleConnection();
        OracleCommand BComm = default(OracleCommand);
        string BSQL = null;
        string BraCode = null;
        string CusNum = null;
        string CustomerName = null;
        OracleDataReader dr = default(OracleDataReader);

        BraCode = branchcode;
        CusNum = customerNum;
      
        BSQL = "select cus_sho_name from address where bra_code='" + BraCode + "' and cus_num='" + CusNum + "'";

        //BConn.ConnectionString = ConfigurationManager.ConnectionStrings["BASISConString_eone"].ConnectionString;
        //BConn.Open();
        BComm = new OracleCommand(BSQL, BConn);
        //BComm.ExecuteNonQuery()
        dr = BComm.ExecuteReader();

        if ((dr.Read()))
        {
            CustomerName = dr.GetValue(0).ToString();            
        }
        else
        {
            CustomerName = "";
        }

        dr.Close();
        BConn.Close();

        return CustomerName;
    }

    protected string GetCustomer2(string branchcode, string customerNum)
    {
        OracleConnection BConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        BConn.Open();

        //OracleConnection BConn = new OracleConnection();
        OracleCommand BComm = default(OracleCommand);
        string BSQL = null;
        string BraCode = null;
        string CusNum = null;
        string CustomerName = null;
        OracleDataReader dr = default(OracleDataReader);

        BraCode = branchcode;
        CusNum = customerNum;

        BSQL = "select cus_sho_name from address where bra_code='" + BraCode + "' and cus_num='" + CusNum + "'";

        //BConn.ConnectionString = ConfigurationManager.ConnectionStrings["BASISConString_eone"].ConnectionString;
        //BConn.Open();
        BComm = new OracleCommand(BSQL, BConn);
        //BComm.ExecuteNonQuery()
        dr = BComm.ExecuteReader();

        if ((dr.Read()))
        {
            CustomerName = dr.GetValue(0).ToString();
        }
        else
        {
            xmlstring = xmlstring + "Invalid account number inputted" + "</Response>";
            return xmlstring;
        }

        dr.Close();
        BConn.Close();

        return CustomerName;
    }

    //public string InternationalDispute(string dateFrom, string dateTo)
    //{

    //    string sqlconn = ConfigurationManager.AppSettings["Dispenseconn"];
    //    SqlConnection sqlcon = new SqlConnection(sqlconn);
    //    string surname = "";
    //    string firstname = "";
    //    Int16 returnval = 0;
    //    string[] a = new string[2];

    //    SqlDataAdapter adpt = default(SqlDataAdapter);
    //    DataTable dt = new DataTable();
    //    if (string.IsNullOrEmpty(dateFrom))
    //    {
    //        xmlstring = xmlstring + "DateFrom cannot be less than 8 characters 'DDMMMYYYY'" + "</Response>";
    //        return xmlstring;
    //    }
    //    if (string.IsNullOrEmpty(dateTo))
    //    {
    //        xmlstring = xmlstring + "DateTo cannot be less than 8 characters 'DDMMMYYYY'" + "</Response>";
    //        return xmlstring;
    //    }


    //    try
    //    {
    //        SqlCommand cmd = new SqlCommand();

    //        cmd.CommandText = "usp_InternationalDisputeLogReport";
    //        cmd.CommandType = CommandType.StoredProcedure;
    //        cmd.Connection = sqlcon;

    //        cmd.Parameters.Add("@FromDate", SqlDbType.DateTime);
    //        cmd.Parameters("@FromDate").Value = dateFrom;

    //        cmd.Parameters.Add("@ToDate", SqlDbType.DateTime);
    //        cmd.Parameters("@ToDate").Value = dateTo;

    //        cmd.Parameters.Add("@datetype", SqlDbType.Int);
    //        cmd.Parameters("@datetype").Value = DropDownList1.SelectedValue;

    //        cmd.Parameters.Add("@resolutionStatus", SqlDbType.VarChar);
    //        cmd.Parameters("@resolutionStatus").Value = ddlstatus.SelectedValue;


    //        adpt = new SqlDataAdapter(cmd);

    //        if (sqlcon.State == ConnectionState.Closed)
    //        {
    //            sqlcon.Open();
    //        }

    //        adpt.Fill(dt);

    //        if (dt.Rows.Count > 0)
    //        {
    //            GridReport1.DataSource = dt;
    //            GridReport1.DataBind();
    //        }
    //        else
    //        {
    //            msg("Record does not exist");

    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        string exc = ex.Message;

    //    }
    //    finally
    //    {
    //        sqlcon.Close();
    //    }
    //}

    //public string MobileMoney(int branchCode, int origbraCode, int cusNum, int curCode, int ledCode, int subacctCode, int tranAmount, string transacDate, string typeofTrans, string detailsofTransType, string mobileNumber, string userID, string refID)
    //{
    //    Emailer emailer = new Emailer();
                
    //    if (branchCode.ToString().Length != 3)
    //    {
    //        xmlstring = xmlstring + "<ERROR>Branch Code must be 3 characters.</ERROR>";
    //        return xmlstring;
    //    }

    //    else if (origbraCode.ToString().Length != 3)
    //    {
    //        xmlstring = xmlstring + "<ERROR>Originating branch Code must be 3 characters.</ERROR>";
    //        return xmlstring;
    //    }

    //    else if (cusNum.ToString().Length != 6)
    //    {
    //        xmlstring = xmlstring + "<ERROR>Customer number must be 6 characters.</ERROR>";
    //        return xmlstring;
    //    }

    //    else if (curCode.ToString() == null)
    //    {
    //        xmlstring = xmlstring + "<ERROR>Currency Code cannot be null.</ERROR>";
    //        return xmlstring;
    //    }

    //    else if (ledCode.ToString() == null)
    //    {
    //        xmlstring = xmlstring + "<ERROR>Ledger Code cannot be null.</ERROR>";
    //        return xmlstring;
    //    }

    //    else if (subacctCode.ToString() == null)
    //    {
    //        xmlstring = xmlstring + "<ERROR>Sub Account Code cannot be null.</ERROR>";
    //        return xmlstring;
    //    }

    //    //else if (cusName.Length <= 0)
    //    //{
    //    //    xmlstring = xmlstring + "<ERROR>Customer name cannot be null.</ERROR>";
    //    //    return xmlstring;
            
    //    //}

    //    else if (tranAmount.ToString() == null)
    //    {
    //        xmlstring = xmlstring + "<ERROR>Transaction amount cannot be null.</ERROR>";
    //        return xmlstring;
    //    }

    //    else if (transacDate.Length < 9)
    //    {
    //        xmlstring = xmlstring + "<ERROR>Transaction date cannot be less than 9 characters 'DDMMMYYYY'.</ERROR>";
    //        return xmlstring;
    //    }

    //    else if (userID.Length <= 0)
    //    {
    //        xmlstring = xmlstring + "<ERROR>userID cannot be null.</ERROR>";
    //        return xmlstring;
    //    }

    //    else if (refID.Length <= 0)
    //    {
    //        xmlstring = xmlstring + "<ERROR>refID cannot be null.</ERROR>";
    //        return xmlstring;
    //    }

    //    else if (typeofTrans.Length <= 0)
    //    {
    //        xmlstring = xmlstring + "<ERROR>Type of transaction cannot be null.</ERROR>";
    //        return xmlstring;
    //    }

    //    else if (detailsofTransType.Length <= 0)
    //    {
    //        xmlstring = xmlstring + "<ERROR>Kindly provide the details of the type of transaction.</ERROR>";
    //        return xmlstring;
    //    }

    //    string transdetail = detailsofTransType;
    //    string transtype = string.Empty;
    //    string bracode = string.Empty;
    //    string cusnum = string.Empty;
    //    string curcode = string.Empty;
    //    string ledcode = string.Empty;
    //    string subacct = string.Empty;
    //    string cusname = string.Empty;
    //    string email = string.Empty;
    //    string phoneno = string.Empty;
    //    decimal transamt = 0;
    //    string transdate = string.Empty;
    //    string refid = string.Empty;
    //    string loggedby = string.Empty;
    //    DateTime datelogged = default(DateTime);
    //    string status = string.Empty;
    //    Int64 returnval = default(Int64);
    //    string txt = null;
    //    string emailmessage = null;
    //    string acct_name = null;
    //    string bankDate2 = DateTime.Now.Date.ToString("dd-MMM-yyyy", CultureInfo.CreateSpecificCulture("en-GB"));
    //    string mmemail = string.Empty;
    //    int stacheck = 0;
    //    string bank = "Mobile Money";
    //    int platid = 4;
    //    int settled = 0;
    //    int origbra = origbraCode;
    //    string errortype = string.Empty;

    //    SqlConnection conn = new SqlConnection(sqlconn);

        
    //    bracode = branchCode.ToString();
    //    cusnum = cusNum.ToString();
    //    curcode = curCode.ToString();
    //    ledcode = ledCode.ToString();
    //    subacct = subacctCode.ToString();
    //    cusname = getname(bracode, cusnum, curcode, ledcode, subacct);
        
    //    phoneno = mobileNumber;
    //    transamt = tranAmount;
    //    transdate = transacDate;
    //    refid = refID;
    //    loggedby = userID;
    //    datelogged = DateTime.Now;
    //    status = "Logged";

    //    errortype = typeofTrans;
    //    SqlCommand cmd = new SqlCommand();
    //    if (conn.State == ConnectionState.Closed)
    //    {
    //        conn.Open();
    //    }
    //    try
    //    {
    //        cmd.Connection = conn;
    //        cmd.CommandText = "usp_MobileMoneyInsert";
    //        cmd.CommandType = CommandType.StoredProcedure;
    //        cmd.Parameters.AddWithValue("@BranchCode", bracode);
    //        cmd.Parameters.AddWithValue("@CustomerNumber", cusnum);
    //        cmd.Parameters.AddWithValue("@CurrencyCode", curcode);
    //        cmd.Parameters.AddWithValue("@LedgerCode", ledcode);
    //        cmd.Parameters.AddWithValue("@SubAccountCode", subacct);
    //        cmd.Parameters.AddWithValue("@CustomerName", cusname);
    //        cmd.Parameters.AddWithValue("@statuscheck", stacheck);
    //        cmd.Parameters.AddWithValue("@PhoneNo", phoneno);
    //        cmd.Parameters.AddWithValue("@bank", bank);
    //        cmd.Parameters.AddWithValue("@platformid", platid);
    //        cmd.Parameters.AddWithValue("@TransactionAmount", transamt);
    //        cmd.Parameters.AddWithValue("@TransactionDate", transdate);
    //        cmd.Parameters.AddWithValue("@Referenceid", refid);
    //        cmd.Parameters.AddWithValue("@settled", settled);
    //        cmd.Parameters.AddWithValue("@errortype", errortype);
    //        cmd.Parameters.AddWithValue("@TransactionDetail", transdetail);
    //        cmd.Parameters.AddWithValue("@LoggedBy", loggedby);
    //        cmd.Parameters.AddWithValue("@DateLogged", datelogged);
    //        cmd.Parameters.AddWithValue("@origbracode", origbra);
    //        cmd.Parameters.AddWithValue("@Status", status);


    //        returnval = Convert.ToInt64(cmd.ExecuteNonQuery());

    //        if (!(returnval >= 1))
    //        {
    //            emailmessage = string.Empty;
    //            txt = string.Empty;
    //            acct_name = string.Empty;
    //            email = string.Empty;
    //            emailmessage = "Your Mobile money dispense error request with Reference ID " + refid + " and amount " + transamt + " has been logged by GTBank. Please expect further updates.";


    //            //txt = System.IO.File.ReadAllText(Server.MapPath("~") + "\\HtmlFiles\\Statement.html");
    //            txt = txt.Replace("{EVENTDATE}", bankDate2);
    //            acct_name = cusname;
    //            txt = txt.Replace("{CUSNAME}", acct_name);
    //            txt = txt.Replace("{msg}", emailmessage);

    //            mmemail = "Dear Team, A mobile money dispense error has been logged on Dispense error portal. Customer Name: '" + cusname + "' Amount: '" + transamt + "' Transaction Detail: '" + transdetail + "' RefereneceID: '" + refid + "' Please log on to the Portal to spool.";

    //            email = getbasisemail(bracode, cusnum);

    //            //uncomment

    //            if (!(string.IsNullOrEmpty(email)))
    //            {
    //                Emailer.SendMessage2("Mobile Money Dispense Error", mmemail, "CardServices@gtbank.com", "mobilemoneyteam@gtbank.com", "", "");
    //                // "Dispense Error Request Status", txt, "")
    //            }

    //            smssender.Send_SMS(branchCode, cusNum, "GTBANK", emailmessage);
    //            xmlstring = xmlstring + "Operation Successful" + "</Response>";
    //            return xmlstring;
    //        }
    //        else
    //        {
    //            xmlstring = xmlstring + "Operation not Successful" + "</Response>";
    //            return xmlstring;
    //        }
    //    }

    //    catch (Exception ex)
    //    {
    //        ErrHandler.WriteError(ex.Message);
    //    }
    //    finally
    //    {
    //        conn.Close();
    //    }

    //    return xmlstring + "</Response>";

    //}

}

   