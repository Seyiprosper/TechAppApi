﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using Vanso.WMP;
using System.Data.SqlClient;
using System.Configuration;

public class SendSMS
{
    Error_Log ErrorLog = new Error_Log();
    ErrHandler ErrorWriter = new ErrHandler();
    string ConnHoBank_Test = GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]);
    string conn = ConfigurationManager.AppSettings["DispenseCon"];

    public string Send_SMS (int pBranchCode, int pCustomerNo, string pSenderID, string pMessage)
    {
        string functionReturnValue = null;
        System.Data.SqlClient.SqlCommand cmdSQLSelect = new System.Data.SqlClient.SqlCommand();
        //Dim drOraselect As OracleClient.OracleDataReader
        System.Data.OracleClient.OracleDataAdapter daOraSelect = new System.Data.OracleClient.OracleDataAdapter("select Mob_num,Tel_num from Address where bra_code=" + pBranchCode + " and cus_num=" + pCustomerNo, ConnHoBank_Test);
        DataTable dtMobile = new DataTable();
        string MobileNum = "";
        SMS MySMS = new SMS();
        //Simplewire.SMS
        //Dim ReturnNo
        bool isInternational = false;
        bool isSA_num = false;

        try
        {
            daOraSelect.Fill(dtMobile);
            if (dtMobile.Rows.Count > 0)
            {
                MobileNum = (!string.IsNullOrEmpty(dtMobile.Rows[0]["Mob_Num"].ToString().Replace("-", "")) ? dtMobile.Rows[0]["Mob_Num"].ToString().Replace("-", "") : dtMobile.Rows[0]["Tel_Num"].ToString().Replace("-", ""));
                MySMS.ServerName = "wmp";
                MySMS.ServerDomain = "gtbplc.com";
                MySMS.SubscriberID = "174-541-908-12371";
                MySMS.SubscriberPassword = "VqONrtWl";

                //MySMS.SourceType = Simplewire.ADDR_TYPE.swAtAlphanumeric
                //check the length of the mobile number
                if (MobileNum.StartsWith("234") | MobileNum.StartsWith("08") | MobileNum.StartsWith("07"))
                {
                    if (MobileNum.StartsWith("234"))
                    {
                        if (MobileNum.Length == 14)
                        {
                            MobileNum = "234" + MobileNum.Trim().Substring(4, 10);
                        }
                        else if (MobileNum.Length == 13)
                        {
                            MobileNum = "234" + MobileNum.Trim().Substring(3, 10);
                        }
                    }
                    else
                    {
                        if (MobileNum.Length == 11)
                        {
                            MobileNum = "234" + MobileNum.Trim().Substring(1, 10);
                        }
                    }
                }
                else if (MobileNum.StartsWith("+") | MobileNum.Length >= 10)
                {
                    if (MobileNum.StartsWith("+"))
                    {
                        MobileNum = MobileNum.Trim().Substring(1);
                        if (MobileNum.Substring(0, 2) != "27")
                        {
                            isInternational = true;
                        }
                        else
                        {
                            isSA_num = true;
                            //South Africa number
                        }
                    }
                    else
                    {
                        MobileNum = MobileNum.Trim();
                        if (MobileNum.Substring(0, 2) != "27")
                        {
                            isInternational = true;
                        }
                        else
                        {
                            isSA_num = true;
                            //South Africa number
                        }
                        //isInternational = True
                    }
                }
                else if (MobileNum.Length >= 7)
                {
                    MobileNum = MobileNum;
                }

                if (isInternational == false | isSA_num == true)
                {
                    MySMS.SourceAddress = new Address("GTBANK", AddressType.Alphanumeric);
                }
                else
                {
                    MySMS.SourceAddress = new Address("08039003900", AddressType.Alphanumeric);
                }
                //MySMS.SourceAddress = New Address("GTBANK", AddressType.Alphanumeric) '(pSenderID)
                MySMS.DestinationAddress = new Address(MobileNum, AddressType.International);
                //.DestinationAddr = MobileNum
                MySMS.MessageText = pMessage;
                //MySMS.DestinationCarrier = 2

                if (MySMS.Submit())
                {
                    functionReturnValue = MySMS.TicketID + "," + MobileNum;
                    logsms(pBranchCode, pCustomerNo, MobileNum, MySMS.TicketID, pMessage);
                    //MsgBox("Message sent successfully!!!")
                    //ErrorLog.AppLogWrite(pRecipientID & "- " & pMessage & ":" & "Ticket_ID:" & MySMS.MsgTicketID, False)
                }
                else
                {
                    functionReturnValue = "";

                    ErrHandler.WriteError("Error Code: " + MySMS.ErrorCode.ToString() + " Error Description: " + MySMS.ErrorDescription);
                    ErrorLog.AppLogWrite(MobileNum + ":" + "Error:" + MySMS.ErrorCode.ToString() + " /Description:" + MySMS.ErrorDescription, true);
                    //AppLogWrite(txtTo.Text & ":" & "Error:" & MySMS.ErrorDesc & " /Resolution:" & MySMS.ErrorResolution, True)
                }
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message);
            functionReturnValue = "";
            ErrorLog.AppLogWrite(ex.Message, true);
        }
        return functionReturnValue;
    }

    protected void logsms(int bra_code, Int64 cus_num, string mobilenum, string ticketid, string message)
    {
        SqlConnection sqlconnect = new SqlConnection(conn);
        // updatequery = "Update DispenseErrorLog set status = 'Settled', Settled = 1 where SN = " + SN + " ";
        SqlCommand sqlcmd = new SqlCommand();
        sqlcmd.CommandType = CommandType.StoredProcedure;
        sqlcmd.Connection = sqlconnect;
        sqlcmd.CommandText = "usp_SentSMSInsert";
        sqlcmd.Parameters.Add("@Bra_code", SqlDbType.Int);
        sqlcmd.Parameters["@Bra_code"].Value = bra_code;
        sqlcmd.Parameters.Add("@Cus_num", SqlDbType.BigInt);
        sqlcmd.Parameters["@Cus_num"].Value = cus_num;
        sqlcmd.Parameters.Add("@MobileNum", SqlDbType.NVarChar);
        sqlcmd.Parameters["@MobileNum"].Value = mobilenum;
        sqlcmd.Parameters.Add("@Ticketid", SqlDbType.NVarChar);
        sqlcmd.Parameters["@Ticketid"].Value = ticketid;
        sqlcmd.Parameters.Add("@Datesent", SqlDbType.DateTime);
        sqlcmd.Parameters["@Datesent"].Value = DateTime.Now;
        sqlcmd.Parameters.Add("@Message", SqlDbType.VarChar);
        sqlcmd.Parameters["@Message"].Value = message;


        try
        {
            if (sqlconnect.State == ConnectionState.Closed)
            {
                sqlconnect.Open();
            }
            sqlcmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message);
        }
        finally
        {
            sqlconnect.Close();
        }
    }
}

