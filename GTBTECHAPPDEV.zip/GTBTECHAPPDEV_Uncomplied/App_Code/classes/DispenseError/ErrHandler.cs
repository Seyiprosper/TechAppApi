﻿
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Globalization;
using System.Web;
using System.Web.Security;
using System.Web.UI;


public class ErrHandler
{


    public static void WriteError(string errorMessage)
    {
        Error_Log errLog = new Error_Log();

        try
        {

            string path = "~/Error/" + DateTime.Today.ToString("dd-MM-yy") + ".txt";
            if (!File.Exists(System.Web.HttpContext.Current.Server.MapPath(path)))
            {
                File.Create(System.Web.HttpContext.Current.Server.MapPath(path)).Close();
            }

            StreamWriter w = File.AppendText(System.Web.HttpContext.Current.Server.MapPath(path));
            //w.WriteLine("\\r\\nLog Entry : UserID:" + HttpContext.Current.Session["mUserId"]);
            w.WriteLine("{0}", DateTime.Now.ToString(CultureInfo.InvariantCulture));
            string err = "Message From: " + System.Web.HttpContext.Current.Request.Url.ToString() + ". Message:" + errorMessage;
            w.WriteLine(err);
            w.WriteLine("_______________________________________");
            w.Flush();
            w.Close();

        }
        catch (Exception ex)
        {
            //WriteError(ex.Message)
            Emailer.SendMessage2("Failed to write to Ibank Log", "Please check as error occured writing to ibank txt log. the error is " + ex.Message, "intopsmonitor", "servicemanagement@gtbank.com", "appdev@gtbank.com", "appdev@gtbank.com");
            errLog.AppLogWrite(ex.Message, true);
        }
    }

    public static void Log(string method, string uniqueRef, string message)
    {
        try
        {
            string path = "~/Error/Activity Log ~ " + DateTime.Today.ToString("dd-MM-yy") + ".txt";
            if (!File.Exists(System.Web.HttpContext.Current.Server.MapPath(path)))
            {
                File.Create(System.Web.HttpContext.Current.Server.MapPath(path)).Close();
            }
            using (StreamWriter w = File.AppendText(System.Web.HttpContext.Current.Server.MapPath(path)))
            {
                w.WriteLine("\r\nLog Entry:");
                w.WriteLine("{0}", DateTime.Now.ToString(CultureInfo.InvariantCulture));
                //w.WriteLine("\r\n");
                w.WriteLine("{0}", method);
                //w.WriteLine("\r\n");
                w.WriteLine("{0}", uniqueRef);
                w.WriteLine("{0}", System.Web.HttpContext.Current.Request.Url.ToString());
                w.WriteLine("{0}", "MESSAGE:");
                w.WriteLine(message);
                w.WriteLine("_____________________________________________________________________________________________");
                w.Flush();
                w.Close();
            }
        }
        catch (Exception ex)
        {
            EventLog eventLog1 = new EventLog();
            //WriteError(ex.Message);
            eventLog1.Source = "GTBTECHAPPDEV";

            eventLog1.WriteEntry("Error in: " + System.Web.HttpContext.Current.Request.Url.ToString());

            eventLog1.WriteEntry(ex.Message, EventLogEntryType.Information);
        }
    }

    public static void WriteError(string errorMessage, string filename)
    {
        Error_Log errLog = new Error_Log();

        try
        {

            string path = "~/Error/" + DateTime.Today.ToString("dd-MM-yy") + "/" + filename + ".txt";
            if (!File.Exists(System.Web.HttpContext.Current.Server.MapPath(path)))
            {
                File.Create(System.Web.HttpContext.Current.Server.MapPath(path)).Close();
            }

            StreamWriter w = File.AppendText(System.Web.HttpContext.Current.Server.MapPath(path));
            //w.WriteLine("\\r\\nLog Entry : UserID:" + HttpContext.Current.Session["mUserId"]);
            w.WriteLine("{0}", DateTime.Now.ToString(CultureInfo.InvariantCulture));
            string err = "Message From: " + System.Web.HttpContext.Current.Request.Url.ToString() + ". Message:" + errorMessage;
            w.WriteLine(err);
            w.WriteLine("_______________________________________");
            w.Flush();
            w.Close();

        }
        catch (Exception ex)
        {
            //WriteError(ex.Message)
            Emailer.SendMessage2("Failed to write to Ibank Log", "Please check as error occured writing to ibank txt log. the error is " + ex.Message, "intopsmonitor", "servicemanagement@gtbank.com", "appdev@gtbank.com", "appdev@gtbank.com");
            errLog.AppLogWrite(ex.Message, true);
        }
    }

    public static void CalypsoPostLog(string errorMessage)
    {
        Error_Log errLog = new Error_Log();

        try
        {

            string path = "~/Error/CalypsoPostLog-" + DateTime.Today.ToString("dd-MM-yy") + ".txt";
            if (!File.Exists(System.Web.HttpContext.Current.Server.MapPath(path)))
            {
                File.Create(System.Web.HttpContext.Current.Server.MapPath(path)).Close();
            }

            StreamWriter w = File.AppendText(System.Web.HttpContext.Current.Server.MapPath(path));
            //w.WriteLine("\\r\\nLog Entry : UserID:" + HttpContext.Current.Session["mUserId"]);
            w.WriteLine("{0}", DateTime.Now.ToString(CultureInfo.InvariantCulture));
            string err = "Message From: " + System.Web.HttpContext.Current.Request.Url.ToString() + ". Message:" + errorMessage;
            w.WriteLine(err);
            w.WriteLine("_______________________________________");
            w.Flush();
            w.Close();

        }
        catch (Exception ex)
        {
            //WriteError(ex.Message)
            Emailer.SendMessage2("Failed to write to Ibank Log", "Please check as error occured writing to ibank txt log. the error is " + ex.Message, "intopsmonitor", "servicemanagement@gtbank.com", "appdev@gtbank.com", "appdev@gtbank.com");
            errLog.AppLogWrite(ex.Message, true);
        }
    }



}

