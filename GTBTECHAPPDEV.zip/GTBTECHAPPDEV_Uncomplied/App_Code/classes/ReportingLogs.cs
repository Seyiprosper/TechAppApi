﻿using System;
using System.Collections.Specialized;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.DirectoryServices;
using System.Security.Cryptography;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data.OracleClient;
using System.IO;
using APPDEVDLL;
using Vanso.WMP;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.XPath;
using System.Collections;
using Microsoft.VisualBasic;
using System.Globalization;
using MT940Generator;

/// <summary>
/// Summary description for ReportingLogs
/// </summary>
public class ReportingLogs
{
	public ReportingLogs()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public void PostingToBasis_Logs(string channel, long out_tra_seq1, long inp_tra_seq1, string inp_doc_alp, double amount, string appTransUniqIndenf, string debitAcct, string creditAcct, string ipAddress, string hostName)
    {
        SqlCommand sqlSelect = new SqlCommand();
        //SqlDataReader sqlreader;
        SqlConnection TranSeq = new SqlConnection(ConfigurationManager.AppSettings["REPORTING_LOG"].ToString());
        try
        {
            if (TranSeq.State == ConnectionState.Closed)
            {
                TranSeq.Open();
            }

            sqlSelect.CommandText = "PostingToBasis_Logs";
            sqlSelect.CommandType = CommandType.StoredProcedure;
            sqlSelect.Connection = TranSeq;
            sqlSelect.CommandTimeout = 120;
            sqlSelect.Parameters.AddWithValue("@out_tra_seq1", out_tra_seq1);
            sqlSelect.Parameters.AddWithValue("@inp_tra_seq1", inp_tra_seq1);
            sqlSelect.Parameters.AddWithValue("@inp_doc_alp", inp_doc_alp);
            sqlSelect.Parameters.AddWithValue("@amount", amount);
            sqlSelect.Parameters.AddWithValue("@uniqIdentifier", appTransUniqIndenf);
            sqlSelect.Parameters.AddWithValue("@debitAcct", debitAcct);
            sqlSelect.Parameters.AddWithValue("@creditAcct", creditAcct);
            sqlSelect.Parameters.AddWithValue("@ipAddress", ipAddress);
            sqlSelect.Parameters.AddWithValue("@computerName", hostName);

            int res = sqlSelect.ExecuteNonQuery();
            if (res < 1)
                ErrHandler.WriteError("Unable to transaction insert into Transfer_OrigtTraSeq.  || (channel, out_tra_seq1, inp_tra_seq1,  amount, appTransUniqIndenf, debitAcct, creditAcct, ipAddress, hostName) = (" + channel + "," + out_tra_seq1 + "," + inp_doc_alp + "," + amount + "," + appTransUniqIndenf + "," + debitAcct + "," + creditAcct + "," + ipAddress + "," + hostName + ")");

        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + " || Unable to transaction insert into Transfer_OrigtTraSeq.  || (channel, out_tra_seq1, inp_tra_seq1,  amount, appTransUniqIndenf, debitAcct, creditAcct, ipAddress, hostName) = (" + channel + "," + out_tra_seq1 + "," + inp_doc_alp + "," + amount + "," + appTransUniqIndenf + "," + debitAcct + "," + creditAcct + "," + ipAddress + "," + hostName + ")");
        }
        finally
        {
            if (TranSeq.State == ConnectionState.Open)
            {
                TranSeq.Close();
            }
        }
    }
}