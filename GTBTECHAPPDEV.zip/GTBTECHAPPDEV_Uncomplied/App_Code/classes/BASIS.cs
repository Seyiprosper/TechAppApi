using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data.OracleClient;
using System.IO;
using System.Text;
using System.Net.Mail;
using System.Net.Mime;
using APPDEVDLL;
using System.Xml;
using System.Xml.XPath;
using System.Globalization;
using Microsoft.VisualBasic;
using System.Linq;

/// <summary>
/// Summary description for BASIS
/// </summary>
public class BASIS
{
    private String xmlstring = null;
    OracleConnection OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

    public BASIS()
    {
        //
        // TODO: Add constructor logic here
        //
    }



    public DataTable NewGetTaggedTranx(int bra_code, int cusNum, DateTime startDate, DateTime endDate)
    {

        DataTable dt = new DataTable("TransTagService");
        try
        {
                LogHandler log = new LogHandler();
                if (ConfigurationManager.AppSettings["LogSwitch"].Equals("1")) { log.WriteLog("Before Spooling Records for Customer: " + bra_code + "/" + cusNum, "NewGetTaggedTranx_Log"); }

                String StartDate = startDate.ToString("ddMMMyyyy", CultureInfo.CreateSpecificCulture("en-GB"));
                String EndDate = endDate.ToString("ddMMMyyyy", CultureInfo.CreateSpecificCulture("en-GB"));
       
				StartDate = "01NOV2016";
				EndDate = "30NOV2016";

                if (ConfigurationManager.AppSettings["LogSwitch"].Equals("1")) { log.WriteLog("The start date is " + StartDate, "NewGetTaggedTranx_Log"); }
                if (ConfigurationManager.AppSettings["LogSwitch"].Equals("1")) { log.WriteLog("The start date is " + EndDate, "NewGetTaggedTranx_Log"); }
                string queryString;
                using (OracleConnection conn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["LifeStyle"])))
                {
                    // queryString = "select get_name2(" + bra_code + "," + cusNum + "," + cur_code + "," + led_code + "," + sub_acct_code + ") cus_sho_name FROM DUAL";

                    //  queryString = "select mapid,bra_code, cus_num, count(1), sum(tra_amt) tranx_amt from tell_act  where bra_code = '" + bra_code + "' and cus_num = '" + cusNum + "' and tra_date between  '" + StartDate + "' and   '" + EndDate + "' group by mapid,bra_code, cus_num ";

                    //";
                       // queryString = queryString + " ";




                 queryString = "select bra_code, cus_num, tag_description, sum(tra_amt) AMT  from ( SELECT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, tra_amt, key_words, TAG_DESCRIPTION, ROW_NUMBER() OVER(PARTITION BY ORIGT_TRA_SEQ1 ORDER BY key_words) RNK";
                 queryString = queryString +  " fROM (SELECT BRA_CODE,  CUS_NUM,  ORIGT_TRA_SEQ1,  TRA_DATE,  remarks,  expl_code,  tra_amt, 'OTHERS' key_words, 'OTHERS' TAG_DESCRIPTION  FROM (   select /*+INDEX(tag_param,IND_tag_param)*/ ";
                 queryString = queryString +  " DISTINCT BRA_CODE,  CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, tra_amt From tell_act a ";
                 queryString = queryString +  " where tra_date between  '" + StartDate + "' and '" + EndDate  + "'  and deb_cre_ind = 1 and bra_code = '" + bra_code + "'   and cus_num = '" + cusNum + "' AND can_rea_code = 0 ";
                 queryString = queryString +  " and expl_code in (470)  minus (select   /*+INDEX(tag_param,IND_tag_param)*/  DISTINCT BRA_CODE,  CUS_NUM,  ORIGT_TRA_SEQ1, TRA_DATE, remarks,  expl_code, tra_amt  From tell_act a, tag_param b ";
                 queryString = queryString +  " where UPPER(remarks) like '%' || key_words || '%'  and tra_date between '" + StartDate + "' and '" + EndDate  + "' and deb_cre_ind = 1  and expl_code not in  (466, 466, 467, 1, 955, 100) ";                                     
                 queryString = queryString +  " and bra_code =  '" + bra_code + "'  and cus_num =  '" + cusNum + "' AND TAG_TYPE = 1  and expl_code not in (470, 100)  AND can_rea_code = 0 UNION  select /*+INDEX(tag_param,IND_tag_param)*/ DISTINCT BRA_CODE, CUS_NUM, ";
                 queryString = queryString +  " ORIGT_TRA_SEQ1, TRA_DATE, remarks,  expl_code,  tra_amt  From tell_act a, tag_param b   where tra_date  between  '" + StartDate + "' and '" + EndDate  + "' and deb_cre_ind = 1 and expl_code = TO_NUMBER(KEY_WORDS)  ";
                 queryString = queryString +  " and bra_code = '" + bra_code + "'   and cus_num =  '" + cusNum + "'  AND TAG_TYPE = 2  and expl_code not in (470, 100) AND can_rea_code = 0)) ";                
                 queryString = queryString +  " UNION  select /*+INDEX(tag_param,IND_tag_param)*/  DISTINCT BRA_CODE,  CUS_NUM,   ORIGT_TRA_SEQ1,  TRA_DATE, remarks, expl_code,  tra_amt,   key_words, TAG_DESCRIPTION ";
                 queryString = queryString +  " From tell_act a, tag_param b  where UPPER(remarks) like '%' || key_words || '%'  and tra_date between '" + StartDate + "' and '" + EndDate  + "'  ";
                 queryString = queryString +  " and deb_cre_ind = 1  and expl_code not in (466, 466, 467, 1, 955, 100)  and bra_code =  '" + bra_code + "'  and cus_num =  '" + cusNum + "'  AND TAG_TYPE = 1  and expl_code not in (470, 100)  AND can_rea_code = 0 ";
                 queryString = queryString +  " UNION   select  /*+INDEX(tag_param,IND_tag_param)*/   DISTINCT BRA_CODE,   CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE,  remarks, expl_code, tra_amt,  key_words, TAG_DESCRIPTION  From tell_act a, tag_param b ";
                 queryString = queryString +  " where tra_date  between '" + StartDate + "' and '" + EndDate  + "' and deb_cre_ind = 1   and expl_code = TO_NUMBER(KEY_WORDS) and bra_code =  '" + bra_code + "'   and cus_num =  '" + cusNum + "' AND TAG_TYPE = 2  and expl_code not in (470, 100)  AND can_rea_code = 0)) ";
                 queryString = queryString + " where rnk = 1  and (bra_code, cus_num) in  (select bra_code, cus_num from lifestyle_staff) group by bra_code, cus_num, tag_description ";


                 if (ConfigurationManager.AppSettings["LogSwitch"].Equals("1")) { log.WriteLog("The query to be run is " + queryString, "NewGetTaggedTranx_Log"); }

                    //////queryString = "select * from ( SELECT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, key_words, TAG_DESCRIPTION, ROW_NUMBER() OVER(PARTITION BY ORIGT_TRA_SEQ1   ORDER BY  key_words ) RNK";
                    //////queryString = queryString + " fROM ( SELECT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE,  remarks,  expl_code,  'OTHERS' key_words, 'OTHERS' TAG_DESCRIPTION FROM ( select /*+INDEX(tag_param,IND_tag_param)*/ ";
                    //////queryString = queryString + " DISTINCT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code From tell_act a where tra_date between '" + StartDate + "'  and '" + EndDate + "' and deb_cre_ind = 1 ";
                    //////queryString = queryString + " and bra_code = '" + bra_code + "' and cus_num = '" + cusNum + "'  AND can_rea_code = 0  and expl_code in ( 470 ) minus (select /*+INDEX(tag_param,IND_tag_param)*/  DISTINCT BRA_CODE,  CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code ";
                    //////queryString = queryString + " From tell_act a, tag_param b  where UPPER(remarks) like '%' || key_words || '%'  and tra_date between '" + StartDate + "'  and '" + EndDate + "' and deb_cre_ind = 1 and expl_code not in (466, 466, 467, 1, 955 , 100) ";
                    //////queryString = queryString + " and bra_code = '" + bra_code + "' and cus_num = '" + cusNum + "'  AND TAG_TYPE = 1  and expl_code not in ( 470, 100)  AND can_rea_code = 0  UNION ";
                    //////queryString = queryString + " select /*+INDEX(tag_param,IND_tag_param)*/  DISTINCT BRA_CODE,  CUS_NUM,  ORIGT_TRA_SEQ1,  TRA_DATE,  remarks,  expl_code   From tell_act a, tag_param b  ";
                    //////queryString = queryString + " where tra_date between '" + StartDate + "' and '" + EndDate + "'   and deb_cre_ind = 1 and expl_code = TO_NUMBER(KEY_WORDS)  and bra_code =  '" + bra_code + "'   and cus_num = '" + cusNum + "' AND TAG_TYPE = 2  and expl_code not in ( 470, 100) AND can_rea_code = 0)) ";
                    //////queryString = queryString + " UNION ";
                    //////queryString = queryString + " select  /*+INDEX(tag_param,IND_tag_param)*/  DISTINCT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, key_words, TAG_DESCRIPTION From tell_act a, tag_param b ";
                    //////queryString = queryString + " where UPPER(remarks) like '%' || key_words || '%'  and tra_date between '" + StartDate + "' and '" + EndDate + "' and deb_cre_ind = 1 and expl_code not in (466, 466, 467, 1, 955, 100) ";
                    //////queryString = queryString + " and bra_code = '" + bra_code + "'  and cus_num = '" + cusNum + "' AND TAG_TYPE = 1 and expl_code not in ( 470, 100)  AND can_rea_code = 0 ";
                    //////queryString = queryString + " UNION ";
                    //////queryString = queryString + " select  /*+INDEX(tag_param,IND_tag_param)*/ DISTINCT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, key_words, TAG_DESCRIPTION ";
                    //////queryString = queryString + " From tell_act a, tag_param b  where tra_date between '" + StartDate + "' and '" + EndDate + "' and deb_cre_ind = 1  and expl_code = TO_NUMBER(KEY_WORDS) ";
                    //////queryString = queryString + " and bra_code = '" + bra_code + "' and cus_num = '" + cusNum + "' AND TAG_TYPE = 2 ";
                    //////queryString = queryString + " and expl_code not in ( 470, 100) AND can_rea_code = 0 )) where rnk=1 ";

                    ////////////queryString = "select BRA_CODE,CUS_NUM, TAG_DESCRIPTION, SUM(TRA_AMT) AMT  from (SELECT BRA_CODE,CUS_NUM,ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, TRA_AMT,";
                    ////////////queryString = queryString + "key_words, TAG_DESCRIPTION, ROW_NUMBER()OVER(PARTITION BY ORIGT_TRA_SEQ1   ORDER BY  key_words ) RNK fROM ( SELECT BRA_CODE,";
                    ////////////queryString = queryString + " CUS_NUM, ORIGT_TRA_SEQ1,  TRA_DATE, remarks, expl_code, TRA_AMT,'OTHERS' key_words, 'OTHERS' TAG_DESCRIPTION ";
                    ////////////queryString = queryString + " FROM ( select /*+INDEX(tag_param,IND_tag_param)*/  DISTINCT BRA_CODE,  CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, ";
                    ////////////queryString = queryString + " remarks, expl_code, TRA_AMT  From tell_act a  where tra_date between   '01OCT2016'  and '31OCT2016' ";
                    ////////////queryString = queryString + " and deb_cre_ind = 1   and bra_code = '" + bra_code + "'  and cus_num =  '" + cusNum + "' AND can_rea_code = 0    and expl_code in ( 470 ) ";
                    ////////////queryString = queryString + " minus (select /*+INDEX(tag_param,IND_tag_param)*/   DISTINCT BRA_CODE,  CUS_NUM,  ORIGT_TRA_SEQ1,  TRA_DATE,  remarks, ";
                    ////////////queryString = queryString + "  expl_code, TRA_AMT    From tell_act a, tag_param b   where UPPER(remarks) like '%' || key_words || '%' ";
                    ////////////queryString = queryString + " and tra_date between   '01OCT2016'  and '31OCT2016' and deb_cre_ind = 1  and expl_code not in (466, 466, 467, 1, 955 , 100) ";
                    ////////////queryString = queryString + " and bra_code =  '" + bra_code + "' and cus_num =  '" + cusNum + "' AND TAG_TYPE = 1 and expl_code not in ( 470, 100) AND can_rea_code = 0 ";
                    ////////////queryString = queryString + " UNION select /*+INDEX(tag_param,IND_tag_param)*/ DISTINCT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, ";
                    ////////////queryString = queryString + "expl_code, TRA_AMT From tell_act a, tag_param b  where tra_date  between   '01OCT2016'  and '31OCT2016'  and deb_cre_ind = 1 and expl_code = TO_NUMBER(KEY_WORDS) ";
                    ////////////queryString = queryString + " and bra_code = '" + bra_code + "'  and cus_num = '" + cusNum + "'  AND TAG_TYPE = 2 and expl_code not in ( 470, 100) AND can_rea_code = 0)) ";
                    ////////////queryString = queryString + " UNION select /*+INDEX(tag_param,IND_tag_param)*/ DISTINCT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, TRA_AMT, key_words, TAG_DESCRIPTION";
                    ////////////queryString = queryString + " From tell_act a, tag_param b where UPPER(remarks) like '%' || key_words || '%' ";
                    ////////////queryString = queryString + "  and tra_date  between   '01OCT2016'  and '31OCT2016' and deb_cre_ind = 1 and expl_code not in (466, 466, 467, 1, 955, 100)";
                    ////////////queryString = queryString + "  and bra_code =  '" + bra_code + "'  and cus_num = '" + cusNum + "'  AND TAG_TYPE = 1 and expl_code not in ( 470, 100) AND can_rea_code = 0";
                    ////////////queryString = queryString + "  UNION select /*+INDEX(tag_param,IND_tag_param)*/ DISTINCT BRA_CODE, CUS_NUM,  ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, TRA_AMT, key_words, TAG_DESCRIPTION";
                    ////////////queryString = queryString + " From tell_act a, tag_param b where tra_date  between   '01OCT2016'  and '31OCT2016'  ";
                    ////////////queryString = queryString + "  and deb_cre_ind = 1 and expl_code = TO_NUMBER(KEY_WORDS) and bra_code = '" + bra_code + "'  ";
                    ////////////queryString = queryString + "     and cus_num = '" + cusNum + "' ";
                    ////////////queryString = queryString + " AND TAG_TYPE = 2";
                    ////////////queryString = queryString + " and expl_code not in ( 470, 100) ";
                    ////////////queryString = queryString + " AND can_rea_code = 0  ) ) where rnk=1 GROUP BY BRA_CODE,CUS_NUM, TAG_DESCRIPTION ";


                    ////queryString = "select * from ( SELECT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, key_words, TAG_DESCRIPTION, ROW_NUMBER() OVER(PARTITION BY ORIGT_TRA_SEQ1   ORDER BY  key_words ) RNK";
                    ////queryString = queryString + " fROM ( SELECT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE,  remarks,  expl_code,  'OTHERS' key_words, 'OTHERS' TAG_DESCRIPTION FROM ( select /*+INDEX(tag_param,IND_tag_param)*/ ";
                    ////queryString = queryString + " DISTINCT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code From tell_act a where tra_date between '" + StartDate + "'  and '" + EndDate + "' and deb_cre_ind = 1 ";
                    ////queryString = queryString + " and bra_code = '" + bra_code + "' and cus_num = '" + cusNum + "'  AND can_rea_code = 0  and expl_code in ( 470 ) minus (select /*+INDEX(tag_param,IND_tag_param)*/  DISTINCT BRA_CODE,  CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code ";
                    ////queryString = queryString + " From tell_act a, tag_param b  where UPPER(remarks) like '%' || key_words || '%'  and tra_date between '" + StartDate + "'  and '" + EndDate + "' and deb_cre_ind = 1 and expl_code not in (466, 466, 467, 1, 955 , 100) ";
                    ////queryString = queryString + " and bra_code = '" + bra_code + "' and cus_num = '" + cusNum + "'  AND TAG_TYPE = 1  and expl_code not in ( 470, 100)  AND can_rea_code = 0  UNION ";
                    ////queryString = queryString + " select /*+INDEX(tag_param,IND_tag_param)*/  DISTINCT BRA_CODE,  CUS_NUM,  ORIGT_TRA_SEQ1,  TRA_DATE,  remarks,  expl_code   From tell_act a, tag_param b  ";
                    ////queryString = queryString + " where tra_date between '" + StartDate + "' and '" + EndDate + "'   and deb_cre_ind = 1 and expl_code = TO_NUMBER(KEY_WORDS)  and bra_code =  '" + bra_code + "'   and cus_num = '" + cusNum + "' AND TAG_TYPE = 2  and expl_code not in ( 470, 100) AND can_rea_code = 0)) ";
                    ////queryString = queryString + " UNION ";
                    ////queryString = queryString + " select  /*+INDEX(tag_param,IND_tag_param)*/  DISTINCT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, key_words, TAG_DESCRIPTION From tell_act a, tag_param b ";
                    ////queryString = queryString + " where UPPER(remarks) like '%' || key_words || '%'  and tra_date between '" + StartDate + "' and '" + EndDate + "' and deb_cre_ind = 1 and expl_code not in (466, 466, 467, 1, 955, 100) ";
                    ////queryString = queryString + " and bra_code = '" + bra_code + "'  and cus_num = '" + cusNum + "' AND TAG_TYPE = 1 and expl_code not in ( 470, 100)  AND can_rea_code = 0 ";
                    ////queryString = queryString + " UNION ";
                    ////queryString = queryString + " select  /*+INDEX(tag_param,IND_tag_param)*/ DISTINCT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, key_words, TAG_DESCRIPTION ";
                    ////queryString = queryString + " From tell_act a, tag_param b  where tra_date between '" + StartDate + "' and '" + EndDate + "' and deb_cre_ind = 1  and expl_code = TO_NUMBER(KEY_WORDS) ";
                    ////queryString = queryString + " and bra_code = '" + bra_code + "' and cus_num = '" + cusNum + "' AND TAG_TYPE = 2 ";
                    ////queryString = queryString + " and expl_code not in ( 470, 100) AND can_rea_code = 0 )) where rnk=1 ";

                    //queryString = "select BRA_CODE,CUS_NUM, TAG_DESCRIPTION, SUM(TRA_AMT) AMT  from (SELECT BRA_CODE,CUS_NUM,ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, TRA_AMT,";
                    //queryString = queryString + "key_words, TAG_DESCRIPTION, ROW_NUMBER()OVER(PARTITION BY ORIGT_TRA_SEQ1   ORDER BY  key_words ) RNK fROM ( SELECT BRA_CODE,";
                    //queryString = queryString + " CUS_NUM, ORIGT_TRA_SEQ1,  TRA_DATE, remarks, expl_code, TRA_AMT,'OTHERS' key_words, 'OTHERS' TAG_DESCRIPTION ";
                    //queryString = queryString + " FROM ( select /*+INDEX(tag_param,IND_tag_param)*/  DISTINCT BRA_CODE,  CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, ";
                    //queryString = queryString + " remarks, expl_code, TRA_AMT  From tell_act a  where tra_date between  '" + StartDate + "' and '" + EndDate + "' ";
                    //queryString = queryString + " and deb_cre_ind = 1   and bra_code = '" + bra_code + "'  and cus_num =  '" + cusNum + "' AND can_rea_code = 0    and expl_code in ( 470 ) ";
                    //queryString = queryString + " minus (select /*+INDEX(tag_param,IND_tag_param)*/   DISTINCT BRA_CODE,  CUS_NUM,  ORIGT_TRA_SEQ1,  TRA_DATE,  remarks, ";
                    //queryString = queryString + "  expl_code, TRA_AMT    From tell_act a, tag_param b   where UPPER(remarks) like '%' || key_words || '%' ";
                    //queryString = queryString + " and tra_date between   '" + StartDate + "' and '" + EndDate + "' and deb_cre_ind = 1  and expl_code not in (466, 466, 467, 1, 955 , 100) ";
                    //queryString = queryString + " and bra_code =  '" + bra_code + "' and cus_num =  '" + cusNum + "' AND TAG_TYPE = 1 and expl_code not in ( 470, 100) AND can_rea_code = 0 ";
                    //queryString = queryString + " UNION select /*+INDEX(tag_param,IND_tag_param)*/ DISTINCT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, ";
                    //queryString = queryString + "expl_code, TRA_AMT From tell_act a, tag_param b  where tra_date  between  '" + StartDate + "' and '" + EndDate + "'  and deb_cre_ind = 1 and expl_code = TO_NUMBER(KEY_WORDS) ";
                    //queryString = queryString + " and bra_code = '" + bra_code + "'  and cus_num = '" + cusNum + "'  AND TAG_TYPE = 2 and expl_code not in ( 470, 100) AND can_rea_code = 0)) ";
                    //queryString = queryString + " UNION select /*+INDEX(tag_param,IND_tag_param)*/ DISTINCT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, TRA_AMT, key_words, TAG_DESCRIPTION";
                    //queryString = queryString + " From tell_act a, tag_param b where UPPER(remarks) like '%' || key_words || '%' ";
                    //queryString = queryString + "  and tra_date  between  '" + StartDate + "' and '" + EndDate + "' and deb_cre_ind = 1 and expl_code not in (466, 466, 467, 1, 955, 100)";
                    //queryString = queryString + "  and bra_code =  '" + bra_code + "'  and cus_num = '" + cusNum + "'  AND TAG_TYPE = 1 and expl_code not in ( 470, 100) AND can_rea_code = 0";
                    //queryString = queryString + "  UNION select /*+INDEX(tag_param,IND_tag_param)*/ DISTINCT BRA_CODE, CUS_NUM,  ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, TRA_AMT, key_words, TAG_DESCRIPTION";
                    //queryString = queryString + " From tell_act a, tag_param b where tra_date  between  '" + StartDate + "' and '" + EndDate + "'  ";
                    //queryString = queryString + "  and deb_cre_ind = 1 and expl_code = TO_NUMBER(KEY_WORDS) and bra_code = '" + bra_code + "'  ";
                    //queryString = queryString + "     and cus_num = '" + cusNum + "' ";
                    //queryString = queryString + " AND TAG_TYPE = 2";
                    //queryString = queryString + " and expl_code not in ( 470, 100) ";
                    //queryString = queryString + " AND can_rea_code = 0  ) ) where rnk=1 GROUP BY BRA_CODE,CUS_NUM, TAG_DESCRIPTION ";

                    OracleDataAdapter adapter = new OracleDataAdapter(queryString, conn);
                    try
                    {
                        if (conn.State != ConnectionState.Open)
                        {
                            conn.Open();
                        }
                        adapter.Fill(dt);
                    }
                    catch (Exception ex)
                    {
                        ErrHandler.WriteError(ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }

                    if (ConfigurationManager.AppSettings["LogSwitch"].Equals("1")) { log.WriteLog("After Spooling Records for Customer: " + bra_code + "/" + cusNum, "NewGetTaggedTranx_Log"); }
                    if (ConfigurationManager.AppSettings["LogSwitch"].Equals("1")) { log.WriteLog("Total Records found for Customer: " + bra_code + "/" + cusNum + " is: " + dt.Rows.Count, "NewGetTaggedTranx_Log");  }
                }
        }
        catch (Exception)
        {
            
            throw;
        }
        return dt;
    }



    ////public DataTable NewGetTaggedTranx(int bra_code, int cusNum, DateTime startDate, DateTime endDate)
    ////{

    ////    String StartDate = startDate.ToString("ddMMMyyyy", CultureInfo.CreateSpecificCulture("en-GB"));
    ////    String EndDate = endDate.ToString("ddMMMyyyy", CultureInfo.CreateSpecificCulture("en-GB"));
    ////    DataTable dt = new DataTable("TransTagService");
    ////    string queryString;
    ////    using (OracleConnection conn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["LifeStyle"])))
    ////    {
    ////        // queryString = "select get_name2(" + bra_code + "," + cusNum + "," + cur_code + "," + led_code + "," + sub_acct_code + ") cus_sho_name FROM DUAL";

    ////        //  queryString = "select mapid,bra_code, cus_num, count(1), sum(tra_amt) tranx_amt from tell_act  where bra_code = '" + bra_code + "' and cus_num = '" + cusNum + "' and tra_date between  '" + StartDate + "' and   '" + EndDate + "' group by mapid,bra_code, cus_num ";


    ////        queryString = "select BRA_CODE,CUS_NUM, TAG_DESCRIPTION, SUM(TRA_AMT) AMT  from (SELECT BRA_CODE,CUS_NUM,ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, TRA_AMT,";
    ////        queryString = queryString + "key_words, TAG_DESCRIPTION, ROW_NUMBER()OVER(PARTITION BY ORIGT_TRA_SEQ1   ORDER BY  key_words ) RNK fROM ( SELECT BRA_CODE,";
    ////        queryString = queryString + " CUS_NUM, ORIGT_TRA_SEQ1,  TRA_DATE, remarks, expl_code, TRA_AMT,'OTHERS' key_words, 'OTHERS' TAG_DESCRIPTION ";
    ////        queryString = queryString + " FROM ( select /*+INDEX(tag_param,IND_tag_param)*/  DISTINCT BRA_CODE,  CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, ";
    ////        queryString = queryString + " remarks, expl_code, TRA_AMT  From tell_act a  where tra_date between   '01OCT2016'  and '31OCT2016' ";
    ////        queryString = queryString + " and deb_cre_ind = 1   and bra_code = '" + bra_code + "'  and cus_num =  '" + cusNum + "' AND can_rea_code = 0    and expl_code in ( 470 ) ";
    ////        queryString = queryString + " minus (select /*+INDEX(tag_param,IND_tag_param)*/   DISTINCT BRA_CODE,  CUS_NUM,  ORIGT_TRA_SEQ1,  TRA_DATE,  remarks, ";
    ////        queryString = queryString + "  expl_code, TRA_AMT    From tell_act a, tag_param b   where UPPER(remarks) like '%' || key_words || '%' ";
    ////        queryString = queryString + " and tra_date between   '01OCT2016'  and '31OCT2016' and deb_cre_ind = 1  and expl_code not in (466, 466, 467, 1, 955 , 100) ";
    ////        queryString = queryString + " and bra_code =  '" + bra_code + "' and cus_num =  '" + cusNum + "' AND TAG_TYPE = 1 and expl_code not in ( 470, 100) AND can_rea_code = 0 ";
    ////        queryString = queryString + " UNION select /*+INDEX(tag_param,IND_tag_param)*/ DISTINCT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, ";
    ////        queryString = queryString + "expl_code, TRA_AMT From tell_act a, tag_param b  where tra_date  between   '01OCT2016'  and '31OCT2016'  and deb_cre_ind = 1 and expl_code = TO_NUMBER(KEY_WORDS) ";
    ////        queryString = queryString + " and bra_code = '" + bra_code + "'  and cus_num = '" + cusNum + "'  AND TAG_TYPE = 2 and expl_code not in ( 470, 100) AND can_rea_code = 0)) ";
    ////        queryString = queryString + " UNION select /*+INDEX(tag_param,IND_tag_param)*/ DISTINCT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, TRA_AMT, key_words, TAG_DESCRIPTION";
    ////        queryString = queryString + " From tell_act a, tag_param b where UPPER(remarks) like '%' || key_words || '%' ";
    ////        queryString = queryString + "  and tra_date  between   '01OCT2016'  and '31OCT2016' and deb_cre_ind = 1 and expl_code not in (466, 466, 467, 1, 955, 100)";
    ////        queryString = queryString + "  and bra_code =  '" + bra_code + "'  and cus_num = '" + cusNum + "'  AND TAG_TYPE = 1 and expl_code not in ( 470, 100) AND can_rea_code = 0";
    ////        queryString = queryString + "  UNION select /*+INDEX(tag_param,IND_tag_param)*/ DISTINCT BRA_CODE, CUS_NUM,  ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, TRA_AMT, key_words, TAG_DESCRIPTION";
    ////        queryString = queryString + " From tell_act a, tag_param b where tra_date  between   '01OCT2016'  and '31OCT2016'  ";
    ////        queryString = queryString + "  and deb_cre_ind = 1 and expl_code = TO_NUMBER(KEY_WORDS) and bra_code = '" + bra_code + "'  ";
    ////        queryString = queryString + "     and cus_num = '" + cusNum + "' ";
    ////        queryString = queryString + " AND TAG_TYPE = 2";
    ////        queryString = queryString + " and expl_code not in ( 470, 100) ";
    ////        queryString = queryString + " AND can_rea_code = 0  ) ) where rnk=1 GROUP BY BRA_CODE,CUS_NUM, TAG_DESCRIPTION ";


    ////        //queryString = "select BRA_CODE,CUS_NUM, TAG_DESCRIPTION, SUM(TRA_AMT) AMT  from (SELECT BRA_CODE,CUS_NUM,ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, TRA_AMT," ;
    ////        //queryString = queryString + "key_words, TAG_DESCRIPTION, ROW_NUMBER()OVER(PARTITION BY ORIGT_TRA_SEQ1   ORDER BY  key_words ) RNK fROM ( SELECT BRA_CODE," ;
    ////        //queryString = queryString + " CUS_NUM, ORIGT_TRA_SEQ1,  TRA_DATE, remarks, expl_code, TRA_AMT,'OTHERS' key_words, 'OTHERS' TAG_DESCRIPTION ";
    ////        //queryString = queryString + " FROM ( select /*+INDEX(tag_param,IND_tag_param)*/  DISTINCT BRA_CODE,  CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, ";
    ////        //queryString = queryString + " remarks, expl_code, TRA_AMT  From tell_act a  where tra_date between  '" + StartDate + "' and '" + EndDate + "' ";
    ////        //queryString = queryString + " and deb_cre_ind = 1   and bra_code = '" + bra_code + "'  and cus_num =  '" + cusNum + "' AND can_rea_code = 0    and expl_code in ( 470 ) ";
    ////        //queryString = queryString + " minus (select /*+INDEX(tag_param,IND_tag_param)*/   DISTINCT BRA_CODE,  CUS_NUM,  ORIGT_TRA_SEQ1,  TRA_DATE,  remarks, ";
    ////        //queryString = queryString + "  expl_code, TRA_AMT    From tell_act a, tag_param b   where UPPER(remarks) like '%' || key_words || '%' ";
    ////        //queryString = queryString + " and tra_date between   '" + StartDate + "' and '" + EndDate + "' and deb_cre_ind = 1  and expl_code not in (466, 466, 467, 1, 955 , 100) ";
    ////        //queryString = queryString + " and bra_code =  '" + bra_code + "' and cus_num =  '" + cusNum + "' AND TAG_TYPE = 1 and expl_code not in ( 470, 100) AND can_rea_code = 0 ";
    ////        //queryString = queryString + " UNION select /*+INDEX(tag_param,IND_tag_param)*/ DISTINCT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, ";
    ////        //queryString = queryString + "expl_code, TRA_AMT From tell_act a, tag_param b  where tra_date  between  '" + StartDate + "' and '" + EndDate + "'  and deb_cre_ind = 1 and expl_code = TO_NUMBER(KEY_WORDS) ";
    ////        //queryString = queryString + " and bra_code = '" + bra_code + "'  and cus_num = '" + cusNum + "'  AND TAG_TYPE = 2 and expl_code not in ( 470, 100) AND can_rea_code = 0)) ";
    ////        //queryString = queryString + " UNION select /*+INDEX(tag_param,IND_tag_param)*/ DISTINCT BRA_CODE, CUS_NUM, ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, TRA_AMT, key_words, TAG_DESCRIPTION";
    ////        //queryString = queryString + " From tell_act a, tag_param b where UPPER(remarks) like '%' || key_words || '%' ";
    ////        //queryString = queryString + "  and tra_date  between  '" + StartDate + "' and '" + EndDate + "' and deb_cre_ind = 1 and expl_code not in (466, 466, 467, 1, 955, 100)";
    ////        //queryString = queryString + "  and bra_code =  '" + bra_code + "'  and cus_num = '" + cusNum + "'  AND TAG_TYPE = 1 and expl_code not in ( 470, 100) AND can_rea_code = 0";
    ////        //queryString = queryString + "  UNION select /*+INDEX(tag_param,IND_tag_param)*/ DISTINCT BRA_CODE, CUS_NUM,  ORIGT_TRA_SEQ1, TRA_DATE, remarks, expl_code, TRA_AMT, key_words, TAG_DESCRIPTION";
    ////        //queryString = queryString + " From tell_act a, tag_param b where tra_date  between  '" + StartDate + "' and '" + EndDate + "'  ";
    ////        //queryString = queryString + "  and deb_cre_ind = 1 and expl_code = TO_NUMBER(KEY_WORDS) and bra_code = '" + bra_code + "'  ";
    ////        //queryString = queryString + "     and cus_num = '" + cusNum + "' ";
    ////        //queryString = queryString + " AND TAG_TYPE = 2";
    ////        //queryString = queryString + " and expl_code not in ( 470, 100) ";
    ////        //queryString = queryString + " AND can_rea_code = 0  ) ) where rnk=1 GROUP BY BRA_CODE,CUS_NUM, TAG_DESCRIPTION ";

    ////        OracleDataAdapter adapter = new OracleDataAdapter(queryString, conn);
    ////        try
    ////        {
    ////            if (conn.State != ConnectionState.Open)
    ////            {
    ////                conn.Open();
    ////            }
    ////            adapter.Fill(dt);
    ////        }
    ////        catch (Exception ex)
    ////        {
    ////            ErrHandler.WriteError(ex.Message);
    ////        }
    ////        finally
    ////        {
    ////            conn.Close();
    ////        }
    ////    }
    ////    return dt;
    ////}
    public string AddTeller(int BASISID, String Username, String password, int branch_code, String roleid, String UpdateFlag)
    {
        string Result = string.Empty;
        xmlstring = "<Response>";
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("EBIZ_PACKAGE.GTB_TELLERS", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("inp_bra_code", OracleType.Number, 15).Value = branch_code;
            oracomm.Parameters.Add("inp_tell_id", OracleType.Number, 15).Value = BASISID;
            oracomm.Parameters.Add("inprole", OracleType.VarChar, 30).Value = roleid.Trim();

            oracomm.Parameters.Add("inp_ho_code", OracleType.Number, 15).Value = 999;
            oracomm.Parameters.Add("inphorole", OracleType.VarChar, 30).Value = roleid.Trim();

            oracomm.Parameters.Add("inp_OPER_type", OracleType.Number, 15).Value = UpdateFlag.Trim();
            oracomm.Parameters.Add("inp_CUS_SHO_NAME", OracleType.VarChar, 100).Value = Username.Trim();
            oracomm.Parameters.Add("inp_PASSWORD", OracleType.VarChar, 100).Value = password;
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.Number, 15).Direction = ParameterDirection.Output;

            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
            oraconn.Close();

            if (Result.CompareTo("0") == 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "</Response>";
            }
            else
            {
                //Get BASIS Error Description
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + GetBASISError(Convert.ToInt32(Result.Trim())) + "</Error>";
                xmlstring = xmlstring + "</Response>";
            }
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        oracomm = null;
        oraconn = null;

        return xmlstring;
    }

    public string KillMyID(int bracode, int tellerid)
    {
        string Result = string.Empty;
        xmlstring = "<Response>";
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("EONEPKG.GTBKILLID", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("INP_BRA_CODE", OracleType.Number, 15).Value = Convert.ToInt32(bracode);
            oracomm.Parameters.Add("INP_TELLER_ID", OracleType.VarChar, 15).Value = Convert.ToInt32(tellerid);

            oracomm.Parameters.Add("RETURN_STATUS", OracleType.Number, 15).Direction = ParameterDirection.Output;

            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
            oraconn.Close();

            if (Result.CompareTo("0") == 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "</Response>";
            }
            //If Teller is not Logged on
            if (Result.CompareTo("-1") == -1)
            {
                //Get BASIS Error Description
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<Error>" + "Teller Not Logged On" + "</Error>";
                xmlstring = xmlstring + "</Response>";
            }
            // Any other BASIS error
            else
            {
                //Get BASIS Error Description
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + GetBASISError(Convert.ToInt32(Result.Trim())) + "</Error>";
                xmlstring = xmlstring + "</Response>";
            }
        }
        // Any dotnet error
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        oracomm = null;
        oraconn = null;

        return xmlstring;
    }

    public string KillMyID2(String username)
    {
        string Result = "1";
        String returnstr = "FAILED";
        Eone eone = new Eone();

        //Get Branch Code and BASIS IS from Eone
        DataTable dt1 = eone.GetAdminUserDetails2(username);

        if (dt1.Rows.Count > 0)
        {

            OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
            OracleCommand oracomm = new OracleCommand("EONEPKG.GTBKILLID", oraconn);
            oracomm.CommandType = CommandType.StoredProcedure;
            try
            {
                if (oraconn.State == ConnectionState.Closed)
                {
                    oraconn.Open();
                }
                oracomm.Parameters.Add("INP_BRA_CODE", OracleType.Number, 15).Value = Convert.ToInt32(dt1.Rows[0]["branch_code"]);
                oracomm.Parameters.Add("INP_TELLER_ID", OracleType.VarChar, 15).Value = Convert.ToInt32(dt1.Rows[0]["basis_id"]);

                oracomm.Parameters.Add("RETURN_STATUS", OracleType.Number, 15).Direction = ParameterDirection.InputOutput;

                oracomm.ExecuteNonQuery();
                Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
                oraconn.Close();

                if (Result == "0")
                {
                    returnstr = "SUCCESS";
                }
                //If Teller is not Logged on
                else if (Result == "-1")
                {
                    //Get BASIS Error Description

                    returnstr = "Teller Not Logged On";

                }
                // Any other BASIS error
                else
                {
                    //Get BASIS Error Description

                    returnstr = GetBASISError(Convert.ToInt32(Result.Trim()));

                }
            }
            // Any dotnet error
            catch (Exception ex)
            {

                returnstr = ex.Message.Replace("'", "");

            }

            oracomm = null;
            oraconn = null;
        }
        else
        {

            returnstr = "Could not retrieve user information";

        }

        return returnstr;
    }

    public string KillMyID3(String username, String bracode)
    {
        string Result = "1";
        String returnstr = "FAILED";
        Eone eone = new Eone();
        //Get Branch Code and BASIS IS from Eone
        DataTable dt1 = eone.GetAdminUserDetails2(username);

        if (dt1.Rows.Count > 0)
        {

            OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
            OracleCommand oracomm = new OracleCommand("EONEPKG.GTBKILLID", oraconn);
            oracomm.CommandType = CommandType.StoredProcedure;
            try
            {
                if (oraconn.State == ConnectionState.Closed)
                {
                    oraconn.Open();
                }
                //oracomm.Parameters.Add("INP_BRA_CODE", OracleType.Number, 15).Value = Convert.ToInt32(dt1.Rows[0]["branch_code"]);
                oracomm.Parameters.Add("INP_BRA_CODE", OracleType.Number, 15).Value = Convert.ToInt32(bracode);
                oracomm.Parameters.Add("INP_TELLER_ID", OracleType.VarChar, 15).Value = Convert.ToInt32(dt1.Rows[0]["basis_id"]);

                oracomm.Parameters.Add("RETURN_STATUS", OracleType.Number, 15).Direction = ParameterDirection.InputOutput;

                oracomm.ExecuteNonQuery();
                Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
                oraconn.Close();

                if (Result == "0")
                {
                    returnstr = "SUCCESS";
                }
                //If Teller is not Logged on
                else if (Result == "-1")
                {
                    //Get BASIS Error Description

                    returnstr = "Teller Not Logged On";

                }
                // Any other BASIS error
                else
                {
                    //Get BASIS Error Description

                    returnstr = GetBASISError(Convert.ToInt32(Result.Trim()));

                }
            }
            // Any dotnet error
            catch (Exception ex)
            {

                returnstr = ex.Message.Replace("'", "");

            }

            oracomm = null;
            oraconn = null;
        }
        else
        {

            returnstr = "Could not retrieve user information";

        }

        return returnstr;
    }

    public string GetAllBasisRoles()
    {
        string Result = string.Empty;
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        DataTable dt;

        String query_str = null;

        try
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
            
            // create the command for the function
            query_str = "select role_num as role_id, des_eng as role_desc from role_inf";

            oraconn.Open();
            cmd = new OracleCommand(query_str, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            dt = new DataTable();

            ora_adpt.Fill(dt);

            xmlstring = "<Response>";

            if (dt.Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<ROLES>";
                foreach (DataRow dr in dt.Rows)
                {
                    //GET ROLE
                    xmlstring = xmlstring + "<ROLE>";
                    xmlstring = xmlstring + "<ROLE_ID>" + dr["role_id"] + "</ROLE_ID>";
                    xmlstring = xmlstring + "<ROLE_NAME>" + dr["role_desc"].ToString().Replace("&","&amp;") + "</ROLE_NAME>";
                    xmlstring = xmlstring + "</ROLE>";
                }
                xmlstring = xmlstring + "</ROLES>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "NO ROLES" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";

            dt = null;
            ora_adpt = null;
            cmd = null;
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;        
    }

    public CustDetRetVal GetBasisCustomerDetails(int bra_code, int cus_num)
    {
        string Result = string.Empty;
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        DataTable dt;
        CustDetRetVal custretval = null;
        int i=0;
        
        String query_str = null;

        try
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

            // create the command for the function
            query_str = "select a.bra_code, b.des_eng, a.cus_num, a.cus_sho_name, a.aut_amt, to_char(a.del_date,'DDMMYYYY') del_date, to_char(a.eff_date,'DDMMYYYY') eff_date, a.signature from acct_sig a, branch b where a.bra_code=b.bra_code and a.bra_code=" + bra_code.ToString() + " and cus_num=" + cus_num.ToString();

            oraconn.Open();
            cmd = new OracleCommand(query_str, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            dt = new DataTable();

            ora_adpt.Fill(dt);

            xmlstring = "<Response>";

            if (dt.Rows.Count > 0)
            {
                custretval = new CustDetRetVal();
                custretval.picture = new object[dt.Rows.Count];
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<CUSTOMERS>";
                foreach (DataRow dr in dt.Rows)
                {
                    //GET ROLE
                    xmlstring = xmlstring + "<CUSTOMER>";
                    xmlstring = xmlstring + "<BRANCH_CODE>" + dr["bra_code"] + "</BRANCH_CODE>";
                    xmlstring = xmlstring + "<BRANCH_NAME>" + dr["des_eng"] + "</BRANCH_NAME>";
                    xmlstring = xmlstring + "<SIGNATORY_NAME>" + dr["cus_sho_name"] + "</SIGNATORY_NAME>";
                    xmlstring = xmlstring + "<AUTHORITY_AMOUNT>" + dr["aut_amt"] + "</AUTHORITY_AMOUNT>";
                    xmlstring = xmlstring + "<DELETION_DATE>" + dr["del_date"] + "</DELETION_DATE>";
                    xmlstring = xmlstring + "<EFFECTIVE_DATE>" + dr["eff_date"] + "</EFFECTIVE_DATE>";
                    
                    custretval.picture[i] = dr["signature"];
                    //xmlstring = xmlstring + "<IMAGE>" + Encoding.ASCII.GetString( + "</IMAGE>";
                    xmlstring = xmlstring + "</CUSTOMER>";
                    i = i + 1;
                }
                xmlstring = xmlstring + "</CUSTOMERS>";
                xmlstring = xmlstring + "</Response>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "NO RECORDS" + "</Error>";
                xmlstring = xmlstring + "</Response>";
            }
            

            dt = null;
            ora_adpt = null;
            cmd = null;

            query_str = "select a.bra_code||'/'||a.cus_num||'/'||cur_code||'/'||led_code||'/'||sub_acct_code acct_key from account a where a.bra_code=" + bra_code.ToString() + " and cus_num=" + cus_num.ToString() + " and led_code in (1,2,3,59,82,65)";

            cmd = new OracleCommand(query_str, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            dt = new DataTable();

            ora_adpt.Fill(dt);
            i = 0;
            if (dt.Rows.Count > 0)
            {
                custretval.Accounts = new String[dt.Rows.Count];
                
                foreach (DataRow dr in dt.Rows)
                {
                    //GET ACCOUNT
                    custretval.Accounts[i] = Convert.ToString(dr["acct_key"]);

                    i = i + 1;
                }
            }

            oraconn.Close();
        }
        catch (Exception ex)
        {
            custretval.Accounts = null;
        }

        custretval.custdet = xmlstring;
        return custretval;
    }

    public String GetBasisCustomerDetails_NoSig(int bra_code, int cus_num)
    {
        string Result = string.Empty;
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        DataTable dt;

        String query_str = null;

        try
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

            // create the command for the function
            query_str = "select a.bra_code, a.cus_num, a.cur_code, a.led_code, a.sub_acct_code, a.cus_sho_name, a.mob_num, a.email, a.add_line1, a.add_line2 from address a where a.bra_code=" + bra_code.ToString() + " and cus_num=" + cus_num.ToString();

            oraconn.Open();
            cmd = new OracleCommand(query_str, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            dt = new DataTable();

            ora_adpt.Fill(dt);

            xmlstring = "<Response>";

            if (dt.Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<CUSTOMER_DETAILS>";
                foreach (DataRow dr in dt.Rows)
                {
                    //GET Details
                    xmlstring = xmlstring + "<CUSTOMER>";
                    xmlstring = xmlstring + "<BRANCH>" + dr["bra_code"] + "</BRANCH>";
                    xmlstring = xmlstring + "<CUS_NUM>" + dr["cus_num"] + "</CUS_NUM>";
                    xmlstring = xmlstring + "<CUR_CODE>" + dr["cur_code"] + "</CUR_CODE>";
                    xmlstring = xmlstring + "<LED_CODE>" + dr["led_code"] + "</LED_CODE>";
                    xmlstring = xmlstring + "<SUB_ACCT_CODE>" + dr["sub_acct_code"] + "</SUB_ACCT_CODE>";
                    xmlstring = xmlstring + "<NAME>" + dr["cus_sho_name"] + "</NAME>";
                    xmlstring = xmlstring + "<MOBILE_NUM>" + dr["mob_num"] + "</MOBILE_NUM>";
                    xmlstring = xmlstring + "<EMAIL>" + dr["email"] + "</EMAIL>";
                    xmlstring = xmlstring + "<ADDRESS>" + dr["add_line1"].ToString() + " " + dr["add_line2"].ToString() + "</ADDRESS>";
                    xmlstring = xmlstring + "</CUSTOMER>";
                }
                xmlstring = xmlstring + "</CUSTOMER_DETAILS>";

                dt = null;
                ora_adpt = null;
                cmd = null;

                query_str = "select a.bra_code||'/'||a.cus_num||'/'||cur_code||'/'||led_code||'/'||sub_acct_code acct_key from account a where a.bra_code=" + bra_code.ToString() + " and cus_num=" + cus_num.ToString() + " and led_code in (1,2,3,59,82,65)";

                cmd = new OracleCommand(query_str, oraconn);
                ora_adpt = new OracleDataAdapter(cmd);
                dt = new DataTable();

                ora_adpt.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    xmlstring = xmlstring + "<ACCOUNTS>";
                    foreach (DataRow dr in dt.Rows)
                    {
                        //GET ACCOUNTS
                        xmlstring = xmlstring + "<ACCOUNT>";
                        xmlstring = xmlstring + Convert.ToString(dr["acct_key"]);
                        xmlstring = xmlstring + "</ACCOUNT>";
                    }
                    xmlstring = xmlstring + "</ACCOUNTS>";
                }

                oraconn.Close();

                xmlstring = xmlstring + "</Response>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "NO RECORDS" + "</Error>";
                xmlstring = xmlstring + "</Response>";
            }

        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public string AddBasisRole(String role_desc)
    {
        string Result = string.Empty;
        xmlstring = "<Response>";
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("GTB_ADDROLE", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("INP_ROLE_NAME", OracleType.VarChar, 50).Value = role_desc;
            //oracomm.Parameters.Add("INP_ACCT_TO", OracleType.VarChar, 21).Value = "";
            //oracomm.Parameters.Add("INP_TRA_AMT", OracleType.Number, 15).Value = 0;
            //oracomm.Parameters.Add("INP_EXPL_CODE", OracleType.Number, 15).Value = 0;
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.Number, 15).Direction = ParameterDirection.Output;

            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
            //oraconn.Close();

            if (Result.CompareTo("0") == 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "</Response>";
            }
            else if (Result == "")
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>EMPTY STRING RETURNED</Error>";
                xmlstring = xmlstring + "</Response>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + GetBASISError(Convert.ToInt32(Result.Trim())) + "</Error>";
                xmlstring = xmlstring + "</Response>";
            }
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>"; 
            //return ex.Message;
        }

        oracomm = null;
        oraconn.Close();
        oraconn = null;

        return xmlstring;
    }

    public string GetAllBasisUsers()
    {
        string Result = string.Empty;
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        DataTable dt;

        String query_str = null;

        try
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

            // create the command for the function
            query_str = "select tell_id as basis_id, max(cus_sho_name) as user_name from teller where cus_sho_name is not null group by tell_id";

            oraconn.Open();
            cmd = new OracleCommand(query_str, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            dt = new DataTable();

            ora_adpt.Fill(dt);

            xmlstring = "<Response>";

            if (dt.Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<USERS>";
                foreach (DataRow dr in dt.Rows)
                {
                    //GET ROLE
                    xmlstring = xmlstring + "<USER>";
                    xmlstring = xmlstring + "<BASIS_ID>" + dr["basis_id"] + "</BASIS_ID>";
                    xmlstring = xmlstring + "<USER_NAME>" + dr["user_name"].ToString().Replace("&","&amp;") + "</USER_NAME>";
                    xmlstring = xmlstring + "</USER>";
                }
                xmlstring = xmlstring + "</USERS>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "NO ROLES" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";

            dt = null;
            ora_adpt = null;
            cmd = null;
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public string SearchBASISUser(String criteria, String bracode)
    {
        string Result = string.Empty;
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        DataTable dt;

        String query_str = null;
        String search = null;

        try
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

            // create the command for the function
            search = criteria.Replace("*", "%");
            //query_str = "select tell_id as basis_id, max(cus_sho_name) as user_name, max(case when mat_date < trunc(sysdate) then 'I' else 'A' end) as status from teller where cus_sho_name like '" + search + "' group by tell_id";
            query_str = "select tell_id as basis_id, cus_sho_name as user_name, bra_code as branch, (case when mat_date < trunc(sysdate) then 'I' else 'A' end) as status from teller where bra_code = " + bracode + " and cus_sho_name like '" + search + "'";
            oraconn.Open();
            cmd = new OracleCommand(query_str, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            dt = new DataTable();

            ora_adpt.Fill(dt);

            xmlstring = "<Response>";

            if (dt.Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<USERS>";
                foreach (DataRow dr in dt.Rows)
                {
                    //GET ROLE
                    xmlstring = xmlstring + "<USER>";
                    xmlstring = xmlstring + "<BASIS_ID>" + dr["basis_id"] + "</BASIS_ID>";
                    xmlstring = xmlstring + "<USER_NAME>" + dr["user_name"] + "</USER_NAME>";
                    xmlstring = xmlstring + "<BRANCH>" + dr["branch"] + "</BRANCH>";
                    xmlstring = xmlstring + "<STATUS>" + dr["status"] + "</STATUS>";

                    xmlstring = xmlstring + "</USER>";
                }
                xmlstring = xmlstring + "</USERS>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "NO ROLES" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";

            dt = null;
            ora_adpt = null;
            cmd = null;
            if (oraconn.State != ConnectionState.Closed) oraconn.Close();
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public string GetExtTransFlagFromBASIS(String ledcode)
    {
        string Result = string.Empty;
        String flag = "2";  //Not Determined
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataReader reader;

        String query_str = null;

        try
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

            query_str = "select EXT_TRA_FLAG from chrt_act where led_code = " + ledcode;
            oraconn.Open();
            cmd = new OracleCommand(query_str, oraconn);
            reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                reader.Read();
                flag = reader["EXT_TRA_FLAG"].ToString();   //0 = Not Set, 1 = "Ext. Tra. Flag is Set, 2 - Not determined"
            }
            else
            {
                flag = "2"; //Not Determined
            }

            reader.Close();
            reader = null;
            cmd = null;
            if (oraconn.State != ConnectionState.Closed) oraconn.Close();
        }
        catch (Exception ex)
        {
            flag = "2";
        }

        return flag;
    }

    public String GetBASISError(int errorcode)
    {
        string Result = string.Empty;
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        DataTable dt;

        String query_str = null;
        

        try
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

            // create the command for the function
           
            //query_str = "select tell_id as basis_id, max(cus_sho_name) as user_name, max(case when mat_date < trunc(sysdate) then 'I' else 'A' end) as status from teller where cus_sho_name like '" + search + "' group by tell_id";
            query_str = "select tab_ent,des_eng from text_tab where tab_id=50 and tab_ent=" + errorcode.ToString();
            oraconn.Open();
            cmd = new OracleCommand(query_str, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            dt = new DataTable();

            ora_adpt.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    //GET ERROR

                    xmlstring = errorcode.ToString() + ":" + dr["des_eng"].ToString();
                   
                }
                
            }
            else
            {
                
                xmlstring = "UNKNOWN ERROR";
            }

            dt = null;
            ora_adpt = null;
            cmd = null;
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring = "UNKNOWN ERROR";
        }

        return xmlstring;
    }

    public string AnalyzeFx(String acctno, Decimal transfer_amt, DateTime anal_date)
    {
        char[] delim = new char[] { '|' };
        char[] delim2 = new char[] { '/' };

        Decimal rate_gbp = 1.62M, rate_eur = 1.36M, rate_rnd = 0.75M, rate_usd = 1.0M, rate=0.0M;
        String resultstr = "", narration = "";
        String[] tempstr;
        Decimal AcctBal = 0, nairabal = 0, total_fx=0, total_usd_fx=0, curBal, tra_amt = 0, cd_limit = 10000;
        DataSet dsTrans, dsDet;
        Decimal out_amt = 0, out_amt_usd=0, valid_out = 0, tot_cr = 0, tot_valid_cr = 0, tot_invalid_cr = 0, tot_cd = 0, tot_inv_cd = 0, tot_inf = 0, tot_trf = 0, tot_valid_trf = 0, tot_debit = 0, tot_invst = 0;
        Decimal daily_limit = 0, weekly_limit = 0;
        Decimal dynamic_bal = 0M;
        Decimal new_credit = 0M;
        int deb_cre, expl_code;
        DataRow drTrans;
        String customer_name = null;
        DateTime anal_end_date = new DateTime();

        xmlstring = "<Response>";

        out_amt = transfer_amt;
        resultstr = GetAcctBal(acctno.Trim(), anal_date );
        dsTrans = GetTransactions(acctno.Trim(),anal_date,AcctBal);
        
        tempstr = resultstr.Split(delim);
        AcctBal = Convert.ToDecimal(tempstr[0]);
        total_fx = Convert.ToDecimal(tempstr[1]);
        customer_name = tempstr[2];
        nairabal = Convert.ToDecimal(tempstr[3]);

        //Convert amount to dollar.
        tempstr = acctno.Split(delim2);
        if (tempstr[2].Trim() == "2")
            rate = rate_usd;
        else if(tempstr[2].Trim() == "3")
            rate = rate_gbp;
        else if (tempstr[2].Trim() == "46")
            rate = rate_eur;
        else if (tempstr[2].Trim() == "43")
            rate = rate_rnd;
        else
            rate = rate_usd;

        total_usd_fx = total_fx * rate;

        //Set limits
        daily_limit = 10000;    //Applicable to cash deposit
        weekly_limit = 50000;   //Applicable to cash deposit
        if (total_usd_fx >= weekly_limit)
        {
            weekly_limit = 0;
        }
        else
        {
            weekly_limit =  weekly_limit - total_usd_fx;
        }

        if (weekly_limit <= daily_limit)
        {
            daily_limit = weekly_limit;
        }
        //else
        //{

        //}

        if (AcctBal < out_amt)
        {
            resultstr = "NOT VALID";
            narration = "Available Balance less than Transfer Amount";
            xmlstring = xmlstring + "<RESULT>" + resultstr + "</RESULT>";
            xmlstring = xmlstring + "<ACCTBAL>" + AcctBal.ToString("N") + "</ACCTBAL>";
            xmlstring = xmlstring + "<NAIRAACCTBAL>" + nairabal.ToString("N") + "</NAIRAACCTBAL>";
            xmlstring = xmlstring + "<CUSTNAME>" + customer_name + "</CUSTNAME>";
            xmlstring = xmlstring + "<VALIDOUT>0.00</VALIDOUT>";
            xmlstring = xmlstring + "<ANALSTARTDATE>" + anal_date.ToString("ddMMyyyy") + "</ANALSTARTDATE>";
            xmlstring = xmlstring + "<ANALENDDATE>" + anal_date.ToString("ddMMyyyy") + "</ANALENDDATE>";
            xmlstring = xmlstring + "<NARRATIONS>";
            xmlstring = xmlstring + "<NARRATION>" + narration + "</NARRATION>";
            xmlstring = xmlstring + "</NARRATIONS>";
            xmlstring = xmlstring + "</Response>";

            return xmlstring;
        }

        dynamic_bal = AcctBal;

        for (int i = dsTrans.Tables[0].Rows.Count - 1; i > 0; i--)
        {
            drTrans = dsTrans.Tables[0].Rows[i];
            tra_amt = Convert.ToDecimal(drTrans["tra_amt"]);
            curBal = Convert.ToDecimal(drTrans["crnt_bal"]);
            expl_code = Convert.ToInt32(drTrans["expl_code"]);
            deb_cre = Convert.ToInt32(drTrans["deb_cre_ind"]);
            anal_end_date = Convert.ToDateTime(drTrans["tra_date"]);

            //if ((curBal > 0 && curBal <= 10) || (dynamic_bal > 0 && dynamic_bal < out_amt))
            if ((dynamic_bal > 0 && dynamic_bal < out_amt))
                break;

            if (deb_cre == 2)
            {
                tot_cr = tot_cr + tra_amt;

                if (expl_code == 700 || expl_code == 312 || expl_code == 953 || expl_code == 45 || expl_code == 316 || expl_code == 330 || expl_code == 1317 || expl_code == 955) //Inflow -- valid
                {
                    tot_inf = tot_inf + tra_amt;
                    tot_valid_cr = tot_valid_cr + tra_amt;
                    new_credit = tra_amt;
                }
                else if (expl_code == 104 || expl_code == 218) //Investment -- invalid
                {
                    tot_invst = tot_invst + tra_amt;
                    tot_invalid_cr = tot_invalid_cr + tra_amt;
                }
                else if ((expl_code == 1) && (tra_amt <= 10000)) //Cash Deposit -- valid
                {
                    tot_cd = tot_cd + tra_amt;
                    tot_valid_cr = tot_valid_cr + tra_amt;
                    new_credit = tra_amt;
                }
                else if ((expl_code == 1) && (tra_amt > 10000)) //Invalid Cash Deposit -- invalid
                {
                    tot_inv_cd = tot_inv_cd + tra_amt;
                    tot_invalid_cr = tot_invalid_cr + tra_amt;
                }
                else if (expl_code == 102 || expl_code == 100 || expl_code == 99 || expl_code == 147) //Local transfer -- invalid
                {
                    tot_trf = tot_trf + tra_amt;
                    tot_invalid_cr = tot_invalid_cr + tra_amt;
                }
                //else if ((expl_code == 102 || expl_code == 100 || expl_code == 99 || expl_code == 147) && tra_amt > 10000) //Local transfer -- invalid
                //{
                //    tot_trf = tot_trf + tra_amt;
                //    tot_invalid_cr = tot_invalid_cr + tra_amt;
                //}
                //else if ((expl_code == 102 || expl_code == 100 || expl_code == 99 || expl_code == 147) && tra_amt <= 10000) //Local transfer -- valid
                //{
                //    tot_valid_trf = tot_valid_trf + tra_amt;
                //    tot_valid_cr = tot_valid_cr + tra_amt;
                //}
                else //398, 98, 903, 242
                {
                    tot_invalid_cr = tot_invalid_cr + tra_amt;
                }
            }
            else
                tot_debit = tot_debit + tra_amt;

            //If dynamic balance < out_amt then exit loop - Amount not valid for transfer
            dynamic_bal = (AcctBal + tot_debit - tot_cr) + new_credit;
            if (tot_valid_cr >= out_amt)
            {
                valid_out = tot_valid_cr;
                break;
            }
            else if (dynamic_bal < out_amt)
            {
                valid_out = dynamic_bal;
                
                break;
            }
            //if ((Math.Abs(tot_cr - (tot_debit + AcctBal)) <= 10))
                //break;
        }

        //if (tot_invalid_cr > tot_debit)
        //{
        //    //valid_out = AcctBal - (tot_invalid_cr - tot_debit);
        //    valid_out = tot_valid_cr;
        //}
        //else
        //{
        //    valid_out = dynamic_bal;
        //}

        //valid_out = (tot_debit + AcctBal) - tot_invalid_cr;

        resultstr = "VALID";
        if (valid_out < out_amt)
        {
            resultstr = "NOT VALID";
        }
        else
        {
            if ((out_amt*rate) <= weekly_limit)
            {
                if ((out_amt > daily_limit) && ((tot_inf*rate) < (out_amt - daily_limit)))
                {
                    resultstr = "NOT VALID";
                }
            }
            else
            {
                if ((tot_inf*rate) < ((out_amt*rate) - weekly_limit))
                    resultstr = "NOT VALID";
            }
        }

        xmlstring = xmlstring + "<RESULT>" + resultstr + "</RESULT>";
        xmlstring = xmlstring + "<ACCTBAL>" + AcctBal.ToString("N") + "</ACCTBAL>";
        xmlstring = xmlstring + "<NAIRAACCTBAL>" + nairabal.ToString("N") + "</NAIRAACCTBAL>";
        xmlstring = xmlstring + "<CUSTNAME>" + customer_name + "</CUSTNAME>";
        xmlstring = xmlstring + "<VALIDOUT>" + valid_out.ToString("N") + "</VALIDOUT>";
        xmlstring = xmlstring + "<ANALSTARTDATE>" + anal_date.ToString("ddMMyyyy") + "</ANALSTARTDATE>";
        xmlstring = xmlstring + "<ANALENDDATE>" + anal_end_date.ToString("ddMMyyyy") + "</ANALENDDATE>";
        
        if (resultstr == "NOT VALID")
        {
            xmlstring = xmlstring + "<NARRATIONS>";
            if (tot_trf > 0)
            {
                narration = "Found funds transferred locally";
                xmlstring = xmlstring + "<NARRATION>" + narration + "</NARRATION>";
            }
            if (tot_invst > 0)
            {
                narration = "Found Matured Investment";
                xmlstring = xmlstring + "<NARRATION>" + narration + "</NARRATION>";
            }
            if (tot_inv_cd > 0)
            {
                narration = "Found Invalid Cash Deposit";
                xmlstring = xmlstring + "<NARRATION>" + narration + "</NARRATION>";
            }

            xmlstring = xmlstring + "</NARRATIONS>";
        }

        xmlstring = xmlstring + "</Response>";

        return xmlstring;
    }
   
    private DataSet GetTransactions(String acctno, DateTime datetm, Decimal balance)
    {
        String query_str, Remark = string.Empty;
        String daterange;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        DataSet ds = null, ds1 = null;
        //String commstr, vatstr;

        try
        {
            daterange = datetm.Day.ToString().PadLeft(2, '0') + datetm.Month.ToString().PadLeft(2, '0') + datetm.Year.ToString().PadLeft(4, '0');
            tempstr = acctno.Split(delim);

            // create the connection
            OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

            // create the command for the function
            
            query_str = "select tra_date, deb_cre_ind, tra_amt, expl_code, crnt_bal, remarks from transact where bra_code=" + tempstr[0].Trim() + " and cus_num=" + tempstr[1].Trim() + " and cur_code=" + tempstr[2].Trim() + " and led_code=" + tempstr[3].Trim() + " and sub_acct_code=" + tempstr[4].Trim() + " and tra_date <= '" + daterange + "' order by tra_date, upd_time";

            oraconn.Open();
            OracleCommand cmd = new OracleCommand(query_str, oraconn);
            ds = new DataSet();
            OracleDataAdapter adpt = new OracleDataAdapter(cmd);

            // execute the function
            adpt.Fill(ds);
            adpt = null;
            cmd = null;

            if (datetm.ToShortDateString() == DateTime.Now.ToShortDateString())
            {
                query_str = "select tra_date, deb_cre_ind, tra_amt, expl_code," + balance.ToString() + " crnt_bal, remarks from tell_act where bra_code=" + tempstr[0].Trim() + " and cus_num=" + tempstr[1].Trim() + " and cur_code=" + tempstr[2].Trim() + " and led_code=" + tempstr[3].Trim() + " and sub_acct_code=" + tempstr[4].Trim() + " order by tra_date, upd_time";
                cmd = new OracleCommand(query_str, oraconn);
                ds1 = new DataSet();
                adpt = new OracleDataAdapter(cmd);

                // execute the function
                adpt.Fill(ds1);
                if (ds1.Tables[0].Rows.Count > 0)
                    ds.Merge(ds1, true, MissingSchemaAction.Ignore);

                adpt = null;
                cmd = null;
            }

            oraconn.Close();
            oraconn = null;
            return ds;
        }
        catch (Exception ex)
        {
            return ds;
        }
    }

    private String GetAcctBal(String acctno, DateTime datetm)
    {
        String query_str, Remark = string.Empty;
        String daterange, mondaystr;
        Decimal retval = 0;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        Decimal bal = 0, nairabal = 0;
        DataSet ds = null;
        DateTime monday = DateTime.Now;
        Decimal FxDone = 0;
        String custname = null;
        DateTime datem1 = datetm.AddDays(0.0);

        OracleCommand cmd;
        OracleDataReader reader;
        OracleDataAdapter adpt;
        //String commstr, vatstr;

        try
        {
            tempstr = acctno.Split(delim);
            if (datetm.DayOfWeek == DayOfWeek.Monday)
                monday = datetm;
            else if (datetm.DayOfWeek == DayOfWeek.Tuesday)
                monday = datetm.AddDays(-1.0);
            else if (datetm.DayOfWeek == DayOfWeek.Wednesday)
                monday = datetm.AddDays(-2.0);
            else if (datetm.DayOfWeek == DayOfWeek.Thursday)
                monday = datetm.AddDays(-3.0);
            else if (datetm.DayOfWeek == DayOfWeek.Friday)
                monday = datetm.AddDays(-4.0);
            else if (datetm.DayOfWeek == DayOfWeek.Saturday)
                monday = datetm.AddDays(-5.0);
            else if (datetm.DayOfWeek == DayOfWeek.Sunday)
                monday = datetm.AddDays(-6.0);

            mondaystr = monday.Day.ToString().PadLeft(2, '0') + monday.Month.ToString().PadLeft(2, '0') + monday.Year.ToString().PadLeft(4, '0');
            daterange = datetm.Day.ToString().PadLeft(2, '0') + datetm.Month.ToString().PadLeft(2, '0') + datetm.Year.ToString().PadLeft(4, '0');

            // create the connection
            OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
            oraconn.Open();

            //Get total sum of Fx from Monday of the selected week
            query_str = "select nvl(sum(tra_amt),0) TOTAL_FX from transact where bra_code=" + tempstr[0].Trim() + " and cus_num=" + tempstr[1].Trim() + " and cur_code=" + tempstr[2].Trim() + " and led_code=" + tempstr[3].Trim() + " and sub_acct_code=" + tempstr[4].Trim() + " and tra_date between '" + mondaystr + "' and '" + daterange + "' and deb_cre_ind=1 and expl_code=305";
            cmd = new OracleCommand(query_str, oraconn);

            // execute the function
            reader = cmd.ExecuteReader();
            if (reader.HasRows == true)
            {
                reader.Read();
                FxDone = Convert.ToDecimal(reader["TOTAL_FX"]);
                reader.Close();
                reader = null;
                cmd = null;
            }
            else
            {
                reader = null;
                reader.Close();
                reader = null;
                cmd = null;
                FxDone = 0;
            }

            //Get Customer's name
            query_str = "select cus_sho_name from address where bra_code=" + tempstr[0].Trim() + " and cus_num=" + tempstr[1].Trim() + " and cur_code=0 and led_code=0 and sub_acct_code=0";
            cmd = new OracleCommand(query_str, oraconn);

            // execute the function
            reader = cmd.ExecuteReader();
            if (reader.HasRows == true)
            {
                reader.Read();
                custname = reader["cus_sho_name"].ToString();
                reader.Close();
                reader = null;
                cmd = null;
            }
            else
            {
                custname = "EMPTY";
                reader.Close();
                reader = null;
                cmd = null;
            }

            // create the command for the function
            if (datetm.ToShortDateString() == DateTime.Now.ToShortDateString())
            {
                query_str = "select nvl(navailbal(" + tempstr[0].Trim() + "," + tempstr[1].Trim() + "," + tempstr[2].Trim() + "," + tempstr[3].Trim() + "," + tempstr[4].Trim() + "),0) as ACCTBAL from dual";
                //query_str = "select nvl(getopnbal6(" + tempstr[0].Trim() + "," + tempstr[1].Trim() + "," + tempstr[2].Trim() + "," + tempstr[3].Trim() + "," + tempstr[4].Trim() + ",'" + datem1.ToString("ddMMyyyy") + "'),0) as ACCTBAL from dual";

                cmd = new OracleCommand(query_str, oraconn);
                
                // execute the function
                reader = cmd.ExecuteReader();
                if (reader.HasRows == true)
                {
                    reader.Read();
                    bal = Convert.ToDecimal(reader["ACCTBAL"]);
                    reader.Close();
                    reader = null;
                    cmd = null;
                    
                }
                else
                {
                    bal = 0;
                    reader = null;
                    cmd = null;
                    
                }

                //Get Balance from Naira Account
                query_str = "select nvl(navailbal(" + tempstr[0].Trim() + "," + tempstr[1].Trim() + ",1,1,0),0) as ACCTBAL from dual";

                cmd = new OracleCommand(query_str, oraconn);

                // execute the function
                reader = cmd.ExecuteReader();
                if (reader.HasRows == true)
                {
                    reader.Read();
                    nairabal = Convert.ToDecimal(reader["ACCTBAL"]);
                    reader.Close();
                    reader = null;
                    cmd = null;
                    oraconn.Close();
                }
                else
                {
                    nairabal = 0;
                    reader = null;
                    cmd = null;
                    oraconn.Close();
                }

            }
            else
            {
                query_str = "select crnt_bal from transact where bra_code=" + tempstr[0].Trim() + " and cus_num=" + tempstr[1].Trim() + " and cur_code=" + tempstr[2].Trim() + " and led_code=" + tempstr[3].Trim() + " and sub_acct_code=" + tempstr[4].Trim() + " and tra_date <= '" + daterange + "' order by tra_date, upd_time";
                cmd = new OracleCommand(query_str, oraconn);
                ds = new DataSet();
                adpt = new OracleDataAdapter(cmd);

                // execute the function
                adpt.Fill(ds);
                adpt = null;
                cmd = null;
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataRow dr = ds.Tables[0].Rows[ds.Tables[0].Rows.Count - 1];
                    bal = Convert.ToDecimal(dr["crnt_bal"]);
                    
                }
                else
                {
                    bal = 0;
                    retval = 0;
                    
                }

                //get balance from Naira account
                query_str = "select crnt_bal from transact where bra_code=" + tempstr[0].Trim() + " and cus_num=" + tempstr[1].Trim() + " and cur_code=1 and led_code=1 and sub_acct_code=0 and tra_date <= '" + daterange + "' order by tra_date, upd_time";
                cmd = new OracleCommand(query_str, oraconn);
                ds = new DataSet();
                adpt = new OracleDataAdapter(cmd);

                // execute the function
                adpt.Fill(ds);
                adpt = null;
                cmd = null;
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DataRow dr = ds.Tables[0].Rows[ds.Tables[0].Rows.Count - 1];
                    nairabal = Convert.ToDecimal(dr["crnt_bal"]);
                    oraconn.Close();
                }
                else
                {
                    nairabal = 0;
                    retval = 0;
                    oraconn.Close();
                }
            }

            return bal.ToString() + "|" + FxDone.ToString() + "|" + custname.Trim() + "|" + nairabal.ToString();
        }
        catch (Exception ex)
        {
            return "0|0|0|0";
        }
    }

    public string CheckBatchRun()
    {
        string Result = string.Empty;
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        DataTable dt;

        String query_str = null;
        String search = null;

        try
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

            // create the command for the function
            query_str = "select * from process where nvl(length(rtrim(ltrim(bat_prog_name))),0) > 0";
            oraconn.Open();
            cmd = new OracleCommand(query_str, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            dt = new DataTable();

            ora_adpt.Fill(dt);

            xmlstring = "<Response>";

            if (dt.Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "END OF DAY PROCESS IN PROGRESS" + "</Error>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }

            xmlstring = xmlstring + "</Response>";

            dt = null;
            ora_adpt = null;
            cmd = null;
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    internal string ChkLimitFuelCard(string acctno)
    {
        char[] delim = new char[] { '/' };
        string Result = string.Empty;
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        DataTable dt;

        String query_str = null;
        String search = null;
        String[] tempstr;
        Decimal limit = Convert.ToDecimal(ConfigurationManager.AppSettings["FuelCardLimit"].ToString()); 
        Decimal available_limit = 0M;
        Decimal tot_credit = 0M;

        try
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

            tempstr = acctno.Split(delim);

            // create the command for the function
            query_str = "select NVL(tra_amt,0) as tra_amt from tell_act where bra_code=" + tempstr[0] + " and cus_num=" + tempstr[1] + " and cur_code=" + tempstr[2] + " and led_code=" + tempstr[3] + " and sub_acct_code=" + tempstr[4] + " and can_rea_code=0 and deb_cre_ind=2";
            oraconn.Open();
            cmd = new OracleCommand(query_str, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            dt = new DataTable();

            ora_adpt.Fill(dt);

            xmlstring = "<Response>";

            if (dt.Rows.Count > 0)
            {
                //get available limit
                foreach (DataRow dr in dt.Rows)
                {
                    tot_credit = tot_credit + Convert.ToDecimal(dr["tra_amt"]);
                }
                //tot_credit = Convert.ToDecimal(dt.Rows[0]["total_credit"]);
                available_limit = limit - tot_credit;
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<LIMIT>" + available_limit.ToString() + "</LIMIT>";
            }
            else
            {
                available_limit = limit - tot_credit;
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<LIMIT>" + available_limit.ToString() + "</LIMIT>";
            }

            dt = null;
            ora_adpt = null;
            cmd = null;
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
        }

        xmlstring = xmlstring + "</Response>";

        return xmlstring;
    }

    public String ValidateBASISAccountNuber(String acctno)
    {
        String finalstr = null;
        String limit = null;
        String oldacctno = null;
        string Result = string.Empty;
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        DataTable dt;
        String query_str = null;
        char[] delim2 = new char[] { '/' };
        String[] tempstr = null;
        String acctType = "";
        string braCode = string.Empty;
        string cusNum = string.Empty;
        string curCode = string.Empty;
        string ledCode = string.Empty;
        string subAcct = string.Empty;

        try
        {
            xmlstring = "<Response>";

            //Parse Account, check for NUBAN
            if (acctno.Length == 10) //Validate NUBAN
            {
                Converter cnv = new Converter(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
                if (cnv.verifyNubanCheckDigit("058", acctno) == true)
                {
                    //oldacctno = cnv.ConvertToOldAccountNumber(acctno);
                    acctType = "NUBAN";
                    oldacctno = cnv.ConvertToOldAccountNumber(acctno);
                    acctType = "REGULAR";
                }
                else
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>" + "INVALID ACCOUNT NUMBER" + "</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }
            }

            else
            {
                oldacctno = acctno;
                acctType = "REGULAR";
            }

            tempstr = oldacctno.Split(delim2);
            braCode = tempstr[0].ToString();
            cusNum = tempstr[1].ToString();
            curCode = tempstr[2].ToString();
            ledCode = tempstr[3].ToString();
            subAcct = tempstr[4].ToString();

            try
            {
                Convert.ToInt32(braCode);
                Convert.ToInt32(cusNum);
                Convert.ToInt32(curCode);
                Convert.ToInt32(ledCode);
                Convert.ToInt32(subAcct);
            }
            catch (Exception)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "INVALID ACCOUNT NUMBER" + "</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            if (tempstr.GetLength(0) != 5)
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "INVALID ACCOUNT NUMBER" + "</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }
            if (tempstr[0].Trim().Length != 3)  //Check branch code
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "INVALID ACCOUNT NUMBER" + "</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }
            

            try
            {
                oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

                // create the command for the function
                if (acctType == "NUBAN")
                {
                    query_str = "select role_num as role_id, des_eng as role_desc from role_inf";
                    query_str = "select navailbal(a.bra_code,a.cus_num,a.cur_code,a.led_code,a.sub_acct_code) as availbal,";
                    query_str = query_str + " a.bra_code||'/'||a.cus_num||'/'||a.cur_code||'/'||a.led_code||'/'||a.sub_acct_code as acctno, b.cus_sho_name as acctname";
                    query_str = query_str + " from map_acct a, address b";
                    query_str = query_str + " where a.bra_code=b.bra_code and a.cus_num=b.cus_num";
                    query_str = query_str + " and a.map_acc_no =" + acctno;
                    query_str = query_str + " and b.cur_code=0 and b.led_code=0 and b.sub_acct_code=0";
                }
                else if (acctType == "REGULAR")
                {
                    query_str = "select role_num as role_id, des_eng as role_desc from role_inf";
                    query_str = "select navailbal(a.bra_code,a.cus_num,a.cur_code,a.led_code,a.sub_acct_code) as availbal,";
                    query_str = query_str + " a.bra_code||'/'||a.cus_num||'/'||a.cur_code||'/'||a.led_code||'/'||a.sub_acct_code as acctno, get_name2(a.bra_code,a.cus_num,a.cur_code,a.led_code,a.sub_acct_code) as acctname, b.tel_num, b.mob_num";
                    query_str = query_str + " from account a, address b";
                    query_str = query_str + " where a.bra_code=b.bra_code and a.cus_num=b.cus_num";
                    query_str = query_str + " and a.bra_code=" + tempstr[0] + " and a.cus_num=" + tempstr[1] + " and a.cur_code=" + tempstr[2] + " and a.led_code=" + tempstr[3] + " and a.sub_acct_code=" + tempstr[4];
                    query_str = query_str + " and b.cur_code=0 and b.led_code=0 and b.sub_acct_code=0";
                }


                oraconn.Open();
                cmd = new OracleCommand(query_str, oraconn);
                ora_adpt = new OracleDataAdapter(cmd);
                dt = new DataTable();

                ora_adpt.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    xmlstring = xmlstring + "<CODE>1000</CODE>";

                    DataRow dr = dt.Rows[0];
                    xmlstring = xmlstring + "<ACCTNO>" + dr["ACCTNO"] + "</ACCTNO>";
                    xmlstring = xmlstring + "<ACCTNAME>" + dr["ACCTNAME"].ToString().Replace("&", "&amp;") + "</ACCTNAME>";
                    xmlstring = xmlstring + "<AVAILBAL>" + dr["AVAILBAL"].ToString () + "</AVAILBAL>";
                    xmlstring = xmlstring + "<MOBNUM>" + dr["MOB_NUM"].ToString() + "</MOBNUM>";
                    xmlstring = xmlstring + "<TELNUM>" + dr["TEL_NUM"].ToString() + "</TELNUM>";
                    xmlstring = xmlstring + "</Response>";
                }
                else
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>" + "COULD NOT VALIDATE ACCOUNT NUMBER. ACCOUNT MAY NOT EXIST" + "</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }

                dt = null;
                ora_adpt = null;
                cmd = null;
            }
            catch (Exception ex)
            {
                xmlstring = xmlstring + "<CODE>1002</CODE>";
                xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
                xmlstring = xmlstring + "</Response>";
            }

        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String ValidateCurrentAccount(String acctno)
    {
        String finalstr = null;
        String limit = null;
        String oldacctno = null;
        string Result = string.Empty;
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        DataTable dt;
        String query_str = null;
        char[] delim2 = new char[] { '/' };
        String[] tempstr = null;
        String acctType = "";

        try
        {
            xmlstring = "<Response>";

            //Parse Account, check for NUBAN
            if (acctno.Length == 10) //Validate NUBAN
            {
                Converter cnv = new Converter(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
                if (cnv.verifyNubanCheckDigit("058", acctno) == true)
                {
                    //oldacctno = cnv.ConvertToOldAccountNumber(acctno);
                    acctType = "NUBAN";
                }
                else
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>" + "INVALID ACCOUNT NUMBER" + "</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }
            }
            //else if (acctno.Length < 12)
            //{
            //    xmlstring = xmlstring + "<CODE>100</CODE>";
            //    xmlstring = xmlstring + "<Error>" + "INVALID ACCOUNT NUMBER" + "</Error>";
            //    xmlstring = xmlstring + "</Response>";
            //    return xmlstring;
            //}
            else
            {
                oldacctno = acctno;
                acctType = "REGULAR";

                tempstr = oldacctno.Split(delim2);
                if (tempstr.GetLength(0) != 5)
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>" + "INVALID ACCOUNT NUMBER" + "</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }
                if (tempstr[0].Trim().Length != 3)  //Check branch code
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>" + "INVALID ACCOUNT NUMBER" + "</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }
            }

            try
            {
                oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

                // create the command for the function
                if (acctType == "NUBAN")
                {
                    query_str = "select navailbal(a.bra_code,a.cus_num,a.cur_code,a.led_code,a.sub_acct_code) as availbal,";
                    query_str = query_str + " a.bra_code||'/'||a.cus_num||'/'||a.cur_code||'/'||a.led_code||'/'||a.sub_acct_code as acctno, b.cus_sho_name as acctname";
                    query_str = query_str + " from map_acct a, address b";
                    query_str = query_str + " where a.bra_code=b.bra_code and a.cus_num=b.cus_num";
                    query_str = query_str + " and a.map_acc_no =" + acctno;
                    query_str = query_str + " and b.cur_code=0 and b.led_code=0 and b.sub_acct_code=0";
                }
                else if (acctType == "REGULAR")
                {
                    query_str = "select navailbal(a.bra_code,a.cus_num,a.cur_code,a.led_code,a.sub_acct_code) as availbal,";
                    query_str = query_str + " a.bra_code||'/'||a.cus_num||'/'||a.cur_code||'/'||a.led_code||'/'||a.sub_acct_code as acctno, b.cus_sho_name as acctname";
                    query_str = query_str + " from account a, address b";
                    query_str = query_str + " where a.bra_code=b.bra_code and a.cus_num=b.cus_num";
                    query_str = query_str + " and a.bra_code=" + tempstr[0] + " and a.cus_num=" + tempstr[1] + " and a.cur_code=" + tempstr[2] + " and a.led_code=" + tempstr[3] + " and a.sub_acct_code=" + tempstr[4];
                    query_str = query_str + " and b.cur_code=0 and b.led_code=0 and b.sub_acct_code=0";
                }


                oraconn.Open();
                cmd = new OracleCommand(query_str, oraconn);
                ora_adpt = new OracleDataAdapter(cmd);
                dt = new DataTable();

                ora_adpt.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    xmlstring = xmlstring + "<CODE>1000</CODE>";

                    DataRow dr = dt.Rows[0];
                    xmlstring = xmlstring + "<ACCTNO>" + dr["ACCTNO"] + "</ACCTNO>";
                    xmlstring = xmlstring + "<ACCTNAME>" + dr["ACCTNAME"].ToString().Replace("&", "&amp;") + "</ACCTNAME>";
                    xmlstring = xmlstring + "<AVAILBAL>" + dr["AVAILBAL"] + "</AVAILBAL>";
                    xmlstring = xmlstring + "</Response>";
                }
                else
                {
                    xmlstring = xmlstring + "<CODE>1001</CODE>";
                    xmlstring = xmlstring + "<Error>" + "COULD NOT RETRIEVE ACCOUNT NUMBER" + "</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }

                dt = null;
                ora_adpt = null;
                cmd = null;
            }
            catch (Exception ex)
            {
                xmlstring = xmlstring + "<CODE>1002</CODE>";
                xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
                xmlstring = xmlstring + "</Response>";
            }

        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String ConfirmCheque(String customer_acct_no, int docnum, Decimal Amount)
    {
        String ResultStr;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        Boolean chk_bal = false;
        Eone eone = new Eone();

        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = eone.checkAccountFormat(customer_acct_no.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            tempstr = customer_acct_no.Split(delim);

            Amount = Math.Round(Amount, 2);

            ResultStr = this.ConfirmChq(Convert.ToInt32(tempstr[0]), Convert.ToInt32(tempstr[1]), Convert.ToInt32(tempstr[2]), Convert.ToInt32(tempstr[3]), Convert.ToInt32(tempstr[4]), docnum, Amount);

            if (ResultStr == "0")
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }
            else
            {
                //get basis return error
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + eone.ErrorMsg(ResultStr) + "</ERROR>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public String ConfirmCheque2(String customer_acct_no, int docnum, Decimal Amount, String chqDate, String benname, String remarks)
    {
        String ResultStr;
        char[] delim = new char[] { '/' };
        String[] tempstr;
        Boolean chk_bal = false;
        Eone eone = new Eone();

        try
        {
            xmlstring = "<Response>";

            //Check account format
            chk_bal = eone.checkAccountFormat(customer_acct_no.Trim());
            if (chk_bal == false)
            {
                xmlstring = xmlstring + "<CODE>1003</CODE>";
                xmlstring = xmlstring + "<ERROR>Transaction failed: Format of account is wrong or account does not exist in BASIS.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            tempstr = customer_acct_no.Split(delim);

            Amount = Math.Round(Amount, 2);

            ResultStr = this.ConfirmChq2(Convert.ToInt32(tempstr[0]), Convert.ToInt32(tempstr[1]), Convert.ToInt32(tempstr[2]), Convert.ToInt32(tempstr[3]), Convert.ToInt32(tempstr[4]), docnum, Amount, chqDate, benname, remarks);

            if (ResultStr == "0")
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }
            else
            {
                //get basis return error
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + eone.ErrorMsg(ResultStr) + "</ERROR>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    private string ConfirmChq(int bra, int cus, int cur, int led, int sub, int docnum, Decimal Amount)
    {
        string Result = string.Empty;
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_ivr"]));
        OracleCommand oracomm = new OracleCommand("eonepkg.IVR_CONF_CHQ", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("BRA", OracleType.Number).Value = bra;
            oracomm.Parameters.Add("CUS", OracleType.Number).Value = cus;
            oracomm.Parameters.Add("CUR", OracleType.Number).Value = cur;
            oracomm.Parameters.Add("LED", OracleType.Number).Value = led;
            oracomm.Parameters.Add("SUB", OracleType.Number).Value = sub;
            oracomm.Parameters.Add("DOC_NUM", OracleType.Number).Value = docnum;
            oracomm.Parameters.Add("DOC_AMT", OracleType.Number).Value = Amount;
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.Number).Direction = ParameterDirection.Output;

            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
            oraconn.Close();
            //Result = "@ERR7@";
        }
        catch (Exception ex)
        {
            return ex.Message;
        }

        //if (Result.CompareTo("@ERR7@") == 0 || Result.CompareTo("@ERR19@") == 0)
        //{
        return Result;
        //}
        //else
        //{
        //    //get basis return error
        //    return ErrorMsg(Result);
        //}
    }

    private string ConfirmChq2(int bra, int cus, int cur, int led, int sub, int docnum, Decimal Amount, String DateStr, String BenName, String Remarks)
    {
        string Result = string.Empty;
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("eonepkg.CONF_CHQ", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("BRA", OracleType.Number).Value = bra;
            oracomm.Parameters.Add("CUS", OracleType.Number).Value = cus;
            oracomm.Parameters.Add("CUR", OracleType.Number).Value = cur;
            oracomm.Parameters.Add("LED", OracleType.Number).Value = led;
            oracomm.Parameters.Add("SUB", OracleType.Number).Value = sub;
            oracomm.Parameters.Add("DOC_NUM", OracleType.Number).Value = docnum;
            oracomm.Parameters.Add("DOC_AMT", OracleType.Number).Value = Amount;
            oracomm.Parameters.Add("DOC_DATE", OracleType.VarChar, 15).Value = DateStr;
            oracomm.Parameters.Add("BEN_NAME", OracleType.VarChar, 30).Value = BenName;
            oracomm.Parameters.Add("REM", OracleType.VarChar, 30).Value = Remarks;
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.Number).Direction = ParameterDirection.Output;

            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
            oraconn.Close();
            //Result = "@ERR7@";
        }
        catch (Exception ex)
        {
            return ex.Message;
        }

        //if (Result.CompareTo("@ERR7@") == 0 || Result.CompareTo("@ERR19@") == 0)
        //{
        return Result;
        //}
        //else
        //{
        //    //get basis return error
        //    return ErrorMsg(Result);
        //}
    }

    public DataSet GetStandInsFromBASIS(String debit_acct, String doc_num, String cred_acct, Decimal amount)
    {
        char[] delim = new char[] { '/' };
        String[] tempstr;
        string Result = string.Empty;
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        DataSet dt = new DataSet("StandInsTab");

        String query_str = null;

        try
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
            tempstr = debit_acct.Split(delim);

            // create the command for the function
            //query_str = "select INST_SEQ, bra_code||'/'||cus_num||'/'||cur_code||'/'||led_code||'/'||sub_acct_code DEBIT_ACCT, to_number(substr(cre_acct,1,4))||'/'||to_number(substr(cre_acct,5,7))||'/'||to_number(substr(cre_acct,12,3))||'/'||to_number(substr(cre_acct,15,4))||'/'||to_number(substr(cre_acct,19,3)) CREDIT_ACCT, pay_amt AMOUNT, pay_freq FREQUENCY, to_char(FST_PAY_DATE,'DDMMYYYY') START_DATE, to_char(LAS_PAY_DATE,'DDMMYYYY') END_DATE, to_char(INST_DATE,'DDMMYYYY') SETUP_DATE, REMARKS from stan_ins where bra_code=" + tempstr[0] + " and cus_num=" + tempstr[1] + " and cur_Code=" + tempstr[2] + " and led_code=" + tempstr[3] + " and sub_acct_Code=" + tempstr[4] + " and tell_id=9938 and remarks like '%" + doc_num + "%' and cre_acct = '" + cred_acct + "' and amount = " + amount.ToString();
            query_str = "select INST_SEQ, bra_code||'/'||cus_num||'/'||cur_code||'/'||led_code||'/'||sub_acct_code DEBIT_ACCT, to_number(substr(cre_acct,1,4))||'/'||to_number(substr(cre_acct,5,7))||'/'||to_number(substr(cre_acct,12,3))||'/'||to_number(substr(cre_acct,15,4))||'/'||to_number(substr(cre_acct,19,3)) CREDIT_ACCT, pay_amt AMOUNT, pay_freq FREQUENCY, to_char(FST_PAY_DATE,'DDMMYYYY') START_DATE, to_char(LAS_PAY_DATE,'DDMMYYYY') END_DATE, to_char(INST_DATE,'DDMMYYYY') SETUP_DATE, REMARKS from stan_ins where bra_code=" + tempstr[0] + " and cus_num=" + tempstr[1] + " and cur_Code=" + tempstr[2] + " and led_code=" + tempstr[3] + " and sub_acct_Code=" + tempstr[4] + " and tell_id=9938 and cre_acct = '" + cred_acct + "' and pay_amt = " + amount.ToString();

            oraconn.Open();
            cmd = new OracleCommand(query_str, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            //dt = new DataTable("StandInsTab");

            ora_adpt.Fill(dt);
            dt.Tables[0].TableName = "StandInsTab1";
            ora_adpt = null;
            cmd = null;
        }
        catch (Exception ex)
        {
        }

        return dt;
    }

    public Decimal GetAuthorizationLimit(String domainuser)
    {
        SqlConnection conn;
        SqlCommand comm;
        DataSet ds;
        SqlDataAdapter adpt;
        DataRow dr_1;
        String tellerid = "0";
        String bracode = "0";
        Decimal AuthLim = 0M;

        try
        {

            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("GetAdminUserDetails", conn);
            comm.Parameters.AddWithValue("@UserID", domainuser);

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);
            ds = new DataSet();

            adpt.Fill(ds);

            if (ds.Tables[0].Rows.Count > 0)
            {
                dr_1 = ds.Tables[0].Rows[0];
                //GET USER
                tellerid = dr_1["BASIS_ID"].ToString();
                bracode = dr_1["branch_code"].ToString();
            }
            dr_1 = null;
            ds = null;
            comm = null;
            conn.Close();
            conn = null;

            using (OracleCommand oracomm = new OracleCommand())
            {

                using (OracleConnection OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationSettings.AppSettings["BASISConString_eone"])))
                {

                    oracomm.Connection = OraConn;

                    oracomm.CommandText = "select AUT_AMT_CR from teller where tell_id = " + tellerid + " and bra_code = " + bracode;

                    oracomm.CommandType = CommandType.Text;

                    if (OraConn.State == ConnectionState.Closed)
                    {

                        OraConn.Open();

                    }

                    using (OracleDataReader dr = oracomm.ExecuteReader(CommandBehavior.CloseConnection))
                    {

                        if (dr.Read())
                        {

                            //string a = "Posting Teller:" + dr["PostingTellerId"].ToString();

                            //a = a + ", Teller Bra Code " + dr["OriginatingBraCode"].ToString();
                            AuthLim = Convert.ToDecimal(dr["AUT_AMT_CR"]);
                            return AuthLim;

                        }

                        else
                        {

                            return 0M;

                        }

                    }

                }

            }

        }

        catch (Exception ex)
        {

            return -1M;



        }



        finally { }

    }

    public DataSet GetStandInsFromBASIS2(String debit_acct, String doc_num, String cred_acct, Decimal amount, int seq)
    {
        char[] delim = new char[] { '/' };
        String[] tempstr;
        string Result = string.Empty;
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        DataSet dt = new DataSet("StandInsTab");

        String query_str = null;

        try
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
            tempstr = debit_acct.Split(delim);

            // create the command for the function
            //query_str = "select INST_SEQ, bra_code||'/'||cus_num||'/'||cur_code||'/'||led_code||'/'||sub_acct_code DEBIT_ACCT, to_number(substr(cre_acct,1,4))||'/'||to_number(substr(cre_acct,5,7))||'/'||to_number(substr(cre_acct,12,3))||'/'||to_number(substr(cre_acct,15,4))||'/'||to_number(substr(cre_acct,19,3)) CREDIT_ACCT, pay_amt AMOUNT, pay_freq FREQUENCY, to_char(FST_PAY_DATE,'DDMMYYYY') START_DATE, to_char(LAS_PAY_DATE,'DDMMYYYY') END_DATE, to_char(INST_DATE,'DDMMYYYY') SETUP_DATE, REMARKS from stan_ins where bra_code=" + tempstr[0] + " and cus_num=" + tempstr[1] + " and cur_Code=" + tempstr[2] + " and led_code=" + tempstr[3] + " and sub_acct_Code=" + tempstr[4] + " and tell_id=9938 and remarks like '%" + doc_num + "%' and cre_acct = '" + cred_acct + "' and amount = " + amount.ToString();
            //query_str = "select INST_SEQ, bra_code||'/'||cus_num||'/'||cur_code||'/'||led_code||'/'||sub_acct_code DEBIT_ACCT, to_number(substr(cre_acct,1,4))||'/'||to_number(substr(cre_acct,5,7))||'/'||to_number(substr(cre_acct,12,3))||'/'||to_number(substr(cre_acct,15,4))||'/'||to_number(substr(cre_acct,19,3)) CREDIT_ACCT, pay_amt AMOUNT, pay_freq FREQUENCY, to_char(FST_PAY_DATE,'DDMMYYYY') START_DATE, to_char(LAS_PAY_DATE,'DDMMYYYY') END_DATE, to_char(INST_DATE,'DDMMYYYY') SETUP_DATE, REMARKS from stan_ins where bra_code=" + tempstr[0] + " and cus_num=" + tempstr[1] + " and cur_Code=" + tempstr[2] + " and led_code=" + tempstr[3] + " and sub_acct_Code=" + tempstr[4] + " and tell_id=9938 and cre_acct = '" + cred_acct + "' and pay_amt = " + amount.ToString() + " and remarks like '%" + doc_num + "%'";

            if(seq == 0)
                query_str = "select INST_SEQ, bra_code||'/'||cus_num||'/'||cur_code||'/'||led_code||'/'||sub_acct_code DEBIT_ACCT, to_number(substr(cre_acct,1,4))||'/'||to_number(substr(cre_acct,5,7))||'/'||to_number(substr(cre_acct,12,3))||'/'||to_number(substr(cre_acct,15,4))||'/'||to_number(substr(cre_acct,19,3)) CREDIT_ACCT, pay_amt AMOUNT, pay_freq FREQUENCY, to_char(FST_PAY_DATE,'DDMMYYYY') START_DATE, to_char(LAS_PAY_DATE,'DDMMYYYY') END_DATE, to_char(INST_DATE,'DDMMYYYY') SETUP_DATE, REMARKS from stan_ins where bra_code=" + tempstr[0] + " and cus_num=" + tempstr[1] + " and cur_Code=" + tempstr[2] + " and led_code=" + tempstr[3] + " and sub_acct_Code=" + tempstr[4] + " and tell_id=9938 and cre_acct = '" + cred_acct + "' and pay_amt = " + amount.ToString(); //+ " and remarks like '%" + doc_num + "%'";
            else
                query_str = "select INST_SEQ, bra_code||'/'||cus_num||'/'||cur_code||'/'||led_code||'/'||sub_acct_code DEBIT_ACCT, to_number(substr(cre_acct,1,4))||'/'||to_number(substr(cre_acct,5,7))||'/'||to_number(substr(cre_acct,12,3))||'/'||to_number(substr(cre_acct,15,4))||'/'||to_number(substr(cre_acct,19,3)) CREDIT_ACCT, pay_amt AMOUNT, pay_freq FREQUENCY, to_char(FST_PAY_DATE,'DDMMYYYY') START_DATE, to_char(LAS_PAY_DATE,'DDMMYYYY') END_DATE, to_char(INST_DATE,'DDMMYYYY') SETUP_DATE, REMARKS from stan_ins where bra_code=" + tempstr[0] + " and cus_num=" + tempstr[1] + " and cur_Code=" + tempstr[2] + " and led_code=" + tempstr[3] + " and sub_acct_Code=" + tempstr[4] + " and tell_id=9938 and cre_acct = '" + cred_acct + "' and pay_amt = " + amount.ToString() + " and inst_seq = " + seq.ToString();

            oraconn.Open();
            cmd = new OracleCommand(query_str, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            
            ora_adpt.Fill(dt);
            dt.Tables[0].TableName = "StandInsTab1";

            ora_adpt = null;
            cmd = null;
        }
        catch (Exception ex)
        {
        }

        return dt;
    }

    //This method is used For Place the Standing Instruction

    internal string InitaiteStandingInstructionForSMSCharge1(string xmlRequest) //string Acct_to, string Acct_fro, string tellerID, string Remarks, decimal payAmount)
    {
        Eone eone = new Eone();
        xmlstring = "<Response>";
     //   string reponse = "<REQUEST><ACCOUNTTO>205/152124/1/1/0</ACCOUNTTO><ACCOUNTFROM>205/152407/1/1/0</ACCOUNTFROM><TELLERID>2961</TELLERID><REMARKS>SMS CHARGE FOR AUGUST 2014</REMARKS><AMOUNT>2000</AMOUNT></REQUEST>";
        try
        {
        XmlDocument doc = new XmlDocument();
        doc.LoadXml(xmlRequest);

        XPathNavigator nav = doc.CreateNavigator();

        XPathNodeIterator node = nav.Select("/REQUEST/ACCOUNTTO");
        node.MoveNext();
        string acctTo = node.Current.Value;

        node = nav.Select("/REQUEST/ACCOUNTFROM");
        node.MoveNext();
        string acctFrom  = node.Current.Value;

        node = nav.Select("/REQUEST/TELLERID");
        node.MoveNext();
        string tellerID = node.Current.Value;

        node = nav.Select("/REQUEST/REMARKS");
        node.MoveNext();
        string Remarks = node.Current.Value;

        node = nav.Select("/REQUEST/AMOUNT");
        node.MoveNext();
        decimal Amount = Convert.ToDecimal(node.Current.Value);

        string resp = PlaceInstructionForSMSCharge1(acctTo, acctFrom, tellerID, Remarks, Amount);
           if (resp == "0")
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }
            else
            {
                //get basis return error
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + eone.ErrorMsg(resp) + "</ERROR>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }
        return xmlstring;
    }
     
    private string PlaceInstructionForSMSCharge1(string Acct_to, string Acct_fro, string tellerID, string Remarks, decimal payAmount)
    {
        string[] accFrom, accTo; 
        char[] delim = new char[] { '/' };

        accTo = Acct_to.Split(delim);
      
         accFrom = Acct_fro.Split(delim);
         string branchToCredit;
         string branchList = ConfigurationManager.AppSettings["Excluded_account_SI"].ToString();
         if (branchList.Contains(accFrom[0]))
         {
             branchToCredit = "205";
         }
         else
         {
             branchToCredit = accFrom[0];
         }




        payAmount = Math.Round(payAmount, 2);

        string Result = string.Empty;
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("GTB_STAN_INS", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("DEB_BRA_CODE", OracleType.Number, 21).Value = accFrom[0];
            oracomm.Parameters.Add("DEB_CUS_NUM", OracleType.Number, 21).Value = accFrom[1];
            oracomm.Parameters.Add("DEB_CUR_CODE", OracleType.Number, 21).Value = accFrom[2];
            oracomm.Parameters.Add("DEB_LED_CODE", OracleType.Number, 21).Value = accFrom[3];
            oracomm.Parameters.Add("DEB_SUB_ACCT_CODE", OracleType.Number, 21).Value = accFrom[4];
            oracomm.Parameters.Add("CRE_BRA_CODE", OracleType.Number, 21).Value = branchToCredit;
            oracomm.Parameters.Add("CRE_CUS_NUM", OracleType.Number, 21).Value = accTo[0];
            oracomm.Parameters.Add("CRE_CUR_CODE", OracleType.Number, 21).Value = accTo[1];
            oracomm.Parameters.Add("CRE_LED_CODE", OracleType.Number, 21).Value = accTo[2];
            oracomm.Parameters.Add("CRE_SUB_ACCT_CODE", OracleType.Number, 21).Value = accTo[3];
            oracomm.Parameters.Add("TELL_ID", OracleType.VarChar, 15).Value = tellerID;
            oracomm.Parameters.Add("PAY_AMT", OracleType.Number, 15).Value = payAmount;
            oracomm.Parameters.Add("REMARKS", OracleType.VarChar, 300).Value =Remarks;
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
                   
            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
            oraconn.Close();
            //Result = "@ERR7@";
        }
        catch (Exception ex)
        {
            return ex.Message;
        }

        //if (Result.CompareTo("@ERR7@") == 0 || Result.CompareTo("@ERR19@") == 0)
        //{
        return Result;
        //}
        //else
        //{
        //    //get basis return error
        //    return ErrorMsg(Result);
        //}
    }

    public UInt64 InitiateCancellationRequest(string OrigbraCode, string tellerId, string origttraseq1, string applicationid, string tellerbracode, string cancelreason) // Online Transactions
    {

        object result = 0;
        try
        {
            using (SqlCommand sqlcomm = new SqlCommand())
            {
                using (SqlConnection EoneConn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
                {


                    sqlcomm.Connection = EoneConn;
                    sqlcomm.Parameters.Add("@TellerID", SqlDbType.NChar).Value = tellerId;
                    sqlcomm.Parameters.Add("@OriginatingBraCode", SqlDbType.NChar).Value = OrigbraCode;
                    sqlcomm.Parameters.Add("@Origt_Tra_Seq1", SqlDbType.NChar).Value = origttraseq1;
                    sqlcomm.Parameters.Add("@TellerBraCode", SqlDbType.NChar).Value = tellerbracode;
                    sqlcomm.Parameters.Add("@ApplicationID", SqlDbType.Decimal).Value = applicationid;
                    sqlcomm.Parameters.Add("@CancellationReason", SqlDbType.NChar).Value = cancelreason;

                    sqlcomm.CommandText = "usp_TransactionCancellationInsert";
                    sqlcomm.CommandType = CommandType.StoredProcedure;



                    if (EoneConn.State == ConnectionState.Closed)
                    {
                        EoneConn.Open();
                    }



                    result = sqlcomm.ExecuteScalar();

                    return Convert.ToUInt64(result);

                }
            }
        }

        catch (Exception ex)
        {
            return 0;
        }
        finally
        {



        }


    }


    public UInt64 UpdateCancellationRequest(string RequestID, string Result)
    {

        object result = 0;
        try
        {
            using (SqlCommand sqlcomm = new SqlCommand())
            {
                using (SqlConnection EoneConn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
                {
                    sqlcomm.Connection = EoneConn;
                    sqlcomm.Parameters.Add("@RequestID", SqlDbType.NChar).Value = RequestID;
                    sqlcomm.Parameters.Add("@CancellationResponse", SqlDbType.NChar).Value = Result;
                    sqlcomm.CommandText = "usp_TransactionCancellationUpdate";
                    sqlcomm.CommandType = CommandType.StoredProcedure;
                    if (EoneConn.State == ConnectionState.Closed)
                    {
                        EoneConn.Open();
                    }
                    result = sqlcomm.ExecuteScalar();
                    return Convert.ToUInt64(result);

                }
            }
        }

        catch (Exception ex)
        {
            return 0;
        }
        finally
        {

        }

    }



    public string CancelBASISPosting(string originatingbracode, string traseq)
    {

        string Result = string.Empty;
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("GTBPBSCO_CANCELLATION", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("INP_ORIGT_TRA_SEQ1", OracleType.VarChar).Value = traseq.Trim();
            oracomm.Parameters.Add("INP_ORIG_BRA_CODE", OracleType.VarChar).Value = originatingbracode.Trim();
            oracomm.Parameters.Add("OUT_RETURN_STATUS", OracleType.VarChar, 100).Direction = ParameterDirection.Output;
            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["OUT_RETURN_STATUS"].Value.ToString();

            oraconn.Close();

        }
        catch (Exception ex)
        {
            oraconn.Close();
            //   ErrHandler.WriteError(ex.Message);
            return ex.Message;
        }
        return Result;


    }



    public string CancellationRequest(string OrigbraCode, string tellerId, string origttraseq1, string applicationid, string tellerbracode, string cancelreason)
    {

        string cancellationrequestresult = "";
        UInt64 initiateresult = 0;
        string basiscancellationresult = "";

        initiateresult = InitiateCancellationRequest(OrigbraCode, tellerId, origttraseq1, applicationid, tellerbracode, cancelreason);

        if (initiateresult > 0)
        {

            basiscancellationresult = CancelBASISPosting(OrigbraCode, origttraseq1);

            UpdateCancellationRequest(initiateresult.ToString(), basiscancellationresult);


            if (basiscancellationresult.Equals("0"))
            {

                cancellationrequestresult = "Transaction Cancelled Succesfully";
            }
            else
            {

                cancellationrequestresult = "Cancellation Failed with error code : " + basiscancellationresult;

            }


        }
        else
        {

            cancellationrequestresult = "Error Initiating Request";


        }



        return cancellationrequestresult;


    }

    public string ConvertToNuban(string OldAccountNumber)//, string cus_num, string cur_code, string led_code, string sub_acct_code)
    {
        char acctsplit = Convert.ToChar("/");
        string[] accountkey = new string[4];//
        string bra_code = null;
        string cus_num = null;
        string cur_code = null;
        string led_code = null;
        string sub_acct_code = null;

        accountkey = OldAccountNumber.Trim().Split(acctsplit);
        bra_code = accountkey[0];
        cus_num = accountkey[1];
        cur_code = accountkey[2];
        led_code = accountkey[3];
        sub_acct_code = accountkey[4];

        OracleCommand OraSelect = new OracleCommand();
        OracleDataReader OraDrSelect;
        string NubanAccountNumber = null;


        try
        {
            using (OracleConnection OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationSettings.AppSettings["BASISConString_eone"])))
            {
                if (OraConn.State == ConnectionState.Closed)
                {
                    OraConn.Open();
                }
                OraSelect.Connection = OraConn;
                string selectquery = "select  MAP_ACC_NO from map_acct where bra_code = " + bra_code + " and cus_num = " + cus_num + "and cur_code = " + cur_code + "and led_code = " + led_code + " and sub_acct_code = " + sub_acct_code;// from map_acct where MAP_ACC_NO = '" + NubanAccountNumber + "'";
                OraSelect.CommandText = selectquery;
                OraSelect.CommandType = CommandType.Text;
                using (OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                {
                    if (OraDrSelect.HasRows == true)
                    {
                        OraDrSelect.Read();
                        NubanAccountNumber = OraDrSelect["MAP_ACC_NO"].ToString();
                        return NubanAccountNumber;

                    }
                    else
                    {
                        return "-2";
                    }
                }
            }
        }
        catch (Exception ex)
        {

            return "-1";
        }
        finally
        {

        }

    }

    public String RemoveBASISRestriction(int braCode, int cusNum, int curCode, int ledCode, int subAcctCode, int tellID, int restCode, int acctResSeq, string restText, int opeType)
    {
        //When opetype 1 = Add, opetype 3 = delete

        int Result = 1;
        OracleConnection oraconn = new OracleConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
        OracleCommand oracomm = new OracleCommand("GTB_RESTRICTION", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("INP_BRA_CODE", OracleType.Int32, 15).Value = braCode;
            oracomm.Parameters.Add("INP_CUS_NUM", OracleType.Int32, 15).Value = cusNum;
            oracomm.Parameters.Add("INP_CUR_CODE", OracleType.Int32, 15).Value = curCode;
            oracomm.Parameters.Add("INP_LED_CODE", OracleType.Int32, 15).Value = ledCode;
            oracomm.Parameters.Add("INP_SUB_ACCT_CODE", OracleType.Int32, 15).Value = subAcctCode;
            oracomm.Parameters.Add("inp_tell_ID", OracleType.Int32, 15).Value = tellID;
            oracomm.Parameters.Add("INP_REST_CODE", OracleType.Int32, 15).Value = restCode;
            oracomm.Parameters.Add("INP_ACCT_RES_SEQ", OracleType.Int32, 15).Value = acctResSeq;
            oracomm.Parameters.Add("INP_REST_TEXT", OracleType.VarChar, 100).Value = restText;
            oracomm.Parameters.Add("OPE_TYPE", OracleType.Double, 20).Value = 3;  //    opeType;
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.Int32, 100).Direction = ParameterDirection.Output;
            oracomm.ExecuteNonQuery();
            Result = Convert.ToInt32(oracomm.Parameters["RETURN_STATUS"].Value.ToString());
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
            Result = 2;
        }
        finally
        {
            oraconn.Close();
        }

        return Result.ToString();
    }

    public String AddBASISRestriction(int braCode, int cusNum, int curCode, int ledCode, int subAcctCode, int tellID, int restCode, int acctResSeq, string restText, int opeType)
    {
        //When opetype 1 = Add, opetype 3 = delete

        int Result = 1;
        OracleConnection oraconn = new OracleConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
        OracleCommand oracomm = new OracleCommand("GTB_RESTRICTION", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("INP_BRA_CODE", OracleType.Int32, 15).Value = braCode;
            oracomm.Parameters.Add("INP_CUS_NUM", OracleType.Int32, 15).Value = cusNum;
            oracomm.Parameters.Add("INP_CUR_CODE", OracleType.Int32, 15).Value = curCode;
            oracomm.Parameters.Add("INP_LED_CODE", OracleType.Int32, 15).Value = ledCode;
            oracomm.Parameters.Add("INP_SUB_ACCT_CODE", OracleType.Int32, 15).Value = subAcctCode;
            oracomm.Parameters.Add("inp_tell_ID", OracleType.Int32, 15).Value = tellID;
            oracomm.Parameters.Add("INP_REST_CODE", OracleType.Int32, 15).Value = restCode;
            oracomm.Parameters.Add("INP_ACCT_RES_SEQ", OracleType.Int32, 15).Value = acctResSeq;
            oracomm.Parameters.Add("INP_REST_TEXT", OracleType.VarChar, 100).Value = restText;
            oracomm.Parameters.Add("OPE_TYPE", OracleType.Double, 20).Value = 1;  //    opeType;
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.Int32, 100).Direction = ParameterDirection.Output;
            oracomm.ExecuteNonQuery();
            Result = Convert.ToInt32(oracomm.Parameters["RETURN_STATUS"].Value.ToString());
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
            Result = 2;
        }
        finally
        {
            oraconn.Close();
        }

        return Result.ToString();
    }

    public string ConvertToOldAccountNumber(string NubanAccountNumber)
    {
        using (OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
        {
            if (verifyNubanCheckDigit("058", NubanAccountNumber))
            {
                // NubanAccountNumber =  NubanAccountNumber;


                using (OracleCommand OraSelect = new OracleCommand())
                {
                    //Dim OraDrSelect As OracleDataReader
                    string bra_code = null;
                    string cus_num = null;
                    string cur_code = null;
                    string led_code = null;
                    string sub_acct_code = null;

                    try
                    {
                        if (OraConn.State == ConnectionState.Closed)
                        {
                            OraConn.Open();
                        }
                        OraSelect.Connection = OraConn;
                        string selectquery = "select  bra_code ,cus_num ,cur_code,led_code,sub_acct_code from map_acct where MAP_ACC_NO = '" + NubanAccountNumber + "'";
                        OraSelect.CommandText = selectquery;
                        OraSelect.CommandType = CommandType.Text;
                        using (OracleDataReader OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                        {
                            if (OraDrSelect.HasRows == true)
                            {
                                OraDrSelect.Read();
                                bra_code = OraDrSelect["bra_code"].ToString();
                                cus_num = OraDrSelect["cus_num"].ToString();
                                cur_code = OraDrSelect["cur_code"].ToString();
                                led_code = OraDrSelect["led_code"].ToString();
                                sub_acct_code = OraDrSelect["sub_acct_code"].ToString();
                                return Convert.ToString((Convert.ToString((Convert.ToString((Convert.ToString(bra_code + Convert.ToString("/")) + cus_num) + "/") + cur_code) + "/") + led_code) + "/") + sub_acct_code;
                            }
                            else
                            {
                                return "-2";
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        return "-1";
                    }
                    finally
                    {

                    }
                }
            }
            else
            {
                return "0";
            }
        }
    }

    public bool verifyNubanCheckDigit(string bankcode, string NubanAccountNumber)
    {
        NubanAccountNumber = bankcode + NubanAccountNumber.Trim();

        if (NubanAccountNumber.Length != 13)
        {
            // Need to decide on response codes;
            return false;
        }
        string NubanAcct = NubanAccountNumber.Substring(0, 12);

        try
        {
            int CheckDigitFromAcctNumber = Convert.ToInt16(NubanAccountNumber.Substring(12, 1));

            string MagicNumber = "373373373373";
            int TotalValue = 0;
            int calculatedCheckDigit = 0;
            for (int i = 0; i <= 11; i++)
            {
                TotalValue = TotalValue + (Convert.ToInt16(MagicNumber.Substring(i, 1)) * Convert.ToInt16(NubanAcct.Substring(i, 1)));
            }
            if ((TotalValue % 10) == 0)
            {
                calculatedCheckDigit = 0;

            }
            else
            {
                calculatedCheckDigit = 10 - (TotalValue % 10);
            }

            if (CheckDigitFromAcctNumber == calculatedCheckDigit)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception ex)
        {
            return false;
        }

    }

    public string NubanToOldAcct(string Nuban)
    {
        string xmlstring = "<Response>";

        if (Nuban.Length != 10)
        {
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>NUBAN should be 10 digits.</Error>";
            return xmlstring + "</Response>";
        }

        string oldAccount = ConvertToOldAccountNumber(Nuban);

        if (oldAccount.Split('/').GetLength(0) < 5)
        {
            xmlstring = xmlstring + "<CODE>1001</CODE>";
            xmlstring = xmlstring + "<Error>Confirm the NUBAN that was provided.</Error>";
            return xmlstring + "</Response>";
        }

        return xmlstring + "<CODE>1000</CODE>" + "<MESSAGE>" + oldAccount + "</MESSAGE>" + "</Response>";
    }


    public string AddRestriction(string userid, string branchcode, string customernum, string currencycode, string ledgercode, string subacctcode, string restrictcode, string restricttext)
    {

        string Result = string.Empty;
        xmlstring = "<Response>";
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("GTB_RESTRICT", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;

        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }

            oracomm.Parameters.Add("INP_TELLER_ID", OracleType.Number, 21).Value = userid;
            oracomm.Parameters.Add("INP_BRA_CODE", OracleType.Number, 21).Value = branchcode;
            oracomm.Parameters.Add("INP_CUS_NUM", OracleType.Number, 21).Value = customernum;
            oracomm.Parameters.Add("INP_CUR_CODE", OracleType.Number, 15).Value = currencycode;
            oracomm.Parameters.Add("INP_LED_CODE", OracleType.Number, 15).Value = ledgercode;
            oracomm.Parameters.Add("INP_SUB_ACCT_CODE", OracleType.Number, 15).Value = subacctcode;
            oracomm.Parameters.Add("INP_REST_CODE", OracleType.Number, 15).Value = restrictcode;
            oracomm.Parameters.Add("INP_REST_TEXT", OracleType.VarChar, 15).Value = restricttext;
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.Number, 15).Direction = ParameterDirection.Output;



            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
            oraconn.Close();


            //if (Result.CompareTo("0") == 0)
            if (Convert.ToInt32(Result) > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "<RESULT>" + Result + "</RESULT>";
                xmlstring = xmlstring + "</Response>";
            }

            // Any other BASIS error

            else
            {
                //Get BASIS Error Description

                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + GetBASISError(Convert.ToInt32(Result.Trim())) + "</Error>";
                xmlstring = xmlstring + "</Response>";

            }
        }

        // Any dotnet error

        catch (Exception ex)
        {

            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }



        oracomm = null;
        oraconn = null;



        return xmlstring;

    }

    public string AddRestriction(string userid, string nuban, string restrictcode, string restricttext)
    {

        //Convert to OldAccoutNo;
        Converter acc = new Converter(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        string accArray = acc.ConvertToOldAccountNumber(nuban);
        string branchcode = string.Empty;
        string customernum = string.Empty;
        string currencycode = string.Empty;
        string ledgercode = string.Empty;
        string subacctcode = string.Empty;

        //Check for valid result
        if (accArray.Contains("/"))
        {
            string[] tempAcc = accArray.Split('/');
            branchcode = tempAcc[0];
            customernum = tempAcc[1];
            currencycode = tempAcc[2];
            ledgercode = tempAcc[3];
            subacctcode = tempAcc[4];
        }
        string Result = string.Empty;
        xmlstring = "<Response>";
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("GTB_RESTRICT", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;

        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }

            oracomm.Parameters.Add("INP_TELLER_ID", OracleType.Number, 21).Value = userid;
            oracomm.Parameters.Add("INP_BRA_CODE", OracleType.Number, 21).Value = branchcode;
            oracomm.Parameters.Add("INP_CUS_NUM", OracleType.Number, 21).Value = customernum;
            oracomm.Parameters.Add("INP_CUR_CODE", OracleType.Number, 15).Value = currencycode;
            oracomm.Parameters.Add("INP_LED_CODE", OracleType.Number, 15).Value = ledgercode;
            oracomm.Parameters.Add("INP_SUB_ACCT_CODE", OracleType.Number, 15).Value = subacctcode;
            oracomm.Parameters.Add("INP_REST_CODE", OracleType.Number, 15).Value = restrictcode;
            oracomm.Parameters.Add("INP_REST_TEXT", OracleType.VarChar, 15).Value = restricttext;
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.Number, 15).Direction = ParameterDirection.Output;



            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
            oraconn.Close();


            //if (Result.CompareTo("0") == 0)
            if (Convert.ToInt32(Result) > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "<RESULT>" + Result + "</RESULT>";
                xmlstring = xmlstring + "</Response>";
            }

            // Any other BASIS error

            else
            {
                //Get BASIS Error Description

                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + GetBASISError(Convert.ToInt32(Result.Trim())) + "</Error>";
                xmlstring = xmlstring + "</Response>";

            }
        }

        // Any dotnet error

        catch (Exception ex)
        {

            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }



        oracomm = null;
        oraconn = null;



        return xmlstring;

    }

    public DataSet ExecuteBasisQuery(string encryptedQuery, int db)
    {
        DataSet result = null;
        OracleDataAdapter da;
        OracleCommandBuilder cb;

        string query = string.Empty;
        query = GTBEncryptLibrary.GTBEncryptLib.DecryptText(encryptedQuery);

        if (db == 1)
            OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        else
            OraConn = new OracleConnection(ConfigurationManager.AppSettings["EXADATAConString"]);

        using (OraConn)
        {
            using (OracleCommand OraSelect = new OracleCommand())
            {
                //Dim OraDrSelect As OracleDataReader
                try
                {
                    if (OraConn.State == ConnectionState.Closed)
                    {
                        OraConn.Open();
                    }
                    OraSelect.Connection = OraConn;

                    OraSelect.CommandText = query;
                    OraSelect.CommandType = CommandType.Text;

                    da = new OracleDataAdapter(OraSelect);
                    cb = new OracleCommandBuilder(da);
                    result = new DataSet();

                    da.Fill(result);
                }
                catch (Exception ex)
                {
                    ErrHandler.WriteError(ex.ToString());
                    OraConn.Close();
                    return result;
                }
                finally
                {
                    if (OraConn.State != ConnectionState.Closed)
                        OraConn.Close();
                }

                return result;
            }
        }

    }

    public string BasisError(string basisError)
    {
        string query = string.Empty;
        string Error_Desc = string.Empty;

        try
        {
            query = "select Error_Desc from BASIS_Transfer_Errors where Error_Code = '" + basisError + "'";

            SqlConnection conn = new SqlConnection(ConfigurationManager.AppSettings["e_oneConnString"].ToString());
            SqlDataReader reader;

            SqlCommand comm1 = new SqlCommand(query, conn);
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            try
            {
                reader = comm1.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    Error_Desc = reader["Error_Desc"].ToString();
                    conn.Close();

                    if (string.IsNullOrEmpty(Error_Desc))
                        return "Unknown error, Transaction unsuccessful";
                    else
                        return Error_Desc;
                }
                else
                {
                    conn.Close();
                    return "Unknown error, Transaction unsuccessful";
                }
            }
            catch (Exception ex)
            {
                ErrHandler.WriteError(ex.ToString());
                conn.Close();
                return "Unknown error, Transaction unsuccessful";
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.ToString());
            return "Unknown error, Transaction unsuccessful";
        }
    }

    public string RemoveRestriction(int tell_id, int branchcode, int customernum, int currencycode, int ledgercode, int subacctcode, int restrictcode, string restricttext, int restrictionseq, int opetype)
    {

        string Result = string.Empty;
        xmlstring = "<Response>";
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("GTB_RESTRICTION", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;

        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }

            oracomm.Parameters.Add("INP_BRA_CODE", OracleType.Number, 21).Value = branchcode;
            oracomm.Parameters.Add("INP_CUS_NUM", OracleType.Number, 21).Value = customernum;
            oracomm.Parameters.Add("INP_CUR_CODE", OracleType.Number, 15).Value = currencycode;
            oracomm.Parameters.Add("INP_LED_CODE", OracleType.Number, 15).Value = ledgercode;
            oracomm.Parameters.Add("INP_SUB_ACCT_CODE", OracleType.Number, 15).Value = subacctcode;
            oracomm.Parameters.Add("INP_TELL_ID", OracleType.Number, 21).Value = tell_id;
            oracomm.Parameters.Add("INP_REST_CODE", OracleType.Number, 15).Value = restrictcode;
            oracomm.Parameters.Add("INP_ACCT_RES_SEQ", OracleType.Number, 15).Value = restrictionseq;
            oracomm.Parameters.Add("INP_REST_TEXT", OracleType.VarChar, 15).Value = restricttext;
            oracomm.Parameters.Add("OPE_TYPE", OracleType.Number, 15).Value = opetype;
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.Number, 15).Direction = ParameterDirection.Output;

            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
            oraconn.Close();

            if (Result.CompareTo("0") == 0)
            //if (Convert.ToInt32(Result) == 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "</Response>";
            }

            // Any other BASIS error

            else
            {
                //Get BASIS Error Description

                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + GetBASISError(Convert.ToInt32(Result.Trim())) + "</Error>";
                xmlstring = xmlstring + "</Response>";

            }
        }

        // Any dotnet error

        catch (Exception ex)
        {

            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        oracomm = null;
        oraconn = null;


        return xmlstring;

    }

    public string BlockFunds_PM(string bracode, string cusnum, string curcode, string ledcode, string subacctcode, string remarks, string tra_amount, string expdate, string tellerid, string blkType, string blkTypeCode)
    {
        string Result = string.Empty;
        string Result2 = string.Empty;
        xmlstring = "<Response>";
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("EONEPKG.GTB_PLACE_BLK", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }

            string expirydate = Convert.ToDateTime(expdate).ToString("ddMMyyyy", CultureInfo.CreateSpecificCulture("en-GB"));
            oracomm.Parameters.Add("bra", OracleType.Number, 15).Value = bracode;
            oracomm.Parameters.Add("cus", OracleType.Number, 15).Value = cusnum;
            oracomm.Parameters.Add("cur", OracleType.Number, 30).Value = curcode;
            oracomm.Parameters.Add("led", OracleType.Number, 15).Value = ledcode;
            oracomm.Parameters.Add("sub", OracleType.Number, 30).Value = subacctcode;
            oracomm.Parameters.Add("expidate", OracleType.NVarChar, 15).Value = expirydate;// Convert.ToDateTime(expdate);
            oracomm.Parameters.Add("traamt", OracleType.Number, 15).Value = Convert.ToDecimal(tra_amount);
            oracomm.Parameters.Add("remarks", OracleType.VarChar, 30).Value = remarks;
            oracomm.Parameters.Add("inp_tellid", OracleType.Number, 15).Value = tellerid;
           // oracomm.Parameters.Add("tellid", OracleType.Number, 15).Value = tellerid;
            oracomm.Parameters.Add("blktype", OracleType.VarChar, 15).Value = blkType;
            oracomm.Parameters.Add("blkfuntypecode", OracleType.VarChar, 15).Value = blkTypeCode;
            oracomm.Parameters.Add("return_bloseq", OracleType.Number, 15).Direction = ParameterDirection.Output;

            oracomm.Parameters.Add("return_status", OracleType.Number, 15).Direction = ParameterDirection.Output;

            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
            Result2 = oracomm.Parameters["return_bloseq"].Value.ToString();
            oraconn.Close();


            if ((Convert.ToInt32(Result) == 0))
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS-" + Result2 + "</MESSAGE>";
                xmlstring = xmlstring + "</Response>";
            }
            else
            {
                //Get BASIS Error Description
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + GetBASISError(Convert.ToInt32(Result.Trim())) + "</Error>";
                xmlstring = xmlstring + "</Response>";
            }
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error> Result:" + Result + " " + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        oracomm = null;
        oraconn = null;

        return xmlstring;
    }

    //unblockfund immediate
    public int UnBlockFundimmediate(int braCode, int cusNum, int curCode, int ledCode, int subAcctCode, int bloSeq, double bloAmt, int tellID)
    {
        int Result = 1;
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"].ToString()));
        OracleCommand oracomm = new OracleCommand("GTB_EXPIRE_BLK", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("BRA", OracleType.Int32, 15).Value = braCode;
            oracomm.Parameters.Add("CUS", OracleType.Int32, 15).Value = cusNum;
            oracomm.Parameters.Add("CUR", OracleType.Int32, 15).Value = curCode;
            oracomm.Parameters.Add("LED", OracleType.Int32, 15).Value = ledCode;
            oracomm.Parameters.Add("SUB", OracleType.Int32, 15).Value = subAcctCode;
            oracomm.Parameters.Add("INP_BLO_SEQ", OracleType.Int32, 15).Value = bloSeq;
            oracomm.Parameters.Add("INP_BLO_AMT", OracleType.Double, 20).Value = bloAmt;
            oracomm.Parameters.Add("INP_TELL_ID", OracleType.Int32, 15).Value = tellID;
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.Int32, 100).Direction = ParameterDirection.Output;
            oracomm.ExecuteNonQuery();
            Result = Convert.ToInt32(oracomm.Parameters["RETURN_STATUS"].Value.ToString());


        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
            Result = 2;
        }
        finally
        {
            oraconn.Close();
        }
        return Result;
    }


    //unblockfund batch
    public int UnBlockFundbatch(int braCode, int cusNum, int curCode, int ledCode, int subAcctCode, int bloSeq, double bloAmt, int tellID, DateTime eff_Date)
    {
        int Result = 1, ope_Type = 1;
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"].ToString()));
        OracleCommand oracomm = new OracleCommand("GTB_ACCT_UNBLOCK", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("INP_BRA", OracleType.Int32, 15).Value = braCode;
            oracomm.Parameters.Add("INP_CUS", OracleType.Int32, 15).Value = cusNum;
            oracomm.Parameters.Add("INP_CUR", OracleType.Int32, 15).Value = curCode;
            oracomm.Parameters.Add("INP_LED", OracleType.Int32, 15).Value = ledCode;
            oracomm.Parameters.Add("INP_SUB", OracleType.Int32, 15).Value = subAcctCode;
            oracomm.Parameters.Add("INP_BLO_SEQ", OracleType.Int32, 15).Value = bloSeq;
            oracomm.Parameters.Add("INP_BLO_AMT", OracleType.Double, 20).Value = bloAmt;
            oracomm.Parameters.Add("INP_TELLER_ID", OracleType.Int32, 15).Value = tellID;
            oracomm.Parameters.Add("INP_EXP_DATE", OracleType.DateTime, 15).Value = eff_Date;
            oracomm.Parameters.Add("OPE_TYPE", OracleType.Int32, 15).Value = ope_Type;
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.Int32, 100).Direction = ParameterDirection.Output;
            oracomm.ExecuteNonQuery();
            Result = Convert.ToInt32(oracomm.Parameters["RETURN_STATUS"].Value.ToString());
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
            Result = 2;
        }
        finally
        {
            oraconn.Close();
        }
        return Result;
    }

    public string BankPort(string bvn, string mobilenumber)
    {
        string bra_code = "";
        string cus_num = "";
        string cur_code = "";
        string led_code = "";
        string sub_acct_code = "";
        string[] accountkey = new string[4];
        string InternalAcctFormat = string.Empty;
        Double amt = 0.0;
        Double clebal = 0.0;
        string mResponse = "";
        string canprocess = "1";
        string IP = "";// GetCustomerIP();
        string sessionid = DateTime.Now.Ticks.ToString();

        string accountexist = checkIfMobileNumberExist(mobilenumber);
        if (!string.IsNullOrEmpty(accountexist)) // this mobile number is associated with an account cannot continue
        {
            if (accountexist.Contains("Error|"))
            {
                canprocess = "1"; //todo cahnge to 0 before deployment to live
                mResponse = "01"; //Internal Error
                amt = 0;
            }
            else if (accountexist.Trim().Equals("1"))
            {

                canprocess = "1";//todo cahnge to 0 before deployment to live
                mResponse = "02"; //Account already linked
                amt = 0;

            }

        }


        string requestexist = CheckGTPortRequest(bvn);

        if (!string.IsNullOrEmpty(requestexist)) // this mobile number is associated with an account cannot continue
        {

            if (requestexist.ToLower().Contains("error")) //errror occured checking if succesful bvn exist
            {
                canprocess = "0";
                mResponse = "11";
            }
            else //succesful bvn request exist
            {
                canprocess = "0";
                mResponse = "12";

            }


        }

        string bvnalreadylinked = CheckIfBvnExist(bvn);

        if (!string.IsNullOrEmpty(bvnalreadylinked)) // this mobile number is associated with an account cannot continue
        {

            if (bvnalreadylinked.ToLower().Contains("error")) //errror occured checking if succesful bvn exist
            {
                canprocess = "0";
                mResponse = "11";
            }
            else //succesful bvn request exist
            {
                canprocess = "0";
                mResponse = "13";

            }


        }





        if (!Information.IsNumeric(bvn))
        {

            canprocess = "0";
            canprocess = "0";
            mResponse = "03"; //Invalid BVN

        }


        UInt64 insertresp = LogBankPortRequest(mobilenumber, bvn, "SMS");


        string ResultStatus = string.Empty;
        string Bvn = string.Empty;
        string FirstName = string.Empty;
        string MiddleName = string.Empty;
        string LastName = string.Empty;
        string DateOfBirth = string.Empty;
        string PhoneNumber = string.Empty;
        string RegistrationDate = string.Empty;
        string EnrollmentBank = string.Empty;
        string EnrollmentBranch = string.Empty;
        string sign = string.Empty;


        if (insertresp > 0)
        {
            if (canprocess.Equals("1")) // the account number is classified as ok to proceed
            {

                NIPService nip_web_serv = new NIPService();

                nip_web_serv.Url = ConfigurationManager.AppSettings["nip_web_serv_url"];


                string nip_resp = string.Empty;

                XmlElement BVNResponse;
                BVNResponse = (XmlElement)nip_web_serv.BVNLinker(bvn, "058");

                if (BVNResponse == null)
                {
                    // WebMsgBox.Show("Your request cannot be completed at the moment, Kindly try again later");
                    //   return;

                }


                if (string.IsNullOrEmpty(BVNResponse.ToString()))
                {
                    //   WebMsgBox.Show("Your request cannot be completed at the moment, Kindly try again later");
                    // return;
                }



                XmlDocument document = null;
                XPathNavigator navigator = null;
                XPathNodeIterator snodes = null;

                navigator = BVNResponse.CreateNavigator();
                snodes = navigator.Select("/ResultStatus");
                snodes.MoveNext();
                ResultStatus = snodes.Current.Value;

                if (ResultStatus.Trim().Equals("00"))
                {
                    snodes = navigator.Select("/BvnSearchResult/Bvn");
                    snodes.MoveNext();
                    Bvn = snodes.Current.Value;

                    snodes = navigator.Select("/BvnSearchResult/FirstName");
                    snodes.MoveNext();
                    FirstName = snodes.Current.Value;

                    snodes = navigator.Select("/BvnSearchResult/MiddleName");
                    snodes.MoveNext();
                    MiddleName = snodes.Current.Value;

                    snodes = navigator.Select("/BvnSearchResult/LastName");
                    snodes.MoveNext();
                    LastName = snodes.Current.Value;

                    snodes = navigator.Select("/BvnSearchResult/DateOfBirth");
                    snodes.MoveNext();
                    DateOfBirth = snodes.Current.Value;

                    snodes = navigator.Select("/BvnSearchResult/PhoneNumber");
                    snodes.MoveNext();
                    PhoneNumber = snodes.Current.Value;

                    snodes = navigator.Select("/BvnSearchResult/RegistrationDate");
                    snodes.MoveNext();
                    RegistrationDate = snodes.Current.Value;

                    snodes = navigator.Select("/BvnSearchResult/EnrollmentBank");
                    snodes.MoveNext();
                    EnrollmentBank = snodes.Current.Value;

                    snodes = navigator.Select("/BvnSearchResult/EnrollmentBranch");
                    snodes.MoveNext();
                    EnrollmentBranch = snodes.Current.Value;

                    snodes = navigator.Select("/BvnSearchResult/ImageBase64");
                    snodes.MoveNext();
                    sign = snodes.Current.Value;
                }

                string piped_resp_from_NIBSS = ResultStatus + "|" + Bvn + "|" + FirstName + "|" + LastName + "|" + DateOfBirth + "|" + PhoneNumber + "|" + RegistrationDate + "|" + EnrollmentBank + "|" + EnrollmentBranch;


                if (ResultStatus == "00")
                {
                    if (PhoneNumber.Trim().Equals(mobilenumber)) // Ok To port
                    {
                        mResponse = "00";
                    }
                    else // Need to send request from mobile number registered with the other bank
                    {
                        mResponse = "04";
                    }

                }
                else //bvn does not exist
                {
                    mResponse = "05";
                }
            }
            else // cannot log request
            {

                //  mResponse = "06";


            }

            UpdateGTPortRequest(insertresp, sign, FirstName, LastName, EnrollmentBank, mResponse);


        }
        else // cannot log request
        {




        }

        return GenerateBankPortResponse(sessionid, bvn, mResponse);

    }



    public bool UpdateGTPortRequest(UInt64 RequestID, string CusImage, string FirstName, string LastName, string SourceBankCode, string ResponseCode)
    {


        SqlConnection e_OneConn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
        SqlCommand cmdSQLselect = new SqlCommand();
        SqlParameter PmRequestID = new SqlParameter("@RequestID", RequestID);

        SqlParameter PmCusImage = new SqlParameter("@CusImage", CusImage);
        SqlParameter PmFirstName = new SqlParameter("@FirstName", FirstName);
        SqlParameter PmLastName = new SqlParameter("@LastName", LastName);
        SqlParameter PmSourceBankCode = new SqlParameter("@SourceBankCode", SourceBankCode);
        SqlParameter PmResponseCode = new SqlParameter("@ResponseCode", ResponseCode);


        try
        {
            // Add Parameter to command Object
            PmRequestID.SqlDbType = SqlDbType.Int;
            cmdSQLselect.Parameters.Add(PmRequestID);
            cmdSQLselect.Parameters.Add(PmCusImage);
            cmdSQLselect.Parameters.Add(PmFirstName);
            cmdSQLselect.Parameters.Add(PmLastName);
            cmdSQLselect.Parameters.Add(PmSourceBankCode);
            cmdSQLselect.Parameters.Add(PmResponseCode);

            if (e_OneConn.State == ConnectionState.Closed)
            {
                e_OneConn.Open();
            }
            cmdSQLselect.Connection = e_OneConn;
            cmdSQLselect.CommandText = "usp_GTPortRequestsUpdate";
            cmdSQLselect.CommandType = CommandType.StoredProcedure;
            cmdSQLselect.ExecuteNonQuery();
            return true;
        }
        catch (Exception ex)
        {

            return false;

            // ErrLog.AppLogWrite(ex.Message + " - " + "AirTime Purchase  ", true);

        }
        finally
        {
            if (e_OneConn.State == ConnectionState.Open)
            {
                e_OneConn.Close();
                cmdSQLselect.Dispose();
            }
        }
    }

    private string GenerateBankPortResponse(string mSessionID, string mAccountNo, string mResponse)
    {


        string response = "";
        if (mResponse.Equals("00"))
        {

            response = mResponse + "|" + response + "GTBank Account Migration" + Environment.NewLine;
            response = response + "Your Account Migration request was successful, please check your phone for an sms containing your account number." + Environment.NewLine;
            response = response + "Thank you for choosing GTBank.";

        }
        else if (mResponse.Equals("01"))
        {

            response = mResponse + "|" + response + "GTBank Account Migration" + Environment.NewLine;
            response = response + "Your Account Migration request failed, Please try again" + Environment.NewLine;
            response = response + "Thank you for choosing GTBank.";
            response = response + "CORRECT FORMAT: MIGRATE BVN";

        }
        else if (mResponse.Equals("02"))
        {

            response = mResponse + "|" + response + "GTBank Account Migration" + Environment.NewLine;
            response = response + "Your Account Migration request failed, the mobile number is already associated with an existing account." + Environment.NewLine;
            response = response + "Thank you for choosing GTBank.";
            response = response + "CORRECT FORMAT: MIGRATE BVN";

        }
        else if (mResponse.Equals("04"))
        {

            response = mResponse + "|" + response + "GTBank Account Migration" + Environment.NewLine;
            response = response + "Your Account Migration request failed, please send the request from the Mobile number used during your BVN registration." + Environment.NewLine;
            response = response + "Thank you for choosing GTBank.";
            response = response + "CORRECT FORMAT: MIGRATE BVN";

        }
        else if (mResponse.Equals("05"))
        {

            response = mResponse + "|" + response + "GTBank Account Migration" + Environment.NewLine;
            response = response + "Your Account Migration request failed, BVN data does not exist on NIBSS system." + Environment.NewLine;
            response = response + "Thank you for choosing GTBank.";
            response = response + "CORRECT FORMAT: MIGRATE BVN";

        }
        else if (mResponse.Equals("06"))
        {

            response = mResponse + "|" + response + "GTBank Account Migration" + Environment.NewLine;
            response = response + "Your Account Migration request failed, an internal error occured, please try again." + Environment.NewLine;
            response = response + "Thank you for choosing GTBank.";
            response = response + "CORRECT FORMAT: MIGRATE BVN";

        }
        else if (mResponse.Equals("11"))
        {

            response = mResponse + "|" + response + "GTBank Account Migration" + Environment.NewLine;
            response = response + "Your Account Migration request failed, an internal error occured, please try again." + Environment.NewLine;
            response = response + "Thank you for choosing GTBank.";
            response = response + "CORRECT FORMAT: MIGRATE BVN";

        }

        else if (mResponse.Equals("12"))
        {

            response = mResponse + "|" + response + "GTBank Account Migration" + Environment.NewLine;
            response = response + "Your Account Migration request failed, a request already exist for this BVN." + Environment.NewLine;
            response = response + "Thank you for choosing GTBank.";
            response = response + "CORRECT FORMAT: MIGRATE BVN";

        }
        else if (mResponse.Equals("13"))
        {

            response = mResponse + "|" + response + "GTBank Account Migration" + Environment.NewLine;
            response = response + "Your Account Migration request failed, this bvn is already linked to an existing account." + Environment.NewLine;
            response = response + "Thank you for choosing GTBank.";
            response = response + "CORRECT FORMAT: MIGRATE BVN";

        }



        return response;
    }



    public string CheckGTPortRequest(string bvn)
    {

        string bvnresponse = string.Empty;
        using (SqlConnection OraConn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
        {
            using (SqlCommand OraSelect = new SqlCommand())
            {
                SqlDataReader OraDrSelect;


                try
                {
                    if (OraConn.State == ConnectionState.Closed)
                    {
                        OraConn.Open();
                    }
                    OraSelect.Connection = OraConn;
                    string selectquery = "GetBvnCode";
                    OraSelect.Parameters.AddWithValue("@bvn", bvn);
                    OraSelect.CommandText = selectquery;
                    OraSelect.CommandType = CommandType.StoredProcedure;
                    using (OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                    {

                        if (OraDrSelect.Read())
                        {
                            bvnresponse = OraDrSelect["bvn"].ToString();

                            //   returnaccount = bvnresponse;



                        }

                    }
                }
                catch (Exception ex)
                {

                    bvnresponse = "Error|" + ex.Message;
                }
                finally
                {
                    if (OraConn.State == ConnectionState.Open)
                    {
                        OraConn.Close();
                    }
                    OraConn.Dispose();
                }
            }
            return bvnresponse;
        }

    }

    public string CheckIfBvnExist(string bvn)
    {

        string bvnresponse = string.Empty;
        using (SqlConnection OraConn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString()))
        {
            using (SqlCommand OraSelect = new SqlCommand())
            {
                SqlDataReader OraDrSelect;


                try
                {
                    if (OraConn.State == ConnectionState.Closed)
                    {
                        OraConn.Open();
                    }
                    OraSelect.Connection = OraConn;
                    string selectquery = "GetBVNPort";
                    OraSelect.Parameters.AddWithValue("@bvn", bvn);
                    OraSelect.CommandText = selectquery;
                    OraSelect.CommandType = CommandType.StoredProcedure;
                    using (OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                    {

                        if (OraDrSelect.Read())
                        {
                            bvnresponse = OraDrSelect["bvn"].ToString();

                            //   returnaccount = bvnresponse;



                        }

                    }
                }
                catch (Exception ex)
                {

                    bvnresponse = "Error|" + ex.Message;
                }
                finally
                {
                    if (OraConn.State == ConnectionState.Open)
                    {
                        OraConn.Close();
                    }
                    OraConn.Dispose();
                }
            }
            return bvnresponse;
        }

    }




    private string checkIfMobileNumberExist(string mobileNum)
    {
        string exist = string.Empty;
        string returnaccount = "";
        using (OracleConnection OraConn = new OracleConnection(ConfigurationManager.AppSettings["EXADATAConString"]))
        {
            using (OracleCommand OraSelect = new OracleCommand())
            {
                OracleDataReader OraDrSelect;

                double cntbal = 0;

                try
                {
                    if (OraConn.State == ConnectionState.Closed)
                    {
                        OraConn.Open();
                    }
                    OraSelect.Connection = OraConn;
                    string selectquery = "select  stg.EONEPKG.MOBILE_AVAIL( " + mobileNum + " ) as mobnumexist from dual";

                    OraSelect.CommandText = selectquery;
                    OraSelect.CommandType = CommandType.Text;
                    using (OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        int count = 0;
                        if (OraDrSelect.Read())
                        {
                            exist = OraDrSelect["mobnumexist"].ToString();

                        }

                    }
                }
                catch (Exception ex)
                {


                    exist = "Error|" + ex.Message;
                }
                finally
                {
                    if (OraConn.State == ConnectionState.Open)
                    {
                        OraConn.Close();
                    }
                    OraConn.Dispose();
                }
            }
            return exist;
        }

    }

    public UInt64 LogBankPortRequest(string MobileNumber, string Bvn, string source)
    {

        //    [dbo].[usp_GTPortRequestsInsert] 
        //@MobileNumber nvarchar(50),
        //@Bvn nvarchar(20) = NULL


        SqlCommand cmdSQLselect = new SqlCommand();
        SqlConnection e_OneConn = new SqlConnection(ConfigurationManager.ConnectionStrings["e_oneConnString"].ToString());
        SqlParameter PmMobileNumber = new SqlParameter("@MobileNumber", MobileNumber);
        SqlParameter PmBvn = new SqlParameter("@Bvn", Bvn);
        SqlParameter PmSource = new SqlParameter("@Source", source);

        try
        {

            cmdSQLselect.Parameters.Add(PmMobileNumber);
            cmdSQLselect.Parameters.Add(PmBvn);
            cmdSQLselect.Parameters.Add(PmSource);

            if (e_OneConn.State == ConnectionState.Closed)
            {
                e_OneConn.Open();
            }
            cmdSQLselect.Connection = e_OneConn;
            cmdSQLselect.CommandText = "usp_GTPortRequestsInsert";
            cmdSQLselect.CommandType = CommandType.StoredProcedure;
            return Convert.ToUInt64(cmdSQLselect.ExecuteScalar());
        }
        catch (Exception ex)
        {

            return 0;
        }
        finally
        {
            if (e_OneConn.State == ConnectionState.Open)
            {
                e_OneConn.Close();
                cmdSQLselect.Dispose();
            }
        }
    }

    public int DeleteBlockImmediate(int braCode, int cusNum, int curCode, int ledCode, int subAcctCode, int bloSeq, double bloAmt, int tellID)
    {
        int Result = 1;
        try
        {

            using (OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"].ToString())))
            {
                OracleCommand oracomm = new OracleCommand("EONEPKG.GTB_REMOVE_BLK", oraconn);
                oracomm.CommandType = CommandType.StoredProcedure;
                if (oraconn.State == ConnectionState.Closed)
                {
                    oraconn.Open();
                }
                oracomm.Parameters.Add("BRA", OracleType.Int32, 15).Value = braCode;
                oracomm.Parameters.Add("CUS", OracleType.Int32, 15).Value = cusNum;
                oracomm.Parameters.Add("CUR", OracleType.Int32, 15).Value = curCode;
                oracomm.Parameters.Add("LED", OracleType.Int32, 15).Value = ledCode;
                oracomm.Parameters.Add("SUB", OracleType.Int32, 15).Value = subAcctCode;
                oracomm.Parameters.Add("TRAAMT", OracleType.Int32, 15).Value = bloAmt;
                oracomm.Parameters.Add("INP_TELLID", OracleType.Int32, 15).Value = tellID;
                oracomm.Parameters.Add("BLOSEQ", OracleType.Int32, 15).Value = bloSeq;
                //oracomm.Parameters.Add("INP_BLO_AMT", OracleType.Double, 20).Value = bloAmt;

                oracomm.Parameters.Add("RETURN_STATUS", OracleType.Int32, 100).Direction = ParameterDirection.Output;
                oracomm.ExecuteNonQuery();
                Result = Convert.ToInt32(oracomm.Parameters["RETURN_STATUS"].Value.ToString());
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + " Stack Trace ==> " + ex.StackTrace);
            Result = 2;
        }
        return Result;
    }

    internal DataSet GetTellersPerBranch(int braCode)
    {
        DataSet dtTellers = new DataSet();
        string query = string.Format("select tell_id, cus_sho_name AS USER_NAME from teller  where bra_code = {0} and cus_num > 0", braCode);

        using (OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            OracleCommand oracomm = new OracleCommand(query, oraconn);
            oracomm.CommandType = CommandType.Text;

            OracleDataAdapter apt = new OracleDataAdapter(oracomm);
            apt.Fill(dtTellers);

        }
        return dtTellers;
    }

    public DataTable GetAccountName(int bra_code, int cusNum, int cur_code, int led_code, int sub_acct_code)
    {
        DataTable dt = new DataTable();
        string queryString;
        using (OracleConnection conn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
        {
            queryString = "select get_name2(" + bra_code + "," + cusNum + "," + cur_code + "," + led_code + "," + sub_acct_code + ") cus_sho_name FROM DUAL";

            OracleDataAdapter adapter = new OracleDataAdapter(queryString, conn);
            try
            {
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }
                adapter.Fill(dt);
            }
            catch (Exception ex)
            {
                ErrHandler.WriteError("Error getting calling GetAccountName in BASIS class: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
        return dt;
    }

    public string CheckTransactionExist(string bra_code, string cus_num, string cur_code, string led_code, string sub_acct_code, double tra_amt, string remark, string expl_code, int deb_cre_ind)
    {
        string Result = string.Empty;
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        DataTable dt;
        String query_str = null;

        try
        {
            oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));

            // create the command for the function
            query_str = "Select count(1) From Tell_Act" + " Where bra_code = " + bra_code + " And cus_num = " + cus_num +

                     " And cur_code = " + cur_code + " And led_code = " + led_code + " And sub_acct_code = " + sub_acct_code +

                     " And tra_amt = " + tra_amt + " And Deb_Cre_Ind = " + deb_cre_ind + " And expl_code = " + expl_code + " And remarks like '%" + remark + "%'";

            oraconn.Open();
            cmd = new OracleCommand(query_str, oraconn);

            int resp = Convert.ToInt16(cmd.ExecuteScalar());
            //ora_adpt = new OracleDataAdapter(cmd);
            //dt = new DataTable();

            //ora_adpt.Fill(dt);

            xmlstring = "<Response>";

            if (resp == 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>" + "SUCCESS" + "</MESSAGE>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "EXISTS" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";

            dt = null;
            ora_adpt = null;
            cmd = null;
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public string SearchOFACList(string cus_sho_name)
    {
        string countOfSplitname_1 = null;
        string countOfSplitname_2 = null;
        string countOfSplitname_3 = null;
        string Result = string.Empty;
        char[] delimiters = new char[] { ' ' };
        string[] parts = cus_sho_name.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
        int countOfSplitname = parts.Length;
        if (countOfSplitname == 2)
        {
            countOfSplitname_1 = parts[0].ToUpper();
            countOfSplitname_2 = parts[1].ToUpper();
        }
        else if (countOfSplitname == 3)
        {
            countOfSplitname_1 = parts[0].ToUpper();
            countOfSplitname_2 = parts[1].ToUpper();
            countOfSplitname_3 = parts[2].ToUpper();

        }
        else
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1003</CODE>";
            xmlstring = xmlstring + "<Error>" + "NAMES MUST BE EITHER TWO OR THREE" + "</Error>";
            xmlstring = xmlstring + "</Response>";
            return xmlstring;
        }
        OracleCommand cmd;
        OracleConnection oraconn;
        OracleDataAdapter ora_adpt;
        DataTable dt;
        String query_str = null;

        try
        {
            oraconn = new OracleConnection(ConfigurationManager.AppSettings["EXADATAConString"]);
            if (countOfSplitname == 2)
            {
                // create the command for the function
                query_str = "select cname from bg5 where upper(cname) like '%" + countOfSplitname_1 + "%" + countOfSplitname_2 +
                    "%'union all select cname from bg5 where upper(cname) like '%" + countOfSplitname_2 + "%" + countOfSplitname_1 + "%'";
            }
            if (countOfSplitname == 3)
            {
                query_str = "select cname from bg5 where upper(cname) like '%" + countOfSplitname_1 + "%" + countOfSplitname_2 +
                        "%' union all select cname from bg5 where upper(cname) like '%" + countOfSplitname_2 + "%" + countOfSplitname_1 +
                        "%' union all select cname from bg5 where upper(cname) like '%" + countOfSplitname_1 + "%" + countOfSplitname_3 +
                    "%' union all select cname from bg5 where upper(cname) like '%" + countOfSplitname_3 + "%" + countOfSplitname_1 +
                    "%' union all select cname from bg5 where upper(cname) like '%" + countOfSplitname_2 + "%" + countOfSplitname_3 +
                    "%' union all select cname from bg5 where upper(cname) like '%" + countOfSplitname_3 + "%" + countOfSplitname_2 + "%'";
            }
            oraconn.Open();
            cmd = new OracleCommand(query_str, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            dt = new DataTable();

            ora_adpt.Fill(dt);

            xmlstring = "<Response>";

            if (dt.Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<NAMEDETAILS>";
                foreach (DataRow dr in dt.Rows)
                {
                    //GET RATE               

                    xmlstring = xmlstring + "<NAMELIKE>" + dr["cname"] + "</NAMELIKE>";
                }
                xmlstring = xmlstring + "</NAMEDETAILS>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "NO NAME" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";

            dt = null;
            ora_adpt = null;
            cmd = null;
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
    }

    public double GetSalaryAdvanceEligibilityStatus(string braCode, string cusNum)
    {

        OracleCommand OraSelect = new OracleCommand();
        OracleDataReader OraDrSelect = default(OracleDataReader);
        double currentSalary = 0;
        ErrHandler ErrHandler = new ErrHandler();
        OracleConnection ConnHoBank_Test = new OracleConnection(ConfigurationManager.AppSettings["EXADATAconstring"]);
        try
        {
            if (ConnHoBank_Test.State == ConnectionState.Closed)
            {
                ConnHoBank_Test.Open();
            }

            OraSelect.Connection = ConnHoBank_Test;
            string query = "select average_salary From stg.gtb_salary_advance@exadata_dr where bra_code = " + braCode + " And cus_num = " + cusNum;

            OraSelect.CommandText = query;

            OraSelect.CommandType = CommandType.Text;

            OraDrSelect = OraSelect.ExecuteReader();


            if (OraDrSelect.HasRows == true)
            {
                if (OraDrSelect.Read())
                {
                    currentSalary = Convert.ToDouble(OraDrSelect["average_salary"]);
                }
                else
                {
                    currentSalary = 0;
                }
            }
            else
            {
                currentSalary = 0;
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("An error occured connecting to EXADATA to retrieve customer prequalification status : " + ex.Message);
            currentSalary = 0;
        }
        finally
        {
            if (ConnHoBank_Test.State == ConnectionState.Open)
            {
                ConnHoBank_Test.Close();
            }
        }
        return currentSalary;
    }

    public string ProcessSalaryAdvanceAutoCredit(string AccttoCredit, double RequestAmount, double CustomerSalary, string MaturityDate)
    {

        string Result = string.Empty;
        string[] accountdetails = AccttoCredit.Split('/');

        double rate = Convert.ToDouble(ConfigurationManager.AppSettings["SalaryAdvanceRate"]);
        using (OracleConnection oraconn = new OracleConnection((GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]))))
        {

            using (OracleCommand oracomm = new OracleCommand("eonepkg1.GTB_SAL_ADVN_INTEREST_RATE", oraconn))
            {
                oracomm.CommandType = CommandType.StoredProcedure;
                oracomm.CommandTimeout = 60;
                try
                {
                    if (oraconn.State == ConnectionState.Closed)
                    {
                        oraconn.Open();

                    }

                    oracomm.Parameters.Add("INP_BRA", OracleType.NVarChar, 4).Value = accountdetails[0];
                    oracomm.Parameters.Add("INP_CUS", OracleType.NVarChar, 7).Value = accountdetails[1];
                    oracomm.Parameters.Add("INP_CUR", OracleType.NVarChar, 3).Value = accountdetails[2];
                    oracomm.Parameters.Add("INP_LED", OracleType.NVarChar, 4).Value = accountdetails[3];
                    oracomm.Parameters.Add("INP_SUB", OracleType.NVarChar, 4).Value = accountdetails[4];
                    oracomm.Parameters.Add("INP_RATE", OracleType.Double, 15).Value = rate;
                    oracomm.Parameters.Add("INP_TELL_ID", OracleType.NVarChar, 6).Value = "9938";
                    oracomm.Parameters.Add("INP_SAL_ADVN_AVAIL", OracleType.Double, 15).Value = RequestAmount;
                    oracomm.Parameters.Add("INP_CUST_SALARY", OracleType.Double, 15).Value = CustomerSalary;
                    oracomm.Parameters.Add("INP_LIM_MAT_DATE", OracleType.DateTime, 15).Value = MaturityDate;
                    oracomm.Parameters.Add("RETURN_STATUS", OracleType.Double, 100).Direction = ParameterDirection.Output;
                    oracomm.ExecuteNonQuery();

                    Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
                }
                catch (Exception ex)
                {
                    ErrHandler.WriteError("Error processing Salary advance auto Credit " + ex.Message);

                }
                finally
                {
                    oraconn.Close();
                }
                return Result;
            }
        }
    }

    public string CreateAdditionalAccount(int braCode, int cusNum, int curCode, int ledCode, int tellerID, string reason, Int64 intUserID, string channel, string creator, string docAlp)
    {
        StringBuilder xmlString = new StringBuilder("<Response>");
        try
        {
            string[] acctNumbers = ConfigurationManager.AppSettings["AddAcctLedgers"].Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            int acctCount = Convert.ToInt16(ConfigurationManager.AppSettings["MaxAddAcctCount"]);

            if (acctNumbers.Contains(ledCode.ToString()) == false)
            {
                xmlString.Append("<Code>1001</Code><Error>Additional Account cannot be opened on Existing Account!</Error></Response>");
                return xmlString.ToString();
            }

            DataTable dtAccts = GetDetailsPerAccount(braCode, cusNum, curCode, ledCode);
            if (dtAccts != null && dtAccts.Rows.Count > 0)
            {
                //First check the account rows
                if (dtAccts.Rows.Count >= acctCount)
                {
                    xmlString.Append("<Code>1001</Code><Error>Error! Maximum Number of Sub Accounts Reached!</Error></Response>");
                    return xmlString.ToString();
                }

                //then check for restrictions
                DataRow[] dwResRows = dtAccts.Select("resCount > 0");
                if (dwResRows.Any())
                {
                    xmlString.Append("<Code>1001</Code><Error>Error! Existing Primary Account has restrictions</Error></Response>");
                    return xmlString.ToString();
                }

                //then check for available bal
                DataRow[] dwBalRows = dtAccts.Select("availbal < 0");
                if (dwBalRows.Any())
                {
                    xmlString.Append("<Code>1001</Code><Error>Error! Existing Primary Account has negative Account Balance</Error></Response>");
                    return xmlString.ToString();
                }

                //then check for dormant acct
                DataRow[] dwstatus = dtAccts.Select("sta_code <> 1");
                if (dwstatus.Any())
                {
                    xmlString.Append("<Code>1001</Code><Error>Error! Existing Primary Account is dormant</Error></Response>");
                    return xmlString.ToString();
                }

                int newSubAcctCode = 0;
                int result = CreateSubAccount(braCode, cusNum, curCode, ledCode, tellerID, out newSubAcctCode);
                string fullAcctKey = string.Format("{0}/{1}/{2}/{3}/{4}", braCode, cusNum, curCode, ledCode, newSubAcctCode);
                if (result == 0)
                {

                    int eoneResult = new Eone().Insert_Account(intUserID, cusNum, braCode, ledCode, newSubAcctCode, fullAcctKey, reason, creator, channel, docAlp);
                    if (eoneResult > 0)
                    {
                        xmlString.Append("<Code>1000</Code>");
                        xmlString.Append("<Message>Sub Account successfully created!</Message>");

                    }
                    else
                    {
                        xmlString.Append("<Code>1000</Code><Message>Sub Account successfully created but unable to insert for balance Enquiry!</Message>");
                    }
                    xmlString.Append("<SubAcctCode>" + newSubAcctCode + "</SubAcctCode>");
                    xmlString.Append("<FullAcctKey>" + fullAcctKey + "</FullAcctKey>");
                    xmlString.Append("<Nuban>" + ConvertToNuban(fullAcctKey) + "</Nuban>");
                    xmlString.Append("</Response>");
                }
                else if (result == 7998)
                {
                    xmlString.Append("<Code>1001</Code><Error>Maximum Number of Sub Accounts Reached!</Error></Response>");
                    return xmlString.ToString();
                }
                else
                {
                    ErrHandler.WriteError(String.Format("Response from Basis Procedure: {0}  when creating Additional Account :{1}", result, fullAcctKey));
                    xmlString.Append("<Code>1001</Code><Error>Unable to create Sub Account! Please try again later!</Error></Response>");
                    return xmlString.ToString();
                }
            }
            else
            {
                xmlString.Append("<Code>1001</Code><Error>Customer Account does not exist</Error></Response>");
                return xmlString.ToString();
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.StackTrace);
            xmlString.Append("<Code>1002</Code><Error>Unspecified Error opening additional Account</Error></Response>");
        }
        return xmlString.ToString();
    }


    public DataTable GetDetailsPerAccount(int bra_code, int cus_num, int cur_code, int led_code)
    {
        //string query = "Select acct_Res_seq, rest_code, text_rest from acct_res where bra_code = :braCode and cus_num = :cusNum and cur_code =:curCode and led_code = :ledCode and sub_acct_code = :subAcctCode";

        String query = @"select bra_code, cus_num, cur_code, led_code, sub_acct_code, sta_code,
                       navailbal(a.bra_code, a.cus_num, a.cur_code, a.led_code, a.sub_acct_code) availbal,
                       get_name1(a.bra_code, a.cus_num, a.cur_code, a.led_code, a.sub_acct_code)cusName,
                       (select count(acct_Rest_seq) from acct_res r 
                        where r.bra_code = a.bra_code and r.cus_num = a.cus_num and r.cur_code = a.cur_code 
                        and r.led_code = a.led_code and a.sub_acct_code = r.sub_acct_code)resCount
                        from account a 
                        where a.bra_code = :braCode and a.cus_num = :cusNum and a.cur_code = :curCode and a.led_code = :ledCode";


        DataTable dtRestrictions = new DataTable();

        using (OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            OracleCommand oracomm = new OracleCommand(query, oraconn);
            oracomm.CommandType = CommandType.Text;
            oracomm.Parameters.AddWithValue(":braCode", bra_code);
            oracomm.Parameters.AddWithValue(":cusNum", cus_num);
            oracomm.Parameters.AddWithValue(":curCode", cur_code);
            oracomm.Parameters.AddWithValue(":ledCode", led_code);

            OracleDataAdapter apt = new OracleDataAdapter(oracomm);
            apt.Fill(dtRestrictions);
        }
        return dtRestrictions;
    }


    int CreateSubAccount(int braCode, int cusNum, int curCode, int ledCode, int tellerID, out int subAcctCode)
    {
        subAcctCode = -1;
        int result1 = -1;

        using (OracleConnection oraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
        {
            OracleCommand oraComm = oraConn.CreateCommand();
            oraComm.CommandType = CommandType.StoredProcedure;
            oraComm.CommandText = "eonepkg.gtbcir30";
            oraComm.CommandTimeout = 60;

            if (oraConn.State == ConnectionState.Closed)
            {
                oraConn.Open();
            }

            oraComm.Parameters.AddWithValue("inp_bra_code", braCode);
            oraComm.Parameters.AddWithValue("inp_cus_num", cusNum);
            oraComm.Parameters.AddWithValue("inp_led_code", ledCode);
            oraComm.Parameters.AddWithValue("inp_cur_code", curCode);
            oraComm.Parameters.AddWithValue("inp_tell_id", tellerID);
            oraComm.Parameters.Add("oerr_flag", OracleType.Float).Direction = ParameterDirection.Output;
            oraComm.Parameters.Add("out_sub_acct_code", OracleType.Float).Direction = ParameterDirection.Output;
            oraComm.ExecuteNonQuery();

            result1 = Convert.ToInt16(oraComm.Parameters["oerr_flag"].Value);

            if (result1 == 0)
            {
                subAcctCode = Convert.ToInt16(oraComm.Parameters["out_sub_acct_code"].Value);
            }
        }

        return result1;
    }

    //public string ValidateLoanMasCustomer(string bra_code, string cus_num, string loan_led)
    //{
    //    string Result = string.Empty;
    //    OracleCommand cmd;
    //    OracleConnection oraconn, oraconn1;
    //    OracleDataAdapter ora_adpt;
    //    DataTable dt;
    //    OracleCommand cmd1;
    //    //OracleConnection oraconn1;
    //    OracleDataAdapter ora_adpt1;
    //    DataTable dt1;

    //    String query_str = null;
    //    String query_str1 = null;
    //    oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
    //    oraconn1 = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
    //    try
    //    {

    //        // create the command for the function
    //        //query_str = "select * from loan_mas where bra_code=" + bra_code + " and cus_num=" + cus_num + " and led_code = " + loan_led;

    //        query_str = "select   a.bra_code, a.cus_num from  customer a where cus_num>=100000 and exists (select null from loan_mas k  where a.bra_code = k.bra_code" +
    //    " and a.cus_num = k.cus_num and k.LED_CODE =" + loan_led + " ) and not exists (select null from account d where a.bra_code = d.bra_code and a.cus_num = d.cus_num " +
    //            " and d.led_code in (1, 12, 23, 24, 2, 6, 8) and (crnt_bal < 0 or (d.lim_type=4 and bal_lim <0 ) ) ) and not exists ( select null from account k " +
    //         " where a.bra_code = k.bra_code and a.cus_num = k.cus_num and k.type_of_dep in (23,109,111) ) and a.bra_code = " + bra_code + " and a.cus_num = " + cus_num;

    //        oraconn.Open();
    //        cmd = new OracleCommand(query_str, oraconn);
    //        ora_adpt = new OracleDataAdapter(cmd);
    //        dt = new DataTable();

    //        ora_adpt.Fill(dt);

    //        xmlstring = "<Response>";

    //        if (!(dt.Rows.Count > 0))
    //        {
    //            try
    //            {

    //                query_str1 = "select a.bra_code, a.cus_num from cust_pro a where cust_grade_seg in (2, 3) and cus_num >= 100000  and not exists (select null from account d " +
    //                  " where a.bra_code = d.bra_code  and a.cus_num = d.cus_num and d.led_code in (1, 12, 23, 24, 2, 6, 8) and (crnt_bal < 0 or (d.lim_type=4 and bal_lim <0 ) ) " +
    //                   "  ) and not exists ( select null from account k where a.bra_code = k.bra_code and a.cus_num = k.cus_num and k.type_of_dep in (23,109,111) )  and a.bra_code = " + bra_code + " and a.cus_num = " + cus_num;

    //                oraconn1.Open();
    //                cmd1 = new OracleCommand(query_str1, oraconn1);
    //                ora_adpt1 = new OracleDataAdapter(cmd1);
    //                dt1 = new DataTable();

    //                ora_adpt1.Fill(dt1);
    //                if (dt1.Rows.Count > 0)
    //                {
    //                    xmlstring = xmlstring + "<CODE>1004</CODE>";
    //                    xmlstring = xmlstring + "<MESSAGE>" + "RETAIL" + "</MESSAGE>";

    //                }
    //                else
    //                {
    //                    xmlstring = xmlstring + "<CODE>1001</CODE>";
    //                    xmlstring = xmlstring + "<Error>" + "NO RECORD" + "</Error>";
    //                }

    //            }
    //            catch (Exception ex)
    //            {
    //                xmlstring = xmlstring + "<CODE>1002</CODE>";
    //                xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
    //                xmlstring = xmlstring + "</Response>";
    //            }

    //        }
    //        else
    //        {
    //            xmlstring = xmlstring + "<CODE>1000</CODE>";
    //            xmlstring = xmlstring + "<MESSAGE>" + "SUCCESS" + "</MESSAGE>";
    //        }

    //        xmlstring = xmlstring + "</Response>";

    //        dt = null;
    //        ora_adpt = null;
    //        cmd = null;
    //        dt1 = null;
    //        ora_adpt1 = null;
    //        cmd1 = null;
    //    }
    //    catch (Exception ex)
    //    {
    //        xmlstring = xmlstring + "<CODE>1002</CODE>";
    //        xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
    //        xmlstring = xmlstring + "</Response>";
    //    }
    //    finally
    //    {
    //        if (oraconn.State == ConnectionState.Open)
    //        {
    //            oraconn.Close();
    //        }
    //        if (oraconn1.State == ConnectionState.Open)
    //        {
    //            oraconn1.Close();
    //        }

    //    }

    //    return xmlstring;
    //}

    public string ValidateLoanMasCustomer(string bra_code, string cus_num, string loan_led)
    {
        string Result = string.Empty;
        OracleCommand cmd;
        OracleConnection oraconn, oraconn1;
        OracleDataAdapter ora_adpt;
        DataTable dt;
        OracleCommand cmd1;
        //OracleConnection oraconn1;
        OracleDataAdapter ora_adpt1;
        DataTable dt1;

        String query_str = null;
        String query_str1 = null;
        oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        oraconn1 = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        try
        {

            // create the command for the function
            //query_str = "select * from loan_mas where bra_code=" + bra_code + " and cus_num=" + cus_num + " and led_code = " + loan_led;

            query_str = "select   a.bra_code, a.cus_num from  customer a where cus_num>=100000 and exists (select null from loan_mas k  where a.bra_code = k.bra_code" +
    " and a.cus_num = k.cus_num and k.LED_CODE =" + loan_led + " ) and not exists (select null from account d where a.bra_code = d.bra_code and a.cus_num = d.cus_num " +
            " and d.led_code in (1, 12, 23, 24, 2, 6, 8) and (crnt_bal < 0 or (lim_mat_date >= sysdate ) ) ) and not exists ( select null from account k " +
         " where a.bra_code = k.bra_code and a.cus_num = k.cus_num and k.type_of_dep in (23,109,111) ) and a.bra_code = " + bra_code + " and a.cus_num = " + cus_num;

            oraconn.Open();
            cmd = new OracleCommand(query_str, oraconn);
            ora_adpt = new OracleDataAdapter(cmd);
            dt = new DataTable();

            ora_adpt.Fill(dt);

            xmlstring = "<Response>";

            if (!(dt.Rows.Count > 0))
            {
                try
                {

                    query_str1 = " select a.bra_code, a.cus_num from cust_pro a where cust_grade_seg in (2, 3) and cus_num >= 100000  and not exists (select null from account d " +
                  " where a.bra_code = d.bra_code  and a.cus_num = d.cus_num and d.led_code in (1, 12, 23, 24, 2, 6, 8) and (crnt_bal < 0 or (lim_mat_date >= sysdate) ) " +
                   "  ) and not exists ( select null from account k where a.bra_code = k.bra_code and a.cus_num = k.cus_num and k.type_of_dep in (23,109,111) )  and a.bra_code = " + bra_code + " and a.cus_num = " + cus_num;

                    oraconn1.Open();
                    cmd1 = new OracleCommand(query_str1, oraconn1);
                    ora_adpt1 = new OracleDataAdapter(cmd1);
                    dt1 = new DataTable();

                    ora_adpt1.Fill(dt1);
                    if (dt1.Rows.Count > 0)
                    {
                        xmlstring = xmlstring + "<CODE>1004</CODE>";
                        xmlstring = xmlstring + "<MESSAGE>" + "RETAIL" + "</MESSAGE>";

                    }
                    else
                    {
                        xmlstring = xmlstring + "<CODE>1001</CODE>";
                        xmlstring = xmlstring + "<Error>" + "NO RECORD" + "</Error>";
                    }

                }
                catch (Exception ex)
                {
                    xmlstring = xmlstring + "<CODE>1002</CODE>";
                    xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
                    xmlstring = xmlstring + "</Response>";
                }

            }
            else
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>" + "SUCCESS" + "</MESSAGE>";
            }

            xmlstring = xmlstring + "</Response>";

            dt = null;
            ora_adpt = null;
            cmd = null;
            dt1 = null;
            ora_adpt1 = null;
            cmd1 = null;
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1002</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }
        finally
        {
            if (oraconn.State == ConnectionState.Open)
            {
                oraconn.Close();
            }
            if (oraconn1.State == ConnectionState.Open)
            {
                oraconn1.Close();
            }

        }

        return xmlstring;
    }

    internal string InitaiteStandingInstructionForSMSCharge(string xmlRequest) //string Acct_to, string Acct_fro, string tellerID, string Remarks, decimal payAmount)
    {
        Eone eone = new Eone();
        xmlstring = "<Response>";
        //xmlRequest = "<REQUEST><ACCOUNTTO>205/152124/1/1/0</ACCOUNTTO><ACCOUNTFROM>205/152407/1/1/0</ACCOUNTFROM><TELLERID>2961</TELLERID><REMARKS>SMS CHARGE FOR AUGUST 2014</REMARKS><AMOUNT>2000</AMOUNT><OVERDRAWFLAG>0</OVERDRAWFLAG><FIRSTPAYDATE>2015-09-29 17:10:46.263</FIRSTPAYDATE></REQUEST>";
        try
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xmlRequest);

            XPathNavigator nav = doc.CreateNavigator();

            XPathNodeIterator node = nav.Select("/REQUEST/ACCOUNTTO");
            node.MoveNext();
            string acctTo = node.Current.Value;

            node = nav.Select("/REQUEST/ACCOUNTFROM");
            node.MoveNext();
            string acctFrom = node.Current.Value;

            node = nav.Select("/REQUEST/TELLERID");
            node.MoveNext();
            string tellerID = node.Current.Value;

            node = nav.Select("/REQUEST/REMARKS");
            node.MoveNext();
            string Remarks = node.Current.Value;

            node = nav.Select("/REQUEST/AMOUNT");
            node.MoveNext();
            decimal Amount = Convert.ToDecimal(node.Current.Value);

            node = nav.Select("/REQUEST/OVERDRAWFLAG");
            node.MoveNext();
            int overDrawFlag = Convert.ToInt32(node.Current.Value);

            node = nav.Select("/REQUEST/FIRSTPAYDATE");
            node.MoveNext();
            DateTime firstPayDate = Convert.ToDateTime(node.Current.Value);


            string resp = PlaceInstructionForSMSCharge(acctTo, acctFrom, tellerID, Remarks, Amount, overDrawFlag, firstPayDate);

            if (resp == "0")
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
            }
            else
            {
                //get basis return error
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<ERROR> " + resp + " " + eone.ErrorMsg(resp) + "</ERROR>";
            }

            xmlstring = xmlstring + "</Response>";
        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1004</CODE>";
            xmlstring = xmlstring + "<ERROR>" + ex.Message + " Stack Trace: " + ex.StackTrace + " </ERROR>";
            xmlstring = xmlstring + "</Response>";
        }
        return xmlstring;
    }

    private string PlaceInstructionForSMSCharge(string Acct_to, string Acct_fro, string tellerID, string Remarks, decimal payAmount, int overdrawflag, DateTime firstPayDate)
    {
        string[] accFrom, accTo;
        char[] delim = new char[] { '/' };

        accTo = Acct_to.Split(delim);

        accFrom = Acct_fro.Split(delim);

        payAmount = Math.Round(payAmount, 2);

        string Result = string.Empty;
        OracleConnection oraconn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]));
        OracleCommand oracomm = new OracleCommand("GTB_STAN_INS", oraconn);
        oracomm.CommandType = CommandType.StoredProcedure;
        try
        {
            if (oraconn.State == ConnectionState.Closed)
            {
                oraconn.Open();
            }
            oracomm.Parameters.Add("DEB_BRA_CODE", OracleType.Number, 21).Value = accFrom[0];
            oracomm.Parameters.Add("DEB_CUS_NUM", OracleType.Number, 21).Value = accFrom[1];
            oracomm.Parameters.Add("DEB_CUR_CODE", OracleType.Number, 21).Value = accFrom[2];
            oracomm.Parameters.Add("DEB_LED_CODE", OracleType.Number, 21).Value = accFrom[3];
            oracomm.Parameters.Add("DEB_SUB_ACCT_CODE", OracleType.Number, 21).Value = accFrom[4];
            oracomm.Parameters.Add("CRE_BRA_CODE", OracleType.Number, 21).Value = accFrom[0];
            oracomm.Parameters.Add("CRE_CUS_NUM", OracleType.Number, 21).Value = accTo[1];
            oracomm.Parameters.Add("CRE_CUR_CODE", OracleType.Number, 21).Value = accTo[2];
            oracomm.Parameters.Add("CRE_LED_CODE", OracleType.Number, 21).Value = accTo[3];
            oracomm.Parameters.Add("CRE_SUB_ACCT_CODE", OracleType.Number, 21).Value = accTo[4];
            oracomm.Parameters.Add("TELL_ID", OracleType.VarChar, 15).Value = tellerID;
            oracomm.Parameters.Add("PAY_AMT", OracleType.Number, 15).Value = payAmount;
            oracomm.Parameters.Add("FST_PAY_DATE", OracleType.DateTime, 15).Value = firstPayDate.ToString("ddMMMyyyy");
            oracomm.Parameters.Add("REMARKS", OracleType.VarChar, 300).Value = Remarks;
            oracomm.Parameters.Add("OVDR_FLAG", OracleType.Number, 300).Value = overdrawflag;
            oracomm.Parameters.Add("RETURN_STATUS", OracleType.VarChar, 100).Direction = ParameterDirection.Output;

            oracomm.ExecuteNonQuery();
            Result = oracomm.Parameters["RETURN_STATUS"].Value.ToString();
            oraconn.Close();
        }
        catch (Exception ex)
        {
            return ex.Message;
        }

        //if (Result.CompareTo("@ERR7@") == 0 || Result.CompareTo("@ERR19@") == 0)
        //{
        return Result;
        //}
        //else
        //{
        //    //get basis return error
        //    return ErrorMsg(Result);
        //}
    }

    public DataTable GetAccountNo_UsingPhoneNo(string phoneNo)
    {
        string classMeth = "Basis|GetAccountNo_UsingPhoneNo";
        DataTable dtTable = new DataTable();

        if (ConfigurationManager.AppSettings["ATMHOTLIST_CONNECT"] == "EXADATA")
        {
            using (OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["ATMSERVICE_CONN_EXADATAConString"])))
            {
                using (OracleCommand OraSelect = new OracleCommand())
                {
                    try
                    {
                        if (OraConn.State == ConnectionState.Closed)
                        {
                            OraConn.Open();
                        }

                        OraSelect.Connection = OraConn;
                        //string selectquery = "select distinct a.bra_code BranchCode, a.cus_num CustomerNo from address a, account c where a.bra_code = c.bra_code and a.cus_num = c.cus_num and a.cur_code = 0 and a.led_code = 0 and a.sub_acct_code = 0 and c.sta_code in (1, 3) and (a.tel_num = '" + phoneNo + "' or a.mob_num = '" + phoneNo + "' or a.tel_num_2 = '" + phoneNo + "') and a.cus_num >= 100000 and c.sta_code = 1";
                        string selectquery = "select distinct a.bra_code BranchCode, a.cus_num CustomerNo from src_address a, src_account c where (a.tel_num = '" + phoneNo + "' or a.mob_num = '" + phoneNo + "' or a.tel_num_2 = '" + phoneNo + "') and a.cus_num >= 100000 and a.bra_code = c.bra_code and a.cus_num = c.cus_num and c.sta_code = 1";

                        OraSelect.CommandText = selectquery;
                        OraSelect.CommandType = CommandType.Text;
                        using (OracleDataReader OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                        {
                            if (OraDrSelect.HasRows == true)
                            {
                                dtTable.Load(OraDrSelect);
                                OraDrSelect.Close();
                                return dtTable;
                            }
                            else
                            {
                                return dtTable;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrHandler.Log(classMeth, phoneNo, ex.Message);
                        return null;
                    }
                    finally
                    {
                        if (OraConn.State == ConnectionState.Open)
                        {
                            OraConn.Close();
                        }
                    }
                }
            }
        }
        else
        {
            using (OraConn = new OracleConnection(GTBEncryptLibrary.GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"])))
            {
                using (OracleCommand OraSelect = new OracleCommand())
                {
                    try
                    {
                        if (OraConn.State == ConnectionState.Closed)
                        {
                            OraConn.Open();
                        }

                        OraSelect.Connection = OraConn;
                        //string selectquery = "select distinct a.bra_code BranchCode, a.cus_num CustomerNo from address a, account c where a.bra_code = c.bra_code and a.cus_num = c.cus_num and a.cur_code = 0 and a.led_code = 0 and a.sub_acct_code = 0 and c.sta_code in (1, 3) and (a.tel_num = '" + phoneNo + "' or a.mob_num = '" + phoneNo + "' or a.tel_num_2 = '" + phoneNo + "') and a.cus_num >= 100000 and c.sta_code = 1";
                        string selectquery = "select distinct a.bra_code BranchCode, a.cus_num CustomerNo from address a, account c where (a.tel_num = '" + phoneNo + "' or a.mob_num = '" + phoneNo + "' or a.tel_num_2 = '" + phoneNo + "') and a.cus_num >= 100000 and a.bra_code = c.bra_code and a.cus_num = c.cus_num and c.sta_code = 1";

                        OraSelect.CommandText = selectquery;
                        OraSelect.CommandType = CommandType.Text;
                        using (OracleDataReader OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                        {
                            if (OraDrSelect.HasRows == true)
                            {
                                dtTable.Load(OraDrSelect);
                                OraDrSelect.Close();
                                return dtTable;
                            }
                            else
                            {
                                return dtTable;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrHandler.Log(classMeth, phoneNo, ex.Message);
                        return null;
                    }
                    finally
                    {
                        if (OraConn.State == ConnectionState.Open)
                        {
                            OraConn.Close();
                        }
                    }
                }
            }
        }
    }


    public int creditCardEligibiltyCheck(string braCode, string cusNum)
    {
        int result = 0;
        OracleCommand OraSelect = new OracleCommand();
        OracleDataReader OraDrSelect = default(OracleDataReader);
        OracleCommand OraSelect1 = new OracleCommand();
        OracleDataReader OraDrSelect1 = default(OracleDataReader);
        double monthlyturn = 0;
        double monthlyturnFX = 0;
        string duratn = DateTime.Now.AddYears(-1).ToString("ddMMMyyyy");
        string duratn1 = DateTime.Now.AddYears(-2).ToString("ddMMMyyyy");
        ErrHandler ErrHandler = new ErrHandler();
        OracleConnection ConnHoBank_Test = new OracleConnection(ConfigurationManager.AppSettings["EXADATAconstring"]);
        try
        {
            if (ConnHoBank_Test.State == ConnectionState.Closed)
            {
                ConnHoBank_Test.Open();
            }

            OraSelect.Connection = ConnHoBank_Test;

            string query = "select BRA_CODE, CUS_NUM, SUM(MTD_TURNOVER)nairaturn from stg.d_CUST_RTL_TURN_LODGE_BAL@exadata_dr " +
                             " where bra_code = " + braCode + " and cus_num = " + cusNum + " AND REFERENCE_DATE >= '" + duratn + "' GROUP BY BRA_CODE, CUS_NUM ";
            OraSelect.CommandText = query;

            OraSelect.CommandType = CommandType.Text;

            OraDrSelect = OraSelect.ExecuteReader();


            if (OraDrSelect.HasRows == true)
            {
                if (OraDrSelect.Read())
                {
                    monthlyturn = Convert.ToDouble(OraDrSelect["nairaturn"]);
                    if (monthlyturn >= 15000000)
                    {
                        result = 1;
                    }
                    else
                    {
                        OraSelect1.Connection = ConnHoBank_Test;

                        string query1 = "select BRA_CODE, CUS_NUM, SUM(MTD_TURNOVER_FX)fxturn from stg.d_CUST_RTL_TURN_LODGE_BAL@exadata_dr " +
                                         " where bra_code = " + braCode + " and cus_num = " + cusNum + " AND REFERENCE_DATE >= '" + duratn1 + "' GROUP BY BRA_CODE, CUS_NUM";
                        OraSelect1.CommandText = query1;

                        OraSelect1.CommandType = CommandType.Text;

                        OraDrSelect1 = OraSelect1.ExecuteReader();


                        if (OraDrSelect1.HasRows == true)
                        {
                            if (OraDrSelect1.Read())
                            {
                                monthlyturnFX = Convert.ToDouble(OraDrSelect1["fxturn"]);
                                if (monthlyturnFX >= 20000)
                                {
                                    result = 1;
                                }
                                else
                                {
                                    result = 0;
                                }
                            }
                            else
                            {
                                result = 0;
                            }
                        }
                        else
                        {
                            result = 0;
                        }
                    }
                }
                else
                {
                    result = 0;
                }
            }
            else
            {
                result = 0;
            }
        }

        catch (Exception ex)
        {
            ErrHandler.WriteError("An error occured connecting to EXADATA to retrieve customer prequalification status : " + ex.Message);
            result = 0;
        }
        finally
        {
            if (ConnHoBank_Test.State == ConnectionState.Open)
            {
                ConnHoBank_Test.Close();
            }
        }
        return result;
    }

}
