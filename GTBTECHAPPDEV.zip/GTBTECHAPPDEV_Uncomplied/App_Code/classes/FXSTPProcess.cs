﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Xml;
using UnifiedServices;

/// <summary>
/// Summary description for FXSTPProcess
/// </summary>
public class FXSTPProcess
{
    public FXSTPProcess()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    //A. Validate a sort code and account number (Requires BankVal UK User ID)
    // response = UnifiedServices.BankValUK.bankValPlus2(acc,scode,uid,pin,format)


    // B.Lookup a sortcode(Requires BankVal UK User ID)
    //response = UnifiedServices.BankValUK.getBranchDetails2(scode,uid,pin,format)

    //  C.Get the IBAN and SWIFT Code for a UK bank account(Requires BankVal UK User ID)
    //   response = UnifiedServices.BankValUK.deriveIbanBic(scode,uid,pin,format)


    // D.Validate Building Society Roll Number(Requires BankVal UK User ID)
    // response = UnifiedServices.BankValUK.refValidate(scode,uid,pin,format)

    //E.Lookup SWIFT bank details(Requires BankVal International User ID)
    //response = UnifiedServices.BankValInt.getBankDetails2(bic,uid,pin,format)


    //F.Validate an IBAN(Requires BankVal International User ID)
    //response = UnifiedServices.BankValInt.ibanValidate(iban,uid,pin,format)

    //    Parameters
    //1: BIC - SWIFT BIC code to lookup
    //2: UserID - register for BankVal International Free Trial
    //3: PIN - register for BankVal International Free Trial
    //4: Format - the response format(either xml, json or csv)


    public string validateSWIFTBIC(string swiftBIC)
    {
        string returnvalue = string.Empty;
        swiftBIC = swiftBIC.ToUpper();
        try
        {

            returnvalue = CheckIfIbanSwiftIsValid(swiftBIC);

            if (string.IsNullOrWhiteSpace(returnvalue))
            {

                string uid = ConfigurationManager.AppSettings["bankvaluid"];
                string pin = ConfigurationManager.AppSettings["bankvalpin"];
                var response = BankValInt.getBankDetails2(swiftBIC, uid, pin, "xml");

                XmlDocument xmlresponse = new XmlDocument();

                xmlresponse.LoadXml(response);

                string validationresult = xmlresponse.SelectSingleNode("swiftbic/result").InnerXml;
                string bankname = string.Empty;
                string bankaddress = string.Empty;
                string banklocation = string.Empty;
                string bankcountry = string.Empty;

                if (validationresult.ToUpper().Trim().Equals("VALID"))
                {
                    bankname = xmlresponse.SelectSingleNode("swiftbic/name1").InnerXml;
                    bankaddress = xmlresponse.SelectSingleNode("swiftbic/address1").InnerXml;
                    banklocation = xmlresponse.SelectSingleNode("swiftbic/location").InnerXml;
                    bankcountry = xmlresponse.SelectSingleNode("swiftbic/country").InnerXml;

                    InsertValidIbanSwift(swiftBIC, bankname, bankaddress + " " + banklocation, bankcountry, 0);
                }

                returnvalue = validationresult + "|" + swiftBIC + "|" + bankname + "|" + bankaddress + " " + banklocation + " " + bankcountry;
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Swift Validation error : " + ex.Message);
        }

        return returnvalue;
    }


    public string validateIBAN(string Iban)
    {
        string returnvalue = string.Empty;
        Iban = Iban.ToUpper();
        try
        {

            returnvalue = CheckIfIbanSwiftIsValid(Iban);

            if (string.IsNullOrWhiteSpace(returnvalue))
            {


                string uid = ConfigurationManager.AppSettings["bankvaluid"];
                string pin = ConfigurationManager.AppSettings["bankvalpin"];
                var response = BankValInt.ibanValidate(Iban, uid, pin, "xml");

                XmlDocument xmlresponse = new XmlDocument();

                xmlresponse.LoadXml(response);

                string validationresult = xmlresponse.SelectSingleNode("iban/result").InnerXml;
                string bankname = string.Empty;
                string bankaddress = string.Empty;
                string banklocation = string.Empty;
                string bankcountry = string.Empty;

                if (validationresult.ToUpper().Trim().Equals("VALID"))
                {

                    InsertValidIbanSwift(Iban, bankname, bankaddress + " " + banklocation, bankcountry, 1);

                }

                returnvalue = validationresult + "|" + Iban + "|" + bankname + "|" + bankaddress + " " + banklocation + " " + bankcountry;

            }

        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("IBAN Validation error : " + ex.Message);
        }

        return returnvalue;
    }



    public string CheckIfIbanSwiftIsValid(string IbanSwiftCode)
    {
        string returnvalue = String.Empty;
        SqlConnection ConFTU = new SqlConnection(ConfigurationManager.AppSettings["FTUConn"].ToString());
        SqlCommand cmdselectUser = new SqlCommand();
      SqlDataReader sqlread ;
        try
        {
            if ((ConFTU.State == ConnectionState.Closed))
            {
                ConFTU.Open();
            }
            cmdselectUser.Parameters.AddWithValue("@IbanSwiftCode", IbanSwiftCode);

            cmdselectUser.Connection = ConFTU;
            cmdselectUser.CommandText = "usp_IbanSwiftCheck";
            cmdselectUser.CommandType = CommandType.StoredProcedure;

               sqlread = cmdselectUser.ExecuteReader();

               if (sqlread.HasRows)
               {
                   if (sqlread.Read())
                   {
                       string bankname = sqlread["BankName"].ToString();
                       string bankaddress = sqlread["BankAddress"].ToString();
                       string country = sqlread["Country"].ToString();

                       returnvalue = "VALID|" + IbanSwiftCode + "|" + bankname + "|" + bankaddress + " " + country;
                   }


               }
            return returnvalue;
         
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Error checking ibanswift " + ex.Message);
        }
        finally
        {
            ConFTU.Close();
        }
        return returnvalue;
    }


    public string InsertValidIbanSwift(string IbanSwiftCode, string BankName, string BankAddress, string Country, int IsIban)
    {

     //   @IbanSwiftCode, @BankName, @BankAddress, @Country, @IsIban
        string returnvalue = String.Empty;
        SqlConnection ConPostcard = new SqlConnection(ConfigurationManager.AppSettings["FTUConn"].ToString());
        SqlCommand cmdselectUser = new SqlCommand();
    
        try
        {
            if (ConPostcard.State == ConnectionState.Closed)
            {
                ConPostcard.Open();
            }
            cmdselectUser.Parameters.AddWithValue("@IbanSwiftCode", IbanSwiftCode);
            cmdselectUser.Parameters.AddWithValue("@BankName", BankName);
            cmdselectUser.Parameters.AddWithValue("@BankAddress", BankAddress);
            cmdselectUser.Parameters.AddWithValue("@Country", Country);
            cmdselectUser.Parameters.AddWithValue("@IsIban", IsIban);
            cmdselectUser.Connection = ConPostcard;
            cmdselectUser.CommandText = "usp_IbanSwiftInsert";
            cmdselectUser.CommandType = CommandType.StoredProcedure;
            returnvalue = cmdselectUser.ExecuteScalar().ToString();
            return returnvalue;
            //   returnvalue = cmdselectUser.ExecuteReader
            // reader = cmdselectUser.ExecuteReader()
            // If reader.HasRows Then
            //     reader.Read()
            // End If
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Error inserting ibanswift " + ex.Message);
              return returnvalue;
        }
        
        finally
        {
            ConPostcard.Close();
        }
     
    }

 

}