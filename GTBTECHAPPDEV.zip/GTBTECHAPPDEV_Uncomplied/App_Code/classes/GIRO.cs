﻿using GTBEncryptLibrary;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OracleClient;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for GIRO
/// </summary>
public class GIRO
{
    string basisConnString = string.Empty;
    string EoneConnString = string.Empty;
    string giroConnString = string.Empty;
    string gtLossConnString = string.Empty;
	public GIRO()
	{
		//
		// TODO: Add constructor logic here
		//
        basisConnString = GTBEncryptLib.DecryptText(ConfigurationManager.AppSettings["BASISConString_eone"]);
        EoneConnString= ConfigurationManager.ConnectionStrings["e_oneConnString"].ConnectionString;
        giroConnString = ConfigurationManager.ConnectionStrings["GiroConnString"].ConnectionString;
        gtLossConnString = ConfigurationManager.ConnectionStrings["GtLossConnString"].ConnectionString;  
	}

    string returnQuery(string postingDate, string FromTraSeq, string ToTraSeq, int subAcctCode)
    {
        string sSQL = string.Empty;
        if (postingDate == DateTime.Today.ToString("ddMMMyyyy"))
        {
            sSQL = string.Format(@"SELECT distinct 'I',
                               substr(remarks, 1, 9) PBRN,
                               substr(remarks, 10, 15) BeneNo,
                               substr(remarks, 25, 20) PayerName,
                               substr(remarks, 45, 20) PayeeName,
                               substr(remarks, 65, 25) TrxnDetail,
                               20 TranCode,
                               tra_seq1,
                               to_char(doc_num) SerialNo,
                               tra_amt amount,
                               '05815' || origt_bra_code || '2' BOFD,
                               '0' MICR,
                               '0' SHI,
                               bra_code || '/' || cus_num || '/' || cur_code || '/' || led_code || '/' ||
                               sub_acct_code acctnum,
                          substr(remarks, 90, 15) PayerNo 
                          FROM tell_act
                         WHERE (tra_seq1 >= {0} AND tra_seq1 <= {1})
                           AND bra_code = 205
                           AND cus_num = 10
                           AND cur_code = 1
                           AND led_code = 4617
                           AND sub_acct_code = {2}
                           AND deb_cre_ind = 2
                           AND can_rea_code = 0", FromTraSeq, ToTraSeq, subAcctCode);
        }
        else
        {
            sSQL = string.Format(@"select DISTINCT a.* From 
                     (SELECT  'I', substr(remarks, 1, 9) PBRN, substr(remarks, 10, 15) BeneNo, 
                     substr(remarks, 25, 20) PayerName, substr(remarks, 45, 20) PayeeName, 
                     substr(remarks, 65, 25) TrxnDetail, 20 TranCode, tra_seq1, 
                     to_char(doc_num) SerialNo, tra_amt amount, '05815' || origt_bra_code || '2' BOFD, 
                     '0' MICR, '0' SHI, bra_code || '/' || cus_num || '/' || cur_code || '/' || led_code || '/' || 
                     sub_acct_code acctnum, substr(remarks, 90, 15)PayerNo 
                     FROM transact WHERE (tra_seq1 >= {0} AND tra_seq1 <= {1})
                     AND tra_date = '{2}' AND bra_code = 205  AND cus_num = 10 AND cur_code = 1  AND led_code = 4617  
                     AND sub_acct_code = {3} AND deb_cre_ind = 2 AND can_rea_code = 0 
                     minus 
                     SELECT DISTINCT 'I', substr(a.remarks, 1, 9) PBRN, substr(a.remarks, 10, 15) BeneNo,
                     substr(a.remarks, 25, 20) PayerName, substr(a.remarks, 45, 20) PayeeName, 
                     substr(a.remarks, 65, 25) TrxnDetail, 20 TranCode, a.tra_seq1, to_char(a.doc_num) SerialNo, 
                     a.tra_amt amount, '05815' || a.origt_bra_code || '2' BOFD, '0' MICR, '0' SHI, 
                     a.bra_code || '/' || a.cus_num || '/' || a.cur_code || '/' || a.led_code || '/' || a.sub_acct_code acctnum, 
                     substr(a.remarks, 90, 15) PayerNo 
                     FROM transact a, transact b WHERE (a.tra_seq1 >= {0} AND a.tra_seq1 <= 9999) 
                     AND a.tra_date  = '{2}'  AND a.bra_code = 205 AND a.cus_num = 10 
                     AND a.cur_code = 1 AND a.led_code = 4617 AND a.sub_acct_code = {3} 
                     AND a.deb_cre_ind = 2 AND b.deb_cre_ind = 1 AND a.can_rea_code = 0 
                     AND b.can_rea_code = 0 and a.origt_bra_code = b.origt_bra_code 
                     and a.origt_tra_date = b.origt_tra_date and a.origt_tra_seq1 = b.origt_tra_seq1 
                     and b.led_code not in (300, 301) and b.cus_num >= 100000 AND A.EXPL_CODE = B.EXPL_CODE) A UNION  
                     SELECT DISTINCT 'I', substr(a.remarks, 1, 9) PBRN, substr(a.remarks, 10, 15) BeneNo,
                     substr(a.remarks, 25, 20) PayerName, substr(a.remarks, 45, 20) PayeeName, 
                     substr(a.remarks, 65, 25) TrxnDetail, 20 TranCode, a.tra_seq1, to_char(a.doc_num) SerialNo, 
                     a.tra_amt amount, '05815' || a.origt_bra_code || '2' BOFD, '0' MICR, '0' SHI, 
                     a.bra_code || '/' || a.cus_num || '/' || a.cur_code || '/' || a.led_code || '/' || a.sub_acct_code acctnum, 
                    substr(a.remarks, 90, 15) PayerNo 
                     FROM transact a, transact b WHERE (a.tra_seq1 >={0} AND a.tra_seq1 <= {1}) 
                     AND a.tra_date = '{2}' AND a.bra_code = 205 AND a.cus_num = 10 
                     AND a.cur_code = 1 AND a.led_code = 4617 AND a.sub_acct_code = {3}
                     AND a.deb_cre_ind = 2 AND b.deb_cre_ind = 1  AND a.can_rea_code = 0 AND b.can_rea_code = 0 
                     and a.origt_bra_code = b.origt_bra_code  and a.origt_tra_date = b.origt_tra_date 
                     and a.origt_tra_seq1 = b.origt_tra_seq1 and b.led_code not in (300, 301) and b.cus_num >= 100000", FromTraSeq, ToTraSeq, postingDate, subAcctCode);
        }

//             sSQL = string.Format(@"SELECT distinct 'I',
//                               substr(remarks, 1, 9) PBRN,
//                               substr(remarks, 10, 15) BeneNo,
//                               substr(remarks, 25, 20) PayerName,
//                               substr(remarks, 45, 20) PayeeName,
//                               substr(remarks, 65, 25) TrxnDetail,
//                               20 TranCode,
//                               tra_seq1,
//                               to_char(doc_num) SerialNo,
//                               tra_amt amount,
//                               '05815' || origt_bra_code || '2' BOFD,
//                               '0' MICR,
//                               '0' SHI,
//                               bra_code || '/' || cus_num || '/' || cur_code || '/' || led_code || '/' ||
//                               sub_acct_code acctnum
//
//                          FROM tell_act
//                         WHERE (tra_seq1 >= {0} AND tra_seq1 <= {1})
//                           AND bra_code = 205
//                           AND cus_num = 10
//                           AND cur_code = 1
//                           AND led_code = 4617
//                           AND sub_acct_code = {2}
//                           AND deb_cre_ind = 2
//                           AND can_rea_code = 0", FromTraSeq, ToTraSeq, subAcctCode);
//        }
//        else
//        {
//            sSQL = string.Format(@"select DISTINCT a.* From 
//                     (SELECT  'I', substr(remarks, 1, 9) PBRN, substr(remarks, 10, 15) BeneNo, 
//                     substr(remarks, 25, 20) PayerName, substr(remarks, 45, 20) PayeeName, 
//                     substr(remarks, 65, 25) TrxnDetail, 20 TranCode, tra_seq1, 
//                     to_char(doc_num) SerialNo, tra_amt amount, '05815' || origt_bra_code || '2' BOFD, 
//                     '0' MICR, '0' SHI, bra_code || '/' || cus_num || '/' || cur_code || '/' || led_code || '/' || 
//                     sub_acct_code acctnum FROM transact WHERE (tra_seq1 >= {0} AND tra_seq1 <= {1})
//                     AND tra_date = '{2}' AND bra_code = 205  AND cus_num = 10 AND cur_code = 1  AND led_code = 4617  
//                     AND sub_acct_code = {3} AND deb_cre_ind = 2 AND can_rea_code = 0 
//                     minus 
//                     SELECT DISTINCT 'I', substr(a.remarks, 1, 9) PBRN, substr(a.remarks, 10, 15) BeneNo,
//                     substr(a.remarks, 25, 20) PayerName, substr(a.remarks, 45, 20) PayeeName, 
//                     substr(a.remarks, 65, 25) TrxnDetail, 20 TranCode, a.tra_seq1, to_char(a.doc_num) SerialNo, 
//                     a.tra_amt amount, '05815' || a.origt_bra_code || '2' BOFD, '0' MICR, '0' SHI, 
//                     a.bra_code || '/' || a.cus_num || '/' || a.cur_code || '/' || a.led_code || '/' || a.sub_acct_code acctnum 
//                     FROM transact a, transact b WHERE (a.tra_seq1 >= {0} AND a.tra_seq1 <= 9999) 
//                     AND a.tra_date  = '{2}'  AND a.bra_code = 205 AND a.cus_num = 10 
//                     AND a.cur_code = 1 AND a.led_code = 4617 AND a.sub_acct_code = {3} 
//                     AND a.deb_cre_ind = 2 AND b.deb_cre_ind = 1 AND a.can_rea_code = 0 
//                     AND b.can_rea_code = 0 and a.origt_bra_code = b.origt_bra_code 
//                     and a.origt_tra_date = b.origt_tra_date and a.origt_tra_seq1 = b.origt_tra_seq1 
//                     and b.led_code not in (300, 301) and b.cus_num >= 100000 AND A.EXPL_CODE = B.EXPL_CODE) A UNION  
//                     SELECT DISTINCT 'I', substr(a.remarks, 1, 9) PBRN, substr(a.remarks, 10, 15) BeneNo,
//                     substr(a.remarks, 25, 20) PayerName, substr(a.remarks, 45, 20) PayeeName, 
//                     substr(a.remarks, 65, 25) TrxnDetail, 20 TranCode, a.tra_seq1, to_char(a.doc_num) SerialNo, 
//                     a.tra_amt amount, '05815' || a.origt_bra_code || '2' BOFD, '0' MICR, '0' SHI, 
//                     a.bra_code || '/' || a.cus_num || '/' || a.cur_code || '/' || a.led_code || '/' || a.sub_acct_code acctnum  
//                     FROM transact a, transact b WHERE (a.tra_seq1 >={0} AND a.tra_seq1 <= {1}) 
//                     AND a.tra_date = '{2}' AND a.bra_code = 205 AND a.cus_num = 10 
//                     AND a.cur_code = 1 AND a.led_code = 4617 AND a.sub_acct_code = {3}
//                     AND a.deb_cre_ind = 2 AND b.deb_cre_ind = 1  AND a.can_rea_code = 0 AND b.can_rea_code = 0 
//                     and a.origt_bra_code = b.origt_bra_code  and a.origt_tra_date = b.origt_tra_date 
//                     and a.origt_tra_seq1 = b.origt_tra_seq1 and b.led_code not in (300, 301) and b.cus_num >= 100000", FromTraSeq, ToTraSeq, postingDate, subAcctCode);
        
        return sSQL;
    }
    public DataSet ReturnTransactions(string postDate, string FromTraSeq, string ToTraSeq, int subAcctCode)
    {
        DataSet dsResult = null;
        string sSQL = returnQuery(postDate, FromTraSeq, ToTraSeq, subAcctCode);
        try
        {
            using (OracleConnection conn = new OracleConnection(basisConnString))
            {
                using (OracleCommand cmd = conn.CreateCommand())
                {
                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    cmd.CommandText = sSQL;
                    cmd.CommandType = CommandType.Text;
                    OracleDataAdapter adapter = new OracleDataAdapter(cmd);
                    dsResult = new DataSet();
                    adapter.Fill(dsResult);
                    conn.Close();
                    adapter.Dispose();
                }
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Error retrieving Transactions for Giro ==> " + ex.Message + "Stack trace: " + ex.StackTrace);
        }
        return dsResult;
    }
    internal DataSet getuserdetails(string username)
    {
        DataSet dt = null;   
        try
        {
            string selectuser = "select * from admin_users where user_id = @username";
            using (SqlConnection eone = new SqlConnection(EoneConnString))
            {
                using (SqlCommand cmd = eone.CreateCommand())
                {
                    cmd.CommandText = selectuser;
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@username", username);
                    SqlDataAdapter adpt = new SqlDataAdapter(cmd);
                    dt = new DataSet();
                    adpt.Fill(dt);                    
                }
            }
        }
        catch (Exception ex)
        {
              ErrHandler.WriteError("Error retrieving getuserdetails for Giro ==> " + ex.Message + "Stack trace: " + ex.StackTrace);
            
        }
        return dt;
    }
    internal void updateGIROLogin(string userName, string firstName, string lastName, string loginStartDate)
    {
        //string loginStartDate = string.Empty;
        try
        {
            using (SqlConnection conn = new SqlConnection(giroConnString)) 
            {
                DateTime loginstart = DateTime.Now;
                //loginStartDate = loginstart.ToString("dd-MM-yyyy hh:mm:ss");
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandText = "Proc_UpdateLoginStart";
                    cmd.Parameters.Add("@username", SqlDbType.NVarChar).Value = userName;
                    cmd.Parameters.Add("@firstname", SqlDbType.NVarChar).Value = firstName;
                    cmd.Parameters.Add("@lastname", SqlDbType.NVarChar).Value = lastName;
                    cmd.Parameters.Add("@loginstart", SqlDbType.NVarChar).Value = loginStartDate;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Error updating GIRO Login ==> " + ex.Message + "Stack trace: " + ex.StackTrace);
        }
    }
    internal Int32 updateGIROLogout(string userName, string loginstart)
    {
        Int32 result = 0;
        try
        {
            string query = "update login_log set loginend = @loginend where username = @username and loginstart = @loginstart";
            try
            {
                using (SqlConnection sqlconn = new SqlConnection(giroConnString))
                {
                    using (SqlCommand cmd = sqlconn.CreateCommand())
                    {
                        cmd.CommandText = query;
                        cmd.CommandType = CommandType.Text;

                        if (sqlconn.State == ConnectionState.Closed)
                            sqlconn.Open();

                        cmd.Parameters.AddWithValue("@loginend", DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
                        cmd.Parameters.AddWithValue("@username", userName);
                        cmd.Parameters.AddWithValue("@loginstart", loginstart);

                        result = Convert.ToInt32(cmd.ExecuteNonQuery());
                        

                    }
                }
            }
            catch (Exception ex)
            {
                ErrHandler.WriteError(ex.Message + "Stack trace: " + ex.StackTrace);
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Error updating GIRO logout ==> " + ex.Message + "Stack trace: " + ex.StackTrace);
        }
        return result;
    }
    internal Int64 getLastSequence()
    {
        Int64 retval;
        try
        {
            using (SqlConnection conn = new SqlConnection(giroConnString))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.Parameters.Add("@seq", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                    cmd.CommandText = "proc_chk_sequence";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                    retval = Convert.ToInt64(cmd.Parameters["@seq"].Value);
                }
            }
        }
        catch (Exception e)
        {
            ErrHandler.WriteError(e.Message + " Stack Trace" + e.StackTrace);
            retval = 0;
        }
        return retval;
    }
  internal DataTable ReturnNIPBasisDebitTransactions(string bracode, string cusnum, string curcode, string ledcode, string subacctcode, string formattedDate, string sessionID)
    { 
        DataTable trans = new DataTable();
        string oraquery = string.Format(@"select tra_date, origt_tra_date, bra_code, cus_num, cur_code, led_code, sub_acct_code, expl_code, tra_amt, remarks, deb_cre_ind, tell_id,doc_num, origt_bra_code, tra_seq1, tra_seq2, origt_tra_seq1, origt_tra_seq2, upd_time from transact 
                        where bra_code = :bra_code and cus_num = :cus_num and cur_code = :cur_code and led_code = :led_code and sub_acct_code = :sub_acct_code
                        and tra_date >= :tra_Date and substr(remarks,1,30) = :session_ID
                        UNION
                        select tra_date, origt_tra_date, bra_code, cus_num, cur_code, led_code, sub_acct_code, expl_code, tra_amt, remarks, deb_cre_ind,tell_id,doc_num,origt_bra_code, tra_seq1, tra_seq2, origt_tra_seq1, origt_tra_seq2, upd_time from tell_act 
                        where bra_code = :bra_code and cus_num = :cus_num and cur_code = :cur_code and led_code = :led_code and sub_acct_code = :sub_acct_code
                        and substr(remarks,1,30) = :session_ID", bracode, cusnum, curcode, ledcode, subacctcode, formattedDate, sessionID);


            using (OracleConnection con = new OracleConnection(basisConnString))
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                OracleCommand oracmd = new OracleCommand(oraquery, con);
                oracmd.CommandType = CommandType.Text;
               
                oracmd.Parameters.AddWithValue(":bra_code", bracode);
                oracmd.Parameters.AddWithValue(":cus_num", cusnum);
                oracmd.Parameters.AddWithValue(":cur_code", curcode);
                oracmd.Parameters.AddWithValue(":led_code", ledcode);
                oracmd.Parameters.AddWithValue(":sub_acct_code", subacctcode);
                oracmd.Parameters.AddWithValue(":session_ID", sessionID);
                oracmd.Parameters.AddWithValue(":tra_Date", formattedDate);

                OracleDataAdapter oradpt = new OracleDataAdapter(oracmd);
                oradpt.Fill(trans);
            }

            return trans;   
    }
    internal DataSet FirstLevelCheckTransactionsForReversals(string sessionID)
    {
        DataSet dsResult = null;
        DataTable dtResult = new DataTable();
        try
        {
            gtLossConnString = ConfigurationManager.ConnectionStrings["GtLossConnString"].ConnectionString;
            string bracode = "";
            string cusnum = "";
            string curcode = "";
            string ledcode = "";
            string subacctcode = "";
            string formattedDate = null;
            DateTime date;
            string chk_expl_code = "";
            string chk_deb_ind = "";
            int reversed = 0;
            DataTable empty = new DataTable();
            DataTable trans = new DataTable();
            DataTable dt = null;
            bool notValid = false;
            decimal amount = 0;
            string transDesc = string.Empty;

            //check that it is not in RevInfo table on gtloss
            using (SqlConnection gtlossConn = new SqlConnection(gtLossConnString))
            {
                dt = new DataTable();
                if (gtlossConn.State == ConnectionState.Closed)
                    gtlossConn.Open();
                SqlCommand cmd = new SqlCommand("proc_GetNIPTransaction", gtlossConn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@TransRef", sessionID);
                SqlDataAdapter adpt = new SqlDataAdapter(cmd);
                adpt.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    return null;
                }
            }

            //then check eone
            using (SqlConnection e_one1 = new SqlConnection(EoneConnString))
            {
                dt = new DataTable();
                string status = string.Empty;
                //then retrieve from e-one

                if (e_one1.State == ConnectionState.Closed)
                    e_one1.Open();
                SqlCommand cmd = new SqlCommand("proc_ChkNIPForReversal", e_one1);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@sessionID", sessionID);
                SqlDataAdapter adpt = new SqlDataAdapter(cmd);
                adpt.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    //check the status
                    foreach (DataRow dr in dt.Rows)
                    {
                        string oldaccountno = string.Empty;
                        string medium = dr["Medium"].ToString();
                        string SM_Flag = dr["SM_Flag"] == DBNull.Value ? string.Empty : dr["SM_Flag"].ToString();
                        string SM_Customer_Acct = dr["SM_Customer_Acct"] == DBNull.Value ? string.Empty : dr["SM_Customer_Acct"].ToString();

                        if (medium.Trim().ToUpper().Equals("GAPS"))
                        {

                            if (SM_Flag.ToUpper().Trim().Equals("Y"))
                            {
                                oldaccountno = SM_Customer_Acct;
                            }
                        }
                        else
                        {
                            oldaccountno = dr["Source_Acct_no"].ToString();
                        }

                        if (string.IsNullOrEmpty(oldaccountno))
                        {
                            oldaccountno = dr["Source_Acct_no"].ToString();
                        }

                        date = Convert.ToDateTime(dr["Date"].ToString());
                        formattedDate = date.ToString("ddMMMyyyy");
                        string[] splitaccount = oldaccountno.Split('/');
                        bracode = splitaccount[0];
                        cusnum = splitaccount[1];
                        curcode = splitaccount[2];
                        ledcode = splitaccount[3];
                        subacctcode = splitaccount[4];
                        status = dr["last_response_status"].ToString();
                        amount = Convert.ToDecimal(dr["Amount"]);
                        transDesc = dr["Description"] == DBNull.Value ? status : dr["Description"].ToString();
                    }
                    string[] statuses = ConfigurationManager.AppSettings["NotFailed"].Split(',');
                    notValid = statuses.Contains(status) ? true : false;
                }
                else
                {
                    return null;
                }
            }


                trans =  ReturnNIPBasisDebitTransactions(bracode, cusnum, curcode,ledcode, subacctcode, formattedDate, sessionID);
                //Check if Transaction has been previously reversed
                if (trans != null & trans.Rows.Count > 0)
                {
                    reversed = 0;
                    foreach (DataRow dr in trans.Rows)
                    {
                        chk_expl_code = dr["EXPL_CODE"].ToString().Trim();
                        chk_deb_ind = dr["DEB_CRE_IND"].ToString().Trim();
                        if (chk_expl_code.Equals("644") || chk_deb_ind.Equals("2"))
                        {
                            reversed++;
                        }
                    }

                    if (reversed == 0)
                    {
                        var rowSources = trans.AsEnumerable()
                                        .Where(x => Convert.ToDecimal(x["Tra_amt"]) == amount);
                        if (rowSources.Any())
                        {
                            dtResult = rowSources.CopyToDataTable<DataRow>();
                        }
                    }
                    else
                        dtResult = empty;
                }
                else
                    dtResult = empty;


            //if result is not empty, then add the valid rows to the table and ch
            if (dtResult != null && dtResult.Rows.Count > 0)
            {
                DataColumn newcolumn = new DataColumn();
                newcolumn.DataType = System.Type.GetType("System.Boolean");
                newcolumn.AllowDBNull = false;
                newcolumn.Caption = "Not Valid";
                newcolumn.ColumnName = "Not Valid";
                newcolumn.DefaultValue = notValid;
                newcolumn.ReadOnly = true;
                dtResult.Columns.Add(newcolumn);
                newcolumn.SetOrdinal(0);

                DataColumn desc = new DataColumn();
                desc.DataType = System.Type.GetType("System.String");
                desc.AllowDBNull = false;
                desc.Caption = "Status";
                desc.ColumnName = "Status";
                desc.DefaultValue = transDesc;
                desc.ReadOnly = true;
                dtResult.Columns.Add(desc);
                desc.SetOrdinal(1);
                dsResult = new DataSet();
                dsResult.Tables.Add(dtResult);
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Error FirstLevelCheckTransactionsForReversals ==> " + ex.Message + "Stack trace: " + ex.StackTrace);
            throw;
        }
        return dsResult;
    }
    internal DataSet SecondLevelCheckTransactionsForReversals(string sessionID)
    {
        DataSet result = null;
        DataTable dtResult = new DataTable();
        try
        {
            string bracode = ""; string cusnum = ""; string curcode = ""; string ledcode = ""; string subacctcode = "";
            string formattedDate = null; DateTime date; string chk_expl_code = ""; string chk_deb_ind = "";
            int reversed = 0;
            DataTable empty = new DataTable();
            DataTable dt = null;
            bool notValid = false;
            decimal amount = 0;
            int count = 0;
            string transDesc = string.Empty;

            //check that it is not in AutoRevInfo table on e-one
            using (SqlConnection eoneSqlConn = new SqlConnection(EoneConnString))
            {
                dt = new DataTable();
                if (eoneSqlConn.State == ConnectionState.Closed)
                    eoneSqlConn.Open();
                SqlCommand cmd = new SqlCommand("Select TransRef from AutoRevInfo where TransRef = @TransRef", eoneSqlConn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@TransRef", sessionID);

                SqlDataAdapter adpt = new SqlDataAdapter(cmd);
                adpt.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    return result = null;
                }
            }

            //check that it is not in revinfo table on gtLoss
            using (SqlConnection gtlossSqlConn = new SqlConnection(gtLossConnString))
            {
                dt = new DataTable();
                //then retrieve from e-one               
                if (gtlossSqlConn.State == ConnectionState.Closed)
                    gtlossSqlConn.Open();
                SqlCommand cmd = new SqlCommand("Select TransRef from RevInfo where TransRef = @TransRef", gtlossSqlConn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@TransRef", sessionID);
                SqlDataAdapter adpt = new SqlDataAdapter(cmd);
                adpt.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    return result = null;
                }
            }

            using (SqlConnection e_one1 = new SqlConnection(EoneConnString))
            {
                dt = new DataTable();
                string status = string.Empty;
                //then retrieve from e-one

                if (e_one1.State == ConnectionState.Closed)
                    e_one1.Open();
                SqlCommand cmd = new SqlCommand(@"Select a.*, b.Description from Nibsstransfer_log a left join Nibss_TransStatus b on a.last_response_status = b.code
                        where TransRef = @TransRef", e_one1);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@TransRef", sessionID);
                SqlDataAdapter adpt = new SqlDataAdapter(cmd);
                adpt.Fill(dt);

                if (dt.Rows.Count <= 0)
                {
                    return result = null;
                }
                else
                {
                    //check the status
                    foreach (DataRow dr in dt.Rows)
                    {
                        string oldaccountno = dr["Source_Acct_No"].ToString();
                        date = Convert.ToDateTime(dr["Date"].ToString());
                        formattedDate = date.ToString("ddMMMyyyy");
                        string[] splitaccount = oldaccountno.Split('/');
                        bracode = splitaccount[0];
                        cusnum = splitaccount[1];
                        curcode = splitaccount[2];
                        ledcode = splitaccount[3];
                        subacctcode = splitaccount[4];
                        status = dr["last_response_status"].ToString();
                        amount = Convert.ToDecimal(dr["Amount"]);
                        transDesc = dr["Description"] == DBNull.Value ? status : dr["Description"].ToString();
                    }
                    string[] statuses = ConfigurationManager.AppSettings["NotFailed"].Split(',');
                    notValid = statuses.Contains(status) ? true : false;
                    //transDesc = returnTransStatus(status); 
                }
            }



            DataTable trans = ReturnNIPBasisDebitTransactions(bracode, cusnum, curcode, ledcode, subacctcode, formattedDate, sessionID);

            //Check if Transaction has been previously reversed
            if (trans != null & trans.Rows.Count > 0)
            {
                reversed = 0;
                foreach (DataRow dr in trans.Rows)
                {
                    chk_expl_code = dr["EXPL_CODE"].ToString().Trim();
                    chk_deb_ind = dr["DEB_CRE_IND"].ToString().Trim();
                    if (chk_expl_code.Equals("644") || chk_deb_ind.Equals("2"))
                    {
                        reversed++;
                    }
                }

                if (reversed == 0)
                {
                    var rowSources = trans.AsEnumerable()
                                    .Where(x => Convert.ToDecimal(x["Tra_amt"]) == amount);
                    if (rowSources.Any())
                    {
                        dtResult = rowSources.CopyToDataTable<DataRow>();
                    }
                }
                else
                    result = null;
            }
            else result = null;

            //if result is not empty, then add the valid rows to the table and ch
            if (dtResult != null && dtResult.Rows.Count > 0)
            {
                DataColumn newcolumn = new DataColumn();
                newcolumn.DataType = System.Type.GetType("System.Boolean");
                newcolumn.AllowDBNull = false;
                newcolumn.Caption = "Not Valid";
                newcolumn.ColumnName = "Not Valid";
                newcolumn.DefaultValue = notValid;
                newcolumn.ReadOnly = true;
                dtResult.Columns.Add(newcolumn);
                newcolumn.SetOrdinal(0);

                DataColumn desc = new DataColumn();
                desc.DataType = System.Type.GetType("System.String");
                desc.AllowDBNull = false;
                desc.Caption = "Status";
                desc.ColumnName = "Status";
                desc.DefaultValue = transDesc;
                desc.ReadOnly = true;
                dtResult.Columns.Add(desc);
                desc.SetOrdinal(1);

                result = new DataSet();
                result.Tables.Add(dtResult);
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Error SecondLevelCheckTransactionsForReversals ==> " + ex.Message + "Stack trace: " + ex.StackTrace);
            throw;
        }
        return result;
    }  
    internal Int64 UpdateNIPTransactionForReversal(string sessionID, string userID, string batchID, string reversalType, DateTime dtReqDate)
    {
        Int64 succeed = 0;
        try
        {
            using (SqlConnection conn = new SqlConnection(EoneConnString))
            {
                using (SqlCommand command = conn.CreateCommand())
                {
                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }
                    command.CommandText = "proc_InsertNIBSSRevInfo";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@sessionID", sessionID);
                    command.Parameters.AddWithValue("@InitiatedBy", userID);
                    command.Parameters.AddWithValue("@batchID", batchID);
                    command.Parameters.AddWithValue("@ReversalType", reversalType);
                    command.Parameters.AddWithValue("@reqDate", dtReqDate);

                   succeed = command.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError("Error Updating NIP Transaction for Reversal  ==> " + ex.Message + "Stack trace: " + ex.StackTrace);
            throw;
        }
        return succeed;
    }
    internal DataSet GiroOutwardNIPRevReport(string sessionID, string dateFrom, string dateTo)
    {
        DataSet dsResult = new DataSet();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(EoneConnString))
            {
                if (sqlConn.State == ConnectionState.Closed)
                {
                    sqlConn.Open();
                }

                SqlCommand sqlComm = new SqlCommand("proc_GiroOutwardNIPReversalReport", sqlConn);
                sqlComm.CommandType = CommandType.StoredProcedure;
                sqlComm.Parameters.AddWithValue("@DateFrom", dateFrom);
                sqlComm.Parameters.AddWithValue("@DateTo", dateTo);
                sqlComm.Parameters.AddWithValue("@SessionID", sessionID);

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlComm);
                sqlDataAdapter.Fill(dsResult);
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + "Stack trace: " + ex.StackTrace);
            throw;
           
        }
        return dsResult;
    }

    internal Int64 UpdateNIPTransactionsForApproval(string sessionID, string userID, int authorizationType)
    {
        Int64  result = 0;
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(EoneConnString))
            {
                if (sqlConn.State == ConnectionState.Closed)
                {
                    sqlConn.Open();
                }

                SqlCommand sqlComm = new SqlCommand("proc_ApproveNIBSSRevInfo", sqlConn);
                sqlComm.CommandType = CommandType.StoredProcedure;
                sqlComm.Parameters.AddWithValue("@TransRef", sessionID);
                sqlComm.Parameters.AddWithValue("@AuthorizedBy", userID);
                sqlComm.Parameters.AddWithValue("@AuthorizationType", authorizationType);

                result = sqlComm.ExecuteNonQuery();
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + "Stack trace: " + ex.StackTrace);
            throw;
           
        }
        return result;
    }

    


     internal DataSet ReturnNIPTransactionForApproval()
    {
        DataSet dsResult = new DataSet();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(EoneConnString))
            {
                if (sqlConn.State == ConnectionState.Closed)
                {
                    sqlConn.Open();
                }

                SqlCommand sqlComm = new SqlCommand("proc_RetrieveNIPReversalsForApproval", sqlConn);
                sqlComm.CommandType = CommandType.StoredProcedure;


                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlComm);
                sqlDataAdapter.Fill(dsResult);
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + "Stack trace: " + ex.StackTrace);
            throw;
           
        }
        return dsResult;
    }

    internal DataSet ReturnNIPTransactionForApprovalByBatchID(string batchID)
    {
        DataSet dsResult = new DataSet();
        try
        {
            using (SqlConnection sqlConn = new SqlConnection(EoneConnString))
            {
                if (sqlConn.State == ConnectionState.Closed)
                {
                    sqlConn.Open();
                }

                SqlCommand sqlComm = new SqlCommand("proc_RetrieveNIPReversalsForApprovalByBatchID", sqlConn);
                sqlComm.CommandType = CommandType.StoredProcedure;
                sqlComm.Parameters.AddWithValue("@BatchID", batchID);

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlComm);
                sqlDataAdapter.Fill(dsResult);
            }
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + "Stack trace: " + ex.StackTrace);
            throw;
           
        }
        return dsResult;
    }



    


    

}