using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Xml.XPath;
using GTCollectionDLL;
using System.Data.SqlClient;
using GTCollectionDLL.BLL;
using Newtonsoft.Json;

/// <summary>
/// Summary description for GTCollect
/// </summary>
public class GTCollect
{
    private String xmlstring = null;
    String rescode = "", resmsg = "", basisseq = "0";

    public GTCollect()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public String GetCollectionListOfValues(int LOV_ID) //String lov_name
    {

        //int LOV_ID = 0; 

        //if (lov_name == "US_LOV")
        //    LOV_ID = 24;
        //else if (lov_name == "EMBASSIES_LOV")
        //    LOV_ID = 20;

        LOVDetails ff = new LOVDetails();
        DataTable dt = new DataTable();

        try
        {
            dt.Merge(ff.GetlovDetailByLOVID(LOV_ID), true);

            xmlstring = "<Response>";

            if (dt.Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<LOVDATA>";
                foreach (DataRow drr in dt.Rows)
                {
                    xmlstring = xmlstring + "<CODE>" + drr["lov_value"].ToString() + "</CODE>";
                    xmlstring = xmlstring + "<DESCRIPTION>" + drr["lov_text"].ToString() + "</DESCRIPTION>";
                    xmlstring = xmlstring + "<AMOUNT>" + drr["lov_data"].ToString() + "</AMOUNT>";
                }
                xmlstring = xmlstring + "</LOVDATA>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "LIST OF VALUES NOT FOUND" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
        //ret.value = "1000";
        //ret.message = xmlstring;
        //return ret;
    }

    public DataTable GetCollectionListOfValues2(int LOV_ID) //String lov_name
    {

        //int LOV_ID = 0; 

        //if (lov_name == "US_LOV")
        //    LOV_ID = 24;
        //else if (lov_name == "EMBASSIES_LOV")
        //    LOV_ID = 20;

        LOVDetails ff = new LOVDetails();
        DataTable dt = new DataTable();

        try
        {
            dt.Merge(ff.GetlovDetailByLOVID(LOV_ID), true);
        }
        catch (Exception ex)
        {

        }

        return dt;
        //ret.value = "1000";
        //ret.message = xmlstring;
        //return ret;
    }

    public String GetCollectionListOfValuesData(int LOV_ID, String custLOV_value)
    {
        int US_LOV = 24;
        LOVDetails ff = new LOVDetails();
        DataTable dt = new DataTable();

        try
        {
            dt.Merge(ff.GetLOVDetailByLOVAndValue(LOV_ID, custLOV_value), true);

            xmlstring = "<Response>";

            if (dt.Rows.Count > 0)
            {
                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<LOVDATA>";
                DataRow drr = dt.Rows[0];

                xmlstring = xmlstring + "<CODE>" + drr["lov_value"].ToString() + "</CODE>";
                xmlstring = xmlstring + "<DESCRIPTION>" + drr["lov_text"].ToString() + "</DESCRIPTION>";
                xmlstring = xmlstring + "<AMOUNT>" + drr["lov_data"].ToString() + "</AMOUNT>";

                xmlstring = xmlstring + "</LOVDATA>";
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>" + "LIST OF VALUE NOT FOUND" + "</Error>";
            }

            xmlstring = xmlstring + "</Response>";
            //----------------------------------------------------------------
            //Create XML string
        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        return xmlstring;
        //ret.value = "1000";
        //ret.message = xmlstring;
        //return ret;
    }

    public DataSet GetCollectionDetails_US()
    {
        DataSet ds_result = new DataSet();
        CollForm cf = new CollForm();

        ds_result = cf.GetCollectionDetails();

        return ds_result;
    }

    public DataSet GetCollectionCustomers()
    {
        DataSet ds_result = new DataSet();
        Customer cust = new Customer();

        ds_result = cust.GetCollectionCustomers();

        return ds_result;
    }

    public String PostCollectionData_GTChurch(int customer_id, int CollFormID, String userid, String postingbranchcode, Decimal tra_amt, String narration, String customer_acct, String mem_name)
    {
        Utility ut = new Utility();
        PIN pp = null;
        DataTable dt_pin = null;
        String coll_acct = null;
        String resp_str;
        String reference = "";
        Decimal total_trans_amt = 0M;
        int res = 0;
        String customReference = "0";
        Decimal charge_amt = 0M;

        xmlstring = "<Response>";

        try
        {
            //Get reference/receipt
            CollForm ff = new CollForm();
            DataTable dd = new DataTable();
            dd.Merge(ff.GetformByID(CollFormID));

            //Get Form  fields
            FormField fff = new FormField();
            DataTable dt_fields = new DataTable();
            dt_fields.Merge(fff.GetformfieldsByFormID(CollFormID), true);

            //Retrieve field names from parameters
            foreach (DataRow dr_field in dt_fields.Rows)
            {
                if (dr_field["field_name"].ToString().ToUpper() == "Member Surname".ToUpper())
                {
                    dr_field["actual_value"] = mem_name;
                }
                else if (dr_field["field_name"].ToString().ToUpper() == "Member Other Names".ToUpper())
                {
                    dr_field["actual_value"] = string.Empty;
                }

                else if (dr_field["field_name"].ToString().ToUpper() == "AMOUNT")
                {
                    dr_field["actual_value"] = tra_amt.ToString();
                }

            }


            if (dd.Rows.Count > 0)
            {
                if (dd.Rows[0]["receiptno_mode"].ToString() == "1") //GENERATE
                {
                    //reference = GetReference(Convert.ToInt32(dd.Rows[0]["receiptno_mode"].ToString()), Convert.ToInt32(dd.Rows[0]["receiptno_length"].ToString()));
                    String ref_str = null;
                    Random random;
                    int rec_count = 1;
                    while (rec_count > 0)
                    {
                        ref_str = ut.getPIN(Convert.ToInt32(dd.Rows[0]["receiptno_type"]), Convert.ToInt32(dd.Rows[0]["receiptno_length"]));
                        //validate reference for duplicate until reference does not exist for the collection form
                        rec_count = GetExistingReference(CollFormID, ref_str);
                    }

                    reference = ref_str;
                }
                else if (dd.Rows[0]["receiptno_mode"].ToString() == "2") //VEND
                {
                    //reference = GetReference(Convert.ToInt32(dd.Rows[0]["receiptno_mode"].ToString()), Convert.ToInt32(dd.Rows[0]["receiptno_length"].ToString()));
                    pp = new PIN();
                    dt_pin = new DataTable();
                    if (dd.Rows[0]["vend_with_amount"].ToString() == "0")
                    {
                        dt_pin.Merge(pp.GetAvailablePIN(CollFormID), true);
                    }
                    else if (dd.Rows[0]["vend_with_amount"].ToString() == "1")
                        dt_pin.Merge(pp.GetAvailablePINWithAmount(tra_amt, CollFormID), true);

                    if (dt_pin.Rows.Count > 0)
                    {
                        if (dt_pin.Rows.Count > 0)
                            reference = dt_pin.Rows[0]["pin"].ToString();

                        int rec = GetExistingReference(CollFormID, reference);
                        if (rec > 0)
                        {
                            xmlstring = xmlstring + "<CODE>1010</CODE>";
                            xmlstring = xmlstring + "<Error>Selected PIN already exist. Please Try Again</Error>";
                            xmlstring = xmlstring + "</Response>";
                            return xmlstring;
                        }
                    }
                    else
                    {
                        xmlstring = xmlstring + "<CODE>1010</CODE>";
                        xmlstring = xmlstring + "<Error>No PIN is Available at the moment. Please Contact Your Admin to load more PINS</Error>";
                        xmlstring = xmlstring + "</Response>";
                        return xmlstring;
                    }
                }
                else if (dd.Rows[0]["receiptno_mode"].ToString() == "3") //CUSTOM
                {
                    reference = customReference;
                    int rec1 = GetExistingReference(CollFormID, reference);
                    if (rec1 > 0)
                    {
                        xmlstring = xmlstring + "<CODE>1010</CODE>";
                        xmlstring = xmlstring + "<Error>PIN Already Exist</Error>";
                        xmlstring = xmlstring + "</Response>";
                        return xmlstring;
                    }
                }

                if (reference == "")
                {
                    xmlstring = xmlstring + "<CODE>1010</CODE>";
                    xmlstring = xmlstring + "<Error>Could Not Retrieve Reference For Transaction</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }

                total_trans_amt = tra_amt + charge_amt;
                narration = reference + " " + narration;

                //save data in transaction table
                Transaction trans = new Transaction();
                TransactionDetail transdet = new TransactionDetail();
                int resdet = 0;

                String details_str = null;
                //---------------------------------Details-------------------------------------------
                details_str = details_str + "<DET>";
                //Insert each field in transaction details using the same transaction reference.
                foreach (DataRow dtr in dt_fields.Rows)
                {
                    details_str = details_str + "<FIELD>";
                    details_str = details_str + "<ID>" + dtr["field_id"].ToString() + "</ID>";
                    details_str = details_str + "<VALUE>" + dtr["actual_value"].ToString() + "</VALUE>";
                    details_str = details_str + "<TYPE>F</TYPE>";
                    details_str = details_str + "</FIELD>";
                }



                details_str = details_str + "</DET>";
                //--------------------------------Details--------------------------------------------


                //   DataTable dt_res = trans.InsertTransaction(DateTime.Now, userid, narration, reference, customer_id, CollFormID, total_trans_amt, postingbranchcode, "1", 2, 0, customer_acct, dd.Rows[0]["account_number"].ToString(), String.Empty, String.Empty, 1, details_str, "IBANK"); //Initialize -- Code will be "1"
                DataTable dt_res = trans.InsertTransaction(DateTime.Now, userid, narration, reference, customer_id, CollFormID, total_trans_amt, total_trans_amt, total_trans_amt, postingbranchcode, "1", 2, 0, customer_acct, dd.Rows[0]["account_number"].ToString(), String.Empty, String.Empty, 1, details_str, "IBANK", "",""); //Initialize -- Code will be "1"

                Boolean errorOccur = false;
                //Update dataset with actual values and save in session
                if (dt_res.Rows.Count > 0)
                {


                    ////Insert each field in transaction details using the same transaction reference.
                    //foreach (DataRow dtr in dt_fields.Rows)
                    //{
                    //    //Insert into transaction details
                    //    resdet = transdet.InsertTransactionDetail(Convert.ToDecimal(dt_res.Rows[0]["transid"]), Convert.ToInt32(dtr["field_id"]), dtr["field_name"].ToString(), dtr["actual_value"].ToString(), 1);
                    //}

                    ////Also include charges details for this transaction
                    //foreach (DataRow grd_r in dt_charges.Rows)
                    //{
                    //        resdet = transdet.InsertTransactionDetail(Convert.ToDecimal(dt_res.Rows[0]["transid"]), 0, grd_r["charge_desc"].ToString(), grd_r["charge_amt"].ToString(), 1);
                    //}

                    //Call GTBTECHAPPDEV service to transfer funds to respective acct debiting teller's till.
                    //Debit teller and credit collection account
                    Eone eone = new Eone();
                    coll_acct = dd.Rows[0]["account_number"].ToString();

                    if (dd.Rows[0]["authorize_credit"].ToString() == "0")
                    {
                        //LIVE
                        if (tra_amt > 0)
                        {
                            resp_str = eone.TransferFunds(customer_acct, coll_acct, Convert.ToDouble(tra_amt), "OTH", "GTCOLL", narration);
                            GetResponseMsg(resp_str);
                        }
                        else
                        {
                            rescode = "1000";
                            resmsg = "SUCCESS";
                        }

                        if (rescode == "1000")
                        {
                            errorOccur = false;
                            //Take charges. Debit customer and credit respective charge account(s)
                            Double chargeamt = 0;
                            //foreach (DataRow grd_r in dt_charges.Rows)
                            //{
                            //    chargeamt = Convert.ToDouble(grd_r["charge_amt"]);
                            //    if (chargeamt > 0)
                            //    {
                            //        resp_str = eone.TransferFunds(customer_acct, grd_r["account_number"].ToString(), chargeamt, "OTH", "GTCOLL", narration);
                            //        GetResponseMsg(resp_str);
                            //    }

                            //    if (rescode != "1000")
                            //    {
                            //        errorOccur = true;
                            //        break;
                            //    }
                            //}
                        }
                        else
                        {
                            errorOccur = true;
                        }
                    }

                    //Update PIN Used Flag if receiptno mode is Vend PIN
                    if (dd.Rows[0]["receiptno_mode"].ToString() == "2") //Vend
                    {
                        res = pp.UpdatePIN(Convert.ToInt32(dt_pin.Rows[0]["id"].ToString()));
                    }
                }
                else
                {
                    xmlstring = xmlstring + "<CODE>1010</CODE>";
                    xmlstring = xmlstring + "<Error>Cannot Retrieve Receipt for this transaction. Please Contact The Nearest Branch</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }

                //Update transaction with a value depending on the errorOccur flag
                if (errorOccur == false)
                {
                    xmlstring = xmlstring + "<CODE>1000</CODE>";

                    if (dd.Rows[0]["authorize_credit"].ToString() == "1")
                    {
                        trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "3", ""); //Pending for authorization
                        xmlstring = xmlstring + "<MESSAGE>Transaction Submitted for Approval</MESSAGE>";
                    }
                    else
                    {
                        trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "0", ""); //Successful
                        xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                    }

                    xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";
                }
                else
                {
                    trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "2", resmsg.Replace("'", "")); //Error
                    xmlstring = xmlstring + "<CODE>1010</CODE>";
                    xmlstring = xmlstring + "<Error>" + resmsg.Replace("'", "") + "</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }

                dt_pin = null;
                pp = null;

            }
            else
            {
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<Error>Could Not Retrieve VFS Information</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }


        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        xmlstring = xmlstring + "</Response>";
        return xmlstring;
    }


    public DataSet GetCollectionCustomersByCategory(int catid)
    {
        DataSet ds_result = new DataSet();
        Customer cust = new Customer();

        ds_result = this.GetCollectionCustomersByCatID(catid);

        return ds_result;
    }

    public DataSet GetCollectionCharges(int formid)
    {
        DataSet ds_result = new DataSet();
        Charge charge = new Charge();

        ds_result.Tables.Add(charge.GetOnlineChargesByFormID2(formid));

        return ds_result;
    }

    public DataSet GetBranchCollectionCharges(int formid)
    {
        DataSet ds_result = new DataSet();
        Charge charge = new Charge();

        ds_result.Tables.Add(charge.GetBranchChargesByFormID2(formid));

        return ds_result;
    }

    public DataSet GetOnlineCollectionCharges(int formid)
    {
        DataSet ds_result = new DataSet();
        Charge charge = new Charge();

        ds_result.Tables.Add(charge.GetOnlineChargesByFormID2(formid));

        return ds_result;
    }

    public DataSet GetWebCollectionCharges(int formid)
    {
        DataSet ds_result = new DataSet();
        Charge charge = new Charge();

        ds_result.Tables.Add(charge.GetWebChargesByFormID2(formid));

        return ds_result;
    }

    public DataSet GetCollectionCategtories()
    {
        DataSet ds_result = new DataSet();
        Category cf = new Category();

        ds_result.Tables.Add(cf.GetAllCategories());

        return ds_result;
    }

    public DataSet GetCollectionFormsByCategory(int catid)
    {
        DataSet ds_result = new DataSet();
        CollForm cf = new CollForm();

        ds_result = this.GetCollectionCustomersByCatID(catid);// cf.GetCollectionFormsByCategory(catid);

        return ds_result;
    }

    public DataSet GetCollectionCustomersByCatID(int catid)
    {
        DataSet ds_result = new DataSet();
        CollForm cf = new CollForm();


        SqlConnection conn;
        SqlCommand comm;
        DataSet ds = new DataSet();
        SqlDataAdapter adpt;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GTCollectionConnstr"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("SelectCollectionCustomersByCategory", conn);
            comm.Parameters.AddWithValue("@categoryid", catid);

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);

            adpt.Fill(ds);

            if (ds.Tables.Count > 0)
            {

            }
            else
            {

            }

            conn.Close();
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
            ds = null;
        }


        return ds;




    }


    public DataSet GetFormsByCustomerID(int cusid)
    {
        DataSet ds_result = new DataSet();
        CollForm cf = new CollForm();


        SqlConnection conn;
        SqlCommand comm;
        DataSet ds = new DataSet();
        SqlDataAdapter adpt;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GTCollectionConnstr"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("SelectCollectionFormsByCustomer", conn);
            comm.Parameters.AddWithValue("@customerid", cusid);

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);

            adpt.Fill(ds);

            if (ds.Tables.Count > 0)
            {

            }
            else
            {

            }
            conn.Close();

        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
            ds = null;
        }


        return ds;




    }


    public DataSet GetBranchCollectionFormsByCategory(int catid)
    {
        DataSet ds_result = new DataSet();
        CollForm cf = new CollForm();

        ds_result = cf.GetBranchCollectionFormsByCategory(catid);

        return ds_result;
    }

    public DataSet GetOnlineCollectionFormsByCategory(int catid)
    {
        DataSet ds_result = new DataSet();
        CollForm cf = new CollForm();

        ds_result = cf.GetOnlineCollectionFormsByCategory(catid);

        return ds_result;
    }

    public DataSet GetWebCollectionFormsByCategory(int catid)
    {
        DataSet ds_result = new DataSet();
        CollForm cf = new CollForm();

        ds_result = cf.GetWebCollectionFormsByCategory(catid);

        return ds_result;
    }

    public DataSet GetBranchCollectionFormsByCustomer(int cid)
    {
        DataSet ds_result = new DataSet();
        CollForm cf = new CollForm();

        ds_result = cf.GetBranchCollectionFormsByCustomer(cid);

        return ds_result;
    }

    public DataSet GetOnlineCollectionFormsByCustomer(int cid)
    {
        DataSet ds_result = new DataSet();
        CollForm cf = new CollForm();

        ds_result = cf.GetOnlineCollectionFormsByCustomer(cid);

        return ds_result;
    }

    public DataSet GetWebCollectionFormsByCustomer(int cid)
    {
        DataSet ds_result = new DataSet();
        CollForm cf = new CollForm();

        ds_result = cf.GetWebCollectionFormsByCustomer(cid);

        return ds_result;
    }

    public DataTable GetCollectionForms(int customerid)
    {
        DataTable ds_result = new DataTable();
        CollForm cf = new CollForm();

        ds_result = cf.GetCollectionForms(customerid);

        return ds_result;
    }

    public DataTable GetCollectionFormByID(int fid)
    {
        DataTable ds_result = new DataTable();
        CollForm cf = new CollForm();

        ds_result.Merge(cf.GetformByID(fid), true);
        ds_result.TableName = "FORMDETAIL";

        cf = null;
        return ds_result;
    }

    public DataSet GetCollectionFormFields(int formid)
    {
        DataSet ds_result = new DataSet();
        FormField cff = new FormField();

        ds_result = cff.GetCollectionFormFields(formid);

        return ds_result;
    }

    public DataSet GetBranchCollectionFormFields(int formid)
    {
        DataSet ds_result = new DataSet();
        FormField cff = new FormField();

        ds_result = cff.GetBranchCollectionFormFields(formid);

        return ds_result;
    }

    public DataSet GetOnlineCollectionFormFields(int formid)
    {
        DataSet ds_result = new DataSet();
        FormField cff = new FormField();

        ds_result = cff.GetOnlineCollectionFormFields(formid);

        return ds_result;
    }

    public DataSet GetWebCollectionFormFields(int formid)
    {
        DataSet ds_result = new DataSet();
        FormField cff = new FormField();

        ds_result = cff.GetWebCollectionFormFields(formid);

        return ds_result;
    }

    public DataSet GetCollectionFormFieldDetails(int customerid, int formid, DataSet dt_fieldset, String acctid, string ch)
    {
        DataTable dt_fields = dt_fieldset.Tables[0];
        DataTable dt_charges = dt_fieldset.Tables[1];
        DataTable dt_charges_split = dt_fieldset.Tables[2];
        DataTable newdt_charges_split = dt_charges_split.Copy();

        newdt_charges_split.TableName = "Charges_split";

        int rcount = 0;
        int lov_count = 0;
        DataSet val_set = null;
        DataSet val_resp = null;
        DataRow rowAdd = null;
        DataRow rowAdd_split = null;
        DataTable ID_val = null, Charge_val = null, ID_message = null;
        String validateokay = "FAILED";
        String fieldname = String.Empty;
        String collact = string.Empty;
        String gtbref = string.Empty;
        String customLOV_name = string.Empty;

        CollForm f = new CollForm();
        DataTable dt_f = new DataTable();
        dt_f.Merge(f.GetformByID(formid), true);
        collact = dt_f.Rows[0]["account_number"].ToString();

        foreach (DataRow dr_field in dt_fields.Rows)
        {
            if (dr_field["Datasource"].ToString() != "1")
            {
                fieldname = dr_field["field_name"].ToString();
                validateokay = ValidateField(dr_field["actual_value"].ToString(), dr_field["field_type"].ToString(), dr_field["field_datatype"].ToString(), Convert.ToInt32(dr_field["field_length"].ToString()), dr_field["field_mandatory"].ToString());
                if (validateokay != "SUCCESS")
                    break;
            }

        }

        ID_val = new DataTable("CustData");
        Charge_val = new DataTable("Charges");
        ID_message = new DataTable("RESPONSE");
        ID_message.Columns.Add("GTBREF", typeof(string));
        ID_message.Columns.Add("COLL_ACCT", typeof(string));
        ID_message.Columns.Add("GTBRESPONSECODE", typeof(string));
        ID_message.Columns.Add("CUSTOMLOVCONTENT", typeof(string));

        if (validateokay == "SUCCESS")
        {
            rcount = 0;
            //get data retrieval fields

            ID_val.Columns.Add("FieldName", typeof(string));
            ID_val.Columns.Add("Value", typeof(string));
            ID_val.Columns.Add("Direction", typeof(string));

            Charge_val.Columns.Add("charge_desc", typeof(string));
            Charge_val.Columns.Add("charge_amt", typeof(string));
            Charge_val.Columns.Add("account_number", typeof(string));

            //Charge_Split.Columns.Add("charge_id", typeof(Int32));
            //Charge_Split.Columns.Add("charge_desc", typeof(string));
            //Charge_Split.Columns.Add("charge_amt", typeof(string));
            //Charge_Split.Columns.Add("account_number", typeof(string));

            foreach (DataRow dr_field in dt_fields.Rows)
            {
                //check if the field uses a custom LOV (this applies to LOV and multiselct fields)
                if ((dr_field["field_type"].ToString() == "1" || dr_field["field_type"].ToString() == "4") && dr_field["field_lov"].ToString() == "1")
                {
                    customLOV_name = "GTB3RDPARTYLOV" + "_" + lov_count.ToString();
                    rowAdd = ID_val.NewRow();
                    rowAdd["FieldName"] = customLOV_name;
                    rowAdd["Direction"] = "INOUT";
                    rowAdd["Value"] = "";
                    ID_val.Rows.Add(rowAdd);
                    lov_count++;
                }
                else
                {
                    rowAdd = ID_val.NewRow();
                    rowAdd["FieldName"] = dr_field["field_name"].ToString();
                    if (dr_field["data_retrieve"].ToString() == "1" && dr_field["datasource"].ToString() == "0")
                    {
                        rowAdd["Value"] = dr_field["actual_value"].ToString();
                        rowAdd["Direction"] = "OUT";
                    }
                    else if (dr_field["data_retrieve"].ToString() == "0" && dr_field["datasource"].ToString() == "1")
                    {
                        rowAdd["Direction"] = "IN";
                    }
                    else if (dr_field["data_retrieve"].ToString() == "0" && dr_field["datasource"].ToString() == "0")
                    {
                        rowAdd["Value"] = dr_field["actual_value"].ToString();
                        rowAdd["Direction"] = "INOUT";
                    }
                    ID_val.Rows.Add(rowAdd);
                }
            }

            //For Custom Receipt Mode, Retrieve the reference
            if (dt_f.Rows[0]["receiptno_mode"].ToString() == "3") //CUSTOM
            {
                rowAdd = ID_val.NewRow();
                rowAdd["FieldName"] = "GTBREF";
                rowAdd["Direction"] = "IN";
                ID_val.Rows.Add(rowAdd);
            }

            //Add the collection account to the dataset
            rowAdd = ID_val.NewRow();
            rowAdd["FieldName"] = "COLL_ACCT";
            rowAdd["Direction"] = "INOUT";
            rowAdd["Value"] = dt_f.Rows[0]["account_number"].ToString();
            ID_val.Rows.Add(rowAdd);

            String chargedesc = "", chargeamt = "", acctno = "", chargeid;
            foreach (DataRow dr in dt_charges.Rows)
            {
                rowAdd = Charge_val.NewRow();
                chargedesc = dr["charge_desc"].ToString();
                chargeamt = dr["charge_amt"].ToString();
                acctno = dr["account_number"].ToString();
                //chargeid = dr["id"].ToString();

                rowAdd["charge_desc"] = chargedesc;
                rowAdd["charge_amt"] = chargeamt;
                rowAdd["account_number"] = acctno;
                //rowAdd["id"] = chargeid;

                Charge_val.Rows.Add(rowAdd);

                //if (dr["split_charge"].ToString() == "1")
                //{
                //    chargeid = dr["id"].ToString();
                //    foreach (DataRow dr_split in dt_charges_split.Rows)
                //    {
                //        rowAdd_split = Charge_Split.NewRow();
                //        //chargeid = (dr_split["charge_id"].ToString());
                //        chargedesc = dr_split["charge_desc"].ToString();
                //        chargeamt = dr_split["charge_amt"].ToString();
                //        acctno = dr_split["account_number"].ToString();

                //        rowAdd_split["charge_desc"] = chargedesc;
                //        rowAdd_split["charge_amt"] = chargeamt;
                //        rowAdd_split["account_number"] = acctno;
                //        rowAdd_split["charge_id"] = chargeid;
                //        Charge_Split.Rows.Add(rowAdd_split);
                //    }


                //}
            }

            //Create the dataset to be sent to the webservive
            val_set = new DataSet("ValueSet");
            val_set.Tables.Add(ID_val);
            val_set.Tables.Add(Charge_val);
            val_set.Tables.Add(newdt_charges_split);

            String resp = "", lov_content = "";

            if (dt_f.Rows[0]["use_thirdparty"].ToString() == "1")
            {
                //call webservice to retrieve data
                String dataservice_url = ConfigurationManager.AppSettings["DataWebservice"].ToString();

                CustomerDataService cds = new CustomerDataService();
                cds.Url = dataservice_url;

                //if (Session["customer_id"].ToString().CompareTo(ConfigurationManager.AppSettings["DangoteFormID"].ToString()) != 0)
                //{

                val_set = cds.GetCustomerData(formid, customerid, collact, "", "", "", "999", val_set, acctid, ch);

                ID_val = val_set.Tables["CustData"];

                foreach (DataRow drr in ID_val.Rows)
                {
                    if (drr["FieldName"].ToString() == "GTBRESPONSECODE")
                    {
                        resp = drr["Value"].ToString();
                        continue;
                    }
                    if (drr["FieldName"].ToString() == "COLL_ACCT")
                    {
                        collact = drr["Value"].ToString();
                        continue;
                    }
                    if (drr["FieldName"].ToString() == "GTBREF")
                    {
                        gtbref = drr["Value"].ToString();
                        continue;
                    }
                    if (drr["FieldName"].ToString().Contains("GTB3RDPARTYLOV"))
                    {
                        if (lov_content == "")
                            lov_content += drr["Value"].ToString();
                        else
                            lov_content += "|" + drr["Value"].ToString();

                        continue;
                    }
                }
            }
            else
            {
                resp = "SUCCESS";
            }

            rowAdd = ID_message.NewRow();
            rowAdd["GTBREF"] = gtbref;
            rowAdd["COLL_ACCT"] = collact;
            rowAdd["GTBRESPONSECODE"] = resp;
            rowAdd["CUSTOMLOVCONTENT"] = lov_content;
            ID_message.Rows.Add(rowAdd);

            //val_set.Tables.Add(ID_message);


            if (resp == "SUCCESS")
            {
                try
                {
                    rcount = 0;
                    //Update actual values
                    foreach (DataRow dr_field in dt_fieldset.Tables[0].Rows)
                    {
                        foreach (DataRow drr in val_set.Tables["CustData"].Rows)
                        {
                            if (drr["FieldName"].ToString() == dr_field["field_name"].ToString())
                            {
                                dr_field["actual_value"] = drr["Value"].ToString();
                            }
                        }
                    }

                    //Update Charges
                    foreach (DataRow dr_field in dt_fieldset.Tables[1].Rows)
                    {
                        foreach (DataRow drr in val_set.Tables["Charges"].Rows)
                        {
                            if (drr["charge_desc"].ToString() == dr_field["charge_desc"].ToString())
                            {
                                dr_field["charge_amt"] = drr["charge_amt"].ToString();
                                dr_field["account_number"] = drr["account_number"].ToString();
                            }
                        }
                    }

                    //Update Charges Splits
                    foreach (DataRow dr_field in dt_fieldset.Tables[2].Rows)
                    {
                        foreach (DataRow drr in val_set.Tables["Charges_split"].Rows)
                        {
                            if (drr["charge_id"].ToString() == dr_field["charge_id"].ToString() && drr["charge_desc"].ToString() == dr_field["charge_desc"].ToString())
                            {
                                dr_field["charge_amt"] = drr["charge_amt"].ToString();
                                dr_field["account_number"] = drr["account_number"].ToString();
                            }
                        }
                    }


                    //Update charges
                    //Charge_val = val_set.Tables["Charges"];
                    //val_resp = new DataSet();
                    //val_resp.Tables.Add(dt_fields);
                    //val_resp.Tables.Add(val_set.Tables["Charges"]);
                    //val_resp.Tables.Add(ID_message);

                    dt_fieldset.Tables.Add(ID_message);

                    ID_val = null;
                    Charge_val = null;

                    //return val_set;
                }
                catch (Exception ex)
                {
                    val_resp = new DataSet("ValueSet");

                    rowAdd = ID_message.NewRow();
                    rowAdd["GTBRESPONSECODE"] = "Error Retrieving Data: " + ex.Message.Replace("'", "");
                    ID_message.Rows.Add(rowAdd);

                    dt_fieldset.Tables.Add(ID_message);
                }
            }
            else
            {
                rowAdd = ID_message.NewRow();
                rowAdd["GTBRESPONSECODE"] = resp;
                ID_message.Rows.Add(rowAdd);

                dt_fieldset.Tables.Add(ID_message);
            }


        }
        else
        {
            //val_resp = new DataSet("ValueSet");

            rowAdd = ID_message.NewRow();
            rowAdd["GTBRESPONSECODE"] = fieldname + ": " + validateokay;
            ID_message.Rows.Add(rowAdd);

            dt_fieldset.Tables.Add(ID_message);

        }

        return dt_fieldset;
    }

    public DataSet GetCustomerData(int formid, int custid, string user_id, string postingbranchcode, DataSet dt_data, string acctid,string ch)
    {
        String dataservice_url = ConfigurationManager.AppSettings["DataWebservice"].ToString();
        CollForm cf = new CollForm();
        DataTable dt_f = new DataTable();
        DataRow dr_f;
        dt_f.Merge(cf.GetformByID(formid), true);
        dr_f = dt_f.Rows[0];

        CustomerDataService cds = new CustomerDataService();
        cds.Url = dataservice_url;
        DataSet val_resp = cds.GetCustomerData(formid, custid, dr_f["account_number"].ToString(), dr_f["alert_email"].ToString(), dr_f["cc_acct_off_email"].ToString(), user_id, postingbranchcode, dt_data, acctid,ch);

        return val_resp;
    }

    public DataSet ValidateCollectionData(int formid, int custid, string user_id, string postingbranchcode, DataSet dt_data)
    {
        DataTable dt = dt_data.Tables[0];
        DataTable dt_chg = dt_data.Tables[1];
        String validateokay = "FAILED";

        CollForm cf = new CollForm();
        DataTable dt_f = new DataTable();
        DataRow dr_f;
        dt_f.Merge(cf.GetformByID(formid), true);
        dr_f = dt_f.Rows[0];

        foreach (DataRow rr in dt.Rows)
        {
            validateokay = ValidateField(rr["actual_value"].ToString(), rr["field_type"].ToString(), rr["field_datatype"].ToString(), Convert.ToInt32(rr["field_length"].ToString()), rr["field_mandatory"].ToString());
            if (validateokay != "SUCCESS")
                break;

            //if (rr["field_type"].ToString() == "2") //TEXT
            //{
            //    validateokay = ValidateField(rr["actual_value"].ToString(), rr["field_type"].ToString(), rr["field_datatype"].ToString(), Convert.ToInt32(rr["field_length"].ToString()), rr["field_mandatory"].ToString());
            //    if (validateokay != "SUCCESS")
            //        break;

            //    //sum Amount Fields
            //    if (rr["amt_ref"].ToString() == "1")
            //    {
            //        tra_amt = tra_amt + Convert.ToDecimal(rr["actual_value"].ToString());
            //    }
            //}
            //else if (rr["field_type"].ToString() == "3") //DATE
            //{
            //    validateokay = ValidateField(rr["actual_value"].ToString(), rr["field_type"].ToString(), rr["field_datatype"].ToString(), Convert.ToInt32(rr["field_length"].ToString()), rr["field_mandatory"].ToString());
            //    if (validateokay != "SUCCESS")
            //        break;

            //}
            //else if (dt.Rows[rcount]["field_type"].ToString() == "1") //LOV
            //{
            //    validateokay = ValidateField(rr["actual_value"].ToString(), dt.Rows[rcount]["field_type"].ToString(), dt.Rows[rcount]["field_datatype"].ToString(), Convert.ToInt32(dt.Rows[rcount]["field_length"].ToString()), dt.Rows[rcount]["field_mandatory"].ToString());
            //    if (validateokay != "SUCCESS")
            //        break;

            //    lovd = null;
            //    dt_lov = null;

            //    //sum Amount Fields
            //    if (dt.Rows[rcount]["amt_ref"].ToString() == "1")
            //    {
            //        tra_amt = tra_amt + Convert.ToDecimal(dt.Rows[rcount]["actual_value"].ToString());
            //    }
            //}
        }

        if (validateokay != "SUCCESS")
        {
            //DisplayMessage(dt.Rows[rcount]["field_name"].ToString() + ": " + validateokay);
            //return;
        }


        return dt_data;
    }

    public DataSet PostValidateCollectionData(int formid, int custid, string user_id, string postingbranchcode, DataSet dt_data)
    {
        String dataservice_url = ConfigurationManager.AppSettings["DataWebservice"].ToString();
        CollForm cf = new CollForm();
        DataTable dt_f = new DataTable();
        DataRow dr_f;
        dt_f.Merge(cf.GetformByID(formid), true);
        dr_f = dt_f.Rows[0];

        CustomerDataService cds = new CustomerDataService();
        cds.Url = dataservice_url;
        DataSet val_resp = cds.PostValidationEvent(formid, custid, dr_f["account_number"].ToString(), dr_f["alert_email"].ToString(), dr_f["cc_acct_off_email"].ToString(), user_id, postingbranchcode, dt_data);

        return val_resp;
    }

    public String PostCollectionData(int customer_id, int CollFormID, String userid, String postingbranchcode, Decimal tra_amt, String narration, String customer_acct, String pptno, String fname, String lname, String dob, String phoneno, String visa_cat, String cat_name, String emb_code, String emb_name)
    {
        Utility ut = new Utility();
        PIN pp = null;
        DataTable dt_pin = null;
        String coll_acct = null;
        String resp_str;
        String reference = "";
        Decimal total_trans_amt = 0M;
        int res = 0;
        String customReference = "0";
        Decimal charge_amt = 0M;

        xmlstring = "<Response>";

        try
        {
            //Get reference/receipt
            CollForm ff = new CollForm();
            DataTable dd = new DataTable();
            dd.Merge(ff.GetformByID(CollFormID));

            //Get Form  fields
            FormField fff = new FormField();
            DataTable dt_fields = new DataTable();
            dt_fields.Merge(fff.GetformfieldsByFormID(CollFormID), true);

            //Retrieve field names from parameters
            foreach (DataRow dr_field in dt_fields.Rows)
            {
                if (dr_field["field_name"].ToString().ToUpper() == "CONFIRM EMBASSY")
                {
                    dr_field["actual_value"] = emb_code;
                }
                else if (dr_field["field_name"].ToString().ToUpper() == "EMBASSY NAME")
                {
                    dr_field["actual_value"] = emb_name;
                }
                else if (dr_field["field_name"].ToString().ToUpper() == "VISA CATEGORY")
                {
                    dr_field["actual_value"] = cat_name;
                }
                else if (dr_field["field_name"].ToString().ToUpper() == "SELECT VISA CATEGORY")
                {
                    dr_field["actual_value"] = visa_cat;
                }
                else if (dr_field["field_name"].ToString().ToUpper() == "PASSPORT NO")
                {
                    dr_field["actual_value"] = pptno;
                }
                else if (dr_field["field_name"].ToString().ToUpper() == "APPLICANT SURNAME")
                {
                    dr_field["actual_value"] = lname;
                }
                else if (dr_field["field_name"].ToString().ToUpper() == "GIVEN NAMES")
                {
                    dr_field["actual_value"] = fname;
                }
                else if (dr_field["field_name"].ToString().ToUpper() == "APPLICANT PHONE NO")
                {
                    dr_field["actual_value"] = phoneno;
                }
                else if (dr_field["field_name"].ToString().ToUpper() == "DATE OF BIRTH")
                {
                    dr_field["actual_value"] = dob;
                }
                else if (dr_field["field_name"].ToString().ToUpper() == "FEE AMOUNT")
                {
                    dr_field["actual_value"] = tra_amt.ToString();
                }
                else if (dr_field["field_name"].ToString().ToUpper() == "CONFIRM AMOUNT")
                {
                    dr_field["actual_value"] = tra_amt.ToString();
                }
                //else if (dr["field_name"].ToString().ToUpper() == "VFS CHARGE")
                //{
                //    LOGISTIC_FEE = dr["trans_value"].ToString();
                //}
                //else if (dr["field_name"].ToString().ToUpper() == "GTB CHARGE")
                //{
                //    GTB_CHARGE = dr["trans_value"].ToString();
                //}
                //else if (dr["field_name"].ToString().ToUpper() == "SMS CHARGE")
                //{
                //    SMS_CHARGE = dr["trans_value"].ToString();
                //}
                //else if (dr["field_name"].ToString().ToUpper() == "VIP CHARGE")
                //{
                //    VIP_CHARGE = dr["trans_value"].ToString();
                //}
                //else if (dr["field_name"].ToString().ToUpper() == "COURIER CHARGE")
                //{
                //    COURIER_CHARGE = dr["trans_value"].ToString();
                //}
                //else if (dr["field_name"].ToString().ToUpper() == "REPARTRIATION CHARGE")
                //{
                //    REPARTRIATION_CHARGE = dr["trans_value"].ToString();
                //}
            }

            //Get Charges (DO NOT IMPLEMENT CHARGES NOW, WE ARE COLLECTING FOR US ONLY)
            DataTable dt_charges = new DataTable();
            Charge ch = new Charge();
            dt_charges.Merge(ch.GetChargesByFormID(-1), true);
            foreach (DataRow dr_charg in dt_charges.Rows)
            {

            }

            if (dd.Rows.Count > 0)
            {
                if (dd.Rows[0]["receiptno_mode"].ToString() == "1") //GENERATE
                {
                    //reference = GetReference(Convert.ToInt32(dd.Rows[0]["receiptno_mode"].ToString()), Convert.ToInt32(dd.Rows[0]["receiptno_length"].ToString()));
                    String ref_str = null;
                    Random random;
                    int rec_count = 1;
                    while (rec_count > 0)
                    {
                        ref_str = ut.getPIN(Convert.ToInt32(dd.Rows[0]["receiptno_type"]), Convert.ToInt32(dd.Rows[0]["receiptno_length"]));
                        //validate reference for duplicate until reference does not exist for the collection form
                        rec_count = GetExistingReference(CollFormID, ref_str);
                    }

                    reference = ref_str;
                }
                else if (dd.Rows[0]["receiptno_mode"].ToString() == "2") //VEND
                {
                    //reference = GetReference(Convert.ToInt32(dd.Rows[0]["receiptno_mode"].ToString()), Convert.ToInt32(dd.Rows[0]["receiptno_length"].ToString()));
                    pp = new PIN();
                    dt_pin = new DataTable();
                    if (dd.Rows[0]["vend_with_amount"].ToString() == "0")
                    {
                        dt_pin.Merge(pp.GetAvailablePIN(CollFormID), true);
                    }
                    else if (dd.Rows[0]["vend_with_amount"].ToString() == "1")
                        dt_pin.Merge(pp.GetAvailablePINWithAmount(tra_amt, CollFormID), true);

                    if (dt_pin.Rows.Count > 0)
                    {
                        if (dt_pin.Rows.Count > 0)
                            reference = dt_pin.Rows[0]["pin"].ToString();

                        int rec = GetExistingReference(CollFormID, reference);
                        if (rec > 0)
                        {
                            xmlstring = xmlstring + "<CODE>1010</CODE>";
                            xmlstring = xmlstring + "<Error>Selected PIN already exist. Please Try Again</Error>";
                            xmlstring = xmlstring + "</Response>";
                            return xmlstring;
                        }
                    }
                    else
                    {
                        xmlstring = xmlstring + "<CODE>1010</CODE>";
                        xmlstring = xmlstring + "<Error>No PIN is Available at the moment. Please Contact Your Admin to load more PINS</Error>";
                        xmlstring = xmlstring + "</Response>";
                        return xmlstring;
                    }
                }
                else if (dd.Rows[0]["receiptno_mode"].ToString() == "3") //CUSTOM
                {
                    reference = customReference;
                    int rec1 = GetExistingReference(CollFormID, reference);
                    if (rec1 > 0)
                    {
                        xmlstring = xmlstring + "<CODE>1010</CODE>";
                        xmlstring = xmlstring + "<Error>PIN Already Exist</Error>";
                        xmlstring = xmlstring + "</Response>";
                        return xmlstring;
                    }
                }

                if (reference == "")
                {
                    xmlstring = xmlstring + "<CODE>1010</CODE>";
                    xmlstring = xmlstring + "<Error>Could Not Retrieve Reference For Transaction</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }

                total_trans_amt = tra_amt + charge_amt;
                narration = reference + " " + narration;

                //save data in transaction table
                Transaction trans = new Transaction();
                TransactionDetail transdet = new TransactionDetail();
                int resdet = 0;

                String details_str = null;
                //---------------------------------Details-------------------------------------------
                details_str = details_str + "<DET>";
                //Insert each field in transaction details using the same transaction reference.
                foreach (DataRow dtr in dt_fields.Rows)
                {
                    details_str = details_str + "<FIELD>";
                    details_str = details_str + "<ID>" + dtr["field_id"].ToString() + "</ID>";
                    details_str = details_str + "<VALUE>" + dtr["actual_value"].ToString() + "</VALUE>";
                    details_str = details_str + "<TYPE>F</TYPE>";
                    details_str = details_str + "</FIELD>";
                }

                //Also include charges details for this transaction
                foreach (DataRow grd_r in dt_charges.Rows)
                {
                    //details_str = details_str + "<FIELD>";
                    //details_str = details_str + "<ID>" + getFieldID(dt_charges, grd_r.Cells[0].Text) + "</ID>";
                    //details_str = details_str + "<VALUE>" + grd_r.Cells[1].Text + "</VALUE>";
                    //details_str = details_str + "<TYPE>C</TYPE>";
                    //details_str = details_str + "</FIELD>";   
                }

                details_str = details_str + "</DET>";
                //--------------------------------Details--------------------------------------------


                DataTable dt_res = trans.InsertTransaction(DateTime.Now, userid, narration, reference, customer_id, CollFormID, total_trans_amt, total_trans_amt, total_trans_amt, postingbranchcode, "1", 2, 0, customer_acct, dd.Rows[0]["account_number"].ToString(), String.Empty, String.Empty, 1, details_str, "IBANK", string.Empty,""); //Initialize -- Code will be "1"

                Boolean errorOccur = false;
                //Update dataset with actual values and save in session
                if (dt_res.Rows.Count > 0)
                {


                    ////Insert each field in transaction details using the same transaction reference.
                    //foreach (DataRow dtr in dt_fields.Rows)
                    //{
                    //    //Insert into transaction details
                    //    resdet = transdet.InsertTransactionDetail(Convert.ToDecimal(dt_res.Rows[0]["transid"]), Convert.ToInt32(dtr["field_id"]), dtr["field_name"].ToString(), dtr["actual_value"].ToString(), 1);
                    //}

                    ////Also include charges details for this transaction
                    //foreach (DataRow grd_r in dt_charges.Rows)
                    //{
                    //        resdet = transdet.InsertTransactionDetail(Convert.ToDecimal(dt_res.Rows[0]["transid"]), 0, grd_r["charge_desc"].ToString(), grd_r["charge_amt"].ToString(), 1);
                    //}

                    //Call GTBTECHAPPDEV service to transfer funds to respective acct debiting teller's till.
                    //Debit teller and credit collection account
                    Eone eone = new Eone();
                    coll_acct = dd.Rows[0]["account_number"].ToString();

                    if (dd.Rows[0]["authorize_credit"].ToString() == "0")
                    {
                        //LIVE
                        if (tra_amt > 0)
                        {
                            resp_str = eone.TransferFunds(customer_acct, coll_acct, Convert.ToDouble(tra_amt), "OTH", "GTCOLL", narration);
                            GetResponseMsg(resp_str);
                        }
                        else
                        {
                            rescode = "1000";
                            resmsg = "SUCCESS";
                        }

                        if (rescode == "1000")
                        {
                            errorOccur = false;
                            //Take charges. Debit customer and credit respective charge account(s)
                            Double chargeamt = 0;
                            foreach (DataRow grd_r in dt_charges.Rows)
                            {
                                chargeamt = Convert.ToDouble(grd_r["charge_amt"]);
                                if (chargeamt > 0)
                                {
                                    resp_str = eone.TransferFunds(customer_acct, grd_r["account_number"].ToString(), chargeamt, "OTH", "GTCOLL", narration);
                                    GetResponseMsg(resp_str);
                                }

                                if (rescode != "1000")
                                {
                                    errorOccur = true;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            errorOccur = true;
                        }
                    }

                    //Update PIN Used Flag if receiptno mode is Vend PIN
                    if (dd.Rows[0]["receiptno_mode"].ToString() == "2") //Vend
                    {
                        res = pp.UpdatePIN(Convert.ToInt32(dt_pin.Rows[0]["id"].ToString()));
                    }
                }
                else
                {
                    xmlstring = xmlstring + "<CODE>1010</CODE>";
                    xmlstring = xmlstring + "<Error>Cannot Retrieve Receipt for this transaction. Please Contact The Nearest Branch</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }

                //Update transaction with a value depending on the errorOccur flag
                if (errorOccur == false)
                {
                    xmlstring = xmlstring + "<CODE>1000</CODE>";

                    if (dd.Rows[0]["authorize_credit"].ToString() == "1")
                    {
                        trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "3", ""); //Pending for authorization
                        xmlstring = xmlstring + "<MESSAGE>Transaction Submitted for Approval</MESSAGE>";
                    }
                    else
                    {
                        trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "0", ""); //Successful
                        xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                    }

                    xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";
                }
                else
                {
                    trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "2", resmsg.Replace("'", "")); //Error
                    xmlstring = xmlstring + "<CODE>1010</CODE>";
                    xmlstring = xmlstring + "<Error>" + resmsg.Replace("'", "") + "</Error>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }

                dt_pin = null;
                pp = null;

            }
            else
            {
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<Error>Could Not Retrieve VFS Information</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }


        }
        catch (Exception ex)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
        }

        xmlstring = xmlstring + "</Response>";
        return xmlstring;
    }

    //public String PostCollectionData2(int customer_id, int CollFormID, String coll_acct, String userid, String postingbranchcode, Decimal total_amt, String customer_acct, String tellersuspacct, String paymentmode, String trans_type, int doc_num, String posref, String custom_receipt, String postflag, String startdate_str, String enddate_str, int frequency, DataSet dt_values)
    //{
    //    int res = 0;
    //    String validateokay = "VALIDATION FAILED";
    //    String narr = null;
    //    String basis_narr = null;
    //    String reference = "";
    //    Decimal tra_amt = 0M;
    //    Decimal tra_Charge = 0M;
    //    Decimal total_trans_amt = 0M;
    //    Decimal tra_Charge_mert = 0M;
    //    Decimal total_trans_amt_net = 0M;
    //    Decimal tra_amt_mert = 0M;
    //    String new_cre_acct = "0/0/0/0/0";
    //    String returnstr = null;
    //    String field_text = "";
    //    Utility ut = new Utility();

    //    xmlstring = "<Response>";

    //    //Iterate through the datatable to get actual values
    //    DataTable dt = dt_values.Tables[0];
    //    DataTable dt_charges = dt_values.Tables[1];
    //    foreach (DataRow rr in dt.Rows)
    //    {
    //        if (rr["field_type"].ToString() == "2") //TEXT
    //        {
    //            validateokay = ValidateField(rr["actual_value"].ToString(), rr["field_type"].ToString(), rr["field_datatype"].ToString(), Convert.ToInt32(rr["field_length"].ToString()), rr["field_mandatory"].ToString());
    //            if (validateokay != "SUCCESS")
    //            {
    //                field_text = rr["field_name"].ToString();
    //                break;
    //            }
    //            //sum Amount Fields
    //            if (rr["amt_ref"].ToString() == "1")
    //            {
    //                tra_amt = tra_amt + Convert.ToDecimal(rr["actual_value"].ToString());
    //            }
    //        }
    //        else if (rr["field_type"].ToString() == "3") //DATE
    //        {
    //            validateokay = ValidateField(rr["actual_value"].ToString(), rr["field_type"].ToString(), rr["field_datatype"].ToString(), Convert.ToInt32(rr["field_length"].ToString()), rr["field_mandatory"].ToString());
    //            if (validateokay != "SUCCESS")
    //            {
    //                field_text = rr["field_name"].ToString();
    //                break;
    //            }
    //        }
    //        else if (rr["field_type"].ToString() == "1") //LOV
    //        {
    //            validateokay = ValidateField(rr["actual_value"].ToString(), rr["field_type"].ToString(), rr["field_datatype"].ToString(), Convert.ToInt32(rr["field_length"].ToString()), rr["field_mandatory"].ToString());
    //            if (validateokay != "SUCCESS")
    //            {
    //                field_text = rr["field_name"].ToString();
    //                break;
    //            }
    //            //sum Amount Fields
    //            if (rr["amt_ref"].ToString() == "1")
    //            {
    //                tra_amt = tra_amt + Convert.ToDecimal(rr["actual_value"].ToString());
    //            }
    //        }
    //        else if (rr["field_type"].ToString() == "4") //MULTISELECT
    //        {
    //            string multiselectvalues = rr["actual_value"].ToString();

    //            validateokay = ValidateField(multiselectvalues, rr["field_type"].ToString(), rr["field_datatype"].ToString(), Convert.ToInt32(rr["field_length"].ToString()), rr["field_mandatory"].ToString());
    //            if (validateokay != "SUCCESS")
    //            {
    //                field_text = rr["field_name"].ToString();
    //                break;
    //            }

    //            //sum Amount Fields
    //            if (rr["amt_ref"].ToString() == "1")
    //            {
    //                foreach (String strarr in multiselectvalues.Split('|'))
    //                {
    //                    //get the main value part
    //                    String[] strings = strarr.Split(':');
    //                    String str = strings[0];

    //                    tra_amt = tra_amt + Convert.ToDecimal(str);
    //                }

    //            }
    //        }
    //    }

    //    if (validateokay != "SUCCESS")
    //    {
    //        returnstr = field_text + ": " + validateokay;
    //        xmlstring = xmlstring + "<CODE>1010</CODE>";
    //        xmlstring = xmlstring + "<ERROR>Error While Validating Data: " + returnstr + "</ERROR>";
    //        xmlstring = xmlstring + "</Response>";
    //        return xmlstring;
    //    }

    //    //Get Charges
    //    foreach (DataRow grd_r in dt_charges.Rows)
    //    {
    //        if (postflag == "IBANK")
    //        {
    //            if (grd_r["Merchant_bear_online_charge"].ToString() == "1")
    //                tra_Charge_mert = tra_Charge_mert + Convert.ToDecimal(grd_r["charge_amt"]);
    //            else
    //                tra_Charge = tra_Charge + Convert.ToDecimal(grd_r["charge_amt"]);
    //        }
    //        else if (postflag == "GTPAY")
    //        {
    //            if (grd_r["Merchant_bear_web_charge"].ToString() == "1")
    //                tra_Charge_mert = tra_Charge_mert + Convert.ToDecimal(grd_r["charge_amt"]);
    //            else
    //                tra_Charge = tra_Charge + Convert.ToDecimal(grd_r["charge_amt"]);
    //        }
    //        else if (postflag == "BRANCH")
    //        {
    //            if (grd_r["Merchant_bear_branch_charge"].ToString() == "1")
    //                tra_Charge_mert = tra_Charge_mert + Convert.ToDecimal(grd_r["charge_amt"]);
    //            else
    //                tra_Charge = tra_Charge + Convert.ToDecimal(grd_r["charge_amt"]);
    //        }
    //        else if (postflag == "USSD")
    //        {
    //            if (grd_r["Merchant_bear_ussd_charge"].ToString() == "1")
    //                tra_Charge_mert = tra_Charge_mert + Convert.ToDecimal(grd_r["charge_amt"]);
    //            else
    //                tra_Charge = tra_Charge + Convert.ToDecimal(grd_r["charge_amt"]);
    //        }
    //        else if (postflag == "ATM")
    //        {
    //            if (grd_r["Merchant_bear_atm_charge"].ToString() == "1")
    //                tra_Charge_mert = tra_Charge_mert + Convert.ToDecimal(grd_r["charge_amt"]);
    //            else
    //                tra_Charge = tra_Charge + Convert.ToDecimal(grd_r["charge_amt"]);
    //        }
    //        else
    //        {
    //            xmlstring = xmlstring + "<CODE>1010</CODE>";
    //            xmlstring = xmlstring + "<ERROR>Error: Invalid channel. Channel not recognized by processing engine.</ERROR>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }
    //        //else
    //        //    tra_Charge = tra_Charge + Convert.ToDecimal(grd_r["charge_amt"]);

    //    }

    //    //if (validateokay != "SUCCESS")
    //    //{
    //    //    DisplayMessage("Error Reading Transaction Data From This Page.");
    //    //    return;
    //    //}

    //    narr = "";
    //    basis_narr = "";

    //    PIN pp = null;
    //    DataTable dt_pin = null;

    //    String resp_str;


    //    //Post-Validate
    //    resp_str = PostValidate(CollFormID, customer_id, coll_acct, userid, postingbranchcode, dt_values);

    //    //resp_str = "SUCCESS";

    //    if (resp_str != "SUCCESS")
    //    {
    //        //DisplayMessage("Error While Validating Data: " + resp_str);
    //        //return;

    //        xmlstring = xmlstring + "<CODE>1010</CODE>";
    //        xmlstring = xmlstring + "<ERROR>Error While Validating Data: " + resp_str + "</ERROR>";
    //        xmlstring = xmlstring + "</Response>";
    //        return xmlstring;
    //    }

    //    Eone eone = new Eone();
    //    //Get Collection Form details
    //    CollForm ff = new CollForm();
    //    DataTable dd = new DataTable();
    //    dd.Merge(ff.GetformByID(Convert.ToInt32(CollFormID)));
    //    if (dd.Rows.Count <= 0)
    //    {
    //        //DisplayMessage("Cannot retrieve collection details for this collection");
    //        //return;

    //        xmlstring = xmlstring + "<CODE>1010</CODE>";
    //        xmlstring = xmlstring + "<ERROR>Cannot retrieve collection details.</ERROR>";
    //        xmlstring = xmlstring + "</Response>";
    //        return xmlstring;
    //    }

    //    DataRow dr_frm = dd.Rows[0];

    //    //Get narration
    //    foreach (DataRow dtr in dt.Rows)
    //    {
    //        if (dtr["field_in_remarks"].ToString() == "1")
    //        {
    //            if (dr_frm["use_remarks_separator"].ToString() == "1")
    //            {
    //                if (narr == "")
    //                    narr = narr + dtr["actual_value"].ToString().Trim(); //.PadRight(Convert.ToInt32(dtr["field_length"]));
    //                else
    //                    narr = narr + dr_frm["remarks_separator_char"].ToString() + dtr["actual_value"].ToString().Trim(); //.PadRight(Convert.ToInt32(dtr["field_length"]));
    //            }
    //            else
    //            {
    //                if (narr == "")
    //                    narr = narr + dtr["actual_value"].ToString().Trim().PadRight(Convert.ToInt32(dtr["field_length"]));
    //                else
    //                    narr = narr + dtr["actual_value"].ToString().Trim().PadRight(Convert.ToInt32(dtr["field_length"]));
    //            }
    //        }
    //    }

    //    basis_narr = narr;

    //    total_trans_amt = tra_amt + tra_Charge + tra_Charge_mert;
    //    total_trans_amt_net = tra_amt + tra_Charge;
    //    tra_amt_mert = tra_amt - tra_Charge_mert;

    //    if (tra_amt_mert < 0)
    //    {
    //        xmlstring = xmlstring + "<CODE>1010</CODE>";
    //        xmlstring = xmlstring + "<ERROR>Invalid Transaction Amount! Too many charges is being borne by the merchant. Please contact the system administrator.</ERROR>";
    //        xmlstring = xmlstring + "</Response>";
    //        return xmlstring;
    //    }

    //    if (total_trans_amt_net < 0)
    //    {
    //        xmlstring = xmlstring + "<CODE>1010</CODE>";
    //        xmlstring = xmlstring + "<ERROR>Invalid Transaction Amount! Please enter a valid amount.</ERROR>";
    //        xmlstring = xmlstring + "</Response>";
    //        return xmlstring;
    //    }

    //    ////Transfer to dangote
    //    //if (Session["customer_id"].ToString().CompareTo(ConfigurationManager.AppSettings["DangoteFormID"].ToString()) == 0)
    //    //{
    //    //    String option = String.Empty;
    //    //    Decimal amountt = 0M;
    //    //    //Check payment option
    //    //    foreach (DataRow dr1 in dt.Rows)
    //    //    {
    //    //        if (dr1["field_name"].ToString().ToUpper() == "PRINT ATC")
    //    //        {
    //    //            option = dr1["actual_value"].ToString();
    //    //            continue;
    //    //        }
    //    //        if (dr1["field_name"].ToString().ToUpper() == "AMOUNT")
    //    //        {
    //    //            amountt = Convert.ToDecimal(dr1["actual_value"]);
    //    //            continue;
    //    //        }
    //    //    }

    //    //    if (option.ToUpper() == "YES")
    //    //    {
    //    //        Session["customer"] = lst_customers.SelectedItem.Text;
    //    //        Session["form"] = lst_forms.SelectedItem.Text;
    //    //        Session["Narration_ATC"] = narr;
    //    //        Response.Redirect("Dangote_atcpage.aspx");
    //    //    }
    //    //    else
    //    //    {
    //    //        if (amountt <= 0)
    //    //        {
    //    //            DisplayMessage("Amount is required for the selected option");
    //    //            return;
    //    //        }
    //    //    }
    //    //}

    //    Boolean errorOccur = false;
    //    Transaction trans = null;
    //    StandIns sti = null;
    //    TransactionDetail transdet;
    //    DataTable dt_res;

    //    //Get reference/receipt

    //    //if (dd.Rows.Count > 0)
    //    //{
    //    if (dr_frm["receiptno_mode"].ToString() == "1") //GENERATE
    //    {
    //        //reference = GetReference(Convert.ToInt32(dr_frm["receiptno_mode"].ToString()), Convert.ToInt32(dr_frm["receiptno_length"].ToString()));
    //        String ref_str = null;
    //        int rec_count = 1;
    //        while (rec_count > 0)
    //        {
    //            ref_str = ut.getPIN(Convert.ToInt32(dr_frm["receiptno_type"]), Convert.ToInt32(dr_frm["receiptno_length"]));
    //            //validate reference for duplicate until reference does not exist for the collection form
    //            rec_count = GetExistingReference(CollFormID, ref_str);
    //        }

    //        reference = ref_str;
    //    }
    //    else if (dr_frm["receiptno_mode"].ToString() == "2")//VEND
    //    {
    //        //reference = GetReference(Convert.ToInt32(dr_frm["receiptno_mode"].ToString()), Convert.ToInt32(dr_frm["receiptno_length"].ToString()));
    //        pp = new PIN();
    //        dt_pin = new DataTable();
    //        if (dr_frm["vend_with_amount"].ToString() == "0")
    //        {
    //            dt_pin.Merge(pp.GetAvailablePIN(CollFormID), true);
    //        }
    //        else if (dr_frm["vend_with_amount"].ToString() == "1")
    //            dt_pin.Merge(pp.GetAvailablePINWithAmount(tra_amt, CollFormID), true);

    //        if (dt_pin.Rows.Count > 0)
    //        {
    //            if (dt_pin.Rows.Count > 0)
    //                reference = dt_pin.Rows[0]["pin"].ToString();

    //            int rec = GetExistingReference(CollFormID, reference);
    //            if (rec > 0)
    //            {
    //                //DisplayMessage("Cannot Post Transaction, Selected PIN already exist. Contact Your System Admin");
    //                //return;
    //                xmlstring = xmlstring + "<CODE>1010</CODE>";
    //                xmlstring = xmlstring + "<ERROR>Cannot Post Transaction, Selected PIN already exist.</ERROR>";
    //                xmlstring = xmlstring + "</Response>";
    //                return xmlstring;
    //            }
    //        }
    //        else
    //        {
    //            //DisplayMessage("No PIN is Available at the moment. Please Contact Your Admin to load more PINS");
    //            //return;
    //            xmlstring = xmlstring + "<CODE>1010</CODE>";
    //            xmlstring = xmlstring + "<ERROR>No PIN is Available at the moment.</ERROR>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }
    //    }
    //    else if (dr_frm["receiptno_mode"].ToString() == "3") //CUSTOM
    //    {
    //        reference = custom_receipt;
    //        int rec1 = GetExistingReference(CollFormID, reference);
    //        if (rec1 > 0)
    //        {
    //            //DisplayMessage("Cannot Post Transaction, PIN already exist");
    //            //return;
    //            xmlstring = xmlstring + "<CODE>1010</CODE>";
    //            xmlstring = xmlstring + "<ERROR>Cannot Post Transaction, PIN already exist</ERROR>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }
    //    }

    //    if (reference == "")
    //    {
    //        //DisplayMessage("Transaction Reference Not Valid");
    //        //return;
    //        xmlstring = xmlstring + "<CODE>1010</CODE>";
    //        xmlstring = xmlstring + "<ERROR>Cannot generate a valid transaction reference</ERROR>";
    //        xmlstring = xmlstring + "</Response>";
    //        return xmlstring;
    //    }

    //    //Append prefix and suffix
    //    reference = dr_frm["receiptno_prefix"].ToString() + reference + dr_frm["receiptno_suffix"].ToString();

    //    String details_str = null;

    //    //---------------------------------Details-------------------------------------------
    //    details_str = details_str + "<DET>";
    //    //Insert each field in transaction details using the same transaction reference.
    //    foreach (DataRow dtr in dt.Rows)
    //    {
    //        details_str = details_str + "<FIELD>";
    //        details_str = details_str + "<ID>" + dtr["field_id"].ToString() + "</ID>";
    //        details_str = details_str + "<VALUE>" + dtr["actual_value"].ToString() + "</VALUE>";
    //        details_str = details_str + "<TYPE>F</TYPE>";
    //        details_str = details_str + "</FIELD>";
    //    }

    //    //Also include charges details for this transaction
    //    foreach (DataRow grd_r in dt_charges.Rows)
    //    {
    //        //if (grd_r.RowType == DataControlRowType.DataRow)
    //        //{
    //        details_str = details_str + "<FIELD>";
    //        details_str = details_str + "<ID>" + getFieldID(dt_charges, grd_r["charge_desc"].ToString()) + "</ID>";
    //        details_str = details_str + "<VALUE>" + grd_r["charge_amt"] + "</VALUE>";
    //        details_str = details_str + "<TYPE>C</TYPE>";
    //        details_str = details_str + "</FIELD>";
    //        //}
    //    }

    //    details_str = details_str + "</DET>";
    //    //--------------------------------Details--------------------------------------------

    //    if (trans_type == "1")    //1=Payment 2=Standing Instruction
    //    {
    //        if (dr_frm["use_remarks_separator"].ToString() == "1")
    //            basis_narr = reference + dr_frm["remarks_separator_char"].ToString() + basis_narr + dr_frm["remarks_separator_char"].ToString() + postingbranchcode + dr_frm["remarks_separator_char"].ToString() + "TRANSFER";
    //        else
    //            basis_narr = reference + basis_narr + postingbranchcode + "TRANSFER";


    //        //save data in transaction table
    //        trans = new Transaction();
    //        transdet = new TransactionDetail();

    //        dt_res = trans.InsertTransaction(DateTime.Now, userid, basis_narr, reference, customer_id, CollFormID, total_trans_amt, total_trans_amt_net, tra_amt_mert, postingbranchcode, "1", Convert.ToInt32(paymentmode), doc_num, customer_acct, coll_acct, posref, String.Empty, 1, details_str, postflag); //Initialize -- Code will be "1"

    //        errorOccur = false;

    //        if (dt_res.Rows.Count > 0)
    //        {
    //            //Call GTBTECHAPPDEV service to transfer funds to respective acct debiting teller's till.
    //            //Debit teller and credit collection account
    //            //coll_acct = dr_frm["account_number"].ToString();
    //            //coll_acct = lbl_collacct.Text;

    //            //if (dr_frm["authorize_credit"].ToString() == "0")
    //            //{
    //            ////LIVE
    //            //if (paymentmode == "1")  //Cheque
    //            //{
    //            //    //Check if charges are applied, then credit teller first and use transferfund method to split from teller's till
    //            //    if (dt_charges.Rows.Count > 0)
    //            //    {
    //            //        if (total_trans_amt > 0)
    //            //        {
    //            //            new_cre_acct = tellersuspacct;
    //            //            resp_str = eone.TransferGTBCheques(customer_acct, new_cre_acct, Convert.ToDouble(total_trans_amt), "33", "GTCOLL", basis_narr, doc_num.ToString(), 4, 58, 0);
    //            //            GetResponseMsg(resp_str);
    //            //            if (rescode == "1000")
    //            //            {
    //            //                if (tra_amt > 0)
    //            //                {
    //            //                    resp_str = eone.TransferFunds(new_cre_acct, coll_acct, Convert.ToDouble(tra_amt), "OTH", "GTCOLL", basis_narr);
    //            //                    GetResponseMsg(resp_str);
    //            //                }
    //            //                else
    //            //                {
    //            //                    rescode = "1000";
    //            //                    resmsg = "SUCCESS";
    //            //                }
    //            //            }
    //            //        }
    //            //        else
    //            //        {
    //            //            rescode = "1000";
    //            //            resmsg = "SUCCESS";
    //            //        }
    //            //    }
    //            //    else
    //            //    {
    //            //        new_cre_acct = customer_acct;
    //            //        if (tra_amt > 0)
    //            //        {
    //            //            resp_str = eone.TransferFunds(new_cre_acct, coll_acct, Convert.ToDouble(tra_amt), "OTH", "GTCOLL", basis_narr);
    //            //            GetResponseMsg(resp_str);
    //            //        }
    //            //        else
    //            //        {
    //            //            rescode = "1000";
    //            //            resmsg = "SUCCESS";
    //            //        }
    //            //    }
    //            //}
    //            //else 
    //            if (paymentmode == "0" || paymentmode == "2" || paymentmode == "8")   //Cash or Transfer or USSD
    //            {
    //                new_cre_acct = customer_acct;
    //                if (tra_amt > 0)
    //                {
    //                    //resp_str = eone.TransferFunds(new_cre_acct, coll_acct, Convert.ToDouble(tra_amt_mert), "OTH", "GTCOLL", basis_narr);
    //                    resp_str = eone.TransferFunds_TranSeqCommit(new_cre_acct, coll_acct, Convert.ToDouble(tra_amt_mert), "OTH", "GTCOLLECTION_IBank", 102, basis_narr, 999, "GTCN", 0, 9938, dt_res.Rows[0]["transid"].ToString());
    //                    GetResponseMsg(resp_str);
    //                }
    //                else
    //                {
    //                    rescode = "1000";
    //                    resmsg = "SUCCESS";
    //                }
    //            }
    //            else if (paymentmode == "3")   //POS Transaction
    //            {
    //                //Do Nothing because customer's account has been debited via the POS
    //                rescode = "1000";
    //                resmsg = "SUCCESS";
    //            }
    //            //else if (paymentmode == "4")   //DRAFT Transaction
    //            //{
    //            //    //Do Nothing because DRAFT is from other bank
    //            //    rescode = "1000";
    //            //    resmsg = "SUCCESS";
    //            //}
    //            else if (paymentmode == "6")   //GTPAY Transaction
    //            {
    //                //Do Nothing because customer's account has been debited via the POS
    //                rescode = "1000";
    //                resmsg = "SUCCESS";
    //            }
    //            else if (paymentmode == "9")   //9=ATM Transaction
    //            {
    //                //Do Nothing because customer's account has been debited via the ATM
    //                rescode = "1000";
    //                resmsg = "SUCCESS";
    //            }
    //            else
    //            {
    //                rescode = "1001";
    //                resmsg = "Error: Cannot Determine Payment Mode";
    //            }

    //            if (rescode == "1000")
    //            {
    //                if (paymentmode == "2" || paymentmode == "8")    //If Not ATM, POS, GTPAY, DRAFT Transactions, post charges
    //                {
    //                    //Take charges. Debit teller and credit respective charge account(s)
    //                    Double chargeamt = 0;
    //                    foreach (DataRow grd_r in dt_charges.Rows)
    //                    {
    //                        //if (grd_r.RowType == DataControlRowType.DataRow)
    //                        //{
    //                        //Post if charge amount is not zero

    //                        //LIVE
    //                        chargeamt = Convert.ToDouble(grd_r["charge_amt"]);
    //                        if (chargeamt > 0)
    //                        {
    //                            //Check if account to debit is a GTMAX account
    //                            String[] acct_array = new_cre_acct.Split('/');
    //                            if (acct_array[3] == "2" || acct_array[3] == "6" || acct_array[3] == "8")   //GTMax account
    //                                //resp_str = eone.TransferFunds(new_cre_acct, grd_r["account_number"].ToString(), chargeamt, "GTMAX", "GTCOLL", basis_narr);
    //                                resp_str = eone.TransferFunds_TranSeqCommit(new_cre_acct, grd_r["account_number"].ToString(), chargeamt, "GTMAX", "GTCOLLECTION_IBank", 983, basis_narr, 999, "GTCN", 0, 9938, dt_res.Rows[0]["transid"].ToString());
    //                            else
    //                                //resp_str = eone.TransferFunds(new_cre_acct, grd_r["account_number"].ToString(), chargeamt, "OTH", "GTCOLL", basis_narr);
    //                                resp_str = eone.TransferFunds_TranSeqCommit(new_cre_acct, grd_r["account_number"].ToString(), chargeamt, "OTH", "GTCOLLECTION_IBank", 102, basis_narr, 999, "GTCN", 0, 9938, dt_res.Rows[0]["transid"].ToString());
                                    

    //                            GetResponseMsg(resp_str);
    //                        }

    //                        ////TEST
    //                        //rescode = "1000";

    //                        if (rescode != "1000")
    //                        {
    //                            errorOccur = true;
    //                        }
    //                        //}
    //                    }
    //                }
    //            }
    //            else
    //            {
    //                errorOccur = true;

    //            }
    //            //}

    //            //Update PIN Used Flag if receiptno mode is Vend PIN
    //            if (dr_frm["receiptno_mode"].ToString() == "2") //Vend
    //            {
    //                res = pp.UpdatePIN(Convert.ToInt32(dt_pin.Rows[0]["id"].ToString()));
    //            }
    //        }
    //        else
    //        {
    //            //DisplayMessage("Cannot post this transaction. Please contact the Applications Support team");
    //            //return;
    //            xmlstring = xmlstring + "<CODE>1010</CODE>";
    //            xmlstring = xmlstring + "<ERROR>Cannot post this transaction. Please contact the Applications Support team</ERROR>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }

    //        //Update transaction with a value depending on the errorOccur flag
    //        if (errorOccur == false)
    //        {
    //            //if (dr_frm["authorize_credit"].ToString() == "1")
    //            //{
    //            //    trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "3", ""); //Pending for authorization
    //            //    //DisplayMessageAndNavigate("Transaction Submitted for Approval by OPS head", "Home.aspx");
    //            //    xmlstring = xmlstring + "<CODE>1000</CODE>";
    //            //    xmlstring = xmlstring + "<MESSAGE>SUCCESS. Transaction Submitted for Authorization</MESSAGE>";
    //            //    xmlstring = xmlstring + "<TRANSID>" + dt_res.Rows[0]["transid"].ToString() + "</TRANSID>";
    //            //    xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";
    //            //}
    //            //else
    //            //{
    //            //Session["customer"] = lst_customers.SelectedItem.Text;
    //            //Session["form"] = lst_forms.SelectedItem.Text;
    //            //Session["transid"] = dt_res.Rows[0]["transid"];

    //            if (paymentmode == "6")     //GTPay Transaction
    //            {
    //                trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "1", "Pending GTPay Transaction"); //Successful
    //            }
    //            else if (paymentmode == "9")     //ATM Transaction
    //            {
    //                trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "0", "Successful ATM Transaction"); //Successful
    //            }
    //            else
    //            {
    //                trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "0", ""); //Successful
    //            }

    //            xmlstring = xmlstring + "<CODE>1000</CODE>";
    //            xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
    //            xmlstring = xmlstring + "<TRANSID>" + dt_res.Rows[0]["transid"].ToString() + "</TRANSID>";
    //            xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";

    //            //}
    //        }
    //        else
    //        {
    //            trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "2", resmsg.Replace("\n", "")); //Error
    //            //DisplayMessage("Cannot Post Transaction in BASIS: " + resmsg.Replace("\n", ""));
    //            //return;
    //            xmlstring = xmlstring + "<CODE>1010</CODE>";
    //            xmlstring = xmlstring + "<ERROR>Cannot Post Transaction in BASIS: " + resmsg.Replace("\n", "") + "</ERROR>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }

    //        dt_pin = null;
    //        pp = null;
    //    }
    //    else if (trans_type == "2")   //1=Payment 2=Standing Instruction
    //    {
    //        //String startdate_str = "", enddate_str = "";
    //        //Post the Standing Instruction Here
    //        //basis_narr = lst_customers.SelectedValue + lst_forms.SelectedValue + reference + "-" + basis_narr;    //CustomerID + formID + reference + narration
    //        if (dr_frm["use_remarks_separator"].ToString() == "1")
    //            basis_narr = reference + "-" + basis_narr + "-" + postingbranchcode;    //CustomerID + formID + reference + narration
    //        else
    //            basis_narr = reference + basis_narr + postingbranchcode;    //CustomerID + formID + reference + narration

    //        //save data in transaction table
    //        sti = new StandIns();
    //        transdet = new TransactionDetail();

    //        //String dateformat = "M/dd/yyyy";
    //        //DateTime dt_st = DateTime.ParseExact(Session["startdate"].ToString(), dateformat, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces);
    //        //DateTime dt_t = DateTime.ParseExact(Session["enddate"].ToString(), dateformat, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces);

    //        //DateTime dt_st = DateTime.Parse(Session["startdate"].ToString());
    //        //DateTime dt_t = DateTime.Parse(Session["enddate"].ToString());

    //        //startdate_str = Session["startdate"].ToString();
    //        //enddate_str = Session["enddate"].ToString();

    //        DateTime dt_st = new DateTime(Convert.ToInt32(startdate_str.Substring(4, 4)), Convert.ToInt32(startdate_str.Substring(2, 2)), Convert.ToInt32(startdate_str.Substring(0, 2)));
    //        DateTime dt_t = new DateTime(Convert.ToInt32(enddate_str.Substring(4, 4)), Convert.ToInt32(enddate_str.Substring(2, 2)), Convert.ToInt32(enddate_str.Substring(0, 2)));

    //        dt_res = sti.InsertStandingInstrction(customer_id, CollFormID, customer_acct, coll_acct, total_trans_amt, frequency, dt_st, dt_t, basis_narr, 1, userid, postingbranchcode, details_str);
    //        //dt_res = null; //COMMENT LATER

    //        errorOccur = false;
    //        //Update dataset with actual values and save in session
    //        if (dt_res.Rows.Count > 0)
    //        {
    //            ////Insert each field in transaction details using the same transaction reference.
    //            //foreach (DataRow dtr in dt.Rows)
    //            //{
    //            //    //Insert into transaction details
    //            //    resdet = transdet.InsertTransactionDetail(Convert.ToDecimal(dt_res.Rows[0]["id"]), Convert.ToInt32(dtr["field_id"]), dtr["field_name"].ToString(), dtr["actual_value"].ToString(), 2);
    //            //}

    //            //Create standing instrucrion in BASIS
    //            //coll_acct = lbl_collacct.Text;

    //            if (dd.Rows[0]["authorize_credit"].ToString() == "0")
    //            {
    //                //LIVE
    //                if (paymentmode == "2")   //Transfer
    //                {
    //                    new_cre_acct = customer_acct;
    //                    if (total_trans_amt > 0)
    //                    {
    //                        resp_str = eone.InitiateStandingInstruction(new_cre_acct, frequency, dt_st, total_trans_amt, dt_t, coll_acct, basis_narr);
    //                        GetResponseMsg(resp_str);
    //                    }
    //                    else
    //                    {
    //                        rescode = "1001";
    //                        resmsg = "Cannot Initiate Standing Instruction when Amount is Less than or Equal to Zero";
    //                    }
    //                }
    //                else
    //                {
    //                    rescode = "1001";
    //                    resmsg = "Error: Cannot Determine Payment Mode";
    //                }

    //                if (rescode == "1000")
    //                {
    //                    errorOccur = false;
    //                }
    //                else
    //                {
    //                    errorOccur = true;
    //                }
    //            }
    //        }
    //        else
    //        {
    //            //DisplayMessage("Cannot Complete this transaction. Kindly Contact The System Administrator");
    //            //return;
    //            xmlstring = xmlstring + "<CODE>1010</CODE>";
    //            xmlstring = xmlstring + "<ERROR>Cannot Complete this transaction. Kindly Contact The System Administrator</ERROR>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }

    //        //Update transaction with a value depending on the errorOccur flag
    //        if (errorOccur == false)
    //        {
    //            if (dr_frm["authorize_credit"].ToString() == "1")
    //            {
    //                sti.UpdateStandingInstructionStatus(Convert.ToInt32(dt_res.Rows[0]["id"]), 3, 0); //Pending for authorization
    //                //DisplayMessageAndNavigate("Standing Instruction Submitted for Approval by OPS head", "Home.aspx");
    //                xmlstring = xmlstring + "<CODE>1000</CODE>";
    //                xmlstring = xmlstring + "<MESSAGE>SUCCESS. Transaction Submitted for Approval by Branch OPS head</MESSAGE>";
    //                xmlstring = xmlstring + "<TRANSID>" + dt_res.Rows[0]["id"].ToString() + "</TRANSID>";
    //                xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";
    //            }
    //            else
    //            {
    //                //Session["customer"] = lst_customers.SelectedItem.Text;
    //                //Session["form"] = lst_forms.SelectedItem.Text;
    //                //Session["transid"] = dt_res.Rows[0]["id"];

    //                sti.UpdateStandingInstructionStatus(Convert.ToInt32(dt_res.Rows[0]["id"]), 0, Convert.ToInt32(basisseq)); //Successful
    //                //DisplayMessageAndNavigate("Standing Instruction Initiated Successfully", "Home.aspx");
    //                xmlstring = xmlstring + "<CODE>1000</CODE>";
    //                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
    //                xmlstring = xmlstring + "<TRANSID>" + dt_res.Rows[0]["id"].ToString() + "</TRANSID>";
    //                xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";
    //            }
    //        }
    //        else
    //        {
    //            sti.UpdateStandingInstructionStatus(Convert.ToInt32(dt_res.Rows[0]["id"]), 2, 0); //Error
    //            //DisplayMessage("Cannot Create Standing Instruction in BASIS: " + resmsg.Replace("\n", ""));
    //            //return;
    //            xmlstring = xmlstring + "<CODE>1010</CODE>";
    //            xmlstring = xmlstring + "<ERROR>Cannot Create Standing Instruction in BASIS: " + resmsg.Replace("\n", "") + "</ERROR>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }

    //        dt_pin = null;
    //        pp = null;

    //        //DisplayMessageAndNavigate("Standing Instruction Posted Successfully", "Home.aspx");
    //    }
    //    else if (trans_type == "3")    //1=Payment 2=Standing Instruction 3 Pay Via GTPay
    //    {
    //        if (dr_frm["use_remarks_separator"].ToString() == "1")
    //            basis_narr = reference + dr_frm["remarks_separator_char"].ToString() + basis_narr + dr_frm["remarks_separator_char"].ToString() + postingbranchcode + dr_frm["remarks_separator_char"].ToString() + "TRANSFER";
    //        else
    //            basis_narr = reference + basis_narr + postingbranchcode + "TRANSFER";


    //        //save data in transaction table
    //        trans = new Transaction();
    //        transdet = new TransactionDetail();

    //        dt_res = trans.InsertTransaction(DateTime.Now, userid, basis_narr, reference, customer_id, CollFormID, total_trans_amt, total_trans_amt_net, tra_amt_mert, postingbranchcode, "1", Convert.ToInt32(paymentmode), doc_num, customer_acct, coll_acct, posref, String.Empty, 1, details_str, postflag); //Initialize -- Code will be "1"

    //        errorOccur = false;

    //        if (dt_res.Rows.Count > 0)
    //        {


    //            string GTPayTransid = dt_res.Rows[0]["transid"].ToString();




    //            xmlstring = xmlstring + "<CODE>1000</CODE>";
    //            xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
    //            xmlstring = xmlstring + "<TRANSID>" + GTPayTransid + "</TRANSID>";
    //            xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";
    //            return xmlstring;
    //            // xmlstring = xmlstring + "<CODE>1000</CODE>";
    //            //xmlstring = xmlstring + "<TRANSID>" + GTPayTransid + "</TRANSID>";
    //            //xmlstring = xmlstring + "</Response>";

    //            //return the transaction id to be used for the transaction



    //        }

    //    }
    //    else
    //    {
    //        //DisplayMessage("Cannot Determine Transaction Type");
    //        //return;

    //        xmlstring = xmlstring + "<CODE>1010</CODE>";
    //        xmlstring = xmlstring + "<ERROR>Cannot Determine Transaction Type</ERROR>";
    //        xmlstring = xmlstring + "</Response>";
    //        return xmlstring;
    //    }
    //    //}

    //    //}

    //    xmlstring = xmlstring + "</Response>";
    //    return xmlstring;
    //}

    public String PostCollectionData2(int customer_id, int CollFormID, String coll_acct, String userid, String postingbranchcode, Decimal total_amt, String customer_acct, String tellersuspacct, String paymentmode, String trans_type, int doc_num, String posref, String custom_receipt, String postflag, String startdate_str, String enddate_str, int frequency, DataSet dt_values)
    {
        int res = 0;
        String validateokay = "VALIDATION FAILED";
        String narr = null;
        String basis_narr = null;
        String reference = "";
        Decimal tra_amt = 0M;
        Decimal tra_Charge = 0M;
        Decimal total_trans_amt = 0M;
        Decimal tra_Charge_mert = 0M;
        Decimal total_trans_amt_net = 0M;
        Decimal tra_amt_mert = 0M;
        String new_cre_acct = "0/0/0/0/0";
        String returnstr = null;
        String field_text = "";

        string [] ChevronAcct = null;
        Utility ut = new Utility();

        xmlstring = "<Response>";

        //Iterate through the datatable to get actual values
        DataTable dt = dt_values.Tables[0];
        DataTable dt_charges = dt_values.Tables[1];
        DataTable dt_charges_Split = dt_values.Tables[2];
        string details_splt_str = "";

        foreach (DataRow rr in dt.Rows)
        {
            if (rr["field_type"].ToString() == "2") //TEXT
            {
                validateokay = ValidateField(rr["actual_value"].ToString(), rr["field_type"].ToString(), rr["field_datatype"].ToString(), Convert.ToInt32(rr["field_length"].ToString()), rr["field_mandatory"].ToString());
                if (validateokay != "SUCCESS")
                {
                    field_text = rr["field_name"].ToString();
                    break;
                }
                //sum Amount Fields
                if (rr["amt_ref"].ToString() == "1")
                {
                    tra_amt = tra_amt + Convert.ToDecimal(rr["actual_value"].ToString());
                }
            }
            else if (rr["field_type"].ToString() == "3") //DATE
            {
                validateokay = ValidateField(rr["actual_value"].ToString(), rr["field_type"].ToString(), rr["field_datatype"].ToString(), Convert.ToInt32(rr["field_length"].ToString()), rr["field_mandatory"].ToString());
                if (validateokay != "SUCCESS")
                {
                    field_text = rr["field_name"].ToString();
                    break;
                }
            }
            else if (rr["field_type"].ToString() == "1") //LOV
            {
                validateokay = ValidateField(rr["actual_value"].ToString(), rr["field_type"].ToString(), rr["field_datatype"].ToString(), Convert.ToInt32(rr["field_length"].ToString()), rr["field_mandatory"].ToString());
                if (validateokay != "SUCCESS")
                {
                    field_text = rr["field_name"].ToString();
                    break;
                }
                //sum Amount Fields
                if (rr["amt_ref"].ToString() == "1")
                {
                    tra_amt = tra_amt + Convert.ToDecimal(rr["actual_value"].ToString());
                }
            }
            else if (rr["field_type"].ToString() == "4") //MULTISELECT
            {
                string multiselectvalues = rr["actual_value"].ToString();

                validateokay = ValidateField(multiselectvalues, rr["field_type"].ToString(), rr["field_datatype"].ToString(), Convert.ToInt32(rr["field_length"].ToString()), rr["field_mandatory"].ToString());
                if (validateokay != "SUCCESS")
                {
                    field_text = rr["field_name"].ToString();
                    break;
                }

                objectMultiSelect xd1;
                xd1 = JsonConvert.DeserializeObject<objectMultiSelect>(multiselectvalues);

                if (rr["amt_ref"].ToString() == "1")
                {
                    foreach (string item in xd1.sValue)
                    {
                        tra_amt = tra_amt + Convert.ToDecimal(item);
                    }
                }
            }
        }

        if (validateokay != "SUCCESS")
        {
            returnstr = field_text + ": " + validateokay;
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<ERROR>Error While Validating Data: " + returnstr + "</ERROR>";
            xmlstring = xmlstring + "</Response>";
            return xmlstring;
        }

        //Get Charges
        foreach (DataRow grd_r in dt_charges.Rows)
        {
            if (postflag == "IBANK" || postflag == "GAPS" || postflag == "MBANK")
            {
                if (grd_r["Merchant_bear_online_charge"].ToString() == "1")
                    tra_Charge_mert = tra_Charge_mert + Convert.ToDecimal(grd_r["charge_amt"]);
                else
                    tra_Charge = tra_Charge + Convert.ToDecimal(grd_r["charge_amt"]);
            }
            else if (postflag == "GTPAY")
            {
                if (grd_r["Merchant_bear_web_charge"].ToString() == "1")
                    tra_Charge_mert = tra_Charge_mert + Convert.ToDecimal(grd_r["charge_amt"]);
                else
                    tra_Charge = tra_Charge + Convert.ToDecimal(grd_r["charge_amt"]);
            }
            else if (postflag == "BRANCH")
            {
                if (grd_r["Merchant_bear_branch_charge"].ToString() == "1")
                    tra_Charge_mert = tra_Charge_mert + Convert.ToDecimal(grd_r["charge_amt"]);
                else
                    tra_Charge = tra_Charge + Convert.ToDecimal(grd_r["charge_amt"]);
            }
            else if (postflag == "USSD")
            {
                if (grd_r["Merchant_bear_ussd_charge"].ToString() == "1")
                    tra_Charge_mert = tra_Charge_mert + Convert.ToDecimal(grd_r["charge_amt"]);
                else
                    tra_Charge = tra_Charge + Convert.ToDecimal(grd_r["charge_amt"]);
            }
            else if (postflag == "ATM")
            {
                if (grd_r["Merchant_bear_atm_charge"].ToString() == "1")
                    tra_Charge_mert = tra_Charge_mert + Convert.ToDecimal(grd_r["charge_amt"]);
                else
                    tra_Charge = tra_Charge + Convert.ToDecimal(grd_r["charge_amt"]);
            }
            else
            {
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<ERROR>Error: Invalid channel. Channel not recognized by processing engine.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }
            //else
            //    tra_Charge = tra_Charge + Convert.ToDecimal(grd_r["charge_amt"]);

        }

        //if (validateokay != "SUCCESS")
        //{
        //    DisplayMessage("Error Reading Transaction Data From This Page.");
        //    return;
        //}

        narr = "";
        basis_narr = "";

        PIN pp = null;
        DataTable dt_pin = null;

        String resp_str;


        //Post-Validate
        resp_str = PostValidate(CollFormID, customer_id, coll_acct, userid, postingbranchcode, dt_values);

        //resp_str = "SUCCESS";

        if (resp_str != "SUCCESS")
        {
            //DisplayMessage("Error While Validating Data: " + resp_str);
            //return;

            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<ERROR>Error While Validating Data: " + resp_str + "</ERROR>";
            xmlstring = xmlstring + "</Response>";
            return xmlstring;
        }

        Eone eone = new Eone();
        //Get Collection Form details
        CollForm ff = new CollForm();
        DataTable dd = new DataTable();
        dd.Merge(ff.GetformByID(Convert.ToInt32(CollFormID)));
        if (dd.Rows.Count <= 0)
        {
            //DisplayMessage("Cannot retrieve collection details for this collection");
            //return;

            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<ERROR>Cannot retrieve collection details.</ERROR>";
            xmlstring = xmlstring + "</Response>";
            return xmlstring;
        }

        DataRow dr_frm = dd.Rows[0];

        //Get narration
        foreach (DataRow dtr in dt.Rows)
        {
            if (dtr["field_in_remarks"].ToString() == "1")
            {
                if (dr_frm["use_remarks_separator"].ToString() == "1")
                {
                    if (narr == "")
                        narr = narr + dtr["actual_value"].ToString().Trim(); //.PadRight(Convert.ToInt32(dtr["field_length"]));
                    else
                        narr = narr + dr_frm["remarks_separator_char"].ToString() + dtr["actual_value"].ToString().Trim(); //.PadRight(Convert.ToInt32(dtr["field_length"]));
                }
                else
                {
                    if (narr == "")
                        narr = narr + dtr["actual_value"].ToString().Trim().PadRight(Convert.ToInt32(dtr["field_length"]));
                    else
                        narr = narr + dtr["actual_value"].ToString().Trim().PadRight(Convert.ToInt32(dtr["field_length"]));
                }
            }
        }

        basis_narr = narr;

        total_trans_amt = tra_amt + tra_Charge + tra_Charge_mert;
        total_trans_amt_net = tra_amt + tra_Charge;
        tra_amt_mert = tra_amt - tra_Charge_mert;

        if (tra_amt_mert < 0)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<ERROR>Invalid Transaction Amount! Too many charges is being borne by the merchant. Please contact the system administrator.</ERROR>";
            xmlstring = xmlstring + "</Response>";
            return xmlstring;
        }

        if (total_trans_amt_net < 0)
        {
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<ERROR>Invalid Transaction Amount! Please enter a valid amount.</ERROR>";
            xmlstring = xmlstring + "</Response>";
            return xmlstring;
        }

        ////Transfer to dangote
        //if (Session["customer_id"].ToString().CompareTo(ConfigurationManager.AppSettings["DangoteFormID"].ToString()) == 0)
        //{
        //    String option = String.Empty;
        //    Decimal amountt = 0M;
        //    //Check payment option
        //    foreach (DataRow dr1 in dt.Rows)
        //    {
        //        if (dr1["field_name"].ToString().ToUpper() == "PRINT ATC")
        //        {
        //            option = dr1["actual_value"].ToString();
        //            continue;
        //        }
        //        if (dr1["field_name"].ToString().ToUpper() == "AMOUNT")
        //        {
        //            amountt = Convert.ToDecimal(dr1["actual_value"]);
        //            continue;
        //        }
        //    }

        //    if (option.ToUpper() == "YES")
        //    {
        //        Session["customer"] = lst_customers.SelectedItem.Text;
        //        Session["form"] = lst_forms.SelectedItem.Text;
        //        Session["Narration_ATC"] = narr;
        //        Response.Redirect("Dangote_atcpage.aspx");
        //    }
        //    else
        //    {
        //        if (amountt <= 0)
        //        {
        //            DisplayMessage("Amount is required for the selected option");
        //            return;
        //        }
        //    }
        //}

        Boolean errorOccur = false;
        Transaction trans = null;
        StandIns sti = null;
        TransactionDetail transdet;
        DataTable dt_res;

        //Get reference/receipt

        //if (dd.Rows.Count > 0)
        //{
        if (dr_frm["receiptno_mode"].ToString() == "1") //GENERATE
        {
            //reference = GetReference(Convert.ToInt32(dr_frm["receiptno_mode"].ToString()), Convert.ToInt32(dr_frm["receiptno_length"].ToString()));
            String ref_str = null;
            int rec_count = 1;
            while (rec_count > 0)
            {
                ref_str = ut.getPIN(Convert.ToInt32(dr_frm["receiptno_type"]), Convert.ToInt32(dr_frm["receiptno_length"]));
                //validate reference for duplicate until reference does not exist for the collection form
                rec_count = GetExistingReference(CollFormID, ref_str);
            }

            reference = ref_str;
        }
        else if (dr_frm["receiptno_mode"].ToString() == "2")//VEND
        {
            //reference = GetReference(Convert.ToInt32(dr_frm["receiptno_mode"].ToString()), Convert.ToInt32(dr_frm["receiptno_length"].ToString()));
            pp = new PIN();
            dt_pin = new DataTable();
            if (dr_frm["vend_with_amount"].ToString() == "0")
            {
                dt_pin.Merge(pp.GetAvailablePIN(CollFormID), true);
            }
            else if (dr_frm["vend_with_amount"].ToString() == "1")
                dt_pin.Merge(pp.GetAvailablePINWithAmount(tra_amt, CollFormID), true);

            if (dt_pin.Rows.Count > 0)
            {
                if (dt_pin.Rows.Count > 0)
                    reference = dt_pin.Rows[0]["pin"].ToString();

                int rec = GetExistingReference(CollFormID, reference);
                if (rec > 0)
                {
                    //DisplayMessage("Cannot Post Transaction, Selected PIN already exist. Contact Your System Admin");
                    //return;
                    xmlstring = xmlstring + "<CODE>1010</CODE>";
                    xmlstring = xmlstring + "<ERROR>Cannot Post Transaction, Selected PIN already exist.</ERROR>";
                    xmlstring = xmlstring + "</Response>";
                    return xmlstring;
                }
            }
            else
            {
                //DisplayMessage("No PIN is Available at the moment. Please Contact Your Admin to load more PINS");
                //return;
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<ERROR>No PIN is Available at the moment.</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }
        }
        else if (dr_frm["receiptno_mode"].ToString() == "3") //CUSTOM
        {
            reference = custom_receipt;
            int rec1 = GetExistingReference(CollFormID, reference);
            if (rec1 > 0)
            {
                //DisplayMessage("Cannot Post Transaction, PIN already exist");
                //return;
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<ERROR>Cannot Post Transaction, PIN already exist</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }
        }

        if (reference == "")
        {
            //DisplayMessage("Transaction Reference Not Valid");
            //return;
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<ERROR>Cannot generate a valid transaction reference</ERROR>";
            xmlstring = xmlstring + "</Response>";
            return xmlstring;
        }

        //Append prefix and suffix
        reference = dr_frm["receiptno_prefix"].ToString() + reference + dr_frm["receiptno_suffix"].ToString();

        String details_str = null;

        //---------------------------------Details-------------------------------------------
        details_str = details_str + "<DET>";
        //Insert each field in transaction details using the same transaction reference.
        foreach (DataRow dtr in dt.Rows)
        {
            details_str = details_str + "<FIELD>";
            details_str = details_str + "<ID>" + dtr["field_id"].ToString() + "</ID>";
            details_str = details_str + "<VALUE>" + dtr["actual_value"].ToString() + "</VALUE>";
            details_str = details_str + "<TYPE>F</TYPE>";
            details_str = details_str + "</FIELD>";
        }

        //Also include charges details for this transaction
        foreach (DataRow grd_r in dt_charges.Rows)
        {
            //if (grd_r.RowType == DataControlRowType.DataRow)
            //{
            details_str = details_str + "<FIELD>";
            details_str = details_str + "<ID>" + getFieldID(dt_charges, grd_r["charge_desc"].ToString()) + "</ID>";
            details_str = details_str + "<VALUE>" + grd_r["charge_amt"] + "</VALUE>";
            details_str = details_str + "<TYPE>C</TYPE>";
            details_str = details_str + "</FIELD>";
            //}
        }

        details_str = details_str + "</DET>";
        //--------------------------------Details--------------------------------------------

        //Create split charges ti XML
        if (dt_charges_Split != null)
        {
            details_splt_str = details_splt_str + "<ChargeSplitDetail>";

            foreach (DataRow grd_r in dt_charges_Split.Rows)
            //foreach (GridViewRow grd_r in grd_charges.Rows)
            {
                details_splt_str = details_splt_str + "<ChargeSplit>";
                details_splt_str = details_splt_str + "<ChargeID>" + grd_r["charge_Id"].ToString() + "</ChargeID>";
                details_splt_str = details_splt_str + "<ChargeDesc>" + grd_r["charge_desc"].ToString() + "</ChargeDesc>";
                details_splt_str = details_splt_str + "<AcctNo>" + grd_r["account_number"].ToString() + "</AcctNo>";
                details_splt_str = details_splt_str + "<ChargeAmt>" + grd_r["charge_amt"].ToString() + "</ChargeAmt>";
                details_splt_str = details_splt_str + "</ChargeSplit>";
            }


            details_splt_str = details_splt_str + "</ChargeSplitDetail>";
        }
        else
        {
            details_splt_str = "";
        }

        if (trans_type == "1")    //1=Payment 2=Standing Instruction
        {
            if (dr_frm["use_remarks_separator"].ToString() == "1")
                basis_narr = reference + dr_frm["remarks_separator_char"].ToString() + basis_narr + dr_frm["remarks_separator_char"].ToString() + postingbranchcode + dr_frm["remarks_separator_char"].ToString() + "TRANSFER";
            else
                basis_narr = reference + basis_narr + postingbranchcode + "TRANSFER";

            trans = new Transaction();
            transdet = new TransactionDetail();
            string productType = "";
            string[] array_ProductType = null;
            string armAcct = string.Empty;

            if (postflag.ToUpper() == "MBANK")
            {
                if (CollFormID.ToString() == ConfigurationManager.AppSettings["ARMFormID"].ToString().Trim())
                {
                    foreach (DataRow item in dt.Rows)
                    {
                        if (item["field_name"].ToString().ToUpper().Trim() == "PRODUCT TYPE")
                        {
                            productType = item["actual_value"].ToString();
                            break;
                        }
                    }

                    array_ProductType = productType.Split(':');
                    if (array_ProductType.GetLength(0) == 2)
                    {
                        productType = array_ProductType[0];

                        coll_acct = productType;

                    }


                }
            }

            //save data in transaction table
            trans = new Transaction();
            transdet = new TransactionDetail();

            dt_res = trans.InsertTransaction(DateTime.Now, userid, basis_narr, reference, customer_id, CollFormID, total_trans_amt, total_trans_amt_net, tra_amt_mert, postingbranchcode, "1", Convert.ToInt32(paymentmode), doc_num, customer_acct, coll_acct, posref, String.Empty, 1, details_str, postflag, details_splt_str,""); //Initialize -- Code will be "1"

            errorOccur = false;

            if (dt_res.Rows.Count > 0)
            {
                //Call GTBTECHAPPDEV service to transfer funds to respective acct debiting teller's till.
                //Debit teller and credit collection account
                //coll_acct = dr_frm["account_number"].ToString();
                //coll_acct = lbl_collacct.Text;

                //if (dr_frm["authorize_credit"].ToString() == "0")
                //{
                ////LIVE
                //if (paymentmode == "1")  //Cheque
                //{
                //    //Check if charges are applied, then credit teller first and use transferfund method to split from teller's till
                //    if (dt_charges.Rows.Count > 0)
                //    {
                //        if (total_trans_amt > 0)
                //        {
                //            new_cre_acct = tellersuspacct;
                //            resp_str = eone.TransferGTBCheques(customer_acct, new_cre_acct, Convert.ToDouble(total_trans_amt), "33", "GTCOLL", basis_narr, doc_num.ToString(), 4, 58, 0);
                //            GetResponseMsg(resp_str);
                //            if (rescode == "1000")
                //            {
                //                if (tra_amt > 0)
                //                {
                //                    resp_str = eone.TransferFunds(new_cre_acct, coll_acct, Convert.ToDouble(tra_amt), "OTH", "GTCOLL", basis_narr);
                //                    GetResponseMsg(resp_str);
                //                }
                //                else
                //                {
                //                    rescode = "1000";
                //                    resmsg = "SUCCESS";
                //                }
                //            }
                //        }
                //        else
                //        {
                //            rescode = "1000";
                //            resmsg = "SUCCESS";
                //        }
                //    }
                //    else
                //    {
                //        new_cre_acct = customer_acct;
                //        if (tra_amt > 0)
                //        {
                //            resp_str = eone.TransferFunds(new_cre_acct, coll_acct, Convert.ToDouble(tra_amt), "OTH", "GTCOLL", basis_narr);
                //            GetResponseMsg(resp_str);
                //        }
                //        else
                //        {
                //            rescode = "1000";
                //            resmsg = "SUCCESS";
                //        }
                //    }
                //}
                //else 
                if (paymentmode == "0" || paymentmode == "2" || paymentmode == "8")   //Cash or Transfer or USSD
                {
                    new_cre_acct = customer_acct;
                    int explCode = 102;

                    double chargeamtChk = 0;

                    foreach (DataRow grd_r in dt_charges.Rows)
                    {
                        chargeamtChk = chargeamtChk + Convert.ToDouble(grd_r["charge_amt"]);
                    }

                    double totalDebit_Amt = chargeamtChk + Convert.ToDouble(tra_amt_mert);

                    string balanceRes = string.Empty;
                    string[] arraynew_cre_acct = new_cre_acct.Split('/');

                    if (arraynew_cre_acct.GetLength(0) != 5)
	                {
		                xmlstring = xmlstring + "<CODE>1010</CODE>";
                        xmlstring = xmlstring + "<ERROR>Cannot post this transaction. Could not valid account no, try again latter.</ERROR>";
                        xmlstring = xmlstring + "</Response>";
                        return xmlstring;
	                }

                    balanceRes = eone.GetAccountBalance(Convert.ToInt32(arraynew_cre_acct[0]), Convert.ToInt32(arraynew_cre_acct[1]), Convert.ToInt32(arraynew_cre_acct[2]), Convert.ToInt32(arraynew_cre_acct[3]), Convert.ToInt32(arraynew_cre_acct[4]));

                    XmlDocument document1 = null;
                    XPathNavigator navigator1 = null;
                    XPathNodeIterator snodes1 = null;
                    string retcode_bal1 = string.Empty;
                    string retmsg_bal1 = string.Empty;
                    double customer_acct_bal1 = 0;

                    document1 = new XmlDocument();
                    document1.LoadXml(balanceRes);
                    navigator1 = document1.CreateNavigator();

                    snodes1 = navigator1.Select("/Response/CODE");
                    snodes1.MoveNext();
                    retcode_bal1 = snodes1.Current.Value;

                    if (retcode_bal1 != "1000")
                    {
                        snodes1 = navigator1.Select("/Response/ERROR");
                        snodes1.MoveNext();
                        xmlstring = xmlstring + "<CODE>1010</CODE>";
                        xmlstring = xmlstring + "<ERROR>Cannot post this transaction. Could not valid account balance, try again latter.</ERROR>";
                        xmlstring = xmlstring + "</Response>";
                        return xmlstring;
                    }
                    else
                    {
                        snodes1 = navigator1.Select("/Response/AVAILABLEBALANCE");
                        snodes1.MoveNext();
                        retmsg_bal1 = snodes1.Current.Value.Replace("'", "");
                        customer_acct_bal1 = Convert.ToDouble(retmsg_bal1);
                        if (customer_acct_bal1 < totalDebit_Amt)
                        {
                            snodes1 = navigator1.Select("/Response/ERROR");
                            snodes1.MoveNext();
                            xmlstring = xmlstring + "<CODE>1010</CODE>";
                            xmlstring = xmlstring + "<ERROR>Insufficient account balance.</ERROR>";
                            xmlstring = xmlstring + "</Response>";
                            return xmlstring;
                        }
                    }

                    if (tra_amt > 0)
                    {
                        if (paymentmode == "8")
                        {
                            explCode = Convert.ToInt32(ConfigurationManager.AppSettings["EXPLCODE737EXEMPT"]);
                        }

                        resp_str = eone.TransferFunds_TranSeqCommit(new_cre_acct, coll_acct, Convert.ToDouble(tra_amt_mert), "OTH", "GTCOLLECTION_IBank", explCode, basis_narr, 999, "GTCN", 0, 9938, dt_res.Rows[0]["transid"].ToString());
                        GetResponseMsg(resp_str);
                    }
                    else
                    {
                        rescode = "1000";
                        resmsg = "SUCCESS";
                    }

                    //if (tra_amt > 0)
                    //{
                    //    //resp_str = eone.TransferFunds(new_cre_acct, coll_acct, Convert.ToDouble(tra_amt_mert), "OTH", "GTCOLL", basis_narr);
                    //    resp_str = eone.TransferFunds_TranSeqCommit(new_cre_acct, coll_acct, Convert.ToDouble(tra_amt_mert), "OTH", "GTCOLLECTION_IBank", 102, basis_narr, 999, "GTCN", 0, 9938, dt_res.Rows[0]["transid"].ToString());
                    //    GetResponseMsg(resp_str);
                    //}
                    //else
                    //{
                    //    rescode = "1000";
                    //    resmsg = "SUCCESS";
                    //}
                }
                else if (paymentmode == "3")   //POS Transaction
                {
                    //Do Nothing because customer's account has been debited via the POS
                    rescode = "1000";
                    resmsg = "SUCCESS";
                }
                //else if (paymentmode == "4")   //DRAFT Transaction
                //{
                //    //Do Nothing because DRAFT is from other bank
                //    rescode = "1000";
                //    resmsg = "SUCCESS";
                //}
                else if (paymentmode == "6")   //GTPAY Transaction
                {
                    //Do Nothing because customer's account has been debited via the POS
                    rescode = "1000";
                    resmsg = "SUCCESS";
                }
                else if (paymentmode == "9")   //9=ATM Transaction
                {
                    //Do Nothing because customer's account has been debited via the ATM
                    rescode = "1000";
                    resmsg = "SUCCESS";
                }
                else
                {
                    rescode = "1001";
                    resmsg = "Error: Cannot Determine Payment Mode";
                }

                if (rescode == "1000")
                {
                    if (paymentmode == "2" || paymentmode == "8")    //If Not ATM, POS, GTPAY, DRAFT Transactions, post charges
                    {
                        //Take charges. Debit teller and credit respective charge account(s)
                        Double chargeamt = 0;
                        foreach (DataRow grd_r in dt_charges.Rows)
                        {
                            chargeamt = Convert.ToDouble(grd_r["charge_amt"]);
                            int expl_comm = 102;

                            if (!string.IsNullOrEmpty(grd_r["account_number"].ToString()))
                            {
                                if (CollFormID.ToString() == ConfigurationManager.AppSettings["RemiterFormId"].ToString() )
                                {

                                    string chevvronAccts = ConfigurationManager.AppSettings["ChevronAccounts"].ToString();
                                   ChevronAcct = chevvronAccts.Split(',') ;

                                    foreach (string x in ChevronAcct)
                                    {
                                        if (x.Contains(new_cre_acct))
                                        {
                                            chargeamt = 0;
                                            break;
                                        }
                                    }


                                    
                                    
                                }
                                
                            }

                            //if (true)
                            //{
                                
                            //}
                            //if (grd_r.RowType == DataControlRowType.DataRow)
                            //{
                            //Post if charge amount is not zero

                            //LIVE
                          
                            if (chargeamt > 0)
                            {
                                //Check if account to debit is a GTMAX account
                                String[] acct_array = new_cre_acct.Split('/');
                                if (acct_array[3] == "2" || acct_array[3] == "6" || acct_array[3] == "8")   //GTMax account
                                {
                                    //resp_str = eone.TransferFunds(new_cre_acct, grd_r["account_number"].ToString(), chargeamt, "GTMAX", "GTCOLL", basis_narr);
                                    if (grd_r["commission_ref"].ToString() == "1")
                                        expl_comm = 44;
                                    else
                                        expl_comm = 983;

                                    resp_str = eone.TransferFunds_TranSeqCommit(new_cre_acct, grd_r["account_number"].ToString(), chargeamt, "GTMAX", "GTCOLLECTION_IBank", expl_comm, basis_narr, 999, "GTCN", 0, 9938, dt_res.Rows[0]["transid"].ToString());
                                }
                                else
                                {
                                    //resp_str = eone.TransferFunds(new_cre_acct, grd_r["account_number"].ToString(), chargeamt, "OTH", "GTCOLL", basis_narr);
                                    if (grd_r["commission_ref"].ToString() == "1")
                                        expl_comm = 44;
                                    else
                                        expl_comm = 102;

                                    resp_str = eone.TransferFunds_TranSeqCommit(new_cre_acct, grd_r["account_number"].ToString(), chargeamt, "OTH", "GTCOLLECTION_IBank", expl_comm, basis_narr, 999, "GTCN", 0, 9938, dt_res.Rows[0]["transid"].ToString());
                                }

                                GetResponseMsg(resp_str);
                            }

                            ////TEST
                            //rescode = "1000";

                            if (rescode != "1000")
                            {
                                errorOccur = true;
                            }
                            //}
                        }
                    }
                }
                else
                {
                    errorOccur = true;

                }
                //}

                //Update PIN Used Flag if receiptno mode is Vend PIN
                if (dr_frm["receiptno_mode"].ToString() == "2") //Vend
                {
                    res = pp.UpdatePIN(Convert.ToInt32(dt_pin.Rows[0]["id"].ToString()));
                }
            }
            else
            {
                //DisplayMessage("Cannot post this transaction. Please contact the Applications Support team");
                //return;
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<ERROR>Cannot post this transaction. Please contact the Applications Support team</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            //Update transaction with a value depending on the errorOccur flag
            if (errorOccur == false)
            {
                //if (dr_frm["authorize_credit"].ToString() == "1")
                //{
                //    trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "3", ""); //Pending for authorization
                //    //DisplayMessageAndNavigate("Transaction Submitted for Approval by OPS head", "Home.aspx");
                //    xmlstring = xmlstring + "<CODE>1000</CODE>";
                //    xmlstring = xmlstring + "<MESSAGE>SUCCESS. Transaction Submitted for Authorization</MESSAGE>";
                //    xmlstring = xmlstring + "<TRANSID>" + dt_res.Rows[0]["transid"].ToString() + "</TRANSID>";
                //    xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";
                //}
                //else
                //{
                //Session["customer"] = lst_customers.SelectedItem.Text;
                //Session["form"] = lst_forms.SelectedItem.Text;
                //Session["transid"] = dt_res.Rows[0]["transid"];

                if (paymentmode == "6")     //GTPay Transaction
                {
                    trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "1", "Pending GTPay Transaction"); //Successful
                }
                else if (paymentmode == "9")     //ATM Transaction
                {
                    trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "0", "Successful ATM Transaction"); //Successful
                }
                else
                {
                    trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "0", ""); //Successful
                }

                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "<TRANSID>" + dt_res.Rows[0]["transid"].ToString() + "</TRANSID>";
                xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";

                //}
            }
            else
            {
                trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "2", resmsg.Replace("\n", "")); //Error
                //DisplayMessage("Cannot Post Transaction in BASIS: " + resmsg.Replace("\n", ""));
                //return;
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<ERROR>Cannot Post Transaction in BASIS: " + resmsg.Replace("\n", "") + "</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            dt_pin = null;
            pp = null;
        }
        else if (trans_type == "2")   //1=Payment 2=Standing Instruction
        {
            //String startdate_str = "", enddate_str = "";
            //Post the Standing Instruction Here
            //basis_narr = lst_customers.SelectedValue + lst_forms.SelectedValue + reference + "-" + basis_narr;    //CustomerID + formID + reference + narration
            if (dr_frm["use_remarks_separator"].ToString() == "1")
                basis_narr = reference + "-" + basis_narr + "-" + postingbranchcode;    //CustomerID + formID + reference + narration
            else
                basis_narr = reference + basis_narr + postingbranchcode;    //CustomerID + formID + reference + narration

            //save data in transaction table
            sti = new StandIns();
            transdet = new TransactionDetail();

            //String dateformat = "M/dd/yyyy";
            //DateTime dt_st = DateTime.ParseExact(Session["startdate"].ToString(), dateformat, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces);
            //DateTime dt_t = DateTime.ParseExact(Session["enddate"].ToString(), dateformat, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces);

            //DateTime dt_st = DateTime.Parse(Session["startdate"].ToString());
            //DateTime dt_t = DateTime.Parse(Session["enddate"].ToString());

            //startdate_str = Session["startdate"].ToString();
            //enddate_str = Session["enddate"].ToString();

            DateTime dt_st = new DateTime(Convert.ToInt32(startdate_str.Substring(4, 4)), Convert.ToInt32(startdate_str.Substring(2, 2)), Convert.ToInt32(startdate_str.Substring(0, 2)));
            DateTime dt_t = new DateTime(Convert.ToInt32(enddate_str.Substring(4, 4)), Convert.ToInt32(enddate_str.Substring(2, 2)), Convert.ToInt32(enddate_str.Substring(0, 2)));

            dt_res = sti.InsertStandingInstrction(customer_id, CollFormID, customer_acct, coll_acct, total_trans_amt, frequency, dt_st, dt_t, basis_narr, 1, userid, postingbranchcode, details_str);
            //dt_res = null; //COMMENT LATER

            errorOccur = false;
            //Update dataset with actual values and save in session
            if (dt_res.Rows.Count > 0)
            {
                ////Insert each field in transaction details using the same transaction reference.
                //foreach (DataRow dtr in dt.Rows)
                //{
                //    //Insert into transaction details
                //    resdet = transdet.InsertTransactionDetail(Convert.ToDecimal(dt_res.Rows[0]["id"]), Convert.ToInt32(dtr["field_id"]), dtr["field_name"].ToString(), dtr["actual_value"].ToString(), 2);
                //}

                //Create standing instrucrion in BASIS
                //coll_acct = lbl_collacct.Text;

                if (dd.Rows[0]["authorize_credit"].ToString() == "0")
                {
                    //LIVE
                    if (paymentmode == "2")   //Transfer
                    {
                        new_cre_acct = customer_acct;
                        if (total_trans_amt > 0)
                        {
                            resp_str = eone.InitiateStandingInstruction(new_cre_acct, frequency, dt_st, total_trans_amt, dt_t, coll_acct, basis_narr);
                            GetResponseMsg(resp_str);
                        }
                        else
                        {
                            rescode = "1001";
                            resmsg = "Cannot Initiate Standing Instruction when Amount is Less than or Equal to Zero";
                        }
                    }
                    else
                    {
                        rescode = "1001";
                        resmsg = "Error: Cannot Determine Payment Mode";
                    }

                    if (rescode == "1000")
                    {
                        errorOccur = false;
                    }
                    else
                    {
                        errorOccur = true;
                    }
                }
            }
            else
            {
                //DisplayMessage("Cannot Complete this transaction. Kindly Contact The System Administrator");
                //return;
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<ERROR>Cannot Complete this transaction. Kindly Contact The System Administrator</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            //Update transaction with a value depending on the errorOccur flag
            if (errorOccur == false)
            {
                if (dr_frm["authorize_credit"].ToString() == "1")
                {
                    sti.UpdateStandingInstructionStatus(Convert.ToInt32(dt_res.Rows[0]["id"]), 3, 0); //Pending for authorization
                    //DisplayMessageAndNavigate("Standing Instruction Submitted for Approval by OPS head", "Home.aspx");
                    xmlstring = xmlstring + "<CODE>1000</CODE>";
                    xmlstring = xmlstring + "<MESSAGE>SUCCESS. Transaction Submitted for Approval by Branch OPS head</MESSAGE>";
                    xmlstring = xmlstring + "<TRANSID>" + dt_res.Rows[0]["id"].ToString() + "</TRANSID>";
                    xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";
                }
                else
                {
                    //Session["customer"] = lst_customers.SelectedItem.Text;
                    //Session["form"] = lst_forms.SelectedItem.Text;
                    //Session["transid"] = dt_res.Rows[0]["id"];

                    sti.UpdateStandingInstructionStatus(Convert.ToInt32(dt_res.Rows[0]["id"]), 0, Convert.ToInt32(basisseq)); //Successful
                    //DisplayMessageAndNavigate("Standing Instruction Initiated Successfully", "Home.aspx");
                    xmlstring = xmlstring + "<CODE>1000</CODE>";
                    xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                    xmlstring = xmlstring + "<TRANSID>" + dt_res.Rows[0]["id"].ToString() + "</TRANSID>";
                    xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";
                }
            }
            else
            {
                sti.UpdateStandingInstructionStatus(Convert.ToInt32(dt_res.Rows[0]["id"]), 2, 0); //Error
                //DisplayMessage("Cannot Create Standing Instruction in BASIS: " + resmsg.Replace("\n", ""));
                //return;
                xmlstring = xmlstring + "<CODE>1010</CODE>";
                xmlstring = xmlstring + "<ERROR>Cannot Create Standing Instruction in BASIS: " + resmsg.Replace("\n", "") + "</ERROR>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            dt_pin = null;
            pp = null;

            //DisplayMessageAndNavigate("Standing Instruction Posted Successfully", "Home.aspx");
        }
        else if (trans_type == "3")    //1=Payment 2=Standing Instruction 3 Pay Via GTPay
        {
            if (dr_frm["use_remarks_separator"].ToString() == "1")
                basis_narr = reference + dr_frm["remarks_separator_char"].ToString() + basis_narr + dr_frm["remarks_separator_char"].ToString() + postingbranchcode + dr_frm["remarks_separator_char"].ToString() + "TRANSFER";
            else
                basis_narr = reference + basis_narr + postingbranchcode + "TRANSFER";


            //save data in transaction table
            trans = new Transaction();
            transdet = new TransactionDetail();

            dt_res = trans.InsertTransaction(DateTime.Now, userid, basis_narr, reference, customer_id, CollFormID, total_trans_amt, total_trans_amt_net, tra_amt_mert, postingbranchcode, "1", Convert.ToInt32(paymentmode), doc_num, customer_acct, coll_acct, posref, String.Empty, 1, details_str, postflag, string.Empty,""); //Initialize -- Code will be "1"

            errorOccur = false;

            if (dt_res.Rows.Count > 0)
            {


                string GTPayTransid = dt_res.Rows[0]["transid"].ToString();


                xmlstring = xmlstring + "<CODE>1000</CODE>";
                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
                xmlstring = xmlstring + "<TRANSID>" + GTPayTransid + "</TRANSID>";
                xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";
                return xmlstring;
                // xmlstring = xmlstring + "<CODE>1000</CODE>";
                //xmlstring = xmlstring + "<TRANSID>" + GTPayTransid + "</TRANSID>";
                //xmlstring = xmlstring + "</Response>";

                //return the transaction id to be used for the transaction


            }

        }
        else
        {
            //DisplayMessage("Cannot Determine Transaction Type");
            //return;

            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<ERROR>Cannot Determine Transaction Type</ERROR>";
            xmlstring = xmlstring + "</Response>";
            return xmlstring;
        }
        //}

        //}

        xmlstring = xmlstring + "</Response>";
        return xmlstring;
    }

    public String UpdateCollectionData(decimal transid, String transref)
    {
        int resp = 0;
        Transaction trans = new Transaction();
        resp = trans.UpdateTransaction2(transid, "0", ""); //Successful

        return resp.ToString();
    }

    public int UpdateTransaction(Decimal ptransid, String pstatus, String pmessage)
    {
        int resp = 0;
        Transaction trans = new Transaction();

        resp = trans.UpdateTransaction2(ptransid, pstatus, pmessage);

        return resp;
    }

    //public String PostCollectionDataGTPay(int customer_id, int CollFormID, String coll_acct, String userid, String postingbranchcode, Decimal total_amt, String customer_acct, String tellersuspacct, String paymentmode, String trans_type, int doc_num, String posref, String custom_receipt, String postflag, String startdate_str, String enddate_str, int frequency, DataSet dt_values)
    //{
    //    int res = 0;
    //    String validateokay = "VALIDATION FAILED";
    //    String narr = null;
    //    String basis_narr = null;
    //    String reference = "";
    //    Decimal tra_amt = 0M;
    //    Decimal tra_Charge = 0M;
    //    Decimal total_trans_amt = 0M;
    //    String new_cre_acct = "0/0/0/0/0";
    //    String returnstr = null;
    //    String field_text = "";
    //    Utility ut = new Utility();

    //    xmlstring = "<Response>";

    //    //Iterate through the datatable to get actual values
    //    DataTable dt = dt_values.Tables[0];
    //    DataTable dt_charges = dt_values.Tables[1];
    //    foreach (DataRow rr in dt.Rows)
    //    {
    //        if (rr["field_type"].ToString() == "2") //TEXT
    //        {
    //            validateokay = ValidateField(rr["actual_value"].ToString(), rr["field_type"].ToString(), rr["field_datatype"].ToString(), Convert.ToInt32(rr["field_length"].ToString()), rr["field_mandatory"].ToString());
    //            if (validateokay != "SUCCESS")
    //            {
    //                field_text = rr["field_name"].ToString();
    //                break;
    //            }
    //            //sum Amount Fields
    //            if (rr["amt_ref"].ToString() == "1")
    //            {
    //                tra_amt = tra_amt + Convert.ToDecimal(rr["actual_value"].ToString());
    //            }
    //        }
    //        else if (rr["field_type"].ToString() == "3") //DATE
    //        {
    //            validateokay = ValidateField(rr["actual_value"].ToString(), rr["field_type"].ToString(), rr["field_datatype"].ToString(), Convert.ToInt32(rr["field_length"].ToString()), rr["field_mandatory"].ToString());
    //            if (validateokay != "SUCCESS")
    //            {
    //                field_text = rr["field_name"].ToString();
    //                break;
    //            }
    //        }
    //        else if (rr["field_type"].ToString() == "1") //LOV
    //        {
    //            validateokay = ValidateField(rr["actual_value"].ToString(), rr["field_type"].ToString(), rr["field_datatype"].ToString(), Convert.ToInt32(rr["field_length"].ToString()), rr["field_mandatory"].ToString());
    //            if (validateokay != "SUCCESS")
    //            {
    //                field_text = rr["field_name"].ToString();
    //                break;
    //            }
    //            //sum Amount Fields
    //            if (rr["amt_ref"].ToString() == "1")
    //            {
    //                tra_amt = tra_amt + Convert.ToDecimal(rr["actual_value"].ToString());
    //            }
    //        }
    //    }

    //    if (validateokay != "SUCCESS")
    //    {
    //        returnstr = field_text + ": " + validateokay;
    //    }

    //    //Get Charges
    //    foreach (DataRow grd_r in dt_charges.Rows)
    //    {
    //        tra_Charge = tra_Charge + Convert.ToDecimal(grd_r["charge_amt"]);
    //    }

    //    //if (validateokay != "SUCCESS")
    //    //{
    //    //    DisplayMessage("Error Reading Transaction Data From This Page.");
    //    //    return;
    //    //}

    //    narr = "";
    //    basis_narr = "";

    //    PIN pp = null;
    //    DataTable dt_pin = null;

    //    String resp_str;


    //    //Post-Validate
    //    resp_str = PostValidate(CollFormID, customer_id, coll_acct, userid, postingbranchcode, dt_values);

    //    //resp_str = "SUCCESS";

    //    if (resp_str != "SUCCESS")
    //    {
    //        //DisplayMessage("Error While Validating Data: " + resp_str);
    //        //return;

    //        xmlstring = xmlstring + "<CODE>1010</CODE>";
    //        xmlstring = xmlstring + "<ERROR>Error While Validating Data: " + resp_str + "</ERROR>";
    //        xmlstring = xmlstring + "</Response>";
    //        return xmlstring;
    //    }

    //    Eone eone = new Eone();
    //    //Get Collection Form details
    //    CollForm ff = new CollForm();
    //    DataTable dd = new DataTable();
    //    dd.Merge(ff.GetformByID(Convert.ToInt32(CollFormID)));
    //    if (dd.Rows.Count <= 0)
    //    {
    //        //DisplayMessage("Cannot retrieve collection details for this collection");
    //        //return;

    //        xmlstring = xmlstring + "<CODE>1010</CODE>";
    //        xmlstring = xmlstring + "<ERROR>Cannot retrieve collection details.</ERROR>";
    //        xmlstring = xmlstring + "</Response>";
    //        return xmlstring;
    //    }

    //    DataRow dr_frm = dd.Rows[0];

    //    //Get narration
    //    foreach (DataRow dtr in dt.Rows)
    //    {
    //        if (dtr["field_in_remarks"].ToString() == "1")
    //        {
    //            if (dr_frm["use_remarks_separator"].ToString() == "1")
    //            {
    //                if (narr == "")
    //                    narr = narr + dtr["actual_value"].ToString().Trim(); //.PadRight(Convert.ToInt32(dtr["field_length"]));
    //                else
    //                    narr = narr + dr_frm["remarks_separator_char"].ToString() + dtr["actual_value"].ToString().Trim(); //.PadRight(Convert.ToInt32(dtr["field_length"]));
    //            }
    //            else
    //            {
    //                if (narr == "")
    //                    narr = narr + dtr["actual_value"].ToString().Trim().PadRight(Convert.ToInt32(dtr["field_length"]));
    //                else
    //                    narr = narr + dtr["actual_value"].ToString().Trim().PadRight(Convert.ToInt32(dtr["field_length"]));
    //            }
    //        }
    //    }

    //    basis_narr = narr;

    //    total_trans_amt = tra_amt + tra_Charge;

    //    ////Transfer to dangote
    //    //if (Session["customer_id"].ToString().CompareTo(ConfigurationManager.AppSettings["DangoteFormID"].ToString()) == 0)
    //    //{
    //    //    String option = String.Empty;
    //    //    Decimal amountt = 0M;
    //    //    //Check payment option
    //    //    foreach (DataRow dr1 in dt.Rows)
    //    //    {
    //    //        if (dr1["field_name"].ToString().ToUpper() == "PRINT ATC")
    //    //        {
    //    //            option = dr1["actual_value"].ToString();
    //    //            continue;
    //    //        }
    //    //        if (dr1["field_name"].ToString().ToUpper() == "AMOUNT")
    //    //        {
    //    //            amountt = Convert.ToDecimal(dr1["actual_value"]);
    //    //            continue;
    //    //        }
    //    //    }

    //    //    if (option.ToUpper() == "YES")
    //    //    {
    //    //        Session["customer"] = lst_customers.SelectedItem.Text;
    //    //        Session["form"] = lst_forms.SelectedItem.Text;
    //    //        Session["Narration_ATC"] = narr;
    //    //        Response.Redirect("Dangote_atcpage.aspx");
    //    //    }
    //    //    else
    //    //    {
    //    //        if (amountt <= 0)
    //    //        {
    //    //            DisplayMessage("Amount is required for the selected option");
    //    //            return;
    //    //        }
    //    //    }
    //    //}

    //    Boolean errorOccur = false;
    //    Transaction trans = null;
    //    StandIns sti = null;
    //    TransactionDetail transdet;
    //    DataTable dt_res;

    //    //Get reference/receipt

    //    //if (dd.Rows.Count > 0)
    //    //{
    //    if (dr_frm["receiptno_mode"].ToString() == "1") //GENERATE
    //    {
    //        //reference = GetReference(Convert.ToInt32(dr_frm["receiptno_mode"].ToString()), Convert.ToInt32(dr_frm["receiptno_length"].ToString()));
    //        String ref_str = null;
    //        int rec_count = 1;
    //        while (rec_count > 0)
    //        {
    //            ref_str = ut.getPIN(Convert.ToInt32(dr_frm["receiptno_type"]), Convert.ToInt32(dr_frm["receiptno_length"]));
    //            //validate reference for duplicate until reference does not exist for the collection form
    //            rec_count = GetExistingReference(CollFormID, ref_str);
    //        }

    //        reference = ref_str;
    //    }
    //    else if (dr_frm["receiptno_mode"].ToString() == "2")//VEND
    //    {
    //        //reference = GetReference(Convert.ToInt32(dr_frm["receiptno_mode"].ToString()), Convert.ToInt32(dr_frm["receiptno_length"].ToString()));
    //        pp = new PIN();
    //        dt_pin = new DataTable();
    //        if (dr_frm["vend_with_amount"].ToString() == "0")
    //        {
    //            dt_pin.Merge(pp.GetAvailablePIN(CollFormID), true);
    //        }
    //        else if (dr_frm["vend_with_amount"].ToString() == "1")
    //            dt_pin.Merge(pp.GetAvailablePINWithAmount(tra_amt, CollFormID), true);

    //        if (dt_pin.Rows.Count > 0)
    //        {
    //            if (dt_pin.Rows.Count > 0)
    //                reference = dt_pin.Rows[0]["pin"].ToString();

    //            int rec = GetExistingReference(CollFormID, reference);
    //            if (rec > 0)
    //            {
    //                //DisplayMessage("Cannot Post Transaction, Selected PIN already exist. Contact Your System Admin");
    //                //return;
    //                xmlstring = xmlstring + "<CODE>1010</CODE>";
    //                xmlstring = xmlstring + "<ERROR>Cannot Post Transaction, Selected PIN already exist.</ERROR>";
    //                xmlstring = xmlstring + "</Response>";
    //                return xmlstring;
    //            }
    //        }
    //        else
    //        {
    //            //DisplayMessage("No PIN is Available at the moment. Please Contact Your Admin to load more PINS");
    //            //return;
    //            xmlstring = xmlstring + "<CODE>1010</CODE>";
    //            xmlstring = xmlstring + "<ERROR>No PIN is Available at the moment.</ERROR>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }
    //    }
    //    else if (dr_frm["receiptno_mode"].ToString() == "3") //CUSTOM
    //    {
    //        reference = custom_receipt;
    //        int rec1 = GetExistingReference(CollFormID, reference);
    //        if (rec1 > 0)
    //        {
    //            //DisplayMessage("Cannot Post Transaction, PIN already exist");
    //            //return;
    //            xmlstring = xmlstring + "<CODE>1010</CODE>";
    //            xmlstring = xmlstring + "<ERROR>Cannot Post Transaction, PIN already exist</ERROR>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }
    //    }

    //    if (reference == "")
    //    {
    //        //DisplayMessage("Transaction Reference Not Valid");
    //        //return;
    //        xmlstring = xmlstring + "<CODE>1010</CODE>";
    //        xmlstring = xmlstring + "<ERROR>Cannot generate a valid transaction reference</ERROR>";
    //        xmlstring = xmlstring + "</Response>";
    //        return xmlstring;
    //    }

    //    //Append prefix and suffix
    //    reference = dr_frm["receiptno_prefix"].ToString() + reference + dr_frm["receiptno_suffix"].ToString();

    //    String details_str = null;

    //    //---------------------------------Details-------------------------------------------
    //    details_str = details_str + "<DET>";
    //    //Insert each field in transaction details using the same transaction reference.
    //    foreach (DataRow dtr in dt.Rows)
    //    {
    //        details_str = details_str + "<FIELD>";
    //        details_str = details_str + "<ID>" + dtr["field_id"].ToString() + "</ID>";
    //        details_str = details_str + "<VALUE>" + dtr["actual_value"].ToString() + "</VALUE>";
    //        details_str = details_str + "<TYPE>F</TYPE>";
    //        details_str = details_str + "</FIELD>";
    //    }

    //    //Also include charges details for this transaction
    //    foreach (DataRow grd_r in dt_charges.Rows)
    //    {
    //        //if (grd_r.RowType == DataControlRowType.DataRow)
    //        //{
    //        details_str = details_str + "<FIELD>";
    //        details_str = details_str + "<ID>" + getFieldID(dt_charges, grd_r["charge_desc"].ToString()) + "</ID>";
    //        details_str = details_str + "<VALUE>" + grd_r["charge_amt"] + "</VALUE>";
    //        details_str = details_str + "<TYPE>C</TYPE>";
    //        details_str = details_str + "</FIELD>";
    //        //}
    //    }

    //    details_str = details_str + "</DET>";
    //    //--------------------------------Details--------------------------------------------

    //    if (trans_type == "1")    //1=Payment 2=Standing Instruction
    //    {
    //        if (dr_frm["use_remarks_separator"].ToString() == "1")
    //            basis_narr = reference + dr_frm["remarks_separator_char"].ToString() + basis_narr + dr_frm["remarks_separator_char"].ToString() + postingbranchcode + dr_frm["remarks_separator_char"].ToString() + "TRANSFER";
    //        else
    //            basis_narr = reference + basis_narr + postingbranchcode + "TRANSFER";


    //        //save data in transaction table
    //        trans = new Transaction();
    //        transdet = new TransactionDetail();

    //        dt_res = trans.InsertTransaction(DateTime.Now, userid, basis_narr, reference, customer_id, CollFormID, total_trans_amt, postingbranchcode, "1", Convert.ToInt32(paymentmode), doc_num, customer_acct, coll_acct, posref, String.Empty, 1, details_str, postflag); //Initialize -- Code will be "1"

    //        errorOccur = false;

    //        if (dt_res.Rows.Count > 0)
    //        {
    //            //Call GTBTECHAPPDEV service to transfer funds to respective acct debiting teller's till.
    //            //Debit teller and credit collection account
    //            //coll_acct = dr_frm["account_number"].ToString();
    //            //coll_acct = lbl_collacct.Text;

    //            if (dr_frm["authorize_credit"].ToString() == "0")
    //            {
    //                //LIVE
    //                if (paymentmode == "1")  //Cheque
    //                {
    //                    //Check if charges are applied, then credit teller first and use transferfund method to split from teller's till
    //                    if (dt_charges.Rows.Count > 0)
    //                    {
    //                        if (total_trans_amt > 0)
    //                        {
    //                            new_cre_acct = tellersuspacct;
    //                            resp_str = eone.TransferGTBCheques(customer_acct, new_cre_acct, Convert.ToDouble(total_trans_amt), "33", "GTCOLL", basis_narr, doc_num.ToString(), 4, 58, 0);
    //                            GetResponseMsg(resp_str);
    //                            if (rescode == "1000")
    //                            {
    //                                if (tra_amt > 0)
    //                                {
    //                                    resp_str = eone.TransferFunds(new_cre_acct, coll_acct, Convert.ToDouble(tra_amt), "OTH", "GTCOLL", basis_narr);
    //                                    GetResponseMsg(resp_str);
    //                                }
    //                                else
    //                                {
    //                                    rescode = "1000";
    //                                    resmsg = "SUCCESS";
    //                                }
    //                            }
    //                        }
    //                        else
    //                        {
    //                            rescode = "1000";
    //                            resmsg = "SUCCESS";
    //                        }
    //                    }
    //                    else
    //                    {
    //                        new_cre_acct = customer_acct;
    //                        if (tra_amt > 0)
    //                        {
    //                            resp_str = eone.TransferFunds(new_cre_acct, coll_acct, Convert.ToDouble(tra_amt), "OTH", "GTCOLL", basis_narr);
    //                            GetResponseMsg(resp_str);
    //                        }
    //                        else
    //                        {
    //                            rescode = "1000";
    //                            resmsg = "SUCCESS";
    //                        }
    //                    }
    //                }
    //                else if (paymentmode == "0" || paymentmode == "2")   //Cash or Transfer
    //                {
    //                    new_cre_acct = customer_acct;
    //                    if (tra_amt > 0)
    //                    {
    //                        resp_str = eone.TransferFunds(new_cre_acct, coll_acct, Convert.ToDouble(tra_amt), "OTH", "GTCOLL", basis_narr);
    //                        GetResponseMsg(resp_str);
    //                    }
    //                    else
    //                    {
    //                        rescode = "1000";
    //                        resmsg = "SUCCESS";
    //                    }
    //                }
    //                else if (paymentmode == "3")   //POS Transaction
    //                {
    //                    //Do Nothing because customer's account has been debited via the POS
    //                    rescode = "1000";
    //                    resmsg = "SUCCESS";
    //                }
    //                else if (paymentmode == "4")   //DRAFT Transaction
    //                {
    //                    //Do Nothing because DRAFT is from other bank
    //                    rescode = "1000";
    //                    resmsg = "SUCCESS";
    //                }
    //                else
    //                {
    //                    rescode = "1001";
    //                    resmsg = "Error: Cannot Determine Payment Mode";
    //                }

    //                if (rescode == "1000")
    //                {
    //                    if (paymentmode != "3" && paymentmode != "4")    //If Not POS Transactions and Not DRAFT Transaction, post charges
    //                    {
    //                        //Take charges. Debit teller and credit respective charge account(s)
    //                        Double chargeamt = 0;
    //                        foreach (DataRow grd_r in dt_charges.Rows)
    //                        {
    //                            //if (grd_r.RowType == DataControlRowType.DataRow)
    //                            //{
    //                            //Post if charge amount is not zero

    //                            //LIVE
    //                            chargeamt = Convert.ToDouble(grd_r["charge_amt"]);
    //                            if (chargeamt > 0)
    //                            {
    //                                resp_str = eone.TransferFunds(new_cre_acct, grd_r["account_number"].ToString(), chargeamt, "OTH", "GTCOLL", basis_narr);
    //                                GetResponseMsg(resp_str);
    //                            }

    //                            ////TEST
    //                            //rescode = "1000";

    //                            if (rescode != "1000")
    //                            {
    //                                errorOccur = true;
    //                            }
    //                            //}
    //                        }
    //                    }
    //                }
    //                else
    //                {
    //                    errorOccur = true;

    //                }
    //            }

    //            //Update PIN Used Flag if receiptno mode is Vend PIN
    //            if (dr_frm["receiptno_mode"].ToString() == "2") //Vend
    //            {
    //                res = pp.UpdatePIN(Convert.ToInt32(dt_pin.Rows[0]["id"].ToString()));
    //            }
    //        }
    //        else
    //        {
    //            //DisplayMessage("Cannot post this transaction. Please contact the Applications Support team");
    //            //return;
    //            xmlstring = xmlstring + "<CODE>1010</CODE>";
    //            xmlstring = xmlstring + "<ERROR>Cannot post this transaction. Please contact the Applications Support team</ERROR>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }

    //        //Update transaction with a value depending on the errorOccur flag
    //        if (errorOccur == false)
    //        {
    //            if (dr_frm["authorize_credit"].ToString() == "1")
    //            {
    //                trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "3", ""); //Pending for authorization
    //                //DisplayMessageAndNavigate("Transaction Submitted for Approval by OPS head", "Home.aspx");
    //                xmlstring = xmlstring + "<CODE>1000</CODE>";
    //                xmlstring = xmlstring + "<MESSAGE>SUCCESS. Transaction Submitted for Approval by Branch OPS head</MESSAGE>";
    //                xmlstring = xmlstring + "<TRANSID>" + dt_res.Rows[0]["transid"].ToString() + "</TRANSID>";
    //                xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";
    //            }
    //            else
    //            {
    //                //Session["customer"] = lst_customers.SelectedItem.Text;
    //                //Session["form"] = lst_forms.SelectedItem.Text;
    //                //Session["transid"] = dt_res.Rows[0]["transid"];

    //                trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "0", ""); //Successful
    //                //Response.Redirect("trans_summary.aspx");
    //                xmlstring = xmlstring + "<CODE>1000</CODE>";
    //                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
    //                xmlstring = xmlstring + "<TRANSID>" + dt_res.Rows[0]["transid"].ToString() + "</TRANSID>";
    //                xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";
    //            }
    //        }
    //        else
    //        {
    //            trans.UpdateTransaction2(Convert.ToDecimal(dt_res.Rows[0]["transid"]), "2", resmsg.Replace("\n", "")); //Error
    //            //DisplayMessage("Cannot Post Transaction in BASIS: " + resmsg.Replace("\n", ""));
    //            //return;
    //            xmlstring = xmlstring + "<CODE>1010</CODE>";
    //            xmlstring = xmlstring + "<ERROR>Cannot Post Transaction in BASIS: " + resmsg.Replace("\n", "") + "</ERROR>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }

    //        dt_pin = null;
    //        pp = null;
    //    }
    //    else if (trans_type == "2")   //1=Payment 2=Standing Instruction
    //    {
    //        //String startdate_str = "", enddate_str = "";
    //        //Post the Standing Instruction Here
    //        //basis_narr = lst_customers.SelectedValue + lst_forms.SelectedValue + reference + "-" + basis_narr;    //CustomerID + formID + reference + narration
    //        if (dr_frm["use_remarks_separator"].ToString() == "1")
    //            basis_narr = reference + "-" + basis_narr + "-" + postingbranchcode;    //CustomerID + formID + reference + narration
    //        else
    //            basis_narr = reference + basis_narr + postingbranchcode;    //CustomerID + formID + reference + narration

    //        //save data in transaction table
    //        sti = new StandIns();
    //        transdet = new TransactionDetail();

    //        //String dateformat = "M/dd/yyyy";
    //        //DateTime dt_st = DateTime.ParseExact(Session["startdate"].ToString(), dateformat, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces);
    //        //DateTime dt_t = DateTime.ParseExact(Session["enddate"].ToString(), dateformat, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces);

    //        //DateTime dt_st = DateTime.Parse(Session["startdate"].ToString());
    //        //DateTime dt_t = DateTime.Parse(Session["enddate"].ToString());

    //        //startdate_str = Session["startdate"].ToString();
    //        //enddate_str = Session["enddate"].ToString();

    //        DateTime dt_st = new DateTime(Convert.ToInt32(startdate_str.Substring(4, 4)), Convert.ToInt32(startdate_str.Substring(2, 2)), Convert.ToInt32(startdate_str.Substring(0, 2)));
    //        DateTime dt_t = new DateTime(Convert.ToInt32(enddate_str.Substring(4, 4)), Convert.ToInt32(enddate_str.Substring(2, 2)), Convert.ToInt32(enddate_str.Substring(0, 2)));

    //        dt_res = sti.InsertStandingInstrction(customer_id, CollFormID, customer_acct, coll_acct, total_trans_amt, frequency, dt_st, dt_t, basis_narr, 1, userid, postingbranchcode, details_str);
    //        //dt_res = null; //COMMENT LATER

    //        errorOccur = false;
    //        //Update dataset with actual values and save in session
    //        if (dt_res.Rows.Count > 0)
    //        {
    //            ////Insert each field in transaction details using the same transaction reference.
    //            //foreach (DataRow dtr in dt.Rows)
    //            //{
    //            //    //Insert into transaction details
    //            //    resdet = transdet.InsertTransactionDetail(Convert.ToDecimal(dt_res.Rows[0]["id"]), Convert.ToInt32(dtr["field_id"]), dtr["field_name"].ToString(), dtr["actual_value"].ToString(), 2);
    //            //}

    //            //Create standing instrucrion in BASIS
    //            //coll_acct = lbl_collacct.Text;

    //            if (dd.Rows[0]["authorize_credit"].ToString() == "0")
    //            {
    //                //LIVE
    //                if (paymentmode == "2")   //Transfer
    //                {
    //                    new_cre_acct = customer_acct;
    //                    if (total_trans_amt > 0)
    //                    {
    //                        resp_str = eone.InitiateStandingInstruction(new_cre_acct, frequency, dt_st, total_trans_amt, dt_t, coll_acct, basis_narr);
    //                        GetResponseMsg(resp_str);
    //                    }
    //                    else
    //                    {
    //                        rescode = "1001";
    //                        resmsg = "Cannot Initiate Standing Instruction when Amount is Less than or Equal to Zero";
    //                    }
    //                }
    //                else
    //                {
    //                    rescode = "1001";
    //                    resmsg = "Error: Cannot Determine Payment Mode";
    //                }

    //                if (rescode == "1000")
    //                {
    //                    errorOccur = false;
    //                }
    //                else
    //                {
    //                    errorOccur = true;
    //                }
    //            }
    //        }
    //        else
    //        {
    //            //DisplayMessage("Cannot Complete this transaction. Kindly Contact The System Administrator");
    //            //return;
    //            xmlstring = xmlstring + "<CODE>1010</CODE>";
    //            xmlstring = xmlstring + "<ERROR>Cannot Complete this transaction. Kindly Contact The System Administrator</ERROR>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }

    //        //Update transaction with a value depending on the errorOccur flag
    //        if (errorOccur == false)
    //        {
    //            if (dr_frm["authorize_credit"].ToString() == "1")
    //            {
    //                sti.UpdateStandingInstructionStatus(Convert.ToInt32(dt_res.Rows[0]["id"]), 3, 0); //Pending for authorization
    //                //DisplayMessageAndNavigate("Standing Instruction Submitted for Approval by OPS head", "Home.aspx");
    //                xmlstring = xmlstring + "<CODE>1000</CODE>";
    //                xmlstring = xmlstring + "<MESSAGE>SUCCESS. Transaction Submitted for Approval by Branch OPS head</MESSAGE>";
    //                xmlstring = xmlstring + "<TRANSID>" + dt_res.Rows[0]["id"].ToString() + "</TRANSID>";
    //                xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";
    //            }
    //            else
    //            {
    //                //Session["customer"] = lst_customers.SelectedItem.Text;
    //                //Session["form"] = lst_forms.SelectedItem.Text;
    //                //Session["transid"] = dt_res.Rows[0]["id"];

    //                sti.UpdateStandingInstructionStatus(Convert.ToInt32(dt_res.Rows[0]["id"]), 0, Convert.ToInt32(basisseq)); //Successful
    //                //DisplayMessageAndNavigate("Standing Instruction Initiated Successfully", "Home.aspx");
    //                xmlstring = xmlstring + "<CODE>1000</CODE>";
    //                xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
    //                xmlstring = xmlstring + "<TRANSID>" + dt_res.Rows[0]["id"].ToString() + "</TRANSID>";
    //                xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";
    //            }
    //        }
    //        else
    //        {
    //            sti.UpdateStandingInstructionStatus(Convert.ToInt32(dt_res.Rows[0]["id"]), 2, 0); //Error
    //            //DisplayMessage("Cannot Create Standing Instruction in BASIS: " + resmsg.Replace("\n", ""));
    //            //return;
    //            xmlstring = xmlstring + "<CODE>1010</CODE>";
    //            xmlstring = xmlstring + "<ERROR>Cannot Create Standing Instruction in BASIS: " + resmsg.Replace("\n", "") + "</ERROR>";
    //            xmlstring = xmlstring + "</Response>";
    //            return xmlstring;
    //        }

    //        dt_pin = null;
    //        pp = null;

    //        //DisplayMessageAndNavigate("Standing Instruction Posted Successfully", "Home.aspx");
    //    }

    //    else if (trans_type == "3")    //1=Payment 2=Standing Instruction 3 Pay Via GTPay
    //    {
    //        if (dr_frm["use_remarks_separator"].ToString() == "1")
    //            basis_narr = reference + dr_frm["remarks_separator_char"].ToString() + basis_narr + dr_frm["remarks_separator_char"].ToString() + postingbranchcode + dr_frm["remarks_separator_char"].ToString() + "TRANSFER";
    //        else
    //            basis_narr = reference + basis_narr + postingbranchcode + "TRANSFER";


    //        //save data in transaction table
    //        trans = new Transaction();
    //        transdet = new TransactionDetail();

    //        dt_res = trans.InsertTransaction(DateTime.Now, userid, basis_narr, reference, customer_id, CollFormID, total_trans_amt, postingbranchcode, "1", Convert.ToInt32(paymentmode), doc_num, customer_acct, coll_acct, posref, String.Empty, 1, details_str, postflag); //Initialize -- Code will be "1"

    //        errorOccur = false;

    //        if (dt_res.Rows.Count > 0)
    //        {


    //            string GTPayTransid = dt_res.Rows[0]["transid"].ToString();




    //            xmlstring = xmlstring + "<CODE>1000</CODE>";
    //            xmlstring = xmlstring + "<MESSAGE>SUCCESS</MESSAGE>";
    //            xmlstring = xmlstring + "<TRANSID>" + GTPayTransid + "</TRANSID>";
    //            xmlstring = xmlstring + "<REFERENCE>" + reference + "</REFERENCE>";
    //            return xmlstring;
    //            // xmlstring = xmlstring + "<CODE>1000</CODE>";
    //            //xmlstring = xmlstring + "<TRANSID>" + GTPayTransid + "</TRANSID>";
    //            //xmlstring = xmlstring + "</Response>";

    //            //return the transaction id to be used for the transaction



    //        }

    //    }



    //    else
    //    {
    //        //DisplayMessage("Cannot Determine Transaction Type");
    //        //return;

    //        xmlstring = xmlstring + "<CODE>1010</CODE>";
    //        xmlstring = xmlstring + "<ERROR>Cannot Determine Transaction Type</ERROR>";
    //        xmlstring = xmlstring + "</Response>";
    //        return xmlstring;
    //    }
    //    //}

    //    //}

    //    xmlstring = xmlstring + "</Response>";
    //    return xmlstring;
    //}


    private String PostValidate(int formid, int customerid, String coll_acct, String userid, String postingbranchcode, DataSet dt_dset)
    {
        int rcount = 0;
        DataSet val_set;
        DataTable ID_val, Charge_val;
        LOVDetails lovd;
        DataTable dt_lov;

        DataTable dt = dt_dset.Tables[0];
        DataTable dt_charges = dt_dset.Tables[1];
        //dt_charges.TableName = "Charges";

        //get data retrieval fields
        ID_val = new DataTable("CustData");
        Charge_val = new DataTable("Charges");

        ID_val.Columns.Add("FieldName", typeof(string));
        ID_val.Columns.Add("Value", typeof(string));
        ID_val.Columns.Add("Direction", typeof(string));

        Charge_val.Columns.Add("charge_desc", typeof(string));
        Charge_val.Columns.Add("charge_amt", typeof(string));
        Charge_val.Columns.Add("account_number", typeof(string));

        DataRow rowAdd = null;

        foreach (DataRow rr in dt.Rows)
        {
            //if (rr.RowType == DataControlRowType.DataRow)
            //{
            //if (dt.Rows[rcount]["field_type"].ToString() == "2") //TEXT
            //{
            //    rowAdd = ID_val.NewRow();
            //    rowAdd["FieldName"] = rr["field_name"].ToString();
            //    rowAdd["Value"] = rr["actual_value"].ToString();
            //    rowAdd["Direction"] = "INOUT";

            //    ID_val.Rows.Add(rowAdd);
            //}
            //else if (dt.Rows[rcount]["field_type"].ToString() == "3") //DATE
            //{
            //    rowAdd = ID_val.NewRow();
            //    rowAdd["FieldName"] = rr["field_name"].ToString();
            //    rowAdd["Value"] = rr["actual_value"].ToString(rr["field_date_format"].ToString());
            //    rowAdd["Direction"] = "INOUT";

            //    ID_val.Rows.Add(rowAdd);
            //}
            //else if (dt.Rows[rcount]["field_type"].ToString() == "1") //LOV
            //{
            //    //get the list for the LOV from the LOV table with selected customer_id and LOV_id
            //    lovd = new LOVDetails();
            //    dt_lov = new DataTable();
            //    dt_lov.Merge(lovd.GetlovDetailByLOVID(Convert.ToInt32(dt.Rows[rcount]["field_lov"].ToString())), true);

            //    foreach (DataRow drr in dt_lov.Rows)
            //    {
            //        if (drr["lov_value"].ToString() == lst_value.SelectedValue)
            //        {
            //            //if (dt.Rows[rcount]["data_retrieve"].ToString() == "1" && dt.Rows[rcount]["datasource"].ToString() == "0")
            //            //{
            //            rowAdd = ID_val.NewRow();
            //            rowAdd["FieldName"] = dt.Rows[rcount]["field_name"].ToString();
            //            rowAdd["Value"] = lst_value.SelectedValue;
            //            rowAdd["Direction"] = "INOUT";

            //            //if (dt.Rows[rcount]["data_retrieve"].ToString() == "1" && dt.Rows[rcount]["datasource"].ToString() == "0")
            //            //{
            //            //    rowAdd["Value"] = lst_value.SelectedValue;
            //            //    rowAdd["Direction"] = "OUT";
            //            //}
            //            //else if (dt.Rows[rcount]["data_retrieve"].ToString() == "0" && dt.Rows[rcount]["datasource"].ToString() == "1")
            //            //{
            //            //    rowAdd["Direction"] = "IN";
            //            //}
            //            //else if(dt.Rows[rcount]["data_retrieve"].ToString() == "0" && dt.Rows[rcount]["datasource"].ToString() == "0")
            //            //{
            //            //    rowAdd["Value"] = lst_value.SelectedValue;
            //            //    rowAdd["Direction"] = "INOUT";
            //            //}
            //            ID_val.Rows.Add(rowAdd);
            //            //}
            //            //break;
            //        }
            //    }

            //    lovd = null;
            //    dt_lov = null;
            //}

            //rcount++;

            rowAdd = ID_val.NewRow();
            rowAdd["FieldName"] = rr["field_name"].ToString();
            rowAdd["Value"] = rr["actual_value"].ToString();
            rowAdd["Direction"] = "INOUT";

            ID_val.Rows.Add(rowAdd);
            //}
        }

        String chargedesc = "", chargeamt = "", acctno = "";
        foreach (DataRow dr in dt_charges.Rows)
        {
            rowAdd = Charge_val.NewRow();
            chargedesc = dr["charge_desc"].ToString();
            chargeamt = dr["charge_amt"].ToString();
            acctno = dr["account_number"].ToString();

            rowAdd["charge_desc"] = chargedesc;
            rowAdd["charge_amt"] = chargeamt;
            rowAdd["account_number"] = acctno;
            Charge_val.Rows.Add(rowAdd);
        }

        //Create the dataset to be sent to the webservive
        val_set = new DataSet("ValueSet");
        val_set.Tables.Add(ID_val);
        val_set.Tables.Add(Charge_val);

        //call webservice to retrieve data
        String dataservice_url = ConfigurationManager.AppSettings["DataWebservice"].ToString();
        DataSet val_resp;
        CustomerDataService cds = new CustomerDataService();
        cds.Url = dataservice_url;

        val_resp = cds.PostValidationEvent(formid, customerid, coll_acct, "", "", userid, postingbranchcode, val_set);

        String resp = "";
        ID_val = val_resp.Tables["CustData"];

        foreach (DataRow drr in ID_val.Rows)
        {
            if (drr["FieldName"].ToString() == "GTBRESPONSECODE")
            {
                resp = drr["Value"].ToString();
                break;
            }
        }

        Charge_val = null;
        ID_val = null;
        val_set = null;

        return resp;
    }

    private String getFieldID(DataTable dt_c, string p)
    {
        String ID = "";
        foreach (DataRow drf in dt_c.Rows)
        {
            if (drf["charge_desc"].ToString() == p)
            {
                ID = drf["id"].ToString();
                break;
            }
        }

        return ID;
    }


    private int GetExistingReference(int formid, string str_reference)
    {
        Transaction t = new Transaction();
        DataTable dt_res = t.GetTransactionByFormIDAndReference(formid, str_reference);
        t = null;
        return dt_res.Rows.Count;
    }

    private void GetResponseMsg(String resp)
    {
        XmlDocument document = null;
        XPathNavigator navigator = null;
        XPathNodeIterator snodes = null;
        XPathNavigator node1 = null;
        String retcode = null;

        document = new XmlDocument();
        document.LoadXml(resp);
        navigator = document.CreateNavigator();

        snodes = navigator.Select("/Response/CODE");
        snodes.MoveNext();
        rescode = snodes.Current.Value;

        if (rescode != "1000")
        {
            snodes = navigator.Select("/Response/ERROR");
            snodes.MoveNext();
            resmsg = snodes.Current.Value;
        }
        else
        {
            snodes = navigator.Select("/Response/MESSAGE");
            snodes.MoveNext();
            resmsg = snodes.Current.Value.Replace("'", "");

            snodes = navigator.Select("/Response/SEQUENCE");
            snodes.MoveNext();
            basisseq = snodes.Current.Value.Replace("'", "");
        }
    }

    private String ValidateField(String fieldval, String fieldtype, String fielddatatype, int fieldlen, String fieldmandatory)
    {
        Int16 resi;
        Decimal resd;
        String fieldok = "SUCCESS";
        DateTime resdate;

        if (fieldtype == "1") //LOV
        {
            if (fieldval == "GTBNONE")
            {
                fieldok = "No Selection From Dropdown List";
                return fieldok;
            }
        }

        if (fieldtype == "2" || fieldtype == "1") //TEXT, LOV
        {
            if (fieldval.Length > fieldlen)
            {
                fieldok = "Field length Greater Than Expected";
            }
            else if (fieldval.Trim() == "" && fieldmandatory == "1")
            {
                fieldok = "Field is Mandatory";
            }
            else
            {
                if (fielddatatype == "1") //NUMERIC
                {
                    for (int s = 0; s < fieldval.Length; s++)
                    {
                        if (Int16.TryParse(fieldval.Substring(s, 1), out resi) == false)
                        {
                            fieldok = "Data Type or Format Not Consistent";
                            break;
                        }
                    }
                }
                else if (fielddatatype == "5") //DECIMAL
                {
                    if (Decimal.TryParse(fieldval, out resd) == false)
                    {
                        fieldok = "Data Type or Format Not Consistent";
                    }
                }
            }
        }
        else if (fieldtype == "3") //DATE
        {
            if (fielddatatype == "4") //DATE
            {
                //No validation should be done since date format is pre-configured
                //if (DateTime.TryParse(fieldval, out resdate) == false)
                //    fieldok = "Data Type or Format not Consistend";
            }
        }

        else if (fieldtype == "4") //MULTISELECT
        {
            String[] multival = fieldval.Split('|');
            if (multival.GetLength(0) < 1 && fieldmandatory == "1")
            {
                fieldok = "Field is Mandatory";
            }
            else
            {
                foreach (String strarr in multival)
                {
                    //get the main value part
                    String[] strings = strarr.Split(':');
                    String str = strings[0];

                    if (str.Length > fieldlen)
                    {
                        fieldok = "Field length Greater Than Expected";
                    }
                    else
                    {
                        if (fielddatatype == "1") //NUMERIC
                        {
                            for (int s = 0; s < str.Length; s++)
                            {
                                if (Int16.TryParse(str.Substring(s, 1), out resi) == false)
                                {
                                    fieldok = "Data Type or Format Not Consistent";
                                    break;
                                }
                            }
                        }
                        else if (fielddatatype == "5") //DECIMAL
                        {
                            if (Decimal.TryParse(str, out resd) == false)
                            {
                                fieldok = "Data Type or Format Not Consistent";
                            }
                        }
                    }

                }
            }
        }

        return fieldok;
    }

    public DataSet GetTransactionHistoryByUser(int formID, String userID)
    {
        TransactionDetail fff = null;
        Charge chg = null;
        DataTable dt_fld1 = null;
        DataTable dt_chg = null;

        Utility ut = new Utility();
        String qry_str = null;
        DataTable dt = new DataTable();
        DataTable dt_fields = new DataTable();
        Transaction t = new Transaction();
        String datestr1 = null;
        String datestr2 = null;

        XmlDocument document = null;
        XPathNavigator navigator = null;
        XPathNavigator snodeInner = null;
        XPathNodeIterator snodes1 = null;
        XPathNodeIterator nodes = null;
        String transid = "0";

        DataSet result_dset;

        try
        {
            DateTime dtt = new DateTime();
            qry_str = "";

            qry_str = qry_str + " and a.user_id = '" + userID + "' and a.form_id=" + formID.ToString() + " and a.trans_status = 0";

            dt = t.GetTransactionsByQuery2(qry_str);

            //Append the detail fields from formfield table
            FormField ff_det = new FormField();
            dt_fields.Merge(ff_det.GetVisibleformfieldsByFormID(formID), true);
            foreach (DataRow dr_fields in dt_fields.Rows)
            {
                dt.Columns.Add(new DataColumn(dr_fields["field_name"].ToString()));
            }

            //Also append details of charges
            chg = new Charge();
            dt_chg = new DataTable();
            dt_chg.Merge(chg.GetChargesByFormID(formID), true);
            foreach (DataRow dr_chg in dt_chg.Rows)
            {
                dt.Columns.Add(new DataColumn(dr_chg["charge_desc"].ToString()));
            }

            //Then populate the rows with the values
            fff = new TransactionDetail();
            String detail_xml = null;
            String fname = null, fvalue = null, ftype = null;

            foreach (DataRow dr in dt.Rows)
            {
                //dt_fld1 = new DataTable();
                //dt_fld1.Merge(fff.GetTransactionDetailsByTransID(Convert.ToDecimal(dr["transid"])), true);
                //transid = dr["transid"].ToString();
                if (dr["Details"].ToString() != "")
                {
                    document = new XmlDocument();
                    document.LoadXml(dr["Details"].ToString().Replace("&", "&amp;"));
                    navigator = document.CreateNavigator();

                    nodes = navigator.Select("/DET/FIELD");
                    while (nodes.MoveNext())
                    {
                        snodeInner = nodes.Current;
                        snodes1 = snodeInner.SelectChildren(XPathNodeType.Element);
                        snodes1.MoveNext();  //read the FIELD ID
                        fname = snodes1.Current.Value;
                        snodes1.MoveNext();  //read the FIELD VALUE
                        fvalue = snodes1.Current.Value;
                        snodes1.MoveNext();  //read the FIELD TYPE  F=Field, C=Charge
                        ftype = snodes1.Current.Value;

                        foreach (DataRow dr_fields1 in dt_fields.Rows)
                        {
                            if (dr_fields1["field_id"].ToString() == fname && ftype == "F")
                            {
                                dr[dr_fields1["field_name"].ToString()] = fvalue;
                            }
                        }

                        foreach (DataRow dr_chg1 in dt_chg.Rows)
                        {
                            if (fname == dr_chg1["id"].ToString() && ftype == "C")
                            {
                                dr[dr_chg1["charge_desc"].ToString()] = fvalue;
                            }
                        }

                        snodeInner = null;
                        snodes1 = null;
                    }
                }

                //foreach (DataRow dr_det in dt_fld1.Rows)
                //{
                //    foreach (DataRow dr_fields1 in dt_fields.Rows)
                //    {
                //        if (dr_fields1["field_name"].ToString() == dr_det["field_name"].ToString())
                //        {
                //            dr[dr_det["field_name"].ToString()] = dr_det["trans_value"].ToString();
                //        }
                //    }

                //    foreach (DataRow dr_chg1 in dt_chg.Rows)
                //    {
                //        if (dr_chg1["charge_desc"].ToString() == dr_det["field_name"].ToString())
                //        {
                //            dr[dr_det["field_name"].ToString()] = dr_det["trans_value"].ToString();
                //        }
                //    }
                //}
            }

            //Delete the Details column
            dt.Columns.Remove("Details");

            result_dset = new DataSet();
            result_dset.Tables.Add(dt);
            //grd_param1.DataSourceID = null;
            //grd_param1.DataSource = dt;
            //grd_param1.DataBind();

            //if (dt.Rows.Count <= 0)
            //    DisplayMessage("No Records For The Date Range Selected");
        }
        catch (Exception ex)
        {
            //DisplayMessage("Error: " + ex.Message.Replace("'", "") + " -->" + transid);
            result_dset = new DataSet();
        }

        return result_dset;
    }

    private String getChargeName(DataTable dt_c, string p)
    {
        String ID = "";
        foreach (DataRow drf in dt_c.Rows)
        {
            if (drf["id"].ToString() == p)
            {
                ID = drf["chage_desc"].ToString();
                break;
            }
        }

        return ID;
    }

    private String getFieldName(DataTable dt_c, string p)
    {
        String ID = "";
        foreach (DataRow drf in dt_c.Rows)
        {
            if (drf["field_id"].ToString() == p)
            {
                ID = drf["field_name"].ToString();
                break;
            }
        }

        return ID;
    }

    public String PostCollectionData_Others(int ussdcode, int merchantcode, int atmcode, String channel, String userid, String postingbranchcode, Decimal tra_amt, Decimal total_tra_amt, String narration, String customer_acct, String customercode, String customername)
    {
        Utility ut = new Utility();
        PIN pp = null;
        DataTable dt_pin = null;
        String resp_str;
        String reference = "";
        Decimal total_trans_amt = 0M;
        int res = 0;
        String customReference = "0";
        Decimal charge_amt = 0M;
        int paymode = 0;
        String postflag = String.Empty;
        string chargeid = "", chargedesc = "", chargeamt = "", acctno = "";
        DataTable dt_split = new DataTable();
        ChargeSplit dtsplit = new ChargeSplit();
        DataRow rowAdd_split = null;

        try
        {
            //Get reference/receipt
            CollForm ff = new CollForm();
            DataTable dd = new DataTable();

            //Get Form  fields
            FormField fff = new FormField();
            DataTable dt_fields = new DataTable();

            //Get Form charges
            Charge chg = new Charge();
            DataTable dt_chg = new DataTable();
            //DataTable dt_chg_split = new DataTable();
            DataTable Charge_split = new DataTable();

            Charge_split.Columns.Add("charge_Id", typeof(Int32));
            Charge_split.Columns.Add("charge_desc", typeof(string));
            Charge_split.Columns.Add("charge_amt", typeof(string));
            Charge_split.Columns.Add("account_number", typeof(string));

            if (channel == "USSD")
            {
                dd.Merge(ff.GetFormByUSSDCode(ussdcode, merchantcode), true);
                dt_fields.Merge(fff.GetUSSDCollectionFormFields(ussdcode, merchantcode).Tables[0], true);
                dt_chg.Merge(chg.GetUSSDChargesByFormID2(ussdcode, merchantcode), true);

                paymode = 8;    //paymode for USSD = 8
                postflag = "USSD";
            }
            else if (channel == "ATM")
            {
                dd.Merge(ff.GetFormByATMCode(atmcode), true);
                dt_fields.Merge(fff.GetATMCollectionFormFields(atmcode).Tables[0], true);
                dt_chg.Merge(chg.GetATMChargesByFormID2(atmcode), true);
                paymode = 9;    //paymode for ATM = 9
                postflag = "ATM";
            }
            else
            {
                xmlstring = "<Response>";
                xmlstring = xmlstring + "<CODE>1001</CODE>";
                xmlstring = xmlstring + "<Error>Invalid Channel. Channel is not recognize by the processing engine</Error>";
                xmlstring = xmlstring + "</Response>";
                return xmlstring;
            }

            int customerid = Convert.ToInt32(dd.Rows[0]["customer_id"]);
            int formid = Convert.ToInt32(dd.Rows[0]["form_id"]);
            String coll_acct = dd.Rows[0]["account_number"].ToString();

            //Retrieve field names from parameters
            foreach (DataRow rr in dt_fields.Rows)
            {

                if (rr["data_retrieve"].ToString() == "1" && rr["amt_ref"].ToString() == "0")
                {
                    rr["actual_value"] = customercode;
                }

                if (rr["data_retrieve"].ToString() == "0" && rr["amt_ref"].ToString() == "0")
                {
                    rr["actual_value"] = customername;
                }

                if (rr["amt_ref"].ToString() == "1")
                {
                    rr["actual_value"] = tra_amt;
                }
            }

            //foreach (DataRow dr_field in dt_fields.Rows)
            //{
            //    if (dr_field["field_name"].ToString().ToUpper() == "Member Surname".ToUpper())
            //    {
            //        dr_field["actual_value"] = mem_name;
            //    }
            //    else if (dr_field["field_name"].ToString().ToUpper() == "Member Other Names".ToUpper())
            //    {
            //        dr_field["actual_value"] = string.Empty;
            //    }

            //    else if (dr_field["field_name"].ToString().ToUpper() == "AMOUNT")
            //    {
            //        dr_field["actual_value"] = tra_amt.ToString();
            //    }

            //}

            foreach (DataRow drr in dt_chg.Rows)
            {
                chargeid = drr["id"].ToString();
                if (drr["split_charge"].ToString() == "1")
                {

                    dt_split = dtsplit.GetChargeSplitByChargeId(Convert.ToInt32(chargeid));
                    foreach (DataRow dr_split in dt_split.Rows)
                    {
                        rowAdd_split = Charge_split.NewRow();
                        //chargeid = (dr_split["charge_id"].ToString());
                        chargedesc = dr_split["charge_desc"].ToString();
                        chargeamt = dr_split["charge_amt"].ToString();
                        acctno = dr_split["account_number"].ToString();

                        rowAdd_split["charge_desc"] = chargedesc;
                        rowAdd_split["charge_amt"] = chargeamt;
                        rowAdd_split["account_number"] = acctno;
                        rowAdd_split["charge_id"] = chargeid;
                        Charge_split.Rows.Add(rowAdd_split);
                    }

                    dt_split = null;
                }
            }

            Charge_split.TableName = "Charges_split";

            DataSet dset = new DataSet();
            dset.Tables.Add(dt_fields);
            dset.Tables.Add(dt_chg);
            dset.Tables.Add(Charge_split);

            xmlstring = PostCollectionData2(customerid, formid, coll_acct, userid, "999", total_tra_amt, customer_acct, "0/0/0/0/0", paymode.ToString(), "1", 0, "0", "", postflag, "", "", 0, dset);


        }
        catch (Exception ex)
        {
            xmlstring = "<Response>";
            xmlstring = xmlstring + "<CODE>1010</CODE>";
            xmlstring = xmlstring + "<Error>" + ex.Message.Replace("'", "") + "</Error>";
            xmlstring = xmlstring + "</Response>";
            xmlstring = xmlstring + "</Response>";
        }


        return xmlstring;
    }

    public DataTable GetCollectionFormByUSSDCode(int ussdcode, int merchantcode)
    {
        DataTable ds_result = new DataTable();
        CollForm cf = new CollForm();

        ds_result.Merge(cf.GetFormByUSSDCode(ussdcode, merchantcode), true);
        ds_result.TableName = "FORMDETAIL";

        cf = null;
        return ds_result;
    }

    public DataTable GetCollectionFormByATMCode(int atmcode)
    {
        DataTable ds_result = new DataTable();
        CollForm cf = new CollForm();

        ds_result.Merge(cf.GetFormByATMCode(atmcode), true);
        ds_result.TableName = "FORMDETAIL";

        cf = null;
        return ds_result;
    }

    public DataSet GetUSSDCollectionFormFields(int ussdcode, int merchantcode)
    {
        DataSet ds_result = new DataSet();
        FormField cff = new FormField();

        ds_result = cff.GetUSSDCollectionFormFields(ussdcode, merchantcode);

        return ds_result;
    }

    public DataSet GetATMCollectionFormFields(int atmcode)
    {
        DataSet ds_result = new DataSet();
        FormField cff = new FormField();

        ds_result = cff.GetATMCollectionFormFields(atmcode);

        return ds_result;
    }

    public DataSet GetCollectionFormFieldDetails_others(string acctid, string channel, int merchantcode, int ussdcode, int atmcode, String customercode)
    {
        int customerid = 0, formid = 0;
        String collection_acct = String.Empty;
        String debitAcc = String.Empty;

        DataTable dt1 = null;
        DataSet val_resp = new DataSet();
        DataRow rowAdd = null;
        DataTable ID_message = null;
        DataTable dt = new DataTable();
        DataTable nn = new DataTable();
        DataRow dr = default(DataRow);
        DataTable dt_charges = new DataTable();
        DataTable dt_f = new DataTable();
        string chargeid = "", chargedesc = "", chargeamt = "", acctno = "";
        DataTable dt_split;
        ChargeSplit dtsplit = new ChargeSplit();
        DataRow rowAdd_split;
        DataTable Charge_split = new DataTable();

        try
        {
            ID_message = new DataTable("RESPONSE");
            ID_message.Columns.Add("GTBREF", typeof(string));
            ID_message.Columns.Add("COLL_ACCT", typeof(string));
            ID_message.Columns.Add("GTBRESPONSECODE", typeof(string));
            ID_message.Columns.Add("CUSTOMLOVCONTENT", typeof(string));

            Charge_split.Columns.Add("charge_Id", typeof(Int32));
            Charge_split.Columns.Add("charge_desc", typeof(string));
            Charge_split.Columns.Add("charge_amt", typeof(string));
            Charge_split.Columns.Add("account_number", typeof(string));

            //Check channel and USSD or ATM code to determine formId and customerId
            if (channel == "USSD")
            {
                dt1 = GetUSSDCollectionFormFields(ussdcode, merchantcode).Tables[0];
                dt_charges.Merge(GetUSSDCollectionCharges(ussdcode, merchantcode).Tables[0], true);
                dt_f.Merge(GetCollectionFormByUSSDCode(ussdcode, merchantcode), true);

                foreach (DataRow drr in dt_charges.Rows)
                {
                    chargeid = drr["id"].ToString();
                    if (drr["split_charge"].ToString() == "1")
                    {

                        dt_split = dtsplit.GetChargeSplitByChargeId(Convert.ToInt32(chargeid));
                        foreach (DataRow dr_split in dt_split.Rows)
                        {
                            rowAdd_split = Charge_split.NewRow();
                            //chargeid = (dr_split["charge_id"].ToString());
                            chargedesc = dr_split["charge_desc"].ToString();
                            chargeamt = dr_split["charge_amt"].ToString();
                            acctno = dr_split["account_number"].ToString();

                            rowAdd_split["charge_desc"] = chargedesc;
                            rowAdd_split["charge_amt"] = chargeamt;
                            rowAdd_split["account_number"] = acctno;
                            rowAdd_split["charge_id"] = chargeid;
                            Charge_split.Rows.Add(rowAdd_split);
                        }

                        dt_split = null;
                    }
                }

            }
            else if (channel == "ATM")
            {
                dt1 = GetATMCollectionFormFields(atmcode).Tables[0];
                dt_charges.Merge(GetATMCollectionCharges(atmcode).Tables[0], true);
                dt_f.Merge(GetCollectionFormByATMCode(atmcode), true);

                foreach (DataRow drr in dt_charges.Rows)
                {
                    chargeid = drr["id"].ToString();
                    if (drr["split_charge"].ToString() == "1")
                    {

                        dt_split = dtsplit.GetChargeSplitByChargeId(Convert.ToInt32(chargeid));
                        foreach (DataRow dr_split in dt_split.Rows)
                        {
                            rowAdd_split = Charge_split.NewRow();
                            //chargeid = (dr_split["charge_id"].ToString());
                            chargedesc = dr_split["charge_desc"].ToString();
                            chargeamt = dr_split["charge_amt"].ToString();
                            acctno = dr_split["account_number"].ToString();

                            rowAdd_split["charge_desc"] = chargedesc;
                            rowAdd_split["charge_amt"] = chargeamt;
                            rowAdd_split["account_number"] = acctno;
                            rowAdd_split["charge_id"] = chargeid;
                            Charge_split.Rows.Add(rowAdd_split);
                        }

                        dt_split = null;
                    }
                }
            }

            if (dt_f.Rows.Count > 0)
            {
                customerid = Convert.ToInt32(dt_f.Rows[0]["customer_id"]);
                formid = Convert.ToInt32(dt_f.Rows[0]["form_id"]);

                nn.Merge(dt1, true);

                dt.Merge(nn, true);

                if (dt_f.Rows.Count > 0)
                {
                    collection_acct = dt_f.Rows[0]["account_number"].ToString();
                }

                ////Iterate through the grid to create fields for posting
                //Validate Out Parameters
                foreach (DataRow rr in dt.Rows)
                {

                    if (rr["data_retrieve"].ToString() == "1" && rr["amt_ref"].ToString() == "0")
                    {
                        rr["actual_value"] = customercode;
                    }
                    else if (rr["amt_ref"].ToString() == "1")
                    {
                        rr["actual_value"] = "0";
                    }
                }
                //Session["charges_split"] = Charge_split;

                val_resp.Tables.Add(dt);
                val_resp.Tables.Add(dt_charges);
                val_resp.Tables.Add(Charge_split);
                


                nn = null;
                val_resp = GetCollectionFormFieldDetails(customerid, formid, val_resp, string.Empty, string.Empty);
            }
            else
            {
                val_resp = new DataSet();
                rowAdd = ID_message.NewRow();
                rowAdd["GTBRESPONSECODE"] = "Error: Could not retrieve merchant profile";
                ID_message.Rows.Add(rowAdd);

                val_resp.Tables.Add(ID_message);
            }
        }
        catch (Exception ex)
        {
            val_resp = new DataSet();
            rowAdd = ID_message.NewRow();
            rowAdd["GTBRESPONSECODE"] = ex.Message.Replace("'", "");
            ID_message.Rows.Add(rowAdd);

            val_resp.Tables.Add(ID_message);
        }

        return val_resp;
    }

    public DataSet GetUSSDCollectionCharges(int ussdcode, int merchantcode)
    {
        DataSet ds_result = new DataSet();
        Charge charge = new Charge();

        ds_result.Tables.Add(charge.GetUSSDChargesByFormID2(ussdcode, merchantcode));

        return ds_result;
    }

    public DataSet GetATMCollectionCharges(int atmcode)
    {
        DataSet ds_result = new DataSet();
        Charge charge = new Charge();

        ds_result.Tables.Add(charge.GetATMChargesByFormID2(atmcode));

        return ds_result;
    }

    public DataSet GetsmehubMerchantdetails(string gtpayid)
    {
        DataSet ds_result = new DataSet();
        CollForm cf = new CollForm();


        SqlConnection conn;
        SqlCommand comm;
        DataSet ds = new DataSet();
        SqlDataAdapter adpt;

        try
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["GTPAYConnstr"].ToString());

            //open connetion
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            comm = new SqlCommand("get_SmeMerchant_Details", conn);
            comm.Parameters.AddWithValue("@mertid", gtpayid);

            comm.CommandType = CommandType.StoredProcedure;
            adpt = new SqlDataAdapter(comm);

            adpt.Fill(ds);

            if (ds.Tables.Count > 0)
            {
                return ds;
            }
            else
            {

            }
            conn.Close();
        }
        catch (Exception ex)
        {
            ErrHandler.WriteError(ex.Message + ex.Source + ex.StackTrace);
            ds = null;
        }
        return ds;
    }



}
