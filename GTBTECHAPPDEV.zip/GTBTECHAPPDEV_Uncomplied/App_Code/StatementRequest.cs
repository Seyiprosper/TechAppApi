﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for StatementRequest
/// </summary>
public class StatementRequest
{
	public StatementRequest()
	{

	}

    public string AccountNumber { get; set; }
    public string DateFrom { get; set; }
    public string DateTo { get; set; }
    public int NoOfCopies { get; set; }
}